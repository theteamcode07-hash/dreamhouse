import React, { useState, useEffect } from 'react';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { optimizeImage } from '../lib/fileUploader';
import { 
  CreditCard, Check, X, Upload, Trash2, Shield, Info, HelpCircle, AlertCircle, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ShopkeeperPaymentSettingsProps {
  userEmail: string;
}

export default function ShopkeeperPaymentSettings({ userEmail }: ShopkeeperPaymentSettingsProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form states
  const [esewaEnabled, setEsewaEnabled] = useState(true);
  const [esewaQr, setEsewaQr] = useState<string | null>(null);
  
  const [khaltiEnabled, setKhaltiEnabled] = useState(true);
  const [khaltiQr, setKhaltiQr] = useState<string | null>(null);
  
  const [bankEnabled, setBankEnabled] = useState(true);
  const [bankQr, setBankQr] = useState<string | null>(null);
  const [bankName, setBankName] = useState('');
  const [accountName, setAccountName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [bankBranch, setBankBranch] = useState('');

  // Presets for easy testing
  const sampleQrs = {
    esewa: 'https://images.unsplash.com/photo-1543269865-cbf427effbad?auto=format&fit=crop&q=80&w=250&h=250',
    khalti: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80&w=250&h=250',
    bank: 'https://images.unsplash.com/photo-1563013544-824ae1d704d3?auto=format&fit=crop&q=80&w=250&h=250'
  };

  // Drag over states
  const [dragActiveEsewa, setDragActiveEsewa] = useState(false);
  const [dragActiveKhalti, setDragActiveKhalti] = useState(false);
  const [dragActiveBank, setDragActiveBank] = useState(false);

  useEffect(() => {
    if (!userEmail) return;

    setLoading(true);
    const docRef = doc(db, 'payment_settings', userEmail.toLowerCase());
    
    const unsub = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setEsewaEnabled(data.esewaEnabled ?? true);
        setEsewaQr(data.esewaQrCode ?? null);
        
        setKhaltiEnabled(data.khaltiEnabled ?? true);
        setKhaltiQr(data.khaltiQrCode ?? null);
        
        setBankEnabled(data.bankEnabled ?? true);
        setBankQr(data.bankQrCode ?? null);
        setBankName(data.bankName ?? '');
        setAccountName(data.accountName ?? '');
        setAccountNumber(data.accountNumber ?? '');
        setBankBranch(data.branch ?? '');
      } else {
        // Doc doesn't exist, keep default state
        setEsewaEnabled(true);
        setEsewaQr(null);
        setKhaltiEnabled(true);
        setKhaltiQr(null);
        setBankEnabled(true);
        setBankQr(null);
        setBankName('');
        setAccountName('');
        setAccountNumber('');
        setBankBranch('');
      }
      setLoading(false);
    }, (error) => {
      console.error("Error subscribing to payment settings:", error);
      setErrorMsg("Failed to sync settings with database.");
      setLoading(false);
    });

    return () => unsub();
  }, [userEmail]);

  // Image reading helper
  const handleImageUpload = async (file: File, type: 'esewa' | 'khalti' | 'bank') => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG/JPG).');
      return;
    }

    try {
      const optimized = await optimizeImage(file, 800, 0.85);
      const base64 = optimized.dataUrl;
      if (type === 'esewa') setEsewaQr(base64);
      else if (type === 'khalti') setKhaltiQr(base64);
      else if (type === 'bank') setBankQr(base64);
      
      setSuccessMsg(`QR Code loaded for ${type === 'esewa' ? 'eSewa' : type === 'khalti' ? 'Khalti' : 'Bank'}. Remember to save!`);
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        if (type === 'esewa') setEsewaQr(base64);
        else if (type === 'khalti') setKhaltiQr(base64);
        else if (type === 'bank') setBankQr(base64);
        
        setSuccessMsg(`QR Code loaded for ${type === 'esewa' ? 'eSewa' : type === 'khalti' ? 'Khalti' : 'Bank'}. Remember to save!`);
        setTimeout(() => setSuccessMsg(null), 4000);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrag = (e: React.DragEvent, type: 'esewa' | 'khalti' | 'bank', active: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    if (type === 'esewa') setDragActiveEsewa(active);
    else if (type === 'khalti') setDragActiveKhalti(active);
    else if (type === 'bank') setDragActiveBank(active);
  };

  const handleDrop = (e: React.DragEvent, type: 'esewa' | 'khalti' | 'bank') => {
    e.preventDefault();
    e.stopPropagation();
    if (type === 'esewa') setDragActiveEsewa(false);
    else if (type === 'khalti') setDragActiveKhalti(false);
    else if (type === 'bank') setDragActiveBank(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageUpload(e.dataTransfer.files[0], type);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setSuccessMsg(null);
    setErrorMsg(null);

    // Validation
    if (bankEnabled) {
      if (!bankName.trim() || !accountName.trim() || !accountNumber.trim()) {
        setErrorMsg('Please fill in all bank credentials (Bank Name, Account Name, Account Number) since Bank Payment is enabled.');
        setSaving(false);
        return;
      }
    }

    try {
      const docRef = doc(db, 'payment_settings', userEmail.toLowerCase());
      await setDoc(docRef, {
        esewaEnabled,
        esewaQrCode: esewaQr,
        khaltiEnabled,
        khaltiQrCode: khaltiQr,
        bankEnabled,
        bankQrCode: bankQr,
        bankName: bankName.trim(),
        accountName: accountName.trim(),
        accountNumber: accountNumber.trim(),
        branch: bankBranch.trim(),
        updatedAt: new Date().toISOString(),
        shopkeeperEmail: userEmail.toLowerCase()
      }, { merge: true });

      setSuccessMsg('Payment Methods settings updated successfully!');
      setTimeout(() => setSuccessMsg(null), 5000);
    } catch (e: any) {
      console.error("Error updating payment settings:", e);
      setErrorMsg(`Failed to save settings: ${e.message || 'Unknown error'}`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[300px] gap-3">
        <div className="w-8 h-8 rounded-full border-4 border-slate-200 border-t-[#fd8b00] animate-spin" />
        <p className="text-xs font-semibold text-slate-500">Loading Payment Gateways...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Upper header block */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 text-white rounded-2xl p-6 shadow-sm border border-slate-800">
        <div>
          <h2 className="text-lg font-black tracking-tight font-sans">Payment Methods Management</h2>
          <p className="text-xs text-slate-400 mt-1">Configure real-time secure checkout endpoints, upload direct merchant QR codes, and input bank accounts.</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-5 py-2.5 rounded-xl bg-[#fd8b00] text-slate-950 font-extrabold text-xs tracking-wide hover:bg-amber-400 transition-colors cursor-pointer flex items-center gap-2 shrink-0 disabled:opacity-50"
        >
          {saving ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>Saving Changes...</span>
            </>
          ) : (
            <>
              <Check className="w-4 h-4 text-slate-950 stroke-[3]" />
              <span>Save Payment Settings</span>
            </>
          )}
        </button>
      </div>

      {/* Notifications */}
      <AnimatePresence mode="wait">
        {successMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }} 
            exit={{ opacity: 0 }} 
            className="p-4 bg-green-500/10 border border-green-500/30 text-green-700 dark:text-green-400 rounded-xl text-xs font-semibold flex items-center gap-2"
          >
            <Check className="w-4 h-4 shrink-0 stroke-[3]" />
            <span>{successMsg}</span>
          </motion.div>
        )}
        {errorMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }} 
            exit={{ opacity: 0 }} 
            className="p-4 bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 rounded-xl text-xs font-semibold flex items-center gap-2"
          >
            <AlertCircle className="w-4 h-4 shrink-0 stroke-[3]" />
            <span>{errorMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* eSewa Nepal Card */}
        <div className={`bg-white rounded-2xl border transition-all p-5 shadow-sm space-y-4 ${esewaEnabled ? 'border-emerald-200' : 'border-slate-200 opacity-70'}`}>
          <div className="flex justify-between items-center pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-black text-xs flex items-center justify-center shrink-0">eS</div>
              <div>
                <h3 className="text-sm font-black text-slate-900">eSewa Nepal</h3>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Wallet Integration</p>
              </div>
            </div>
            
            {/* Toggle */}
            <button
              onClick={() => setEsewaEnabled(!esewaEnabled)}
              className={`w-12 h-6 rounded-full p-1 transition-colors cursor-pointer ${esewaEnabled ? 'bg-emerald-600 flex justify-end' : 'bg-slate-300 flex justify-start'}`}
            >
              <motion.div layout className="w-4 h-4 rounded-full bg-white shadow-sm" />
            </button>
          </div>

          {esewaEnabled && (
            <div className="space-y-4">
              <div>
                <span className="block text-[10px] font-bold text-slate-400 uppercase mb-2">QR Code Graphic</span>
                
                {esewaQr ? (
                  <div className="relative group rounded-xl border border-slate-200 p-2 bg-slate-50 flex flex-col items-center justify-center">
                    <img 
                      src={esewaQr} 
                      alt="eSewa QR Code" 
                      className="w-40 h-40 object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <button 
                        onClick={() => setEsewaQr(null)}
                        className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition-colors cursor-pointer"
                        title="Remove QR Code"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => handleDrag(e, 'esewa', true)}
                    onDragLeave={(e) => handleDrag(e, 'esewa', false)}
                    onDrop={(e) => handleDrop(e, 'esewa')}
                    className={`border-2 border-dashed rounded-xl p-5 text-center flex flex-col items-center justify-center gap-2 transition-colors ${
                      dragActiveEsewa ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50/30'
                    }`}
                  >
                    <Upload className="w-6 h-6 text-slate-400" />
                    <div>
                      <p className="text-xs font-bold text-slate-700">Drag QR Image here</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">or select from file explorer</p>
                    </div>
                    <label className="px-3 py-1 bg-white border border-slate-200 hover:border-slate-300 text-slate-600 font-bold text-[10px] rounded-lg cursor-pointer transition-colors mt-1">
                      Select File
                      <input 
                        type="file" 
                        accept="image/*"
                        className="hidden" 
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) handleImageUpload(e.target.files[0], 'esewa');
                        }}
                      />
                    </label>
                  </div>
                )}
              </div>

              {/* Presets and help tips */}
              <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-3 text-[10px] text-emerald-800 space-y-1.5">
                <p className="font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  Testing Quick Presets:
                </p>
                <p className="text-slate-500 leading-normal">Don't have a merchant QR yet? Click below to instantly load a sample QR code for eSewa testing:</p>
                <button
                  type="button"
                  onClick={() => { setEsewaQr(sampleQrs.esewa); }}
                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[9px] cursor-pointer transition-colors"
                >
                  Load Sample eSewa QR
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Khalti Nepal Card */}
        <div className={`bg-white rounded-2xl border transition-all p-5 shadow-sm space-y-4 ${khaltiEnabled ? 'border-purple-200' : 'border-slate-200 opacity-70'}`}>
          <div className="flex justify-between items-center pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-700 text-white font-black text-xs flex items-center justify-center shrink-0">Kh</div>
              <div>
                <h3 className="text-sm font-black text-slate-900">Khalti Nepal</h3>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Wallet Integration</p>
              </div>
            </div>
            
            {/* Toggle */}
            <button
              onClick={() => setKhaltiEnabled(!khaltiEnabled)}
              className={`w-12 h-6 rounded-full p-1 transition-colors cursor-pointer ${khaltiEnabled ? 'bg-purple-700 flex justify-end' : 'bg-slate-300 flex justify-start'}`}
            >
              <motion.div layout className="w-4 h-4 rounded-full bg-white shadow-sm" />
            </button>
          </div>

          {khaltiEnabled && (
            <div className="space-y-4">
              <div>
                <span className="block text-[10px] font-bold text-slate-400 uppercase mb-2">QR Code Graphic</span>
                
                {khaltiQr ? (
                  <div className="relative group rounded-xl border border-slate-200 p-2 bg-slate-50 flex flex-col items-center justify-center">
                    <img 
                      src={khaltiQr} 
                      alt="Khalti QR Code" 
                      className="w-40 h-40 object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <button 
                        onClick={() => setKhaltiQr(null)}
                        className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition-colors cursor-pointer"
                        title="Remove QR Code"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => handleDrag(e, 'khalti', true)}
                    onDragLeave={(e) => handleDrag(e, 'khalti', false)}
                    onDrop={(e) => handleDrop(e, 'khalti')}
                    className={`border-2 border-dashed rounded-xl p-5 text-center flex flex-col items-center justify-center gap-2 transition-colors ${
                      dragActiveKhalti ? 'border-purple-500 bg-purple-50/50' : 'border-slate-300 bg-slate-50/30'
                    }`}
                  >
                    <Upload className="w-6 h-6 text-slate-400" />
                    <div>
                      <p className="text-xs font-bold text-slate-700">Drag QR Image here</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">or select from file explorer</p>
                    </div>
                    <label className="px-3 py-1 bg-white border border-slate-200 hover:border-slate-300 text-slate-600 font-bold text-[10px] rounded-lg cursor-pointer transition-colors mt-1">
                      Select File
                      <input 
                        type="file" 
                        accept="image/*"
                        className="hidden" 
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) handleImageUpload(e.target.files[0], 'khalti');
                        }}
                      />
                    </label>
                  </div>
                )}
              </div>

              {/* Presets and help tips */}
              <div className="bg-purple-50/60 border border-purple-100 rounded-xl p-3 text-[10px] text-purple-950 space-y-1.5">
                <p className="font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-purple-700" />
                  Testing Quick Presets:
                </p>
                <p className="text-slate-500 leading-normal">Don't have a merchant QR yet? Click below to instantly load a sample QR code for Khalti testing:</p>
                <button
                  type="button"
                  onClick={() => { setKhaltiQr(sampleQrs.khalti); }}
                  className="px-2 py-1 bg-purple-700 hover:bg-purple-800 text-white rounded font-bold text-[9px] cursor-pointer transition-colors"
                >
                  Load Sample Khalti QR
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bank Payment Card */}
        <div className={`bg-white rounded-2xl border transition-all p-5 shadow-sm space-y-4 lg:col-span-1 ${bankEnabled ? 'border-amber-200' : 'border-slate-200 opacity-70'}`}>
          <div className="flex justify-between items-center pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0">BK</div>
              <div>
                <h3 className="text-sm font-black text-slate-900">Bank Payment</h3>
                <p className="text-[10px] text-slate-400 font-semibold uppercase">Direct Bank & QR</p>
              </div>
            </div>
            
            {/* Toggle */}
            <button
              onClick={() => setBankEnabled(!bankEnabled)}
              className={`w-12 h-6 rounded-full p-1 transition-colors cursor-pointer ${bankEnabled ? 'bg-[#fd8b00] flex justify-end' : 'bg-slate-300 flex justify-start'}`}
            >
              <motion.div layout className="w-4 h-4 rounded-full bg-white shadow-sm" />
            </button>
          </div>

          {bankEnabled && (
            <div className="space-y-4">
              {/* Editable Fields */}
              <div className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Bank Name *</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="e.g. Nabil Bank Ltd."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-white font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Account Name *</label>
                  <input
                    type="text"
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    placeholder="e.g. ProBuild Materials Inc."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-white font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Account Number *</label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="e.g. 01201017500124"
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-white font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Branch (Optional)</label>
                  <input
                    type="text"
                    value={bankBranch}
                    onChange={(e) => setBankBranch(e.target.value)}
                    placeholder="e.g. Tinkune, Kathmandu"
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-white font-semibold"
                  />
                </div>
              </div>

              {/* QR Upload */}
              <div>
                <span className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Bank QR Code Graphic (Optional)</span>
                
                {bankQr ? (
                  <div className="relative group rounded-xl border border-slate-200 p-2 bg-slate-50 flex flex-col items-center justify-center">
                    <img 
                      src={bankQr} 
                      alt="Bank QR Code" 
                      className="w-32 h-32 object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <button 
                        onClick={() => setBankQr(null)}
                        className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition-colors cursor-pointer"
                        title="Remove QR Code"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => handleDrag(e, 'bank', true)}
                    onDragLeave={(e) => handleDrag(e, 'bank', false)}
                    onDrop={(e) => handleDrop(e, 'bank')}
                    className={`border-2 border-dashed rounded-xl p-4 text-center flex flex-col items-center justify-center gap-1.5 transition-colors ${
                      dragActiveBank ? 'border-amber-500 bg-amber-50/50' : 'border-slate-300 bg-slate-50/30'
                    }`}
                  >
                    <Upload className="w-5 h-5 text-slate-400" />
                    <div>
                      <p className="text-[11px] font-bold text-slate-700">Drag Bank Fonepay QR</p>
                      <p className="text-[9px] text-slate-400 mt-0.5">or click select file</p>
                    </div>
                    <label className="px-2.5 py-1 bg-white border border-slate-200 hover:border-slate-300 text-slate-600 font-bold text-[9px] rounded-lg cursor-pointer transition-colors mt-0.5">
                      Select File
                      <input 
                        type="file" 
                        accept="image/*"
                        className="hidden" 
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) handleImageUpload(e.target.files[0], 'bank');
                        }}
                      />
                    </label>
                  </div>
                )}
              </div>

              {/* Presets and help tips */}
              <div className="bg-amber-50/60 border border-amber-100 rounded-xl p-3 text-[10px] text-amber-900 space-y-1.5">
                <p className="font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  Testing Quick Presets:
                </p>
                <p className="text-slate-500 leading-normal">Need an instant bank Fonepay QR placeholder? Load one below:</p>
                <button
                  type="button"
                  onClick={() => { setBankQr(sampleQrs.bank); }}
                  className="px-2 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded font-black text-[9px] cursor-pointer transition-colors"
                >
                  Load Sample Bank QR
                </button>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Save banner at bottom */}
      <div className="flex justify-end pt-4 border-t border-slate-100">
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs tracking-wide transition-colors cursor-pointer flex items-center gap-2 disabled:opacity-50"
        >
          {saving ? 'Saving changes...' : 'Save All Configurations'}
        </button>
      </div>
    </div>
  );
}
