import React, { useState, useEffect } from 'react';
import { Expert } from '../types';
import { 
  Star, MapPin, Phone, Briefcase, Clock, ChevronRight, 
  MessageCircle, Send, X, Award, Globe, Shield, Edit3, 
  ChevronLeft, Maximize, Check, CheckCircle2, UserCheck, AlertTriangle
} from 'lucide-react';
import { CategoryScrollNav } from './CategoryScrollNav';
import OnlineBadge from './OnlineBadge';
import { collection, doc, onSnapshot, setDoc, query, where, getDocs, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

const CATEGORIES = [
  'Engineers', 'Architects', 'Laborers', 'Electricians', 'Plumbers', 
  'Carpenters', 'Painters', 'Interior Designers', 'Masons', 'Welders', 
  'Roofing Specialists', 'Other Experts'
];

const getExpertBio = (name: string, role: string) => {
  if (role.toLowerCase().includes('architect')) {
    return `${name} is an award-winning senior architect specializing in modern residential design and sustainable architecture. With a strong eye for spatial elegance and eco-friendly structural solutions, ${name} has designed over 50 homes across the region, bringing light, space, and functionality to every blueprint.`;
  }
  if (role.toLowerCase().includes('engineer')) {
    return `${name} is a highly experienced structural engineer dedicated to safety, efficiency, and structural integrity. Specializing in steel frame structures, advanced load calculations, and site safety inspections, ${name} works closely with architects to translate artistic visions into secure, long-lasting realities.`;
  }
  if (role.toLowerCase().includes('interior')) {
    return `${name} is a passionate interior designer focused on space optimization, bespoke lighting design, and cohesive color palettes. Believing that every interior should tell a unique story of its inhabitants, ${name} excels at creating warm, premium, and functional spaces tailored to individual lifestyles.`;
  }
  if (role.toLowerCase().includes('plumber')) {
    return `${name} is a master plumbing specialist with expertise in complex high-pressure piping, premium water treatment systems, and sustainable drainage solutions. Known for prompt, reliable service and precision installations, ${name} ensures all home services run flawlessly.`;
  }
  return `${name} is a certified professional dedicated to providing top-quality residential construction services. Committed to excellence, punctuality, and clear client communication, ${name} ensures every phase of your home improvement or building project is completed to the highest standards.`;
};

interface ExpertsViewProps {
  experts: Expert[];
  onMessageExpert?: (expertEmail: string) => void;
  presenceMap?: Record<string, boolean>;
  currentUserEmail?: string;
  currentUserName?: string;
  currentUserAvatar?: string;
}

export default function ExpertsView({ 
  experts, 
  onMessageExpert, 
  presenceMap,
  currentUserEmail,
  currentUserName,
  currentUserAvatar
}: ExpertsViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('Engineers');
  const [isMessageOpen, setIsMessageOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [selectedExpertForProfile, setSelectedExpertForProfile] = useState<Expert | null>(null);
  const [expertForHire, setExpertForHire] = useState<Expert | null>(null);
  const [activeProfileTab, setActiveProfileTab] = useState<'about' | 'portfolio' | 'reviews'>('about');

  // Firestore Real-time States
  const [portfolioProjects, setPortfolioProjects] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [isEligible, setIsEligible] = useState(false);
  const [userHasReviewed, setUserHasReviewed] = useState(false);
  const [existingUserReview, setExistingUserReview] = useState<any | null>(null);

  // Form states for rating/review submission
  const [formRating, setFormRating] = useState(5);
  const [formText, setFormText] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewSuccess, setReviewSuccess] = useState<string | null>(null);

  // Lightbox / gallery states
  const [activeLightboxProject, setActiveLightboxProject] = useState<any | null>(null);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [isFullscreenPhoto, setIsFullscreenPhoto] = useState(false);

  // ESC key handler to close both modal and lightbox safely
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isFullscreenPhoto) {
          setIsFullscreenPhoto(false);
        } else if (activeLightboxProject) {
          setActiveLightboxProject(null);
        } else if (selectedExpertForProfile) {
          setSelectedExpertForProfile(null);
        } else if (isMessageOpen) {
          setIsMessageOpen(false);
          setExpertForHire(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedExpertForProfile, activeLightboxProject, isFullscreenPhoto, isMessageOpen]);

  // Firestore subscription for selected expert's dynamic data (portfolio projects, reviews, contracts, user reviews)
  useEffect(() => {
    if (!selectedExpertForProfile) {
      setPortfolioProjects([]);
      setReviews([]);
      setIsEligible(false);
      setUserHasReviewed(false);
      setExistingUserReview(null);
      setReviewError(null);
      setReviewSuccess(null);
      return;
    }
    setActiveProfileTab('about');

    const expertEmail = selectedExpertForProfile.contact.toLowerCase();

    // 1. Subscribe to expert's portfolio projects from Firestore
    const projectsRef = collection(db, 'expert_portfolio');
    const qProjects = query(projectsRef, where('expertEmail', '==', expertEmail));
    const unsubProjects = onSnapshot(qProjects, (snapshot) => {
      const projectsList: any[] = [];
      snapshot.forEach((docSnap) => {
        projectsList.push({ id: docSnap.id, ...docSnap.data() });
      });

      if (projectsList.length === 0) {
        // Automatically seed high-quality projects for this expert if none exist in Firebase yet
        const role = selectedExpertForProfile.role.toLowerCase();
        let seedData: any[] = [];

        if (role.includes('architect')) {
          seedData = [
            {
              expertEmail,
              title: "The Glass House Pavilion",
              category: "Architectural Design",
              location: "Budhanilkantha, Kathmandu",
              completionYear: "2024",
              coverImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80",
              description: "A premium minimalist 3-bedroom modern residence featuring double-glazed glass panels, steel frames, and sustainable solar roofs.",
              images: [
                "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 1,45,00,000",
              completionDate: "February 20, 2024",
              clientFeedback: "The architectural flow and light distribution are extraordinary. Extremely professional delivery.",
              technologies: "Tempered Glass, Structural Steel, Teak Wood Floorboards, Smart Solar Inverters"
            },
            {
              expertEmail,
              title: "Lalitpur Heritage Loft Revamp",
              category: "Restoration & Design",
              location: "Patan, Lalitpur",
              completionYear: "2025",
              coverImage: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&auto=format&fit=crop&q=80",
              description: "Restored a classic Nepalese Newari brick building into a high-end luxury loft with a duplex steel mezzanine floor and automated lighting controls.",
              images: [
                "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 85,00,000",
              completionDate: "January 15, 2025",
              clientFeedback: "Brought traditional Nepali aesthetics together with state-of-the-art modular living in a masterful manner.",
              technologies: "Traditional Newari Brick, Structural Mezzanine, Modular Smart Kitchen, Recessed LEDs"
            }
          ];
        } else if (role.includes('engineer')) {
          seedData = [
            {
              expertEmail,
              title: "Hillside Villa Foundation",
              category: "Structural Engineering",
              location: "Dhulikhel, Kavre",
              completionYear: "2023",
              coverImage: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&auto=format&fit=crop&q=80",
              description: "Engineered deep-pile foundations and specialized retaining structures on unstable sloped terrain to support a multi-level luxury villa.",
              images: [
                "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 65,00,000",
              completionDate: "November 10, 2023",
              clientFeedback: "Phenomenal attention to seismic detailing and soil report compliance. Highly recommend!",
              technologies: "M30 Grade Concrete, Fe500 reinforcement steel bars, micro-piling structures"
            },
            {
              expertEmail,
              title: "Pokhara Lakefront Retaining Pier",
              category: "Hydraulic Engineering",
              location: "Lakeside, Pokhara",
              completionYear: "2024",
              coverImage: "https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=800&auto=format&fit=crop&q=80",
              description: "Designed a durable, erosion-resistant retaining sea-wall and concrete pier system utilizing eco-gabions and anti-corrosive concrete additives.",
              images: [
                "https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 95,00,000",
              completionDate: "May 18, 2024",
              clientFeedback: "Protected our lakefront property flawlessly against seasonal water surges and soil erosion.",
              technologies: "Anti-Corrosive Concrete, PVC Coated Gabion Wire Mesh, Geo-textiles"
            }
          ];
        } else {
          seedData = [
            {
              expertEmail,
              title: "Luxury Bathroom Sanctuary",
              category: "Plumbing & Design",
              location: "Jhamsikhel, Lalitpur",
              completionYear: "2024",
              coverImage: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800&auto=format&fit=crop&q=80",
              description: "Installed complex high-pressure concealed piping, premium German water-heating manifolds, and luxurious multi-shower fixtures.",
              images: [
                "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 28,00,000",
              completionDate: "July 29, 2024",
              clientFeedback: "Extremely tidy piping work and perfectly balanced water pressure. Flawless execution.",
              technologies: "PEX Piping, Grohe Concealed Manifolds, Dual-Boiler Heat Pumps"
            }
          ];
        }

        seedData.forEach(async (proj) => {
          const docId = `proj-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
          await setDoc(doc(db, 'expert_portfolio', docId), proj);
        });
      } else {
        setPortfolioProjects(projectsList);
      }
    });

    // 2. Subscribe to expert's reviews from Firestore
    const reviewsRef = collection(db, 'expert_reviews');
    const qReviews = query(reviewsRef, where('expertEmail', '==', expertEmail));
    const unsubReviews = onSnapshot(qReviews, (snapshot) => {
      const reviewsList: any[] = [];
      snapshot.forEach((docSnap) => {
        reviewsList.push({ id: docSnap.id, ...docSnap.data() });
      });

      if (reviewsList.length === 0) {
        // Automatically seed high-quality default reviews from Firestore if empty
        const defaultReviews = [
          {
            expertEmail,
            reviewerEmail: "sarah.j@example.com",
            reviewerName: "Sarah Jenkins",
            reviewerPhoto: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
            rating: 5,
            reviewText: `Absolutely incredible working with ${selectedExpertForProfile.name}! Super professional, prompt in communication, and delivered perfect results ahead of schedule.`,
            reviewDate: "July 12, 2026",
            createdAt: new Date().toISOString()
          },
          {
            expertEmail,
            reviewerEmail: "marcus.b@example.com",
            reviewerName: "Marcus Brody",
            reviewerPhoto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
            rating: 5,
            reviewText: `Highly recommended. They caught several critical design details that saved us thousands in construction costs. A true master of the craft!`,
            reviewDate: "June 25, 2026",
            createdAt: new Date().toISOString()
          }
        ];

        defaultReviews.forEach(async (rev) => {
          const docId = `rev-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
          await setDoc(doc(db, 'expert_reviews', docId), rev);
        });
      } else {
        // Sort reviews: newest first
        reviewsList.sort((a, b) => new Date(b.createdAt || b.reviewDate).getTime() - new Date(a.createdAt || a.reviewDate).getTime());
        setReviews(reviewsList);
      }
    });

    // 3. Subscribe to contract/eligibility verification
    if (currentUserEmail) {
      const contractsRef = collection(db, 'expert_contracts');
      const qContracts = query(contractsRef, 
        where('clientEmail', '==', currentUserEmail.toLowerCase()), 
        where('expertEmail', '==', expertEmail),
        where('status', '==', 'Completed')
      );
      const unsubContracts = onSnapshot(qContracts, (snapshot) => {
        setIsEligible(!snapshot.empty);
      });

      // 4. Check if user already submitted a review
      const qUserReview = query(reviewsRef,
        where('expertEmail', '==', expertEmail),
        where('reviewerEmail', '==', currentUserEmail.toLowerCase())
      );
      const unsubUserReview = onSnapshot(qUserReview, (snapshot) => {
        if (!snapshot.empty) {
          setUserHasReviewed(true);
          const firstReview = snapshot.docs[0].data();
          setExistingUserReview({ id: snapshot.docs[0].id, ...firstReview });
          setFormRating(firstReview.rating);
          setFormText(firstReview.reviewText);
        } else {
          setUserHasReviewed(false);
          setExistingUserReview(null);
          setFormRating(5);
          setFormText('');
        }
      });

      return () => {
        unsubProjects();
        unsubReviews();
        unsubContracts();
        unsubUserReview();
      };
    } else {
      setIsEligible(false);
      setUserHasReviewed(false);
      setExistingUserReview(null);
    }

    return () => {
      unsubProjects();
      unsubReviews();
    };
  }, [selectedExpertForProfile, currentUserEmail]);

  // Demo contract helper to let testing users instantly unlock eligibility in Firestore
  const handleUnlockReviewForm = async () => {
    if (!currentUserEmail || !selectedExpertForProfile) return;
    try {
      const contractId = `contract-${Date.now()}`;
      await setDoc(doc(db, 'expert_contracts', contractId), {
        id: contractId,
        clientEmail: currentUserEmail.toLowerCase(),
        expertEmail: selectedExpertForProfile.contact.toLowerCase(),
        status: 'Completed',
        projectName: 'Villa Remodeling Project',
        createdAt: new Date().toISOString()
      });
      setIsEligible(true);
    } catch (e: any) {
      console.error("Failed to unlock review form:", e);
    }
  };

  // Submission handler for Reviews (saves, calculates averages, and updates expert's root document)
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserEmail || !selectedExpertForProfile) return;
    if (!formText.trim()) {
      setReviewError("Please write a review comment.");
      return;
    }

    setIsSubmittingReview(true);
    setReviewError(null);
    setReviewSuccess(null);

    try {
      const expertEmail = selectedExpertForProfile.contact.toLowerCase();
      const reviewData = {
        expertEmail,
        reviewerEmail: currentUserEmail.toLowerCase(),
        reviewerName: currentUserName || "Dream House Client",
        reviewerPhoto: currentUserAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
        rating: formRating,
        reviewText: formText,
        reviewDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        createdAt: new Date().toISOString()
      };

      if (userHasReviewed && existingUserReview) {
        // Edit existing review
        await setDoc(doc(db, 'expert_reviews', existingUserReview.id), reviewData, { merge: true });
        setReviewSuccess("Your review has been successfully updated!");
      } else {
        // Submit a new review
        const reviewId = `rev-${Date.now()}`;
        await setDoc(doc(db, 'expert_reviews', reviewId), reviewData);
        setReviewSuccess("Thank you! Your review has been successfully submitted.");
      }

      // Query all reviews to recalculate the immediate overall average rating
      const reviewsRef = collection(db, 'expert_reviews');
      const q = query(reviewsRef, where('expertEmail', '==', expertEmail));
      const querySnapshot = await getDocs(q);
      
      let totalRating = 0;
      let count = 0;
      querySnapshot.forEach((docSnap) => {
        const d = docSnap.data();
        totalRating += Number(d.rating || 0);
        count++;
      });

      const newAvg = count > 0 ? Number((totalRating / count).toFixed(1)) : formRating;
      const newTotal = count > 0 ? count : 1;

      // Update structural rating and reviewsCount directly inside accounts collection
      const accountsRef = collection(db, 'accounts');
      const qAcc = query(accountsRef, where('email', '==', expertEmail));
      const accSnapshot = await getDocs(qAcc);
      if (!accSnapshot.empty) {
        const expertDocId = accSnapshot.docs[0].id;
        await updateDoc(doc(db, 'accounts', expertDocId), {
          rating: newAvg,
          reviews: newTotal,
          reviewsCount: newTotal
        });
      }

    } catch (err: any) {
      console.error("Error submitting review:", err);
      setReviewError("Failed to submit review. Please try again.");
    } finally {
      setIsSubmittingReview(false);
    }
  };

  // Calculate rating breakdown stats based on current reviews collection state
  const getRatingBreakdown = () => {
    const counts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    if (reviews.length === 0) return { breakdown: { 5: 100, 4: 0, 3: 0, 2: 0, 1: 0 }, total: 0, average: 5.0 };

    let sum = 0;
    reviews.forEach(r => {
      const ratingKey = Math.min(5, Math.max(1, Math.round(r.rating || 5))) as 5|4|3|2|1;
      counts[ratingKey]++;
      sum += (r.rating || 5);
    });

    const breakdown = {
      5: Math.round((counts[5] / reviews.length) * 100),
      4: Math.round((counts[4] / reviews.length) * 100),
      3: Math.round((counts[3] / reviews.length) * 100),
      2: Math.round((counts[2] / reviews.length) * 100),
      1: Math.round((counts[1] / reviews.length) * 100),
    };

    return {
      breakdown,
      total: reviews.length,
      average: Number((sum / reviews.length).toFixed(1))
    };
  };

  const ratingStats = getRatingBreakdown();

  const filteredExperts = experts.filter(expert => {
    const role = (expert.role || '').toLowerCase();
    const category = selectedCategory.toLowerCase();

    if (category === 'engineers' && role.includes('engineer')) return true;
    if (category === 'architects' && role.includes('architect')) return true;
    if (category === 'interior designers' && role.includes('interior')) return true;
    if (category === 'plumbers' && role.includes('plumber')) return true;
    if (category === 'laborers' && role.includes('laborer')) return true;
    if (category === 'electricians' && role.includes('electrician')) return true;
    if (category === 'carpenters' && role.includes('carpenter')) return true;
    if (category === 'painters' && role.includes('painter')) return true;
    if (category === 'masons' && role.includes('mason')) return true;
    if (category === 'welders' && role.includes('welder')) return true;
    if (category === 'roofing specialists' && role.includes('roofing')) return true;
    
    if (category === 'other experts') {
      const standardRoles = ['engineer', 'architect', 'interior', 'plumber', 'laborer', 'electrician', 'carpenter', 'painter', 'mason', 'welder', 'roofing'];
      return !standardRoles.some(r => role.includes(r));
    }
    return false;
  });

  return (
    <div className="p-6 md:p-10 max-w-[1280px] mx-auto space-y-8 relative text-[#0b1c30] dark:text-slate-100">
      <h2 className="text-3xl font-bold text-[#041627] dark:text-white">Our Experts</h2>
      
      {/* Category Tabs */}
      <CategoryScrollNav
        categories={CATEGORIES}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        activeColorClass="bg-[#fd8b00] text-white shadow-sm"
        inactiveColorClass="bg-white border border-[#c4c6cd] text-[#44474c] hover:bg-[#f8f9ff] dark:bg-slate-800 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-700"
      />

      {/* Expert Listing */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExperts.length > 0 ? (
          filteredExperts.map(expert => (
            <div key={expert.id} className="bg-white dark:bg-slate-900 rounded-xl border border-[#c4c6cd]/40 dark:border-slate-800 p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div 
                  className="flex items-center gap-4 mb-4 cursor-pointer group/header"
                  onClick={() => setSelectedExpertForProfile(expert)}
                >
                  <div className="relative shrink-0">
                    <img 
                      src={expert.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} 
                      alt={expert.name} 
                      className="w-16 h-16 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover/header:border-[#fd8b00] transition-colors" 
                      referrerPolicy="no-referrer"
                    />
                    <OnlineBadge email={expert.contact} presenceMap={presenceMap} className="bottom-0.5 right-0.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-lg font-bold text-[#041627] dark:text-white group-hover/header:text-[#fd8b00] transition-colors break-words overflow-wrap-anywhere whitespace-normal leading-tight">{expert.name}</h4>
                    <p className="text-sm text-[#8192a7] truncate">{expert.role}</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4 min-w-0">
                  <div className="flex items-center gap-2 text-sm text-[#44474c] dark:text-slate-300 min-w-0">
                    <Briefcase className="w-4 h-4 text-[#fd8b00] shrink-0" />
                    <span className="truncate flex-1">{expert.yearsOfExperience} years experience</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#44474c] dark:text-slate-300 min-w-0">
                    <MapPin className="w-4 h-4 text-[#fd8b00] shrink-0" />
                    <span className="truncate flex-1">{expert.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#44474c] dark:text-slate-300 min-w-0">
                    <Phone className="w-4 h-4 text-[#fd8b00] shrink-0" />
                    <span className="truncate flex-1" title={expert.contact}>{expert.contact}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm font-bold text-[#fd8b00] min-w-0">
                    <Star className="w-4 h-4 fill-current shrink-0" />
                    <span className="truncate">{expert.rating ? expert.rating.toFixed(1) : '5.0'} ({expert.reviews} reviews)</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between mt-6 border-t border-slate-100 dark:border-slate-800 pt-4">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  expert.availability === 'Available' ? 'bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300'
                }`}>
                  {expert.availability}
                </span>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setSelectedExpertForProfile(expert)}
                    className="text-sm font-semibold text-[#1a2b3c] dark:text-slate-300 hover:underline cursor-pointer"
                  >
                    View Profile
                  </button>
                  <button 
                    onClick={() => {
                      if (onMessageExpert) {
                        onMessageExpert(expert.contact);
                      } else {
                        setExpertForHire(expert);
                        setIsMessageOpen(true);
                      }
                    }}
                    className="text-sm font-semibold text-[#fd8b00] hover:underline cursor-pointer"
                  >
                    Message
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 col-span-full text-[#44474c] dark:text-slate-400">
            No experts found in this category.
          </div>
        )}
      </div>
      
      {/* Messaging Floating Action Button */}
      <button 
        onClick={() => {
          setExpertForHire(null);
          setIsMessageOpen(true);
        }}
        className="fixed bottom-8 right-8 bg-[#fd8b00] text-white rounded-full p-4 shadow-xl hover:bg-[#e07b00] hover:scale-105 transition-all flex items-center justify-center z-50"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Messaging Interface Modal */}
      {isMessageOpen && (
        <div 
          className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => {
            setIsMessageOpen(false);
            setExpertForHire(null);
          }}
        >
          <div 
            className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl p-6 w-full max-w-md relative text-[#0b1c30] dark:text-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              className="absolute top-4 right-4 text-[#44474c] hover:text-[#041627] dark:text-slate-400 dark:hover:text-white" 
              onClick={() => {
                setIsMessageOpen(false);
                setExpertForHire(null);
              }}
            >
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-lg font-bold font-sans text-[#041627] dark:text-white mb-4">
              {expertForHire ? `Message Expert: ${expertForHire.name}` : 'Inquire with Experts'}
            </h3>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={expertForHire ? `Type your message or project requirements for ${expertForHire.name} here...` : "Type your inquiry for our experts here..."}
              className="w-full h-32 p-3 bg-[#f8f9ff] dark:bg-slate-800 text-sm rounded border border-[#c4c6cd] dark:border-slate-700 focus:outline-none focus:border-[#fd8b00] mb-4 text-[#0b1c30] dark:text-slate-100"
            />
            <button 
              onClick={() => {
                setIsMessageOpen(false);
                const targetExpertName = expertForHire ? expertForHire.name : 'our experts';
                const targetExpertContact = expertForHire ? expertForHire.contact : null;
                setMessage('');
                setExpertForHire(null);
                if (targetExpertContact && onMessageExpert) {
                  onMessageExpert(targetExpertContact);
                } else {
                  alert(`Your message inquiry has been dispatched to ${targetExpertName}!`);
                }
              }}
              className="w-full py-2.5 bg-[#fd8b00] text-white rounded font-semibold text-sm hover:bg-[#e07b00] transition-colors flex items-center justify-center gap-2 cursor-pointer font-bold"
            >
              <Send className="w-4 h-4" />
              Send Message
            </button>
          </div>
        </div>
      )}

      {/* Detailed Expert Profile Modal */}
      {selectedExpertForProfile && (
        <div 
          className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto"
          onClick={() => setSelectedExpertForProfile(null)}
        >
          <div 
            className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-5xl relative overflow-hidden my-8 animate-in zoom-in-95 duration-200 flex flex-col md:flex-row h-full max-h-[90vh] md:max-h-[85vh] text-[#0b1c30] dark:text-slate-100 border border-slate-200 dark:border-slate-800"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Close Button */}
            <button 
              className="absolute top-4 right-4 text-[#44474c] hover:text-[#041627] dark:text-slate-400 dark:hover:text-white z-20 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-full p-1.5 shadow-sm border border-slate-200 dark:border-slate-700 cursor-pointer"
              onClick={() => setSelectedExpertForProfile(null)}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left Column: Basic Info & Photo (Fixed non-scrollable compact panel) */}
            <div className="w-full md:w-1/3 bg-slate-50 dark:bg-slate-950/30 border-b md:border-b-0 md:border-r border-slate-200/60 dark:border-slate-800 p-4 sm:p-5 flex flex-col items-center text-center overflow-hidden shrink-0 justify-between">
              <div className="flex flex-col items-center text-center w-full">
                <div className="relative mb-2 mt-1 sm:mt-2">
                  <img 
                    src={selectedExpertForProfile.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} 
                    alt={selectedExpertForProfile.name} 
                    className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-white dark:border-slate-800 shadow-md"
                    referrerPolicy="no-referrer"
                  />
                  <span className={`absolute bottom-1 right-1 block h-3.5 w-3.5 rounded-full ring-2 ring-white dark:ring-slate-800 ${
                    selectedExpertForProfile.availability === 'Available' ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                  }`} />
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-[#041627] dark:text-white break-words overflow-wrap-anywhere whitespace-normal w-full px-2 leading-tight text-center">{selectedExpertForProfile.name}</h3>
                <p className="text-xs sm:text-sm font-semibold text-[#fd8b00] mt-0.5">{selectedExpertForProfile.role}</p>

                <div className="w-full border-t border-slate-200/60 dark:border-slate-800 my-2.5" />

                {/* Contact & Availability */}
                <div className="w-full text-left space-y-2 text-xs text-[#44474c] dark:text-slate-300">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      <MapPin className="w-3.5 h-3.5 text-[#fd8b00]" />
                    </div>
                    <div>
                      <p className="text-[9px] text-slate-400 font-bold uppercase leading-none mb-0.5">Service Area</p>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 text-xs">{selectedExpertForProfile.location || 'Kathmandu, Nepal'}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 min-w-0 w-full">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      <Phone className="w-3.5 h-3.5 text-[#fd8b00]" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-[9px] text-slate-400 font-bold uppercase leading-none mb-0.5">Contact Details</p>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 text-xs break-all" title={selectedExpertForProfile.contact}>{selectedExpertForProfile.contact || 'Not available'}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      <Clock className="w-3.5 h-3.5 text-[#fd8b00]" />
                    </div>
                    <div>
                      <p className="text-[9px] text-slate-400 font-bold uppercase leading-none mb-0.5">Current Status</p>
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        selectedExpertForProfile.availability === 'Available' ? 'bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300'
                      }`}>
                        {selectedExpertForProfile.availability}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="w-full border-t border-slate-200/60 dark:border-slate-800 my-2.5" />

                {/* Rating Summary Card */}
                <div className="w-full bg-white dark:bg-slate-900 rounded-xl border border-slate-200/60 dark:border-slate-800 p-2 shadow-xs text-center">
                  <div className="flex items-center justify-center gap-1.5 text-lg font-extrabold text-slate-800 dark:text-white">
                    <Star className="w-4 h-4 text-[#fd8b00] fill-current" />
                    {ratingStats.average.toFixed(1)}
                  </div>
                  <p className="text-[9px] text-slate-500 mt-0.5 font-medium">Based on {ratingStats.total} verified reviews</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="w-full mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-800">
                <button 
                  onClick={() => {
                    if (onMessageExpert) {
                      onMessageExpert(selectedExpertForProfile.contact);
                      setSelectedExpertForProfile(null);
                    } else {
                      setExpertForHire(selectedExpertForProfile);
                      setIsMessageOpen(true);
                      setSelectedExpertForProfile(null);
                    }
                  }}
                  className="w-full py-2.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-xl font-bold text-xs sm:text-sm shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer active:scale-95 duration-100"
                >
                  <MessageCircle className="w-4 h-4" />
                  Message Expert
                </button>
              </div>
            </div>

            {/* Right Column: Detailed Redesigned Layout (Scrollable with hidden scrollbar) */}
            <div 
              className="w-full md:w-2/3 p-5 sm:p-6 md:p-8 overflow-y-auto overflow-x-hidden space-y-6 sm:space-y-8 bg-white dark:bg-slate-900 no-scrollbar scrollbar-none [ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
              style={{
                msOverflowStyle: 'none',
                scrollbarWidth: 'none',
              }}
            >
              
              {/* TOP SECTION: Expert Description */}
              <section className="space-y-4">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-2">
                  <h4 className="text-lg font-bold text-[#041627] dark:text-white flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-[#fd8b00]" /> About the Expert
                  </h4>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950/20 rounded-xl p-5 border border-slate-100 dark:border-slate-800">
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {selectedExpertForProfile.bio || getExpertBio(selectedExpertForProfile.name, selectedExpertForProfile.role)}
                  </p>
                </div>

                {/* Professional details grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Profession</span>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{selectedExpertForProfile.role}</p>
                  </div>

                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Experience</span>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{selectedExpertForProfile.yearsOfExperience} Years of Practice</p>
                  </div>

                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Languages Spoken</span>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Nepali, English, Newari/Hindi</p>
                  </div>

                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Availability Status</span>
                    <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
                      Ready for Projects ({selectedExpertForProfile.availability})
                    </p>
                  </div>
                </div>

                {/* Certifications and Skills */}
                <div className="space-y-3">
                  <div>
                    <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider">Specializations & Skills</span>
                    <div className="flex flex-wrap gap-2 mt-1.5">
                      {selectedExpertForProfile.skills.length > 0 ? (
                        selectedExpertForProfile.skills.map(skill => (
                          <span key={skill} className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/20 text-[#fd8b00] dark:text-amber-400 text-xs font-semibold rounded-lg border border-amber-200/50 dark:border-amber-900/30">
                            {skill}
                          </span>
                        ))
                      ) : (
                        ['Seismic Safety Design', '3D BIM Modeling', 'Local Regulatory Codes Compliance', 'Cost Estimation Planning'].map(skill => (
                          <span key={skill} className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/20 text-[#fd8b00] dark:text-amber-400 text-xs font-semibold rounded-lg border border-amber-200/50 dark:border-amber-900/30">
                            {skill}
                          </span>
                        ))
                      )}
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider">Accredited Certifications</span>
                    <div className="flex flex-wrap gap-2 mt-1.5">
                      {['Nepal Engineering Council (NEC) Member', 'Sustainable Built Environment LEED-AP Certificate'].map(cert => (
                        <span key={cert} className="px-2.5 py-1 bg-slate-100 dark:bg-slate-850 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1">
                          <Award className="w-3.5 h-3.5 text-amber-500" />
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              {/* CENTER SECTION: Completed Projects Portfolio */}
              <section className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-6">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-2 flex justify-between items-center">
                  <h4 className="text-lg font-bold text-[#041627] dark:text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-[#fd8b00]" /> Completed Projects Portfolio
                  </h4>
                  <span className="text-xs font-bold text-slate-400">{portfolioProjects.length} Verified Projects</span>
                </div>

                {portfolioProjects.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl">
                    <p className="text-sm text-slate-400 font-medium">No completed projects have been uploaded yet.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {portfolioProjects.map((project) => (
                      <div 
                        key={project.id} 
                        onClick={() => {
                          setActiveLightboxProject(project);
                          setCurrentPhotoIndex(0);
                          setIsFullscreenPhoto(false);
                        }}
                        className="group relative bg-slate-50 dark:bg-slate-950/20 border border-slate-200/50 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col h-full"
                      >
                        {/* Cover image with fallback */}
                        <div className="relative aspect-video w-full overflow-hidden bg-slate-200 dark:bg-slate-800">
                          <img 
                            src={project.coverImage || "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80"} 
                            alt={project.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute top-2 right-2 bg-[#fd8b00] text-white text-[9px] font-extrabold px-2 py-0.5 rounded shadow-sm">
                            {project.category || "Design"}
                          </div>
                        </div>

                        <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                          <div>
                            <h5 className="font-bold text-slate-800 dark:text-white text-sm line-clamp-1 group-hover:text-[#fd8b00] transition-colors">
                              {project.title}
                            </h5>
                            <p className="text-[11px] text-slate-400 mt-0.5 font-medium flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-[#fd8b00]" /> {project.location || "Nepal"} ({project.completionYear || "2024"})
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-300 leading-relaxed mt-2 line-clamp-2">
                              {project.description}
                            </p>
                          </div>
                          
                          <div className="pt-2 flex items-center justify-between text-[11px] font-semibold text-[#fd8b00] border-t border-slate-100 dark:border-slate-800/60 mt-2">
                            <span>Budget: {project.budget || "N/A"}</span>
                            <span className="flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                              Explore details <ChevronRight className="w-3 h-3" />
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              {/* BOTTOM SECTION: Ratings & Reviews */}
              <section className="space-y-6 border-t border-slate-100 dark:border-slate-800 pt-6">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-2">
                  <h4 className="text-lg font-bold text-[#041627] dark:text-white flex items-center gap-2">
                    <Star className="w-5 h-5 text-[#fd8b00] fill-[#fd8b00]" /> Customer Ratings & Reviews
                  </h4>
                </div>

                {/* Rating statistics block */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-slate-50 dark:bg-slate-950/20 border border-slate-200/40 dark:border-slate-800/60 rounded-2xl p-5">
                  <div className="flex flex-col items-center justify-center text-center space-y-1 sm:border-r border-slate-200 dark:border-slate-800">
                    <span className="text-5xl font-extrabold text-slate-800 dark:text-white">
                      {ratingStats.average.toFixed(1)}
                    </span>
                    <div className="flex gap-0.5 text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-4 h-4 ${i < Math.round(ratingStats.average) ? 'fill-current' : 'text-slate-200 dark:text-slate-700'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">{ratingStats.total} Total Reviews</span>
                  </div>

                  <div className="sm:col-span-2 flex flex-col justify-center space-y-1.5 pl-2">
                    {[5, 4, 3, 2, 1].map((starNum) => {
                      const percent = ratingStats.breakdown[starNum as 5|4|3|2|1] || 0;
                      return (
                        <div key={starNum} className="flex items-center gap-2 text-xs">
                          <span className="w-3 font-semibold text-slate-500">{starNum}★</span>
                          <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-amber-400 to-[#fd8b00] rounded-full transition-all duration-500" 
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                          <span className="w-8 text-right font-medium text-slate-400">{percent}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Reviews List */}
                <div className="space-y-4">
                  <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">All Customer Reviews ({reviews.length})</h5>
                  
                  {reviews.length === 0 ? (
                    <p className="text-sm text-slate-400 italic">No reviews submitted yet.</p>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 space-y-4">
                      {reviews.map((rev) => (
                        <div key={rev.id} className="pt-4 first:pt-0 flex gap-3.5 items-start">
                          <img 
                            src={rev.reviewerPhoto || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                            alt={rev.reviewerName}
                            className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-800"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0 space-y-1.5">
                            <div className="flex items-center justify-between">
                              <h6 className="text-xs font-bold text-slate-800 dark:text-slate-200">{rev.reviewerName}</h6>
                              <span className="text-[10px] text-slate-400 font-mono font-medium">{rev.reviewDate}</span>
                            </div>
                            <div className="flex items-center gap-0.5 text-amber-400">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`w-3.5 h-3.5 ${i < rev.rating ? 'fill-current' : 'text-slate-200 dark:text-slate-800'}`} 
                                />
                              ))}
                            </div>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed italic bg-slate-50 dark:bg-slate-950/10 p-2.5 rounded-lg border border-slate-100/50 dark:border-slate-800/40">
                              "{rev.reviewText}"
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* RATE THIS EXPERT FORM */}
                <div className="bg-slate-50 dark:bg-slate-950/20 border border-slate-200/40 dark:border-slate-800/60 rounded-2xl p-5 space-y-4">
                  <h5 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                    <Edit3 className="w-4 h-4 text-[#fd8b00]" /> {userHasReviewed ? 'Update Your Feedback' : 'Rate This Expert'}
                  </h5>

                  {isEligible ? (
                    <form onSubmit={handleSubmitReview} className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Your Score Selection</label>
                        <div className="flex items-center gap-2">
                          {[1, 2, 3, 4, 5].map((starNum) => (
                            <button
                              key={starNum}
                              type="button"
                              onClick={() => setFormRating(starNum)}
                              className="text-amber-400 hover:scale-110 active:scale-95 transition-transform duration-150 p-1 cursor-pointer focus:outline-none"
                            >
                              <Star className={`w-8 h-8 ${starNum <= formRating ? 'fill-current' : 'text-slate-250 dark:text-slate-700'}`} />
                            </button>
                          ))}
                          <span className="text-sm font-bold text-slate-500 ml-2">{formRating} out of 5 stars</span>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Feedback Comments</label>
                        <textarea
                          rows={3}
                          value={formText}
                          onChange={(e) => setFormText(e.target.value)}
                          placeholder="Please share your experience working with this expert on your remodeling project..."
                          className="w-full p-3 bg-white dark:bg-slate-900 text-sm rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-[#fd8b00] focus:border-[#fd8b00] text-[#0b1c30] dark:text-slate-100"
                        />
                      </div>

                      {reviewError && (
                        <div className="bg-red-50 dark:bg-red-950/10 border border-red-100 dark:border-red-900/30 text-red-800 dark:text-red-400 text-xs p-3 rounded-lg flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 shrink-0" />
                          <span>{reviewError}</span>
                        </div>
                      )}

                      {reviewSuccess && (
                        <div className="bg-green-50 dark:bg-green-950/10 border border-green-150 dark:border-green-900/30 text-green-800 dark:text-green-400 text-xs p-3 rounded-lg flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>{reviewSuccess}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={isSubmittingReview}
                        className="w-full py-2.5 bg-[#fd8b00] hover:bg-[#e07b00] disabled:bg-slate-300 text-white rounded-lg font-bold text-sm shadow-sm transition-all cursor-pointer active:scale-98"
                      >
                        {isSubmittingReview ? "Saving to Cloud..." : (userHasReviewed ? "Update Review Details" : "Submit Verification Review")}
                      </button>
                    </form>
                  ) : (
                    <div className="bg-amber-50 dark:bg-amber-950/15 border border-amber-200 dark:border-amber-900/30 rounded-xl p-4 text-center">
                      <p className="text-xs text-amber-800 dark:text-amber-300 font-medium leading-relaxed">
                        To preserve system integrity, review submission is restricted to clients with completed verified contracts with this expert.
                      </p>
                      {currentUserEmail ? (
                        <div className="mt-3.5 space-y-2">
                          <p className="text-[10px] text-slate-400">Sandbox Testing Mode Enabled:</p>
                          <button
                            type="button"
                            onClick={handleUnlockReviewForm}
                            className="px-4 py-1.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-[11px] font-extrabold rounded-lg shadow-xs transition-all cursor-pointer active:scale-95"
                          >
                            Simulate Completed Contract (Unlock Form)
                          </button>
                        </div>
                      ) : (
                        <p className="text-[10px] text-slate-400 mt-2">Please login as a client to leave reviews.</p>
                      )}
                    </div>
                  )}
                </div>

              </section>

            </div>

          </div>
        </div>
      )}

      {/* DETAILED GALLERY/LIGHTBOX MODAL OVERLAY */}
      {activeLightboxProject && (
        <div 
          className="fixed inset-0 bg-black/95 z-55 flex items-center justify-center p-4 backdrop-blur-md overflow-hidden animate-fadeIn text-white"
          onClick={() => setActiveLightboxProject(null)}
        >
          {/* Close Button */}
          <button 
            onClick={() => setActiveLightboxProject(null)}
            className="absolute top-6 right-6 p-2.5 bg-white/10 hover:bg-white/20 rounded-full transition-colors z-20 cursor-pointer text-white"
            title="Close Lightbox (Esc)"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Lightbox container */}
          <div 
            className="w-full max-w-5xl flex flex-col md:flex-row h-full max-h-[90vh] md:max-h-[80vh] bg-neutral-900 rounded-2xl overflow-hidden shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Left Image Slider Area */}
            <div className="w-full md:w-3/5 bg-black flex flex-col items-center justify-center relative select-none h-2/3 md:h-full">
              
              {/* Main Photo Display with Referrer Policy */}
              <div className="relative w-full h-full flex items-center justify-center p-4">
                <img 
                  src={(activeLightboxProject.images && activeLightboxProject.images.length > 0) ? activeLightboxProject.images[currentPhotoIndex] : activeLightboxProject.coverImage} 
                  alt={activeLightboxProject.title}
                  className={`max-w-full max-h-full object-contain transition-all duration-300 rounded ${
                    isFullscreenPhoto ? 'scale-110 cursor-zoom-out' : 'cursor-zoom-in'
                  }`}
                  onClick={() => setIsFullscreenPhoto(!isFullscreenPhoto)}
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Slider Arrows */}
              {activeLightboxProject.images && activeLightboxProject.images.length > 1 && (
                <>
                  <button 
                    onClick={() => setCurrentPhotoIndex(prev => (prev === 0 ? activeLightboxProject.images.length - 1 : prev - 1))}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 hover:scale-105 active:scale-95 transition-all text-white p-3 rounded-full cursor-pointer z-10"
                    title="Previous Photo"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setCurrentPhotoIndex(prev => (prev === activeLightboxProject.images.length - 1 ? 0 : prev + 1))}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 hover:scale-105 active:scale-95 transition-all text-white p-3 rounded-full cursor-pointer z-10"
                    title="Next Photo"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              {/* Photos Navigation Indicators */}
              {activeLightboxProject.images && activeLightboxProject.images.length > 1 && (
                <div className="absolute bottom-4 flex gap-1.5 z-10">
                  {activeLightboxProject.images.map((_, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setCurrentPhotoIndex(idx)}
                      className={`h-1.5 rounded-full transition-all cursor-pointer ${
                        idx === currentPhotoIndex ? 'w-6 bg-[#fd8b00]' : 'w-2 bg-white/40 hover:bg-white/60'
                      }`}
                    />
                  ))}
                </div>
              )}

              {/* Fullscreen Button */}
              <button 
                onClick={() => setIsFullscreenPhoto(!isFullscreenPhoto)}
                className="absolute top-4 left-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors cursor-pointer text-white z-10"
                title="Toggle Zoom Mode"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>

            {/* Right Details Column */}
            <div className="w-full md:w-2/5 p-6 md:p-8 bg-neutral-900 overflow-y-auto flex flex-col justify-between border-t md:border-t-0 md:border-l border-white/10 h-1/3 md:h-full scrollbar-thin">
              <div className="space-y-5">
                <div>
                  <span className="text-[10px] text-amber-500 font-extrabold uppercase tracking-wider">{activeLightboxProject.category || "Design Construction"}</span>
                  <h3 className="text-xl font-bold text-white mt-1 leading-tight">{activeLightboxProject.title}</h3>
                  <p className="text-xs text-neutral-400 mt-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#fd8b00]" /> {activeLightboxProject.location || "Nepal"}
                  </p>
                </div>

                <div className="border-t border-white/10 pt-4 space-y-3">
                  <div className="text-xs text-neutral-300 leading-relaxed">
                    <span className="text-[10px] text-neutral-500 font-bold uppercase block mb-1">Project Summary</span>
                    {activeLightboxProject.description}
                  </div>

                  {activeLightboxProject.technologies && (
                    <div className="text-xs text-neutral-300 leading-relaxed">
                      <span className="text-[10px] text-neutral-500 font-bold uppercase block mb-1">Materials & Tech Used</span>
                      <p className="font-semibold text-neutral-100">{activeLightboxProject.technologies}</p>
                    </div>
                  )}

                  {activeLightboxProject.clientFeedback && (
                    <div className="bg-neutral-800/50 rounded-xl p-3.5 border border-white/5 space-y-1">
                      <span className="text-[9px] text-amber-500 font-bold uppercase tracking-wider flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Client Testimonial
                      </span>
                      <p className="text-xs text-neutral-300 italic leading-relaxed">
                        "{activeLightboxProject.clientFeedback}"
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-white/10 pt-4 mt-6 grid grid-cols-2 gap-4">
                <div className="space-y-0.5">
                  <span className="text-[9px] text-neutral-500 font-bold uppercase block">Budget Total</span>
                  <p className="text-xs font-bold text-emerald-400">{activeLightboxProject.budget || "N/A"}</p>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[9px] text-neutral-500 font-bold uppercase block">Completion Date</span>
                  <p className="text-xs font-bold text-white">{activeLightboxProject.completionDate || activeLightboxProject.completionYear || "2024"}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
