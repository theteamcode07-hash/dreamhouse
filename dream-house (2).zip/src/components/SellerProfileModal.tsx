import React from 'react';
import { 
  X, CheckCircle2, Star, Mail, Phone, MapPin, 
  Building2, MessageSquare, ShoppingBag, Award, Clock
} from 'lucide-react';
import { SellerInfo, Product } from '../types';

interface SellerProfileModalProps {
  seller: SellerInfo | null;
  allProducts: Product[];
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onOpenChat: (seller: SellerInfo) => void;
}

export default function SellerProfileModal({
  seller,
  allProducts,
  isOpen,
  onClose,
  onAddToCart,
  onOpenChat
}: SellerProfileModalProps) {
  if (!isOpen || !seller) return null;

  // Filter products listed by this seller (matching seller email or shop name)
  const sellerProducts = allProducts.filter(p => {
    if (p.isDraft) return false;
    if (p.seller) {
      if (p.seller.email && seller.email && p.seller.email.toLowerCase() === seller.email.toLowerCase()) return true;
      if (p.seller.shopName && seller.shopName && p.seller.shopName.toLowerCase() === seller.shopName.toLowerCase()) return true;
    }
    return false;
  });

  const rating = seller.rating || 4.9;
  const reviewsCount = seller.reviewsCount || 48;
  const yearsExp = seller.yearsOfExperience || 10;

  return (
    <div className="fixed inset-0 z-50 bg-[#041627]/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in">
      <div 
        className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 my-auto flex flex-col max-h-[90vh] overflow-hidden animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Profile Card Header Info */}
        <div className="p-6 sm:p-8 pb-6 border-b border-slate-100 relative bg-white flex justify-between items-start shrink-0">
          <div className="flex items-center gap-5">
            <div className="relative shrink-0">
              <img
                src={seller.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"}
                alt={seller.shopName || seller.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-slate-200 shadow-md bg-slate-100"
                referrerPolicy="no-referrer"
              />
              {seller.isVerified && (
                <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white p-1 rounded-full border-2 border-white shadow-sm" title="Verified Vendor">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              )}
            </div>

            <div className="space-y-1.5 min-w-0 flex-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold border border-emerald-300/60 shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Verified Shopkeeper
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-[#041627] tracking-tight break-words overflow-wrap-anywhere whitespace-normal leading-tight">
                {seller.shopName || seller.name}
              </h2>
              <p className="text-sm font-bold text-[#fd8b00] break-words overflow-wrap-anywhere whitespace-normal">
                Owner: {seller.name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body (Scrollable) */}
        <div className="p-6 sm:p-8 space-y-6 bg-white overflow-y-auto flex-1">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80 text-center shadow-xs">
            <div className="space-y-0.5">
              <div className="flex items-center justify-center gap-1 text-amber-500 font-bold text-base sm:text-lg">
                <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                <span>{rating.toFixed(1)}</span>
              </div>
              <p className="text-xs text-slate-500 font-medium">({reviewsCount} reviews)</p>
            </div>

            <div className="space-y-0.5 border-x border-slate-200/80">
              <div className="flex items-center justify-center gap-1 text-[#1a2b3c] font-bold text-base sm:text-lg">
                <ShoppingBag className="w-5 h-5 text-[#fd8b00]" />
                <span>{sellerProducts.length || 6}</span>
              </div>
              <p className="text-xs text-slate-500 font-medium">Items Listed</p>
            </div>

            <div className="space-y-0.5">
              <div className="flex items-center justify-center gap-1 text-[#1a2b3c] font-bold text-base sm:text-lg">
                <Award className="w-5 h-5 text-emerald-600" />
                <span>{yearsExp}+ Yrs</span>
              </div>
              <p className="text-xs text-slate-500 font-medium">Experience</p>
            </div>
          </div>

          {/* Contact & Location Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 space-y-2 text-xs text-slate-700">
              <h4 className="font-bold text-[#041627] text-xs uppercase tracking-wider flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[#fd8b00]" />
                Contact Information
              </h4>
              <div className="space-y-1 text-slate-600">
                <p className="flex items-center gap-2">
                  <span className="font-semibold text-slate-800">Email:</span>
                  <a href={`mailto:${seller.email}`} className="text-[#fd8b00] hover:underline font-mono">
                    {seller.email}
                  </a>
                </p>
                <p className="flex items-center gap-2">
                  <span className="font-semibold text-slate-800">Phone:</span>
                  <span className="font-mono">{seller.phone || 'N/A'}</span>
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 space-y-2 text-xs text-slate-700">
              <h4 className="font-bold text-[#041627] text-xs uppercase tracking-wider flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#fd8b00]" />
                Business Location
              </h4>
              <p className="text-slate-600 leading-relaxed">
                {seller.location || '102 Industrial Parkway, Building B, Austin, TX'}
              </p>
            </div>
          </div>

          {/* Listed Products Section */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="font-bold text-[#041627] text-sm flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-[#fd8b00]" />
                Products Listed by {seller.shopName || seller.name}
              </h4>
              <span className="text-xs text-slate-500 font-semibold">
                {sellerProducts.length} Product{sellerProducts.length === 1 ? '' : 's'}
              </span>
            </div>

            {sellerProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-48 overflow-y-auto pr-1">
                {sellerProducts.map((prod) => (
                  <div 
                    key={prod.id}
                    className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs flex gap-3 items-center justify-between"
                  >
                    <img 
                      src={prod.image} 
                      alt={prod.name}
                      className="w-12 h-12 rounded-lg object-contain bg-slate-50 p-1 border border-slate-100 shrink-0" 
                    />
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <div className="flex items-center gap-2 justify-between">
                        <span className="text-[9px] font-mono uppercase text-slate-400 font-bold">
                          {prod.category}
                        </span>
                        {prod.availableQuantity !== undefined && (
                          <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-100">
                            {prod.availableQuantity} {prod.unit || 'pcs'}
                          </span>
                        )}
                      </div>
                      <h5 className="text-xs font-bold text-[#041627] truncate">
                        {prod.name}
                      </h5>
                      <p className="text-xs font-bold text-[#fd8b00] flex items-baseline gap-1">
                        ${prod.price.toFixed(2)}
                        <span className="text-[10px] text-slate-500 font-normal">/ {prod.unit || 'piece'}</span>
                      </p>
                    </div>

                    <button
                      onClick={() => onAddToCart(prod)}
                      className="px-2.5 py-1 bg-[#1a2b3c] hover:bg-[#041627] text-white text-[11px] font-bold rounded-lg transition-colors shrink-0 cursor-pointer"
                    >
                      + Add
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-xl text-center text-xs text-slate-500 border border-dashed border-slate-200">
                No active products listed under this seller currently.
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 shrink-0">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Verified Vendor ID: {seller.id || 'seller-1'}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg transition-colors cursor-pointer"
          >
            Close Profile
          </button>
        </div>
      </div>
    </div>
  );
}
