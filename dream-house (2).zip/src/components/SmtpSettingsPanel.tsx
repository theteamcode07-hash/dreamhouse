import React, { useState, useEffect } from 'react';
import { Mail, Server, Key, User, ShieldCheck, Send, CheckCircle2, AlertTriangle, Loader2, Save, Info, Lock } from 'lucide-react';

interface SmtpSettingsPanelProps {
  showToast?: (msg: string, type?: 'success' | 'error') => void;
}

export default function SmtpSettingsPanel({ showToast }: SmtpSettingsPanelProps) {
  const [smtpHost, setSmtpHost] = useState('');
  const [smtpPort, setSmtpPort] = useState('587');
  const [smtpUser, setSmtpUser] = useState('');
  const [smtpPass, setSmtpPass] = useState('');
  const [smtpFromEmail, setSmtpFromEmail] = useState('');
  const [smtpFromName, setSmtpFromName] = useState('Dream House');
  const [smtpSecure, setSmtpSecure] = useState(false);
  const [resendApiKey, setResendApiKey] = useState('');

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [testEmail, setTestEmail] = useState('');

  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Fetch current server / Firestore email configuration on mount
  useEffect(() => {
    fetchEmailSettings();
  }, []);

  const fetchEmailSettings = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/admin/email-settings');
      const data = await response.json();
      if (response.ok && data.success && data.config) {
        setSmtpHost(data.config.smtpHost || '');
        setSmtpPort(data.config.smtpPort ? String(data.config.smtpPort) : '587');
        setSmtpUser(data.config.smtpUser || '');
        setSmtpPass(data.config.smtpPass || '');
        setSmtpFromEmail(data.config.smtpFromEmail || '');
        setSmtpFromName(data.config.smtpFromName || 'Dream House');
        setSmtpSecure(Boolean(data.config.smtpSecure));
        setResendApiKey(data.config.resendApiKey || '');
      }
    } catch (err: any) {
      console.error('Error fetching SMTP settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    setStatusMessage(null);

    try {
      const response = await fetch('/api/admin/email-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          smtpHost: smtpHost.trim(),
          smtpPort: Number(smtpPort) || 587,
          smtpUser: smtpUser.trim(),
          smtpPass: smtpPass.trim(),
          smtpFromEmail: smtpFromEmail.trim(),
          smtpFromName: smtpFromName.trim(),
          smtpSecure: smtpSecure || Number(smtpPort) === 465,
          resendApiKey: resendApiKey.trim()
        })
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to update email settings.');
      }

      if (data.config) {
        setSmtpPass(data.config.smtpPass || '');
      }

      const isWarn = data.message && data.message.includes('Failed');
      setStatusMessage({
        text: data.message || 'SMTP settings saved and applied successfully across all devices!',
        type: isWarn ? 'error' : 'success'
      });

      if (showToast) {
        showToast(data.message || 'SMTP Settings saved successfully!', isWarn ? 'error' : 'success');
      }
    } catch (err: any) {
      console.error('Error saving SMTP settings:', err);
      setStatusMessage({
        text: err.message || 'Failed to save SMTP configuration.',
        type: 'error'
      });
      if (showToast) showToast(err.message || 'Failed to save settings.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleTestDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testEmail.trim()) return;

    setIsTesting(true);
    setStatusMessage(null);

    try {
      const response = await fetch('/api/admin/test-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipientEmail: testEmail.trim() })
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to send test email.');
      }

      setStatusMessage({
        text: data.message || `Test email successfully delivered to ${testEmail.trim()}!`,
        type: 'success'
      });

      if (showToast) showToast(`Test email sent to ${testEmail.trim()}`, 'success');
    } catch (err: any) {
      console.error('Error sending test email:', err);
      setStatusMessage({
        text: err.message || 'Test email failed to deliver.',
        type: 'error'
      });
      if (showToast) showToast(err.message || 'Test email failed.', 'error');
    } finally {
      setIsTesting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm flex flex-col items-center justify-center min-h-[220px]">
        <Loader2 className="w-8 h-8 text-[#fd8b00] animate-spin mb-2" />
        <p className="text-xs font-bold text-slate-600">Loading SMTP Email Configuration...</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fadeIn">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#041627] to-[#0d2847] p-6 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-[#fd8b00]/20 border border-[#fd8b00]/40 rounded-xl text-[#fd8b00]">
            <Server className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              SMTP Gateway & Email Server Configuration
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Single source of truth for OTP verification, password resets, approvals, and platform announcements.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold px-3 py-1.5 rounded-lg">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          Real-Time Firestore Sync
        </div>
      </div>

      {/* Status Notice Banner */}
      {statusMessage && (
        <div className={`p-4 border-b text-xs font-medium flex items-start gap-3 ${
          statusMessage.type === 'success' 
            ? 'bg-emerald-50 text-emerald-900 border-emerald-200' 
            : 'bg-rose-50 text-rose-900 border-rose-200'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          )}
          <div className="flex-1 leading-relaxed">{statusMessage.text}</div>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSaveSettings} className="p-6 sm:p-8 space-y-6">
        {/* Quick Helper Banner */}
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3 text-xs text-amber-900">
          <Info className="w-5 h-5 text-[#fd8b00] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Gmail SMTP Quick Setup Guide:</p>
            <p>
              Set <strong>SMTP Host</strong> to <code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold">smtp.gmail.com</code>, 
              <strong>Port</strong> to <code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold">587</code> (or <code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold">465</code>), 
              and enter your full Gmail address in <strong>SMTP Username</strong> &amp; <strong>Sender Email</strong>. 
              In <strong>SMTP Password</strong>, enter a 16-character <em>Gmail App Password</em> (generated from Google Account &gt; Security &gt; 2-Step Verification &gt; App Passwords).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* SMTP Host */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-[#fd8b00]" />
              SMTP Server Host <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. smtp.gmail.com"
              value={smtpHost}
              onChange={(e) => setSmtpHost(e.target.value)}
              className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-mono font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
              required
            />
          </div>

          {/* SMTP Port */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-[#fd8b00]" />
              SMTP Port <span className="text-rose-500">*</span>
            </label>
            <div className="flex gap-2 items-center">
              <input
                type="number"
                placeholder="587"
                value={smtpPort}
                onChange={(e) => {
                  const val = e.target.value;
                  setSmtpPort(val);
                  if (Number(val) === 465) setSmtpSecure(true);
                  else if (Number(val) === 587) setSmtpSecure(false);
                }}
                className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-mono font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
                required
              />
              <span className="text-[11px] font-bold text-slate-500 whitespace-nowrap bg-slate-100 px-3 py-3 rounded-xl border border-slate-200">
                {Number(smtpPort) === 465 ? 'SSL (465)' : 'TLS (587)'}
              </span>
            </div>
          </div>

          {/* SMTP Username */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-[#fd8b00]" />
              SMTP Username / Email <span className="text-rose-500">*</span>
            </label>
            <input
              type="email"
              placeholder="e.g. user@gmail.com"
              value={smtpUser}
              onChange={(e) => {
                setSmtpUser(e.target.value);
                if (!smtpFromEmail) setSmtpFromEmail(e.target.value);
              }}
              className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
              required
            />
          </div>

          {/* SMTP Password */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-[#fd8b00]" />
              SMTP Password / App Password <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="16-character App Password"
                value={smtpPass}
                onChange={(e) => setSmtpPass(e.target.value)}
                className="w-full text-xs p-3 pr-10 border border-slate-200 rounded-xl bg-slate-50 font-mono font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          {/* Sender From Email */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#fd8b00]" />
              From Email Address <span className="text-rose-500">*</span>
            </label>
            <input
              type="email"
              placeholder="e.g. verify@dreamhouse.com"
              value={smtpFromEmail}
              onChange={(e) => setSmtpFromEmail(e.target.value)}
              className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
              required
            />
          </div>

          {/* Sender From Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-[#fd8b00]" />
              From Display Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Dream House"
              value={smtpFromName}
              onChange={(e) => setSmtpFromName(e.target.value)}
              className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
              required
            />
          </div>
        </div>

        {/* Toggles & Fallback Options */}
        <div className="pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <label className="flex items-center gap-3 cursor-pointer p-3 border border-slate-200 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              checked={smtpSecure}
              onChange={(e) => setSmtpSecure(e.target.checked)}
              className="w-4 h-4 text-[#fd8b00] rounded accent-[#fd8b00] cursor-pointer"
            />
            <div>
              <span className="text-xs font-bold text-slate-800 block">Use Secure TLS/SSL Connection</span>
              <span className="text-[10px] text-slate-500 block">Required for port 465. Optional for port 587.</span>
            </div>
          </label>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              Resend API Key (Optional Fallback)
            </label>
            <input
              type="text"
              placeholder="re_xxxxxxxxxxxxxxxx"
              value={resendApiKey}
              onChange={(e) => setResendApiKey(e.target.value)}
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-slate-50 font-mono text-slate-800 focus:bg-white focus:outline-none focus:border-[#fd8b00]"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="submit"
            disabled={isSaving}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#041627] hover:bg-[#102a43] text-white font-bold text-xs transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-md"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-[#fd8b00]" />
                Verifying &amp; Saving Settings...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 text-[#fd8b00]" />
                Save &amp; Apply SMTP Configuration
              </>
            )}
          </button>
        </div>
      </form>

      {/* Live Test Email Dispatcher Section */}
      <div className="p-6 sm:p-8 bg-slate-50 border-t border-slate-200">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1 flex items-center gap-2">
          <Send className="w-4 h-4 text-[#fd8b00]" />
          Verify Live Email Dispatch
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Send a real verification test email to any inbox to confirm SMTP delivery and TLS handshake.
        </p>

        <form onSubmit={handleTestDispatch} className="flex flex-col sm:flex-row gap-3">
          <input
            type="email"
            placeholder="Enter recipient email (e.g. your-gmail@gmail.com)..."
            value={testEmail}
            onChange={(e) => setTestEmail(e.target.value)}
            className="flex-1 text-xs p-3 border border-slate-200 rounded-xl bg-white font-semibold text-slate-800 focus:outline-none focus:border-[#fd8b00]"
            required
          />
          <button
            type="submit"
            disabled={isTesting || !testEmail.trim()}
            className="px-6 py-3 bg-[#fd8b00] hover:bg-orange-600 text-white rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-sm shrink-0"
          >
            {isTesting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Sending Test Email...
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Send Test Email
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
