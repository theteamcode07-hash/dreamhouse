import React, { useEffect } from 'react';
import { WebsiteConfig } from '../types';

interface LoadingScreenProps {
  label?: string;
  onFinished?: () => void;
  duration?: number;
  websiteConfig?: WebsiteConfig;
}

export default function LoadingScreen({ 
  label = 'Initializing Blueprint', 
  onFinished, 
  duration = 1500,
  websiteConfig
}: LoadingScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      if (onFinished) onFinished();
    }, duration);
    return () => clearTimeout(timer);
  }, [onFinished, duration]);

  const logoSrc = websiteConfig?.splashScreenLogo || websiteConfig?.logoUrl || "";
  const siteName = websiteConfig?.siteName || "Dream House";

  return (
    <div className="fixed inset-0 z-[100] bg-[#f8f9ff] flex flex-col items-center justify-center p-6 text-center">
      <div className="flex flex-col items-center max-w-sm w-full space-y-12">
        {/* Pulsing Logo Container */}
        <div className="relative w-32 h-32 md:w-40 md:h-40 animate-pulse duration-[3000ms]">
          <div className="absolute inset-0 bg-[#041627]/5 rounded-full blur-2xl transform scale-110"></div>
          {logoSrc ? (
            <img 
              alt={`${siteName} Logo`} 
              className="w-full h-full object-contain relative z-10 drop-shadow-md" 
              src={logoSrc}
            />
          ) : null}
        </div>

        {/* Progress Indicator */}
        <div className="w-full space-y-4">
          <h1 className="font-sans text-xl font-semibold text-[#041627] tracking-wide">
            Building {siteName}...
          </h1>
          
          {/* Sleek Progress Bar */}
          <div className="h-1.5 w-full bg-[#dce9ff] rounded-full overflow-hidden shadow-inner">
            <div className="h-full bg-[#fd8b00] rounded-full animate-infinite w-1/3 progress-animation"></div>
          </div>
          
          <p className="font-mono text-xs text-[#44474c]/80 uppercase tracking-[0.2em]">
            {label}
          </p>
        </div>
      </div>

      <style>{`
        @keyframes progress {
          0% { width: 0%; margin-left: 0%; }
          50% { width: 40%; margin-left: 30%; }
          100% { width: 0%; margin-left: 100%; }
        }
        .progress-animation {
          animation: progress 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
