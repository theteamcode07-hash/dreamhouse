import React, { useState, useEffect } from 'react';
import { 
  Megaphone, Search, Filter, Pin, Calendar, User, Clock, CheckCircle2, 
  Circle, AlertTriangle, ExternalLink, Paperclip, Bell, ChevronRight, Tag
} from 'lucide-react';
import { collection, onSnapshot, doc, setDoc, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Announcement } from '../types';

interface AnnouncementsViewProps {
  userId: string;
  userEmail: string;
  userRole: 'homeowner' | 'professional' | 'shopkeeper' | 'admin';
  userName?: string;
  userCreatedAt?: string;
}

export default function AnnouncementsView({ userId, userEmail, userRole, userName, userCreatedAt }: AnnouncementsViewProps) {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [readDocIds, setReadDocIds] = useState<Set<string>>(new Set());
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [readFilter, setReadFilter] = useState<'All' | 'Unread' | 'Read'>('All');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  // Real-time listener for announcements
  useEffect(() => {
    const q = query(collection(db, 'announcements'), orderBy('createdAt', 'desc'));
    const unsubscribeAnnouncements = onSnapshot(q, (snapshot) => {
      const items: Announcement[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as Announcement;
        items.push({
          ...data,
          id: docSnap.id || data.id
        });
      });
      setAnnouncements(items);
      setLoading(false);
    }, (err) => {
      console.warn('Announcements snapshot listener note:', err);
      setLoading(false);
    });

    return () => unsubscribeAnnouncements();
  }, []);

  // Real-time listener for user's read receipts
  useEffect(() => {
    if (!userId) return;
    const readColRef = collection(db, 'announcement_reads');
    const unsubscribeReads = onSnapshot(readColRef, (snapshot) => {
      const readSet = new Set<string>();
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.userId === userId || data.userEmail === userEmail) {
          readSet.add(data.announcementId);
        }
      });
      setReadDocIds(readSet);
    }, (err) => {
      console.warn('Reads snapshot listener note:', err);
    });

    return () => unsubscribeReads();
  }, [userId, userEmail]);

  // Mark announcement as read
  const markAsRead = async (announcementId: string, annCreatedAt?: string) => {
    if (!userId) return;
    const readDocId = `${announcementId}_${userId}`;
    try {
      await setDoc(doc(db, 'announcement_reads', readDocId), {
        id: readDocId,
        announcementId,
        userId,
        userEmail: userEmail || '',
        readStatus: 'Read',
        readAt: new Date().toISOString(),
        createdAt: annCreatedAt || new Date().toISOString()
      });
      setReadDocIds(prev => new Set(prev).add(announcementId));
    } catch (err) {
      console.error('Failed to mark as read:', err);
    }
  };

  // Filter announcements for current user
  const relevantAnnouncements = announcements.filter(item => {
    // Audience match check
    const isTargeted = 
      item.targetAudience === 'All' ||
      item.targetAudience === userRole ||
      (item.targetAudience === 'individual' && (item.targetUserEmail?.toLowerCase() === userEmail?.toLowerCase() || item.targetUserId === userId));

    if (!isTargeted) return false;

    // Schedule check: hide future scheduled announcements unless admin
    if (item.scheduleTime && new Date(item.scheduleTime) > new Date() && userRole !== 'admin') {
      return false;
    }

    // Account creation date check: only show announcements published on or after user account creation date
    if (userCreatedAt && userRole !== 'admin') {
      const itemDate = new Date(item.createdAt || item.scheduleTime || 0);
      const userDate = new Date(userCreatedAt);
      if (!isNaN(itemDate.getTime()) && !isNaN(userDate.getTime())) {
        if (itemDate < userDate) {
          return false;
        }
      }
    }

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = item.title?.toLowerCase().includes(q);
      const matchContent = item.content?.toLowerCase().includes(q);
      const matchCategory = item.category?.toLowerCase().includes(q);
      if (!matchTitle && !matchContent && !matchCategory) return false;
    }

    // Category filter
    if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;

    // Priority filter
    if (priorityFilter !== 'All' && item.priority !== priorityFilter) return false;

    // Read/Unread filter
    const isRead = readDocIds.has(item.id);
    if (readFilter === 'Unread' && isRead) return false;
    if (readFilter === 'Read' && !isRead) return false;

    return true;
  });

  // Sort: Pinned items first, then by date according to sortOrder
  const sortedAnnouncements = [...relevantAnnouncements].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;

    const timeA = new Date(a.createdAt || 0).getTime();
    const timeB = new Date(b.createdAt || 0).getTime();

    return sortOrder === 'newest' ? timeB - timeA : timeA - timeB;
  });

  const unreadCount = relevantAnnouncements.filter(item => !readDocIds.has(item.id)).length;

  const handleOpenDetail = (announcement: Announcement) => {
    setSelectedAnnouncement(announcement);
    if (!readDocIds.has(announcement.id)) {
      markAsRead(announcement.id, announcement.createdAt);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-[#041627] via-[#1a2b3c] to-[#041627] text-white p-6 sm:p-8 rounded-2xl shadow-xl relative overflow-hidden">
        <div className="absolute -right-6 -bottom-6 opacity-10">
          <Megaphone className="w-48 h-48 text-white" />
        </div>
        <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#fd8b00]/20 border border-[#fd8b00]/40 flex items-center justify-center text-[#fd8b00]">
                <Bell className="w-5 h-5" />
              </div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight">Platform Announcements</h1>
            </div>
            <p className="text-xs text-[#8192a7] mt-1.5 max-w-xl">
              Official updates, system releases, maintenance schedules, and important notices directly from Dream House administration.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/10 shrink-0">
            <div className="text-right">
              <p className="text-[10px] font-extrabold uppercase tracking-wider text-[#8192a7]">Unread Notices</p>
              <p className="text-lg font-black text-white">{unreadCount}</p>
            </div>
            {unreadCount > 0 && (
              <span className="w-3 h-3 rounded-full bg-[#fd8b00] animate-ping" />
            )}
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col lg:flex-row gap-3 items-center justify-between">
          
          {/* Search Input */}
          <div className="relative w-full lg:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search announcements by title or keyword..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 transition-all"
            />
          </div>

          {/* Select Filters Group */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 w-full lg:w-auto">
            {/* Category */}
            <select 
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200"
            >
              <option value="All">All Categories</option>
              <option value="General">General</option>
              <option value="System Update">System Update</option>
              <option value="Maintenance">Maintenance</option>
              <option value="Promotion">Promotion</option>
              <option value="Urgent Notice">Urgent Notice</option>
            </select>

            {/* Priority */}
            <select 
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200"
            >
              <option value="All">All Priorities</option>
              <option value="Normal">Normal</option>
              <option value="Important">Important</option>
              <option value="Urgent">Urgent</option>
            </select>

            {/* Read/Unread */}
            <select 
              value={readFilter}
              onChange={e => setReadFilter(e.target.value as any)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200"
            >
              <option value="All">All Statuses</option>
              <option value="Unread">Unread Only</option>
              <option value="Read">Read Only</option>
            </select>

            {/* Sort Order */}
            <select 
              value={sortOrder}
              onChange={e => setSortOrder(e.target.value as any)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
            </select>
          </div>
        </div>
      </div>

      {/* Announcements List */}
      {loading ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-2xl border border-slate-200 dark:border-slate-800 text-center text-slate-400 text-xs">
          <div className="w-8 h-8 border-2 border-[#fd8b00] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          Loading announcements...
        </div>
      ) : sortedAnnouncements.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
          <Megaphone className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">No announcements match your search or filter</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
            Try adjusting your search criteria or resetting filters to view all broadcasted announcements.
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {sortedAnnouncements.map((announcement) => {
            const isRead = readDocIds.has(announcement.id);
            return (
              <div 
                key={announcement.id}
                onClick={() => handleOpenDetail(announcement)}
                className={`group cursor-pointer rounded-2xl border p-5 transition-all duration-200 ${
                  !isRead 
                    ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300/80 dark:border-amber-700/60 shadow-sm hover:border-[#fd8b00]' 
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    
                    {/* Priority Badge */}
                    {announcement.priority === 'Urgent' ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-100 text-red-700 border border-red-200 flex items-center gap-1 animate-pulse">
                        <AlertTriangle className="w-3 h-3" />
                        Urgent
                      </span>
                    ) : announcement.priority === 'Important' ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200">
                        Important
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                        Normal
                      </span>
                    )}

                    {/* Category Tag */}
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-900/50">
                      {announcement.category || 'General'}
                    </span>

                    {/* Pinned Indicator */}
                    {announcement.isPinned && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300 flex items-center gap-1">
                        <Pin className="w-3 h-3 text-[#fd8b00] fill-[#fd8b00]" />
                        Pinned Notice
                      </span>
                    )}

                    {/* Attachment Badge */}
                    {announcement.attachmentUrl && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-1">
                        <Paperclip className="w-3 h-3" />
                        Attachment
                      </span>
                    )}
                  </div>

                  {/* Read / Unread Status Badge */}
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-mono">
                      {announcement.createdAt ? new Date(announcement.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : ''}
                    </span>
                    {isRead ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3 h-3 text-slate-400" />
                        Read
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-black text-[#fd8b00] bg-[#fd8b00]/10 px-2 py-0.5 rounded-full border border-[#fd8b00]/30">
                        <Circle className="w-2 h-2 fill-[#fd8b00] text-[#fd8b00]" />
                        New
                      </span>
                    )}
                  </div>
                </div>

                {/* Content Header & Snippet */}
                <div className="mt-3">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-[#fd8b00] transition-colors flex items-center gap-2">
                    {announcement.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 line-clamp-2 leading-relaxed">
                    {announcement.content}
                  </p>
                </div>

                {/* Footer Info */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex justify-between items-center text-[11px] text-slate-400">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1 font-medium">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      {announcement.createdByName || 'System Admin'}
                    </span>
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {announcement.createdAt ? new Date(announcement.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                    </span>
                  </div>

                  <span className="text-[#fd8b00] font-bold text-xs flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    View Details
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Announcement Detail Modal */}
      {selectedAnnouncement && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="p-6 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex justify-between items-start gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    selectedAnnouncement.priority === 'Urgent' ? 'bg-red-100 text-red-700' :
                    selectedAnnouncement.priority === 'Important' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {selectedAnnouncement.priority} Priority
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                    {selectedAnnouncement.category || 'General'}
                  </span>
                </div>
                <h2 className="text-xl font-black text-slate-900 dark:text-white">{selectedAnnouncement.title}</h2>
              </div>

              <button 
                onClick={() => setSelectedAnnouncement(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white text-sm font-bold p-1 rounded-lg transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-slate-700 dark:text-slate-200 text-sm leading-relaxed whitespace-pre-wrap">
              <p>{selectedAnnouncement.content}</p>

              {/* Attachment link if available */}
              {selectedAnnouncement.attachmentUrl && (
                <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Paperclip className="w-5 h-5 text-[#fd8b00]" />
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">Announcement Attachment</p>
                      <p className="text-[10px] text-slate-400 truncate max-w-xs">{selectedAnnouncement.attachmentUrl}</p>
                    </div>
                  </div>
                  <a 
                    href={selectedAnnouncement.attachmentUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors"
                  >
                    Open <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>

            {/* Modal Footer Metadata */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-3">
                <span><strong>By:</strong> {selectedAnnouncement.createdByName || 'System Admin'}</span>
                <span>•</span>
                <span><strong>Date:</strong> {selectedAnnouncement.createdAt ? new Date(selectedAnnouncement.createdAt).toLocaleString() : ''}</span>
              </div>
              <button 
                onClick={() => setSelectedAnnouncement(null)}
                className="w-full sm:w-auto px-5 py-2 bg-[#041627] text-white font-bold text-xs rounded-xl hover:bg-black transition-colors"
              >
                Close Notice
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
