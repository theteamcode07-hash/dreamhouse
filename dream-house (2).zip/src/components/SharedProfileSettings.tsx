import React, { useState, useEffect, useRef } from 'react';
import { Sun, Moon, Camera, X, CheckCircle, Eye, EyeOff, MapPin, User, FileText, Award, Store, Shield, Briefcase, Key, Save, Trash2, AlertTriangle } from 'lucide-react';
import { updatePassword, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, onSnapshot, query, collection, where, getDocs } from 'firebase/firestore';
import { optimizeImage } from '../lib/fileUploader';
import { useTheme } from '../lib/theme';

interface SharedProfileSettingsProps {
  roleName: string;
  username: string;
  userEmail: string;
  userPhone?: string;
  userAvatar?: string;
  registrationDate?: string;
  emailVerified?: string;
  accountStatus?: string;
  address?: string;
  province?: string;
  district?: string;
  municipality?: string;
  bio?: string;
  yearsOfExperience?: number;
  skillsOrTags?: string[];
  professionalTitle?: string;
  certifications?: string;
  shopName?: string;
  businessCategory?: string;
  shopAddress?: string;
  businessRegistrationNumber?: string;
  onSave: (data: { 
    fullName?: string; 
    phone?: string; 
    avatar?: string;
    address?: string;
    province?: string;
    district?: string;
    municipality?: string;
    bio?: string;
    yearsOfExperience?: number;
    skillsOrTags?: string[];
    professionalTitle?: string;
    certifications?: string;
    shopName?: string;
    businessCategory?: string;
    shopAddress?: string;
    businessRegistrationNumber?: string;
  }) => void;
}

export default function SharedProfileSettings({
  roleName,
  username,
  userEmail,
  userPhone = '',
  userAvatar,
  registrationDate = '',
  emailVerified = 'Verified',
  accountStatus = 'Active',
  address: initialAddress = '',
  province: initialProvince = '',
  district: initialDistrict = '',
  municipality: initialMunicipality = '',
  bio: initialBio = '',
  yearsOfExperience: initialExp = 0,
  skillsOrTags: initialSkills = [],
  professionalTitle: initialTitle = '',
  certifications: initialCerts = '',
  shopName: initialShopName = '',
  businessCategory: initialCategory = '',
  shopAddress: initialShopAddress = '',
  businessRegistrationNumber: initialRegNo = '',
  onSave
}: SharedProfileSettingsProps) {
  const [fullName, setFullName] = useState(username);
  const [phone, setPhone] = useState(userPhone !== 'N/A' ? userPhone : '');
  const [avatar, setAvatar] = useState(userAvatar);
  const [displayEmail, setDisplayEmail] = useState(userEmail || auth.currentUser?.email || '');
  const [displayRegistrationDate, setDisplayRegistrationDate] = useState(registrationDate !== 'N/A' ? registrationDate : '');
  
  // Location fields
  const [address, setAddress] = useState(initialAddress);
  const [province, setProvince] = useState(initialProvince);
  const [district, setDistrict] = useState(initialDistrict);
  const [municipality, setMunicipality] = useState(initialMunicipality);
  const [bio, setBio] = useState(initialBio);

  // Role specific fields
  const [yearsOfExperience, setYearsOfExperience] = useState<number>(initialExp);
  const [skillsInput, setSkillsInput] = useState<string>(Array.isArray(initialSkills) ? initialSkills.join(', ') : '');
  const [professionalTitle, setProfessionalTitle] = useState(initialTitle);
  const [certifications, setCertifications] = useState(initialCerts);

  const [shopName, setShopName] = useState(initialShopName);
  const [businessCategory, setBusinessCategory] = useState(initialCategory);
  const [shopAddress, setShopAddress] = useState(initialShopAddress);
  const [businessRegistrationNumber, setBusinessRegistrationNumber] = useState(initialRegNo);

  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { theme, toggleTheme } = useTheme();

  // Password reset states
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [isSubmittingPassword, setIsSubmittingPassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Delete Account States
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteStep, setDeleteStep] = useState<'confirm' | 'password' | 'otp'>('confirm');
  const [deletePassword, setDeletePassword] = useState('');
  const [deletePasswordError, setDeletePasswordError] = useState('');
  const [isVerifyingPassword, setIsVerifyingPassword] = useState(false);
  const [deleteOtp, setDeleteOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [deleteOtpError, setDeleteOtpError] = useState('');
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [otpAttempts, setOtpAttempts] = useState(0);

  useEffect(() => {
    let timer: any;
    if (resendCooldown > 0) {
      timer = setInterval(() => setResendCooldown(prev => prev - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  const handleVerifyDeletePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeletePasswordError('');
    if (!deletePassword) {
      setDeletePasswordError('Please enter your current password.');
      return;
    }
    setIsVerifyingPassword(true);
    try {
      if (auth.currentUser && auth.currentUser.email) {
        const credential = EmailAuthProvider.credential(auth.currentUser.email, deletePassword);
        await reauthenticateWithCredential(auth.currentUser, credential);
      } else {
        const qAcc = query(collection(db, 'accounts'), where('email', '==', userEmail.toLowerCase()));
        const snap = await getDocs(qAcc);
        let valid = false;
        if (!snap.empty) {
          const data = snap.docs[0].data();
          if (data.password === deletePassword) valid = true;
        }
        if (!valid) {
          throw new Error('Incorrect password.');
        }
      }

      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOtp(otp);

      try {
        await fetch('/api/admin/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            recipients: [userEmail],
            subject: 'Account Deletion Verification',
            title: 'Account Deletion Verification',
            content: `Your verification code for temporary account deletion is:\n\n${otp}\n\nThis code expires in 5 minutes.`
          })
        });
      } catch (err) {
        console.warn("Email dispatch error:", err);
      }

      setDeleteStep('otp');
      setResendCooldown(60);
    } catch (err: any) {
      setDeletePasswordError('Incorrect password.');
    } finally {
      setIsVerifyingPassword(false);
    }
  };

  const handleResendDeleteOtp = async () => {
    if (resendCooldown > 0) return;
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    try {
      await fetch('/api/admin/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipients: [userEmail],
          subject: 'Account Deletion Verification',
          title: 'Account Deletion Verification',
          content: `Your new verification code for temporary account deletion is:\n\n${otp}\n\nThis code expires in 5 minutes.`
        })
      });
    } catch (err) {}
    setResendCooldown(60);
    setDeleteOtpError('');
  };

  const handleVerifyDeleteOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeleteOtpError('');
    if (otpAttempts >= 3) {
      setDeleteOtpError('Maximum attempt limit reached. Please request a new code.');
      return;
    }
    if (!deleteOtp || deleteOtp.trim() !== generatedOtp.trim()) {
      setOtpAttempts(prev => prev + 1);
      setDeleteOtpError('Invalid or expired OTP.');
      return;
    }

    setIsVerifyingOtp(true);
    try {
      const now = new Date();
      const payload = {
        status: 'Disabled',
        accountStatus: 'Disabled',
        deleteRequestedDate: now.toLocaleDateString(),
        deleteRequestedTime: now.toLocaleTimeString(),
        recoveryExpiryDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        deletedBy: 'User',
        otpVerified: 'Yes',
        recoveryAvailable: 'Yes',
        updatedAt: now.toISOString()
      };

      const qAcc = query(collection(db, 'accounts'), where('email', '==', userEmail.toLowerCase()));
      const snapAcc = await getDocs(qAcc);
      for (const d of snapAcc.docs) {
        await setDoc(doc(db, 'accounts', d.id), payload, { merge: true });
      }

      const qUsers = query(collection(db, 'users'), where('email', '==', userEmail.toLowerCase()));
      const snapUsers = await getDocs(qUsers);
      for (const d of snapUsers.docs) {
        await setDoc(doc(db, 'users', d.id), payload, { merge: true });
      }

      await auth.signOut();
      localStorage.clear();
      window.location.reload();
    } catch (err: any) {
      setDeleteOtpError(err.message || 'Failed to disable account.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Sync props from parent component when updated
  useEffect(() => {
    if (username) setFullName(username);
    if (userPhone && userPhone !== 'N/A') setPhone(userPhone);
    if (userAvatar) setAvatar(userAvatar);
    if (userEmail) setDisplayEmail(userEmail);
    if (registrationDate && registrationDate !== 'N/A') setDisplayRegistrationDate(registrationDate);
  }, [username, userPhone, userAvatar, userEmail, registrationDate]);

  // Sync from Firestore in real-time when user is logged in
  useEffect(() => {
    let unsub: (() => void) | null = null;

    const setupListener = (uid: string) => {
      unsub = onSnapshot(doc(db, 'accounts', uid), (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.email) setDisplayEmail(data.email);
          if (data.fullName && data.fullName !== fullName) setFullName(data.fullName);
          if (data.phone && data.phone !== 'N/A') setPhone(data.phone);
          if (data.avatar && data.avatar !== avatar) setAvatar(data.avatar);

          const regTime = data.registrationDateTime || data.registrationDate || data.createdAt;
          if (regTime) setDisplayRegistrationDate(regTime);

          if (data.address !== undefined) setAddress(data.address);
          if (data.province !== undefined) setProvince(data.province);
          if (data.district !== undefined) setDistrict(data.district);
          if (data.municipality !== undefined) setMunicipality(data.municipality);
          if (data.bio !== undefined) setBio(data.bio);
          if (data.yearsOfExperience !== undefined) setYearsOfExperience(Number(data.yearsOfExperience));
          if (data.professionalTitle !== undefined) setProfessionalTitle(data.professionalTitle);
          if (data.certifications !== undefined) setCertifications(data.certifications);
          if (data.shopName !== undefined) setShopName(data.shopName);
          if (data.businessCategory !== undefined) setBusinessCategory(data.businessCategory);
          if (data.shopAddress !== undefined) setShopAddress(data.shopAddress);
          if (data.businessRegistrationNumber !== undefined) setBusinessRegistrationNumber(data.businessRegistrationNumber);
          if (Array.isArray(data.skillsOrTags)) setSkillsInput(data.skillsOrTags.join(', '));
        }
      });
    };

    const user = auth.currentUser;
    if (user) {
      if (user.email) setDisplayEmail(user.email);
      if (user.metadata?.creationTime && (!displayRegistrationDate || displayRegistrationDate === 'N/A')) {
        try {
          const creationDate = new Date(user.metadata.creationTime);
          const formatted = creationDate.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
          });
          setDisplayRegistrationDate(formatted);
        } catch (e) {}
      }
      setupListener(user.uid);
    } else if (userEmail) {
      getDocs(query(collection(db, 'accounts'), where('email', '==', userEmail.toLowerCase().trim()))).then(snap => {
        if (!snap.empty) {
          setupListener(snap.docs[0].id);
        }
      }).catch(() => {});
    }

    return () => {
      if (unsub) unsub();
    };
  }, [userEmail]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 512, 0.85);
        setAvatar(optimized.dataUrl);
        saveProfileToFirestore(optimized.dataUrl);
      } catch {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            const base64Avatar = event.target.result as string;
            setAvatar(base64Avatar);
            saveProfileToFirestore(base64Avatar);
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const saveProfileToFirestore = async (customAvatar?: string) => {
    setIsSaving(true);
    const skillsArray = skillsInput
      ? skillsInput.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    const payload = {
      fullName: fullName.trim(),
      phone: phone.trim(),
      avatar: customAvatar || avatar,
      address: address.trim(),
      province: province.trim(),
      district: district.trim(),
      municipality: municipality.trim(),
      bio: bio.trim(),
      about: bio.trim(),
      yearsOfExperience: Number(yearsOfExperience) || 0,
      skillsOrTags: skillsArray,
      skills: skillsArray,
      professionalTitle: professionalTitle.trim(),
      professionType: professionalTitle.trim(),
      certifications: certifications.trim(),
      shopName: shopName.trim(),
      businessCategory: businessCategory.trim(),
      shopAddress: shopAddress.trim(),
      businessRegistrationNumber: businessRegistrationNumber.trim(),
      updatedAt: new Date().toISOString()
    };

    // Save locally via prop callback
    onSave(payload);

    // Save directly to Firestore if auth user exists
    const user = auth.currentUser;
    if (user) {
      try {
        await setDoc(doc(db, 'accounts', user.uid), payload, { merge: true });
        
        // Also update matching docs in users collection
        const qUsers = query(collection(db, 'users'), where('email', '==', user.email?.toLowerCase()));
        const uSnap = await getDocs(qUsers);
        for (const uDoc of uSnap.docs) {
          await setDoc(doc(db, 'users', uDoc.id), payload, { merge: true });
        }
      } catch (err) {
        console.warn("Firestore user sync error:", err);
      }
    }

    setIsSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess(false);

    if (!currentPassword) {
      setPasswordError('Please enter your current password.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    const user = auth.currentUser;
    if (!user || !user.email) {
      setPasswordError('You must be logged in to change your password.');
      return;
    }

    setIsSubmittingPassword(true);
    try {
      const credential = EmailAuthProvider.credential(user.email, currentPassword);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, newPassword);
      
      try {
        const updateData = { passwordLastChangedAt: new Date().toISOString() };
        await setDoc(doc(db, 'accounts', user.uid), updateData, { merge: true });
        
        const qUsers = query(collection(db, 'users'), where('email', '==', user.email.toLowerCase()));
        const usersSnap = await getDocs(qUsers);
        for (const uDoc of usersSnap.docs) {
          await setDoc(doc(db, 'users', uDoc.id), updateData, { merge: true });
        }
      } catch (e) {
        console.warn("Could not sync password to Firestore", e);
      }
      
      setPasswordSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setTimeout(() => {
        setIsChangingPassword(false);
        setPasswordSuccess(false);
      }, 3000);
    } catch (error: any) {
      console.error('Password change error:', error);
      if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        setPasswordError('Incorrect current password.');
      } else {
        let msg = error.message || 'Failed to update password.';
        setPasswordError(msg);
      }
    } finally {
      setIsSubmittingPassword(false);
    }
  };

  const isExpert = roleName.toLowerCase().includes('expert') || roleName.toLowerCase().includes('pro');
  const isShopkeeper = roleName.toLowerCase().includes('shopkeeper') || roleName.toLowerCase().includes('vendor') || roleName.toLowerCase().includes('seller');

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-[#c4c6cd]/40 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#041627] dark:text-white flex items-center gap-2">
            <User className="w-6 h-6 text-[#fd8b00]" /> {roleName} Profile & Personal Information
          </h1>
          <p className="text-xs text-[#44474c] dark:text-slate-300 mt-1">
            Manage your personal identity credentials, contact details, and workspace profile photo stored in real-time Firestore.
          </p>
        </div>
        <span className="text-xs bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 py-1.5 px-3 rounded-xl font-bold border border-emerald-200 dark:border-emerald-800/60 shrink-0">
          Account Status: {accountStatus}
        </span>
      </div>

      {saveSuccess && (
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 p-4 rounded-xl flex items-center gap-3 text-sm font-semibold animate-fadeIn">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Profile information updated and saved directly to Firebase Firestore!</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Left Column - Profile picture */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-[#c4c6cd]/40 dark:border-slate-800 shadow-sm flex flex-col items-center text-center justify-between min-h-[340px]">
          <div className="space-y-4 flex flex-col items-center w-full">
            <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider">Profile Photo</h3>
            
            <div className="relative mx-auto w-32 h-32 flex items-center justify-center">
              <img 
                src={avatar || "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80"}
                alt={fullName}
                className="w-32 h-32 rounded-2xl object-cover border-2 border-[#fd8b00] shadow-md transition-transform duration-200"
                referrerPolicy="no-referrer"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 p-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-full shadow-md transition-all duration-200 hover:scale-110 cursor-pointer flex items-center justify-center border-2 border-white dark:border-slate-800"
                id="upload-camera-icon"
                title="Change Photo"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            
            <input 
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/png, image/jpeg, image/webp"
              className="hidden"
            />

            <div className="w-full">
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-xs font-bold text-[#fd8b00] hover:underline cursor-pointer"
                id="choose-photo-btn"
              >
                Choose New Photo
              </button>
              
              <div className="mt-3 text-center space-y-0.5">
                <div className="text-sm font-bold text-[#041627] dark:text-white">{fullName}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[200px] mx-auto font-medium">{displayEmail || userEmail || 'N/A'}</div>
              </div>
            </div>
          </div>

          {/* Workspace Role Badge */}
          <div className="pt-4 w-full border-t border-slate-100 dark:border-slate-800 mt-4">
            <div className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider mb-1">Workspace Role</div>
            <div className="inline-block text-xs font-bold bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-400 py-1 px-3.5 rounded-full border border-amber-200 dark:border-amber-800/60">
              {roleName}
            </div>
          </div>

          {/* Theme Preferences */}
          <div className="pt-4 w-full border-t border-slate-100 dark:border-slate-800 mt-4 text-left">
            <div className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider mb-2">Display Mode</div>
            <div className="bg-slate-50 dark:bg-slate-800/80 p-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {theme === 'dark' ? (
                  <Moon className="w-4 h-4 text-amber-400" />
                ) : (
                  <Sun className="w-4 h-4 text-amber-500" />
                )}
                <div>
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400">
                    {theme === 'dark' ? 'Eye-friendly interface' : 'Bright interface'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={toggleTheme}
                className={`relative inline-flex h-6 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  theme === 'dark' ? 'bg-[#fd8b00]' : 'bg-slate-300'
                }`}
                title="Toggle Light/Dark Theme"
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out flex items-center justify-center ${
                    theme === 'dark' ? 'translate-x-6' : 'translate-x-0'
                  }`}
                >
                  {theme === 'dark' ? (
                    <Moon className="w-3 h-3 text-slate-900" />
                  ) : (
                    <Sun className="w-3 h-3 text-amber-500" />
                  )}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column - Comprehensive Personal Information Form */}
        <div className="md:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-[#c4c6cd]/40 dark:border-slate-800 shadow-sm space-y-6">
          
          {/* Section 1: Read-only Identity Metadata */}
          <div>
            <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#fd8b00]" /> Account Identity & System Status
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Email Address (Read-only)</label>
                <div className="relative">
                  <input 
                    type="email"
                    value={displayEmail || userEmail || ''}
                    disabled
                    className="w-full text-xs p-3 bg-slate-50 dark:bg-slate-800/60 border border-[#c4c6cd]/60 dark:border-slate-700 text-slate-600 dark:text-slate-200 rounded-xl cursor-not-allowed font-medium"
                  />
                  <span className="absolute right-3 top-3 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60">
                    {emailVerified}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Registration Date & Time</label>
                <input 
                  type="text"
                  value={displayRegistrationDate || registrationDate || 'N/A'}
                  disabled
                  className="w-full text-xs p-3 bg-slate-50 dark:bg-slate-800/60 border border-[#c4c6cd]/60 dark:border-slate-700 text-slate-600 dark:text-slate-200 rounded-xl cursor-not-allowed font-mono"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Personal & Contact Information */}
          <div>
            <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <User className="w-4 h-4 text-[#fd8b00]" /> Personal & Contact Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Full Name *</label>
                <input 
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl focus:outline-none focus:border-[#fd8b00] font-sans font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Phone Number</label>
                <input 
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl focus:outline-none focus:border-[#fd8b00] font-mono font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Street Address</label>
                <input 
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. New Baneshwor, Ward 10"
                  className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Province</label>
                <input 
                  type="text"
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  placeholder="e.g. Bagmati Province"
                  className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">District</label>
                <input 
                  type="text"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  placeholder="e.g. Kathmandu"
                  className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Municipality / Rural Muni</label>
                <input 
                  type="text"
                  value={municipality}
                  onChange={(e) => setMunicipality(e.target.value)}
                  placeholder="e.g. Kathmandu Metropolitan City"
                  className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Role Specific Professional / Shop Information */}
          {isExpert && (
            <div>
              <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <Award className="w-4 h-4 text-[#fd8b00]" /> Professional Expert Details
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Professional Title</label>
                  <input 
                    type="text"
                    value={professionalTitle}
                    onChange={(e) => setProfessionalTitle(e.target.value)}
                    placeholder="e.g. Senior Structural Engineer"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Years of Experience</label>
                  <input 
                    type="number"
                    value={yearsOfExperience}
                    onChange={(e) => setYearsOfExperience(Number(e.target.value))}
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>

                <div className="col-span-full">
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Skills & Specializations (Comma separated)</label>
                  <input 
                    type="text"
                    value={skillsInput}
                    onChange={(e) => setSkillsInput(e.target.value)}
                    placeholder="e.g. Blueprint Design, Structural Audit, 3D Rendering, HVAC"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>

                <div className="col-span-full">
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Certifications / Licenses</label>
                  <input 
                    type="text"
                    value={certifications}
                    onChange={(e) => setCertifications(e.target.value)}
                    placeholder="e.g. Nepal Engineering Council License #1234"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>
              </div>
            </div>
          )}

          {isShopkeeper && (
            <div>
              <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <Store className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> Shop & Business Credentials
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Shop Name</label>
                  <input 
                    type="text"
                    value={shopName}
                    onChange={(e) => setShopName(e.target.value)}
                    placeholder="e.g. Everest Hardware & Suppliers"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Business Category</label>
                  <input 
                    type="text"
                    value={businessCategory}
                    onChange={(e) => setBusinessCategory(e.target.value)}
                    placeholder="e.g. Cement, Steel & Electricals"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Shop Address</label>
                  <input 
                    type="text"
                    value={shopAddress}
                    onChange={(e) => setShopAddress(e.target.value)}
                    placeholder="e.g. Koteshwor Ring Road Shop #12"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Business Registration Number (PAN/VAT)</label>
                  <input 
                    type="text"
                    value={businessRegistrationNumber}
                    onChange={(e) => setBusinessRegistrationNumber(e.target.value)}
                    placeholder="e.g. PAN 60281938"
                    className="w-full text-xs p-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-mono font-medium"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Section 4: Bio / About Me Description */}
          <div>
            <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#fd8b00]" /> Bio / About Me
            </h3>
            <textarea 
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell clients and partners about your experience, project goals, or business overview..."
              className="w-full text-xs p-3 mt-3 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 dark:placeholder-slate-500 rounded-xl focus:outline-none focus:border-[#fd8b00] font-medium leading-relaxed"
            />
          </div>

          {/* Section 5: Password Change Drawer or Action Buttons */}
          {isChangingPassword ? (
            <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 animate-fadeIn">
              <h3 className="text-xs font-extrabold text-[#041627] dark:text-white uppercase tracking-wider mb-4 flex items-center justify-between">
                <span>Change Account Password</span>
                <button 
                  type="button" 
                  onClick={() => {
                    setIsChangingPassword(false);
                    setPasswordError('');
                    setPasswordSuccess(false);
                    setCurrentPassword('');
                    setNewPassword('');
                    setConfirmNewPassword('');
                    setShowPassword(false);
                  }}
                  className="text-slate-400 hover:text-[#041627] dark:hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </h3>
              
              <form onSubmit={handlePasswordChange} className="space-y-4 max-w-sm">
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] dark:text-slate-300 mb-1">Current Password</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="w-full text-xs p-3 pr-10 bg-white dark:bg-slate-800 border border-[#c4c6cd] dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl focus:outline-none focus:border-[#fd8b00] font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1">New Password</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full text-xs p-3 pr-10 bg-white border border-[#c4c6cd] rounded-xl focus:outline-none focus:border-[#fd8b00] font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1">Confirm New Password</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      className="w-full text-xs p-3 pr-10 bg-white border border-[#c4c6cd] rounded-xl focus:outline-none focus:border-[#fd8b00] font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {passwordError && (
                  <div className="p-3 bg-red-50 text-red-600 border border-red-100 rounded-xl text-xs text-left font-medium">
                    {passwordError}
                  </div>
                )}
                {passwordSuccess && (
                  <div className="p-3 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-xl text-xs text-left flex items-center gap-2 font-semibold">
                    <CheckCircle className="w-4 h-4" />
                    Password updated successfully!
                  </div>
                )}

                <button 
                  type="submit"
                  disabled={isSubmittingPassword}
                  className="w-full py-3 bg-[#041627] hover:bg-[#0b1c30] text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50 cursor-pointer"
                >
                  {isSubmittingPassword ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            </div>
          ) : (
            <div className="pt-4 flex flex-wrap justify-between items-center gap-3 border-t border-slate-100">
              <div className="flex items-center gap-3">
                <button 
                  type="button"
                  onClick={() => setIsChangingPassword(true)}
                  className="px-5 py-3 bg-white border border-[#c4c6cd] hover:border-[#fd8b00] hover:text-[#fd8b00] text-[#44474c] rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Key className="w-4 h-4 text-[#fd8b00]" /> Change Password
                </button>

                <button 
                  type="button"
                  onClick={() => {
                    setShowDeleteModal(true);
                    setDeleteStep('confirm');
                    setDeletePassword('');
                    setDeletePasswordError('');
                    setDeleteOtp('');
                    setDeleteOtpError('');
                    setOtpAttempts(0);
                  }}
                  className="px-5 py-3 bg-red-50 border border-red-200 hover:bg-red-100 text-red-600 rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-sm"
                >
                  <Trash2 className="w-4 h-4 text-red-500" /> Delete Account
                </button>
              </div>

              <button 
                type="button"
                onClick={() => saveProfileToFirestore()}
                disabled={isSaving}
                className="px-6 py-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-xl font-bold text-xs shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" /> {isSaving ? 'Saving to Firestore...' : 'Save Profile Changes'}
              </button>
            </div>
          )}

          {/* Delete Account Modal */}
          {showDeleteModal && (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5 text-red-600">
                    <AlertTriangle className="w-5 h-5" />
                    <h3 className="text-base font-extrabold text-[#041627]">Delete Account</h3>
                  </div>
                  <button 
                    onClick={() => setShowDeleteModal(false)}
                    className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {deleteStep === 'confirm' && (
                  <div className="space-y-4 text-xs">
                    <p className="text-slate-600 leading-relaxed font-medium">
                      This action will temporarily disable your account for 30 days. During this period, you can recover your account by logging in. After 30 days, your account can be permanently deleted by the administrator.
                    </p>
                    <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setShowDeleteModal(false)}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteStep('password')}
                        className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-all shadow-md cursor-pointer"
                      >
                        Continue
                      </button>
                    </div>
                  </div>
                )}

                {deleteStep === 'password' && (
                  <form onSubmit={handleVerifyDeletePassword} className="space-y-4 text-xs">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Current Password</label>
                      <input 
                        type="password"
                        value={deletePassword}
                        onChange={(e) => setDeletePassword(e.target.value)}
                        placeholder="Enter your current account password"
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-red-500 font-sans"
                        required
                      />
                    </div>
                    {deletePasswordError && (
                      <div className="p-3 bg-red-50 text-red-600 border border-red-100 rounded-xl font-medium">
                        {deletePasswordError}
                      </div>
                    )}
                    <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setDeleteStep('confirm')}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all cursor-pointer"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        disabled={isVerifyingPassword}
                        className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50"
                      >
                        {isVerifyingPassword ? 'Verifying...' : 'Continue'}
                      </button>
                    </div>
                  </form>
                )}

                {deleteStep === 'otp' && (
                  <form onSubmit={handleVerifyDeleteOtp} className="space-y-4 text-xs">
                    <p className="text-slate-600 font-medium">
                      Enter the 6-digit verification code sent to <span className="font-bold text-[#041627]">{userEmail}</span>. This code expires in 5 minutes.
                    </p>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Enter OTP</label>
                      <input 
                        type="text"
                        maxLength={6}
                        value={deleteOtp}
                        onChange={(e) => setDeleteOtp(e.target.value)}
                        placeholder="e.g. 482910"
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-red-500 font-mono tracking-widest text-center text-sm font-bold"
                        required
                      />
                    </div>
                    {deleteOtpError && (
                      <div className="p-3 bg-red-50 text-red-600 border border-red-100 rounded-xl font-medium">
                        {deleteOtpError}
                      </div>
                    )}
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>Attempts remaining: {3 - otpAttempts}</span>
                      <button
                        type="button"
                        onClick={handleResendDeleteOtp}
                        disabled={resendCooldown > 0}
                        className="text-[#fd8b00] hover:underline font-bold disabled:opacity-50 cursor-pointer"
                      >
                        {resendCooldown > 0 ? `Resend OTP in ${resendCooldown}s` : 'Resend OTP'}
                      </button>
                    </div>
                    <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setDeleteStep('password')}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all cursor-pointer"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        disabled={isVerifyingOtp}
                        className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50"
                      >
                        {isVerifyingOtp ? 'Disabling Account...' : 'Verify & Disable'}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
