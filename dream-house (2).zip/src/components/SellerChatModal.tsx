import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Send, Image as ImageIcon, CheckCheck, Check, Clock, 
  Store, Building2, Paperclip, AlertCircle, Sparkles
} from 'lucide-react';
import { SellerInfo } from '../types';
import { subscribeToUserMessages, sendChatMessage, markConversationAsRead, ChatMessage } from '../lib/messaging';
import { subscribeToPresence } from '../lib/presence';
import UserProfileModal from './UserProfileModal';

import { optimizeImage } from '../lib/fileUploader';

interface SellerChatModalProps {
  seller: SellerInfo | null;
  isOpen: boolean;
  onClose: () => void;
  currentUserEmail?: string;
  currentUserName?: string;
  currentUserAvatar?: string;
  presenceMap?: Record<string, boolean>;
}

const SAMPLE_ATTACHMENTS = [
  { label: 'Site Plan Blueprint', url: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600&auto=format&fit=crop&q=80' },
  { label: 'Brick Measurement Spec', url: 'https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=600&auto=format&fit=crop&q=80' },
  { label: 'Rebar Delivery Receipt', url: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?w=600&auto=format&fit=crop&q=80' }
];

export default function SellerChatModal({
  seller,
  isOpen,
  onClose,
  currentUserEmail = 'homeowner@gmail.com',
  currentUserName = 'Demo Homeowner',
  currentUserAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
  presenceMap: presenceMapProp
}: SellerChatModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [presenceMapState, setPresenceMapState] = useState<Record<string, boolean>>({});
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [showImageInput, setShowImageInput] = useState(false);
  const [selectedProfileEmail, setSelectedProfileEmail] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sellerEmail = (seller?.email || 'shopkeeper@gmail.com').toLowerCase().trim();
  const buyerEmail = (currentUserEmail || 'homeowner@gmail.com').toLowerCase().trim();

  // Consistent conversationId by sorting emails
  const emails = [buyerEmail, sellerEmail].sort();
  const conversationId = `${emails[0]}_${emails[1]}`;

  // Presence listener
  useEffect(() => {
    if (presenceMapProp) {
      setPresenceMapState(presenceMapProp);
      return;
    }
    const unsub = subscribeToPresence((pMap) => setPresenceMapState(pMap));
    return () => unsub();
  }, [presenceMapProp]);

  const isSellerOnline = presenceMapState[sellerEmail] !== undefined ? presenceMapState[sellerEmail] : true;

  // Real-time Firestore subscription
  useEffect(() => {
    if (!isOpen || !currentUserEmail) return;

    const unsubscribe = subscribeToUserMessages(currentUserEmail, (allUserMsgs) => {
      const filtered = allUserMsgs.filter(m => m.conversationId === conversationId);
      setMessages(filtered);
    });

    return () => unsubscribe();
  }, [isOpen, conversationId, currentUserEmail]);

  // Mark unread messages as read
  useEffect(() => {
    if (isOpen && conversationId && currentUserEmail) {
      markConversationAsRead(conversationId, currentUserEmail);
    }
  }, [isOpen, conversationId, currentUserEmail, messages]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen || !seller) return null;

  const handleSendMessage = async (e?: React.FormEvent, attachmentUrl?: string) => {
    if (e) e.preventDefault();

    const textToSend = inputText.trim();
    const finalImageUrl = attachmentUrl || selectedImage || (customImageUrl.trim() ? customImageUrl.trim() : undefined);

    if (!textToSend && !finalImageUrl) return;

    const newMessage: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 8)}`,
      conversationId,
      senderId: currentUserEmail,
      senderEmail: currentUserEmail,
      senderName: currentUserName,
      senderRole: 'homeowner',
      senderAvatar: currentUserAvatar,
      recipientId: seller.email,
      recipientEmail: seller.email,
      recipientName: seller.shopName || seller.name,
      recipientRole: 'shopkeeper',
      recipientAvatar: seller.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      text: textToSend || 'Sent an attachment',
      imageUrl: finalImageUrl,
      timestamp: Date.now(),
      read: false
    };

    setInputText('');
    setSelectedImage(null);
    setCustomImageUrl('');
    setShowAttachMenu(false);
    setShowImageInput(false);

    try {
      await sendChatMessage(newMessage);

      // Trigger shopkeeper auto reply if first contact
      setTimeout(async () => {
        const replyText = getShopkeeperAutoReply(textToSend, seller.shopName || seller.name);
        const autoReply: ChatMessage = {
          id: `msg_reply_${Date.now()}_${Math.random().toString(36).substr(2, 8)}`,
          conversationId,
          senderId: seller.email,
          senderEmail: seller.email,
          senderName: seller.shopName || seller.name,
          senderRole: 'shopkeeper',
          senderAvatar: seller.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          recipientId: currentUserEmail,
          recipientEmail: currentUserEmail,
          recipientName: currentUserName,
          recipientRole: 'homeowner',
          recipientAvatar: currentUserAvatar,
          text: replyText,
          timestamp: Date.now() + 500,
          read: true
        };
        await sendChatMessage(autoReply);
      }, 1200);
    } catch (err) {
      console.warn("Error sending message in SellerChatModal:", err);
    }
  };

  const getShopkeeperAutoReply = (query: string, shopName: string) => {
    const q = query.toLowerCase();
    if (q.includes('bulk') || q.includes('price') || q.includes('discount')) {
      return `Hello! Thanks for asking. Yes, at ${shopName}, we offer contractor bulk discounts on orders over Rs. 1,000 with direct jobsite delivery.`;
    }
    if (q.includes('deliver') || q.includes('shipping') || q.includes('freight')) {
      return `Hi there! We process local site deliveries within 24–48 hours across the metro area. Freight logistics options are available in cart.`;
    }
    if (q.includes('available') || q.includes('stock')) {
      return `Hello! Yes, all items listed on our ${shopName} page are currently in stock and ready for immediate loading or dispatch!`;
    }
    return `Hello! Thanks for reaching out to ${shopName}. We have received your inquiry and our dispatch team will answer any specific technical questions right away.`;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 1200, 0.85);
        setSelectedImage(optimized.dataUrl);
      } catch {
        const reader = new FileReader();
        reader.onloadend = () => {
          setSelectedImage(reader.result as string);
        };
        reader.readAsDataURL(file);
      }
      setShowAttachMenu(false);
    }
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#041627]/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-fade-in">
      <div 
        className="bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col h-[90vh] max-h-[680px] animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="bg-[#1a2b3c] text-white px-5 py-3.5 flex items-center justify-between shadow-md shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={seller.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"} 
                alt={seller.shopName || seller.name} 
                title={`View ${seller.shopName || seller.name}'s Profile`}
                onClick={() => setSelectedProfileEmail(seller.email)}
                className="w-10 h-10 rounded-full object-cover border-2 border-[#fd8b00] cursor-pointer hover:scale-105 transition-all"
                referrerPolicy="no-referrer"
              />
              {isSellerOnline && (
                <span className="w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#1a2b3c] absolute bottom-0 right-0" title="Online now"></span>
              )}
            </div>

            <div>
              <h3 
                onClick={() => setSelectedProfileEmail(seller.email)}
                className="text-sm font-bold text-white leading-tight flex items-center gap-1.5 cursor-pointer hover:text-[#fd8b00] transition-colors"
              >
                {seller.shopName || seller.name}
              </h3>
              <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                <span>●</span> Active Vendor • {seller.phone || seller.email}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 text-white/80 hover:text-white rounded-full transition-colors cursor-pointer"
            title="Close chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="bg-amber-50 border-b border-amber-200/80 px-4 py-2 flex items-center justify-between text-[11px] text-amber-900 shrink-0">
          <span className="font-medium flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#fd8b00]" />
            Direct chat with supplier — responses usually within 5 mins
          </span>
          <span className="text-[10px] bg-amber-200/60 font-bold px-2 py-0.5 rounded text-amber-800">
            Verified Store
          </span>
        </div>

        {/* Message Thread Box */}
        <div className="flex-1 overflow-y-auto no-scrollbar scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden p-4 space-y-3 bg-[#f8f9ff]">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3 my-auto">
              <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-md border border-slate-200 text-[#fd8b00]">
                <Store className="w-7 h-7" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#041627]">Start a conversation with {seller.shopName || seller.name}</h4>
                <p className="text-xs text-slate-500 max-w-xs mt-1 leading-relaxed">
                  Ask about product availability, bulk discounts, custom jobsite dispatch, or delivery options.
                </p>
              </div>

              {/* Quick Inquiry Chips */}
              <div className="pt-2 flex flex-wrap gap-2 justify-center max-w-sm">
                {[
                  "Is this item available in bulk?",
                  "What is your freight delivery estimate?",
                  "Can I request a custom price quote?"
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(undefined, undefined)}
                    className="text-[11px] bg-white hover:bg-amber-50 text-slate-700 hover:text-[#041627] font-medium px-3 py-1.5 rounded-full border border-slate-200 shadow-sm transition-all cursor-pointer"
                  >
                    "{chip}"
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isBuyer = msg.senderId.toLowerCase() === buyerEmail;

              return (
                <div 
                  key={msg.id}
                  className={`flex items-end gap-2 ${isBuyer ? 'justify-end' : 'justify-start'}`}
                >
                  {!isBuyer && (
                    <img
                      src={msg.senderAvatar || seller.avatar}
                      alt={msg.senderName}
                      title={`View ${msg.senderName}'s Profile`}
                      onClick={() => setSelectedProfileEmail(msg.senderEmail || msg.senderId || seller.email)}
                      className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0 cursor-pointer hover:ring-2 hover:ring-[#fd8b00] hover:scale-105 transition-all"
                      referrerPolicy="no-referrer"
                    />
                  )}

                  <div className={`max-w-[80%] space-y-1 ${isBuyer ? 'items-end' : 'items-start'}`}>
                    <div 
                      className={`p-3 rounded-2xl text-xs shadow-sm leading-relaxed ${
                        isBuyer 
                          ? 'bg-[#1a2b3c] text-white rounded-br-xs' 
                          : 'bg-white text-slate-800 border border-slate-200/90 rounded-bl-xs'
                      }`}
                    >
                      {msg.imageUrl && (
                        <div className="mb-2 rounded-lg overflow-hidden border border-black/10 max-h-48">
                          <img src={msg.imageUrl} alt="Attachment" className="w-full h-full object-cover" />
                        </div>
                      )}
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    </div>

                    <div className={`flex items-center gap-1.5 text-[9px] text-slate-400 px-1 ${isBuyer ? 'justify-end' : 'justify-start'}`}>
                      <span>{formatTime(msg.timestamp)}</span>
                      {isBuyer && (
                        msg.read ? (
                          <CheckCheck className="w-3 h-3 text-emerald-500" title="Read" />
                        ) : (
                          <Check className="w-3 h-3 text-slate-400" title="Sent" />
                        )
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Selected Image Preview Bar */}
        {selectedImage && (
          <div className="p-2 bg-slate-100 border-t border-slate-200 flex items-center justify-between px-4 text-xs">
            <div className="flex items-center gap-2">
              <img src={selectedImage} alt="Preview" className="w-8 h-8 rounded object-cover border" />
              <span className="text-slate-700 font-semibold text-[11px]">Image attached</span>
            </div>
            <button 
              onClick={() => setSelectedImage(null)}
              className="text-red-500 hover:text-red-700 p-1 font-bold text-xs"
            >
              Remove
            </button>
          </div>
        )}

        {/* Image URL Input Drawer */}
        {showImageInput && (
          <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center gap-2">
            <input
              type="url"
              placeholder="Paste image URL (https://...)"
              value={customImageUrl}
              onChange={(e) => setCustomImageUrl(e.target.value)}
              className="flex-1 bg-white border border-slate-300 rounded-lg text-xs px-3 py-1.5 outline-none focus:border-[#fd8b00]"
            />
            <button
              onClick={() => {
                if (customImageUrl.trim()) {
                  setSelectedImage(customImageUrl.trim());
                  setShowImageInput(false);
                }
              }}
              className="px-3 py-1.5 bg-[#1a2b3c] text-white text-xs font-bold rounded-lg"
            >
              Attach
            </button>
            <button
              onClick={() => setShowImageInput(false)}
              className="p-1.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Attach Menu Drawer */}
        {showAttachMenu && (
          <div className="p-3 bg-slate-100 border-t border-slate-200 space-y-2 animate-fade-in">
            <p className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">Quick Jobsite Attachments:</p>
            <div className="grid grid-cols-3 gap-2">
              {SAMPLE_ATTACHMENTS.map((att, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setSelectedImage(att.url);
                    setShowAttachMenu(false);
                  }}
                  className="bg-white hover:bg-amber-50 p-2 rounded-lg border border-slate-200 text-left transition-all cursor-pointer"
                >
                  <p className="text-[10px] font-bold text-slate-800 truncate">{att.label}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Bar */}
        <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowAttachMenu(!showAttachMenu)}
            className="p-2 text-slate-500 hover:text-[#fd8b00] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title="Attach sample image"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-slate-500 hover:text-[#fd8b00] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title="Upload photo file"
          >
            <ImageIcon className="w-4 h-4" />
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileUpload} 
            accept="image/*" 
            className="hidden" 
          />

          <textarea
            rows={1}
            placeholder={`Message ${seller.shopName || seller.name}...`}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            className="flex-1 bg-slate-100 border border-slate-200 text-xs rounded-xl px-4 py-2.5 outline-none focus:border-[#fd8b00] focus:ring-1 focus:ring-[#fd8b00] focus:bg-white transition-all text-slate-800 resize-none overflow-y-auto max-h-24 no-scrollbar scrollbar-none"
          />

          <button
            type="submit"
            disabled={!inputText.trim() && !selectedImage}
            className={`p-2.5 rounded-xl font-bold transition-all cursor-pointer ${
              inputText.trim() || selectedImage
                ? 'bg-[#fd8b00] hover:bg-[#e07b00] text-white shadow-md active:scale-95'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
            title="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* User Profile Modal */}
      {selectedProfileEmail && (
        <UserProfileModal
          userEmailOrId={selectedProfileEmail}
          onClose={() => setSelectedProfileEmail(null)}
          presenceMap={presenceMapState}
        />
      )}
    </div>
  );
}
