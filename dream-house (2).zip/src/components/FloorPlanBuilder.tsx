import React, { useState, useRef, useEffect, useCallback } from 'react';
import { auth } from '../lib/firebase';
import { 
  ArrowLeft, Plus, Trash2, LayoutGrid, Download, CheckCircle, 
  Send, ZoomIn, ZoomOut, Copy, RotateCw, Save, 
  FolderOpen, Sliders, Layers, Eye, EyeOff, Lock, Unlock, 
  MousePointer, Hand, Undo2, Redo2, FileText, Printer, Search, 
  ChevronRight, ChevronDown, ChevronUp, Move, Maximize2, Minimize2, Grid, 
  Settings2, Scissors, Clipboard, RefreshCw, Compass, HelpCircle, 
  Ruler, Box, Type, Shield, Sparkles, Building2, Home, Store, 
  Briefcase, Utensils, GraduationCap, Hospital, Warehouse, Check,
  Share2, Image as ImageIcon
} from 'lucide-react';

// Measurement Units
export type MeasurementUnit = 'ft' | 'm' | 'cm' | 'in' | 'mm';

export interface FloorElement {
  id: string;
  type: 'room' | 'wall' | 'door' | 'window' | 'furniture' | 'staircase' | 'column' | 'balcony' | 'garage' | 'garden' | 'pool' | 'dimension' | 'text';
  subType?: string;
  name: string;
  x: number; // in feet on grid
  y: number; // in feet on grid
  width: number; // in feet
  height: number; // in feet (length)
  rotation: number; // degrees
  thickness?: number; // for walls (in inches)
  color?: string;
  fillTexture?: string; // wood, marble, tile, carpet, concrete, brick, water, grass
  strokeColor?: string;
  opacity?: number;
  locked?: boolean;
  visible?: boolean;
  layerId?: string;
  // Door & Window specific
  doorDirection?: 'left' | 'right';
  swingSide?: 'inside' | 'outside';
  openAngle?: number; // 0 - 90
  // Wall specific
  wallType?: 'straight' | 'l-shape' | 'curved';
  // Text specific
  fontSize?: number;
  textContent?: string;
}

export interface Layer {
  id: string;
  elementId: string;
  name: string;
  visible: boolean;
  locked: boolean;
  color: string;
}

const GET_LAYER_COLOR = (type?: string): string => {
  switch (type) {
    case 'room': return '#3b82f6';
    case 'wall': return '#64748b';
    case 'door':
    case 'window': return '#eab308';
    case 'furniture': return '#ec4899';
    case 'pool':
    case 'garden': return '#06b6d4';
    case 'balcony':
    case 'garage': return '#f97316';
    case 'staircase': return '#8b5cf6';
    case 'dimension':
    case 'text': return '#10b981';
    default: return '#6366f1';
  }
};

const createInitialLayers = (els: FloorElement[]): Layer[] => {
  return els.map(el => ({
    id: `layer-${el.id}`,
    elementId: el.id,
    name: el.name || 'Room Block',
    visible: el.visible !== false,
    locked: el.locked === true,
    color: GET_LAYER_COLOR(el.type)
  }));
};

export interface SavedProject {
  id: string;
  name: string;
  date: string;
  unit: MeasurementUnit;
  elements: FloorElement[];
  layers: Layer[];
}

interface FloorPlanBuilderProps {
  onBackToDashboard: () => void;
}

// Textures & Gradients definitions
const TEXTURES: Record<string, { name: string; fill: string; stroke: string; preview: string }> = {
  oak: { name: 'Warm Oak Wood', fill: '#f5ebe0', stroke: '#d4a373', preview: 'linear-gradient(135deg, #f5ebe0, #e6ccb2)' },
  walnut: { name: 'Dark Walnut', fill: '#8d6e63', stroke: '#5d4037', preview: 'linear-gradient(135deg, #8d6e63, #4e342e)' },
  marble: { name: 'Carrara Marble', fill: '#f8fafc', stroke: '#cbd5e1', preview: 'linear-gradient(135deg, #ffffff, #e2e8f0)' },
  tile: { name: 'Ceramic Tile', fill: '#f1f5f9', stroke: '#94a3b8', preview: 'linear-gradient(135deg, #f8fafc, #cbd5e1)' },
  concrete: { name: 'Polished Concrete', fill: '#e2e8f0', stroke: '#64748b', preview: 'linear-gradient(135deg, #f1f5f9, #94a3b8)' },
  carpet: { name: 'Soft Linen Carpet', fill: '#fef3c7', stroke: '#f59e0b', preview: 'linear-gradient(135deg, #fef3c7, #fde68a)' },
  grass: { name: 'Lawn Grass', fill: '#dcfce7', stroke: '#22c55e', preview: 'linear-gradient(135deg, #dcfce7, #86efac)' },
  water: { name: 'Swimming Pool Water', fill: '#e0f2fe', stroke: '#0284c7', preview: 'linear-gradient(135deg, #e0f2fe, #38bdf8)' },
  brick: { name: 'Red Brick', fill: '#fee2e2', stroke: '#ef4444', preview: 'linear-gradient(135deg, #fee2e2, #fca5a5)' },
  plaster: { name: 'Clean White Plaster', fill: '#ffffff', stroke: '#475569', preview: '#ffffff' }
};

// Preset Templates
const PRESET_TEMPLATES: Record<string, { name: string; icon: string; elements: FloorElement[] }> = {
  '1bed': {
    name: '1 Bedroom Modern Apartment',
    icon: 'Home',
    elements: [
      { id: 't1-r1', type: 'room', name: 'Living & Dining Room', x: 10, y: 10, width: 20, height: 16, rotation: 0, fillTexture: 'oak', strokeColor: '#1e293b', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't1-r2', type: 'room', name: 'Master Bedroom', x: 30, y: 10, width: 16, height: 14, rotation: 0, fillTexture: 'carpet', strokeColor: '#1e293b', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't1-r3', type: 'room', name: 'Kitchen Zone', x: 10, y: 26, width: 14, height: 12, rotation: 0, fillTexture: 'tile', strokeColor: '#1e293b', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't1-r4', type: 'room', name: 'Luxury Bath', x: 24, y: 26, width: 10, height: 12, rotation: 0, fillTexture: 'marble', strokeColor: '#1e293b', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't1-d1', type: 'door', name: 'Main Entry Door', x: 10, y: 18, width: 3, height: 3, rotation: 0, doorDirection: 'left', swingSide: 'inside', layerId: 'layer-openings', visible: true, locked: false },
      { id: 't1-d2', type: 'door', name: 'Bedroom Door', x: 30, y: 16, width: 3, height: 3, rotation: 90, doorDirection: 'left', swingSide: 'inside', layerId: 'layer-openings', visible: true, locked: false },
      { id: 't1-w1', type: 'window', name: 'Living Window', x: 18, y: 10, width: 6, height: 1, rotation: 0, layerId: 'layer-openings', visible: true, locked: false },
      { id: 't1-w2', type: 'window', name: 'Bedroom Window', x: 38, y: 10, width: 5, height: 1, rotation: 0, layerId: 'layer-openings', visible: true, locked: false },
      { id: 't1-f1', type: 'furniture', subType: 'King Bed', name: 'King Bed', x: 34, y: 13, width: 7, height: 7, rotation: 0, fillTexture: 'plaster', layerId: 'layer-furniture', visible: true, locked: false },
      { id: 't1-f2', type: 'furniture', subType: 'Sectional Sofa', name: 'L-Sofa', x: 12, y: 12, width: 8, height: 6, rotation: 0, fillTexture: 'plaster', layerId: 'layer-furniture', visible: true, locked: false },
      { id: 't1-f3', type: 'furniture', subType: 'Dining Table', name: '4-Seat Dining', x: 21, y: 18, width: 6, height: 4, rotation: 0, fillTexture: 'oak', layerId: 'layer-furniture', visible: true, locked: false }
    ]
  },
  '2bed': {
    name: '2 Bedroom Family Home',
    icon: 'Building2',
    elements: [
      { id: 't2-r1', type: 'room', name: 'Grand Living Salon', x: 10, y: 10, width: 24, height: 18, rotation: 0, fillTexture: 'oak', strokeColor: '#0f172a', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't2-r2', type: 'room', name: 'Primary Suite', x: 34, y: 10, width: 18, height: 16, rotation: 0, fillTexture: 'carpet', strokeColor: '#0f172a', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't2-r3', type: 'room', name: 'Guest Bed', x: 34, y: 26, width: 18, height: 14, rotation: 0, fillTexture: 'carpet', strokeColor: '#0f172a', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't2-r4', type: 'room', name: 'Open Kitchen', x: 10, y: 28, width: 14, height: 12, rotation: 0, fillTexture: 'tile', strokeColor: '#0f172a', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't2-r5', type: 'room', name: 'Family Bathroom', x: 24, y: 28, width: 10, height: 12, rotation: 0, fillTexture: 'marble', strokeColor: '#0f172a', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't2-d1', type: 'door', name: 'Main Double Door', x: 18, y: 10, width: 6, height: 3, rotation: 0, doorDirection: 'right', swingSide: 'inside', layerId: 'layer-openings', visible: true, locked: false },
      { id: 't2-f1', type: 'furniture', subType: 'King Bed', name: 'Master Bed', x: 38, y: 13, width: 7, height: 7, rotation: 0, layerId: 'layer-furniture', visible: true, locked: false },
      { id: 't2-f2', type: 'furniture', subType: 'Single Bed', name: 'Guest Bed', x: 38, y: 29, width: 5, height: 7, rotation: 0, layerId: 'layer-furniture', visible: true, locked: false }
    ]
  },
  'villa': {
    name: '3 Bedroom Luxury Estate',
    icon: 'Home',
    elements: [
      { id: 't3-r1', type: 'room', name: 'Great Room', x: 15, y: 10, width: 28, height: 20, rotation: 0, fillTexture: 'marble', strokeColor: '#0284c7', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't3-r2', type: 'room', name: 'Master Bedroom', x: 43, y: 10, width: 20, height: 18, rotation: 0, fillTexture: 'oak', strokeColor: '#0284c7', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't3-r3', type: 'room', name: 'Bedroom 2', x: 43, y: 28, width: 16, height: 14, rotation: 0, fillTexture: 'carpet', strokeColor: '#0284c7', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't3-r4', type: 'room', name: 'Bedroom 3', x: 43, y: 42, width: 16, height: 14, rotation: 0, fillTexture: 'carpet', strokeColor: '#0284c7', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't3-p1', type: 'pool', name: 'Resort Swimming Pool', x: 15, y: 34, width: 24, height: 18, rotation: 0, fillTexture: 'water', strokeColor: '#0284c7', layerId: 'layer-walls', visible: true, locked: false },
      { id: 't3-g1', type: 'garage', name: 'Double Garage', x: -5, y: 10, width: 20, height: 20, rotation: 0, fillTexture: 'concrete', strokeColor: '#475569', layerId: 'layer-walls', visible: true, locked: false }
    ]
  },
  'office': {
    name: 'Corporate Open Plan Office',
    icon: 'Briefcase',
    elements: [
      { id: 'o-r1', type: 'room', name: 'Open Work Hall', x: 10, y: 10, width: 36, height: 24, rotation: 0, fillTexture: 'concrete', strokeColor: '#334155', layerId: 'layer-walls', visible: true, locked: false },
      { id: 'o-r2', type: 'room', name: 'Executive Conference Room', x: 46, y: 10, width: 20, height: 16, rotation: 0, fillTexture: 'walnut', strokeColor: '#334155', layerId: 'layer-walls', visible: true, locked: false },
      { id: 'o-r3', type: 'room', name: 'CEO Office', x: 46, y: 26, width: 20, height: 14, rotation: 0, fillTexture: 'oak', strokeColor: '#334155', layerId: 'layer-walls', visible: true, locked: false },
      { id: 'o-f1', type: 'furniture', subType: 'Meeting Table', name: 'Conference Table', x: 50, y: 14, width: 12, height: 6, rotation: 0, layerId: 'layer-furniture', visible: true, locked: false }
    ]
  },
  'restaurant': {
    name: 'Cozy Restaurant & Bar',
    icon: 'Utensils',
    elements: [
      { id: 'res-1', type: 'room', name: 'Dining Hall', x: 10, y: 10, width: 32, height: 24, rotation: 0, fillTexture: 'walnut', strokeColor: '#78350f', layerId: 'layer-walls', visible: true, locked: false },
      { id: 'res-2', type: 'room', name: 'Chef Kitchen', x: 42, y: 10, width: 20, height: 18, rotation: 0, fillTexture: 'tile', strokeColor: '#78350f', layerId: 'layer-walls', visible: true, locked: false }
    ]
  }
};

export default function FloorPlanBuilder({ onBackToDashboard }: FloorPlanBuilderProps) {
  // Master Elements & Layers State
  const [elements, setElements] = useState<FloorElement[]>(PRESET_TEMPLATES['1bed'].elements);
  const [layers, setLayers] = useState<Layer[]>(() => createInitialLayers(PRESET_TEMPLATES['1bed'].elements));
  const [editingLayerId, setEditingLayerId] = useState<string | null>(null);
  const [editingLayerName, setEditingLayerName] = useState<string>('');

  // History Stack (Undo / Redo)
  const [history, setHistory] = useState<FloorElement[][]>([PRESET_TEMPLATES['1bed'].elements]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Selection & Clipboard
  const [selectedIds, setSelectedIds] = useState<string[]>(['t1-r1']);
  const [clipboard, setClipboard] = useState<FloorElement[]>([]);

  // Project Settings
  const [projectName, setProjectName] = useState<string>('Dream Villa 2D CAD Plan');
  const [unit, setUnit] = useState<MeasurementUnit>('ft');
  const [gridSize, setGridSize] = useState<number>(1); // in feet (1ft = 12in)
  const [snapToGrid, setSnapToGrid] = useState<boolean>(true);
  const [snapToWall, setSnapToWall] = useState<boolean>(true);
  const [showRulers, setShowRulers] = useState<boolean>(true);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [showRoomLabels, setShowRoomLabels] = useState<boolean>(true);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState<boolean>(true);

  // Active Tool state
  const [activeTool, setActiveTool] = useState<'select' | 'pan' | 'draw_wall' | 'draw_room' | 'dimension' | 'text'>('select');
  const [wallDrawMode, setWallDrawMode] = useState<'straight' | 'l-shape' | 'curved'>('straight');

  // Viewport Pan & Zoom
  const [zoom, setZoom] = useState<number>(18); // Pixels per foot scale factor
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 80, y: 80 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Sidebar Tabs
  const [leftSidebarTab, setLeftSidebarTab] = useState<'library' | 'templates' | 'search'>('library');
  const [rightSidebarTab, setRightSidebarTab] = useState<'properties' | 'layers'>('properties');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Dragging / Resizing / Rotating Element state
  const [dragState, setDragState] = useState<{
    isDragging: boolean;
    isResizing: boolean;
    isRotating: boolean;
    resizeHandle?: string;
    startMouseGridX: number;
    startMouseGridY: number;
    elementStartPositions: Map<string, { x: number; y: number; width: number; height: number; rotation: number }>;
    targetIds: string[];
  } | null>(null);

  // Mouse cursor coords on grid
  const [mouseGridPos, setMouseGridPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Modals & Popups
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showSavedModal, setShowSavedModal] = useState<boolean>(false);
  const [savedProjects, setSavedProjects] = useState<SavedProject[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const canvasRef = useRef<SVGSVGElement>(null);

  // Helper to show brief toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Record History State
  const recordState = useCallback((newElements: FloorElement[]) => {
    setElements(newElements);
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newElements);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  // Undo / Redo handlers
  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      setElements(prev);
      triggerToast('Undo Action');
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      setElements(next);
      triggerToast('Redo Action');
    }
  }, [history, historyIndex]);

  // Unit conversion helper
  const convertFromFeet = useCallback((valInFeet: number): string => {
    switch (unit) {
      case 'ft': return `${valInFeet.toFixed(1)} ft`;
      case 'm': return `${(valInFeet * 0.3048).toFixed(2)} m`;
      case 'cm': return `${(valInFeet * 30.48).toFixed(0)} cm`;
      case 'mm': return `${(valInFeet * 304.8).toFixed(0)} mm`;
      case 'in': return `${(valInFeet * 12).toFixed(0)} in`;
      default: return `${valInFeet.toFixed(1)} ft`;
    }
  }, [unit]);

  const convertSqFt = useCallback((sqft: number): string => {
    if (unit === 'm' || unit === 'cm' || unit === 'mm') {
      const sqMeters = sqft * 0.092903;
      return `${sqMeters.toFixed(1)} m²`;
    }
    return `${sqft.toFixed(0)} Sq Ft`;
  }, [unit]);

  const currentUserEmail = (auth.currentUser?.email || localStorage.getItem('dreamhouse_current_user_email') || '').toLowerCase().trim();
  const projectsKey = currentUserEmail ? `dreamhouse_2d_projects_${currentUserEmail}` : 'dreamhouse_2d_projects';
  const currentPlanKey = currentUserEmail ? `dreamhouse_2d_current_plan_${currentUserEmail}` : 'dreamhouse_2d_current_plan';

  // Load Saved Projects & Last Active Plan from localStorage on mount
  useEffect(() => {
    const savedProjectsData = localStorage.getItem(projectsKey);
    if (savedProjectsData) {
      try { setSavedProjects(JSON.parse(savedProjectsData)); } catch (e) {}
    }

    const currentPlanData = localStorage.getItem(currentPlanKey);
    if (currentPlanData) {
      try {
        const parsed = JSON.parse(currentPlanData);
        if (parsed && Array.isArray(parsed.elements) && parsed.elements.length > 0) {
          setElements(parsed.elements);
          setHistory([parsed.elements]);
          setHistoryIndex(0);
          if (parsed.projectName) setProjectName(parsed.projectName);
          if (parsed.unit) setUnit(parsed.unit);
          if (Array.isArray(parsed.layers)) setLayers(parsed.layers);
        }
      } catch (e) {
        console.error('Error loading stored plan:', e);
      }
    }
  }, [projectsKey, currentPlanKey]);

  // Instant Auto Save on every element or plan change
  useEffect(() => {
    if (elements.length > 0) {
      const activePlanObj = {
        projectName,
        unit,
        elements,
        layers,
        updatedAt: new Date().toISOString()
      };
      localStorage.setItem(currentPlanKey, JSON.stringify(activePlanObj));
    }
  }, [elements, projectName, unit, layers, currentPlanKey]);

  // Auto Synchronize Layers with Elements
  useEffect(() => {
    setLayers(prevLayers => {
      const elementMap = new Map<string, FloorElement>(elements.map(e => [e.id, e]));

      // Preserve existing layer state and ordering for existing elements
      const updatedLayers: Layer[] = [];
      prevLayers.forEach(l => {
        const el = elementMap.get(l.elementId);
        if (el) {
          updatedLayers.push({
            ...l,
            name: el.name,
            visible: el.visible !== false,
            locked: el.locked === true,
          });
        }
      });

      // Identify newly created elements that lack a corresponding layer
      const existingElementIds = new Set(prevLayers.map(l => l.elementId));
      const newElements = elements.filter(el => !existingElementIds.has(el.id));

      if (newElements.length > 0) {
        const newLayers: Layer[] = newElements.map(el => ({
          id: `layer-${el.id}`,
          elementId: el.id,
          name: el.name || 'Room Block',
          visible: el.visible !== false,
          locked: el.locked === true,
          color: GET_LAYER_COLOR(el.type)
        }));
        return [...newLayers, ...updatedLayers];
      }

      // Check if layers state needs updating
      const isDifferent = updatedLayers.length !== prevLayers.length ||
        updatedLayers.some((l, idx) => 
          l.id !== prevLayers[idx]?.id ||
          l.name !== prevLayers[idx]?.name ||
          l.visible !== prevLayers[idx]?.visible ||
          l.locked !== prevLayers[idx]?.locked
        );

      return isDifferent ? updatedLayers : prevLayers;
    });
  }, [elements]);

  // Layer Control Handlers
  const handleToggleLayerVisibility = (layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    const newVisible = !layer.visible;
    setLayers(prev => prev.map(l => l.id === layerId ? { ...l, visible: newVisible } : l));
    setElements(prev => prev.map(el => el.id === layer.elementId ? { ...el, visible: newVisible } : el));
  };

  const handleToggleLayerLock = (layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    const newLocked = !layer.locked;
    setLayers(prev => prev.map(l => l.id === layerId ? { ...l, locked: newLocked } : l));
    setElements(prev => prev.map(el => el.id === layer.elementId ? { ...el, locked: newLocked } : el));
  };

  const handleRenameLayer = (layerId: string, newName: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    const trimmed = newName.trim();
    if (!trimmed) return;
    setLayers(prev => prev.map(l => l.id === layerId ? { ...l, name: trimmed } : l));
    setElements(prev => prev.map(el => el.id === layer.elementId ? { ...el, name: trimmed } : el));
  };

  const handleDeleteLayer = (layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    const targetElementId = layer.elementId;
    const updatedElements = elements.filter(el => el.id !== targetElementId);
    recordState(updatedElements);
    setLayers(prev => prev.filter(l => l.id !== layerId));
    setSelectedIds(prev => prev.filter(id => id !== targetElementId));
    triggerToast(`Deleted layer "${layer.name}"`);
  };

  const handleDuplicateLayer = (layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    const sourceEl = elements.find(el => el.id === layer.elementId);
    if (!sourceEl) return;

    const newElId = `el-${Date.now()}-${Math.floor(Math.random()*1000)}`;
    const newEl: FloorElement = {
      ...sourceEl,
      id: newElId,
      name: `${sourceEl.name} (Copy)`,
      x: sourceEl.x + 2,
      y: sourceEl.y + 2
    };

    const newLayer: Layer = {
      id: `layer-${newElId}`,
      elementId: newElId,
      name: newEl.name,
      visible: true,
      locked: false,
      color: layer.color
    };

    const updatedElements = [...elements, newEl];
    recordState(updatedElements);
    setElements(updatedElements);
    setLayers(prev => [newLayer, ...prev]);
    setSelectedIds([newElId]);
    triggerToast(`Duplicated "${sourceEl.name}"`);
  };

  const handleMoveLayer = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= layers.length) return;

    const newLayers = [...layers];
    const [moved] = newLayers.splice(index, 1);
    newLayers.splice(targetIndex, 0, moved);

    setLayers(newLayers);
    triggerToast('Reordered layer position');
  };

  const handleSelectLayer = (layer: Layer) => {
    const el = elements.find(e => e.id === layer.elementId);
    if (!el) return;
    setSelectedIds([layer.elementId]);
  };

  // Total Statistics
  const totalFloorAreaSqFt = elements
    .filter(el => ['room', 'balcony', 'garage', 'garden', 'pool'].includes(el.type))
    .reduce((acc, el) => acc + (el.width * el.height), 0);

  const roomCount = elements.filter(el => el.type === 'room').length;
  const objectCount = elements.length;

  // Add Element to Canvas
  const handleAddElement = (type: FloorElement['type'], subType?: string) => {
    let name = subType || 'Custom Element';
    let width = 12;
    let height = 10;
    let fillTexture = 'oak';
    let strokeColor = '#1e293b';

    switch (type) {
      case 'room':
        if (subType === 'Living Room') { width = 20; height = 16; fillTexture = 'oak'; }
        else if (subType === 'Bedroom') { width = 16; height = 14; fillTexture = 'carpet'; }
        else if (subType === 'Kitchen') { width = 14; height = 12; fillTexture = 'tile'; }
        else if (subType === 'Bathroom') { width = 10; height = 8; fillTexture = 'marble'; }
        else if (subType === 'Dining Room') { width = 14; height = 12; fillTexture = 'walnut'; }
        break;
      case 'wall':
        name = 'Straight Wall'; width = 16; height = 1; fillTexture = 'plaster'; strokeColor = '#0f172a';
        break;
      case 'door':
        name = subType || 'Single Door'; width = 3.5; height = 3; fillTexture = 'plaster';
        break;
      case 'window':
        name = subType || 'Window'; width = 5; height = 1; fillTexture = 'plaster';
        break;
      case 'furniture':
        if (subType === 'King Bed') { width = 7; height = 7; }
        else if (subType === 'Single Bed') { width = 4; height = 7; }
        else if (subType === 'Sectional Sofa') { width = 8; height = 6; }
        else if (subType === 'Dining Table') { width = 6; height = 4; }
        else if (subType === 'Office Desk') { width = 5; height = 3; }
        else if (subType === 'Car') { width = 7; height = 15; }
        else if (subType === 'Tree') { width = 6; height = 6; }
        break;
      case 'staircase':
        name = 'Staircase'; width = 10; height = 5; fillTexture = 'concrete';
        break;
      case 'pool':
        name = 'Swimming Pool'; width = 20; height = 12; fillTexture = 'water'; strokeColor = '#0284c7';
        break;
      case 'dimension':
        name = 'Dimension Ruler'; width = 15; height = 2; fillTexture = 'plaster';
        break;
      case 'text':
        name = 'Text Label'; width = 10; height = 3;
        break;
    }

    // Spawn near view center
    const centerX = Math.round((-panOffset.x + 400) / zoom);
    const centerY = Math.round((-panOffset.y + 300) / zoom);

    const newEl: FloorElement = {
      id: `el-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      type,
      subType,
      name,
      x: Math.max(0, centerX),
      y: Math.max(0, centerY),
      width,
      height,
      rotation: 0,
      thickness: 8,
      fillTexture,
      strokeColor,
      opacity: 1,
      visible: true,
      locked: false,
      layerId: `layer-el-${Date.now()}`,
      doorDirection: 'left',
      swingSide: 'inside',
      openAngle: 90,
      textContent: subType === 'Text Label' ? 'Sample Room Label' : name
    };

    const updated = [...elements, newEl];
    recordState(updated);
    setSelectedIds([newEl.id]);
    triggerToast(`Added ${name} to canvas`);
  };

  const handleAddNewRoomLayer = () => {
    handleAddElement('room', 'Living Room');
  };

  // Keyboard Shortcuts (Ctrl+C, Ctrl+V, Delete, Undo, Redo, Arrows)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when typing in inputs
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) return;

      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        if (e.shiftKey) handleRedo(); else handleUndo();
        e.preventDefault();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        handleRedo();
        e.preventDefault();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        // Copy
        const selectedEls = elements.filter(el => selectedIds.includes(el.id));
        if (selectedEls.length > 0) {
          setClipboard(selectedEls);
          triggerToast(`Copied ${selectedEls.length} item(s)`);
        }
        e.preventDefault();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'v') {
        // Paste
        if (clipboard.length > 0) {
          const pasted = clipboard.map(el => ({
            ...el,
            id: `el-${Date.now()}-${Math.floor(Math.random()*1000)}`,
            x: el.x + 2,
            y: el.y + 2
          }));
          const updated = [...elements, ...pasted];
          recordState(updated);
          setSelectedIds(pasted.map(p => p.id));
          triggerToast(`Pasted ${pasted.length} item(s)`);
        }
        e.preventDefault();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedIds.length > 0) {
          const updated = elements.filter(el => !selectedIds.includes(el.id));
          recordState(updated);
          setSelectedIds([]);
          triggerToast('Deleted selected items');
        }
      } else if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        if (selectedIds.length > 0) {
          const step = e.shiftKey ? 5 : 1;
          const updated = elements.map(el => {
            if (!selectedIds.includes(el.id) || el.locked) return el;
            let nx = el.x;
            let ny = el.y;
            if (e.key === 'ArrowLeft') nx -= step;
            if (e.key === 'ArrowRight') nx += step;
            if (e.key === 'ArrowUp') ny -= step;
            if (e.key === 'ArrowDown') ny += step;
            return { ...el, x: Math.max(0, nx), y: Math.max(0, ny) };
          });
          recordState(updated);
          e.preventDefault();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [elements, selectedIds, clipboard, handleUndo, handleRedo, recordState]);

  // Wheel Zoom & Pan Handler
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey || true) {
      const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
      const newZoom = Math.min(60, Math.max(6, zoom * zoomFactor));
      setZoom(newZoom);
    }
  };

  // Canvas Mouse Down
  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (activeTool === 'pan' || e.button === 1 || e.spaceKey) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      return;
    }

    if (activeTool === 'select') {
      // Clear selection when clicking on empty canvas
      setSelectedIds([]);
    }
  };

  // Start Dragging Element
  const handleElementMouseDown = (e: React.MouseEvent, el: FloorElement) => {
    e.stopPropagation();
    const layer = layers.find(l => l.elementId === el.id);
    if (el.locked || layer?.locked) return;

    if (activeTool === 'pan') {
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      return;
    }

    let nextSelected: string[];
    if (e.shiftKey) {
      if (selectedIds.includes(el.id)) {
        nextSelected = selectedIds.filter(id => id !== el.id);
      } else {
        nextSelected = [...selectedIds, el.id];
      }
    } else {
      nextSelected = [el.id];
    }
    setSelectedIds(nextSelected);

    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseCanvasX = e.clientX - rect.left;
    const mouseCanvasY = e.clientY - rect.top;
    const startMouseGridX = (mouseCanvasX - panOffset.x) / zoom;
    const startMouseGridY = (mouseCanvasY - panOffset.y) / zoom;

    const startMap = new Map<string, { x: number; y: number; width: number; height: number; rotation: number }>();
    elements.forEach(item => {
      startMap.set(item.id, { x: item.x, y: item.y, width: item.width, height: item.height, rotation: item.rotation });
    });

    setDragState({
      isDragging: true,
      isResizing: false,
      isRotating: false,
      startMouseGridX,
      startMouseGridY,
      elementStartPositions: startMap,
      targetIds: nextSelected
    });
  };

  // Start Resize Handle Drag
  const handleResizeHandleMouseDown = (e: React.MouseEvent, handle: string, el: FloorElement) => {
    e.stopPropagation();
    const layer = layers.find(l => l.elementId === el.id);
    if (el.locked || layer?.locked) return;

    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseCanvasX = e.clientX - rect.left;
    const mouseCanvasY = e.clientY - rect.top;
    const startMouseGridX = (mouseCanvasX - panOffset.x) / zoom;
    const startMouseGridY = (mouseCanvasY - panOffset.y) / zoom;

    const startMap = new Map<string, { x: number; y: number; width: number; height: number; rotation: number }>();
    startMap.set(el.id, { x: el.x, y: el.y, width: el.width, height: el.height, rotation: el.rotation });

    setDragState({
      isDragging: false,
      isResizing: true,
      isRotating: false,
      resizeHandle: handle,
      startMouseGridX,
      startMouseGridY,
      elementStartPositions: startMap,
      targetIds: [el.id]
    });
  };

  // Start Rotate Handle Drag
  const handleRotateHandleMouseDown = (e: React.MouseEvent, el: FloorElement) => {
    e.stopPropagation();
    const layer = layers.find(l => l.elementId === el.id);
    if (el.locked || layer?.locked) return;

    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseCanvasX = e.clientX - rect.left;
    const mouseCanvasY = e.clientY - rect.top;
    const startMouseGridX = (mouseCanvasX - panOffset.x) / zoom;
    const startMouseGridY = (mouseCanvasY - panOffset.y) / zoom;

    const startMap = new Map<string, { x: number; y: number; width: number; height: number; rotation: number }>();
    startMap.set(el.id, { x: el.x, y: el.y, width: el.width, height: el.height, rotation: el.rotation });

    setDragState({
      isDragging: false,
      isResizing: false,
      isRotating: true,
      startMouseGridX,
      startMouseGridY,
      elementStartPositions: startMap,
      targetIds: [el.id]
    });
  };

  // Global Mouse Move Handler
  const handleGlobalMouseMove = useCallback((e: MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseCanvasX = e.clientX - rect.left;
    const mouseCanvasY = e.clientY - rect.top;

    const currentMouseGridX = (mouseCanvasX - panOffset.x) / zoom;
    const currentMouseGridY = (mouseCanvasY - panOffset.y) / zoom;

    setMouseGridPos({ 
      x: Math.max(0, Math.round(currentMouseGridX)), 
      y: Math.max(0, Math.round(currentMouseGridY)) 
    });

    if (isPanning) {
      setPanOffset({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y
      });
      return;
    }

    if (!dragState) return;

    const deltaFeetX = currentMouseGridX - dragState.startMouseGridX;
    const deltaFeetY = currentMouseGridY - dragState.startMouseGridY;

    if (dragState.isDragging && dragState.targetIds.length > 0) {
      const updated = elements.map(el => {
        if (!dragState.targetIds.includes(el.id)) return el;

        const startPos = dragState.elementStartPositions.get(el.id);
        if (!startPos || el.locked) return el;

        let newX = startPos.x + deltaFeetX;
        let newY = startPos.y + deltaFeetY;

        if (snapToGrid) {
          const step = gridSize || 1;
          newX = Math.round(newX / step) * step;
          newY = Math.round(newY / step) * step;
        }

        return {
          ...el,
          x: Math.max(0, newX),
          y: Math.max(0, newY)
        };
      });

      setElements(updated);
    } else if (dragState.isResizing && dragState.targetIds.length === 1) {
      const targetId = dragState.targetIds[0];
      const startPos = dragState.elementStartPositions.get(targetId);
      if (!startPos) return;

      const handle = dragState.resizeHandle || 'se';
      let newW = startPos.width;
      let newH = startPos.height;
      let newX = startPos.x;
      let newY = startPos.y;

      if (handle.includes('e')) newW = startPos.width + deltaFeetX;
      if (handle.includes('s')) newH = startPos.height + deltaFeetY;
      if (handle.includes('w')) {
        newW = startPos.width - deltaFeetX;
        newX = startPos.x + deltaFeetX;
      }
      if (handle.includes('n')) {
        newH = startPos.height - deltaFeetY;
        newY = startPos.y + deltaFeetY;
      }

      if (snapToGrid) {
        const step = gridSize || 1;
        newW = Math.round(newW / step) * step;
        newH = Math.round(newH / step) * step;
        newX = Math.round(newX / step) * step;
        newY = Math.round(newY / step) * step;
      }

      newW = Math.max(1, newW);
      newH = Math.max(1, newH);
      newX = Math.max(0, newX);
      newY = Math.max(0, newY);

      setElements(prev => prev.map(el => el.id === targetId ? {
        ...el,
        x: newX,
        y: newY,
        width: newW,
        height: newH
      } : el));
    } else if (dragState.isRotating && dragState.targetIds.length === 1) {
      const targetId = dragState.targetIds[0];
      const startPos = dragState.elementStartPositions.get(targetId);
      if (!startPos) return;

      const centerGridX = startPos.x + startPos.width / 2;
      const centerGridY = startPos.y + startPos.height / 2;

      const rad = Math.atan2(currentMouseGridY - centerGridY, currentMouseGridX - centerGridX);
      let deg = Math.round((rad * 180) / Math.PI) + 90;
      if (deg < 0) deg += 360;

      if (e.shiftKey) {
        deg = Math.round(deg / 15) * 15;
      }

      const newRotation = (deg + 360) % 360;

      setElements(prev => prev.map(el => el.id === targetId ? {
        ...el,
        rotation: newRotation
      } : el));
    }
  }, [zoom, panOffset, isPanning, panStart, dragState, selectedIds, elements, snapToGrid, gridSize]);

  // Global Mouse Up Handler
  const handleGlobalMouseUp = useCallback(() => {
    if (isPanning) {
      setIsPanning(false);
    }
    if (dragState) {
      recordState(elements);
      setDragState(null);
    }
  }, [isPanning, dragState, recordState, elements]);

  // Attach window event listeners for smooth drag & pan
  useEffect(() => {
    window.addEventListener('mousemove', handleGlobalMouseMove);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [handleGlobalMouseMove, handleGlobalMouseUp]);

  // Load Preset Template
  const handleLoadTemplate = (key: string) => {
    const t = PRESET_TEMPLATES[key];
    if (t) {
      setElements(t.elements);
      recordState(t.elements);
      setSelectedIds(t.elements[0] ? [t.elements[0].id] : []);
      setProjectName(t.name);
      triggerToast(`Loaded template: ${t.name}`);
    }
  };

  // Export JSON File
  const handleExportJSON = () => {
    const data = {
      project: projectName,
      date: new Date().toISOString(),
      unit,
      totalAreaSqFt: totalFloorAreaSqFt,
      elements,
      layers
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectName.toLowerCase().replace(/\s+/g, '_')}_2d_plan.json`;
    a.click();
    URL.revokeObjectURL(url);
    triggerToast('Exported JSON Blueprint');
  };

  // Import JSON File
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && Array.isArray(parsed.elements)) {
          setElements(parsed.elements);
          recordState(parsed.elements);
          if (parsed.project) setProjectName(parsed.project);
          if (parsed.unit) setUnit(parsed.unit);
          triggerToast('Imported Floor Plan JSON successfully');
        }
      } catch (err) {
        alert('Invalid JSON floor plan file');
      }
    };
    reader.readAsText(file);
  };

  // Save Project to LocalStorage
  const handleSaveProject = () => {
    const proj: SavedProject = {
      id: `proj-${Date.now()}`,
      name: projectName,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      unit,
      elements,
      layers
    };
    const updated = [proj, ...savedProjects.filter(p => p.name !== projectName)];
    setSavedProjects(updated);
    localStorage.setItem('dreamhouse_2d_projects', JSON.stringify(updated));
    triggerToast(`Saved '${projectName}' to local designs`);
  };

  // Export Image (PNG / JPG) via Canvas rendering
  const handleExportImage = (format: 'png' | 'jpg') => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Determine bounds
    let minX = 0, minY = 0, maxX = 60, maxY = 50;
    elements.forEach(el => {
      maxX = Math.max(maxX, el.x + el.width + 10);
      maxY = Math.max(maxY, el.y + el.height + 10);
    });

    const scale = 20; // 20px per foot for export
    canvas.width = (maxX - minX) * scale;
    canvas.height = (maxY - minY) * scale;

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Grid
    ctx.strokeStyle = '#f1f5f9';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += scale) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += scale) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }

    // Draw elements
    elements.forEach(el => {
      if (!el.visible) return;
      const x = (el.x - minX) * scale;
      const y = (el.y - minY) * scale;
      const w = el.width * scale;
      const h = el.height * scale;

      ctx.save();
      ctx.translate(x + w/2, y + h/2);
      ctx.rotate((el.rotation * Math.PI) / 180);

      // Fill
      if (TEXTURES[el.fillTexture || 'plaster']) {
        ctx.fillStyle = TEXTURES[el.fillTexture || 'plaster'].fill;
      } else {
        ctx.fillStyle = '#f8fafc';
      }
      ctx.fillRect(-w/2, -h/2, w, h);

      // Stroke
      ctx.strokeStyle = el.strokeColor || '#0f172a';
      ctx.lineWidth = 2;
      ctx.strokeRect(-w/2, -h/2, w, h);

      // Label text
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(el.name, 0, -2);
      ctx.font = '10px sans-serif';
      ctx.fillText(`${el.width} x ${el.height} ft`, 0, 12);

      ctx.restore();
    });

    // Download
    const dataUrl = canvas.toDataURL(format === 'png' ? 'image/png' : 'image/jpeg');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `${projectName.toLowerCase().replace(/\s+/g, '_')}.${format}`;
    a.click();
    setShowExportModal(false);
    triggerToast(`Exported ${format.toUpperCase()} image`);
  };

  const selectedElement = elements.find(el => selectedIds.includes(el.id));

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-900 text-slate-100 font-sans select-none overflow-hidden">
      
      {/* 1. TOP TOOLBAR */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 z-20 flex-shrink-0 shadow-lg">
        
        {/* Left: Brand & Title */}
        <div className="flex items-center gap-3">
          <button 
            onClick={onBackToDashboard}
            className="p-2 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
            title="Return to Dashboard"
          >
            <ArrowLeft className="w-4 h-4 text-orange-400" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>
          <div className="h-4 w-px bg-slate-700"></div>

          <div className="flex items-center gap-2">
            <input 
              type="text" 
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              className="bg-slate-800/80 hover:bg-slate-800 focus:bg-slate-950 text-white font-bold text-sm px-2.5 py-1 rounded border border-slate-700/60 focus:border-indigo-500 outline-none w-48 transition-all"
            />
            <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider">
              2D CAD
            </span>
          </div>
        </div>

        {/* Center: Primary Editing Tools */}
        <div className="flex items-center gap-1 bg-slate-950/70 p-1 rounded-xl border border-slate-800">
          <button 
            onClick={() => setActiveTool('select')}
            className={`p-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTool === 'select' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="Select & Drag Tool (V)"
          >
            <MousePointer className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Select</span>
          </button>

          <button 
            onClick={() => setActiveTool('pan')}
            className={`p-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTool === 'pan' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="Hand Pan Canvas (Spacebar)"
          >
            <Hand className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Pan</span>
          </button>

          <div className="h-4 w-px bg-slate-800 my-auto mx-1"></div>

          <button 
            onClick={handleUndo}
            disabled={historyIndex <= 0}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent rounded-lg transition-colors cursor-pointer"
            title="Undo (Ctrl+Z)"
          >
            <Undo2 className="w-4 h-4" />
          </button>

          <button 
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent rounded-lg transition-colors cursor-pointer"
            title="Redo (Ctrl+Y)"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          <div className="h-4 w-px bg-slate-800 my-auto mx-1"></div>

          {/* Unit Switcher */}
          <select 
            value={unit}
            onChange={(e) => setUnit(e.target.value as MeasurementUnit)}
            className="bg-slate-800 text-slate-200 text-xs font-bold px-2 py-1.5 rounded-lg border border-slate-700 outline-none cursor-pointer"
          >
            <option value="ft">Unit: Feet (ft)</option>
            <option value="m">Unit: Meters (m)</option>
            <option value="cm">Unit: Centimeters (cm)</option>
            <option value="mm">Unit: Millimeters (mm)</option>
            <option value="in">Unit: Inches (in)</option>
          </select>

          {/* Zoom controls */}
          <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 text-xs font-mono font-bold text-slate-300">
            <button onClick={() => setZoom(Math.max(6, zoom - 3))} className="hover:text-white cursor-pointer"><ZoomOut className="w-3.5 h-3.5" /></button>
            <span className="min-w-[42px] text-center">{Math.round((zoom / 18) * 100)}%</span>
            <button onClick={() => setZoom(Math.min(60, zoom + 3))} className="hover:text-white cursor-pointer"><ZoomIn className="w-3.5 h-3.5" /></button>
          </div>
        </div>

        {/* Right Actions: File Actions & Export */}
        <div className="flex items-center gap-2">
          
          <button 
            onClick={handleSaveProject}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
            title="Save Plan to Browser Storage"
          >
            <Save className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Save</span>
          </button>

          <label className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer">
            <FolderOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Import</span>
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>

          <button 
            onClick={() => setShowExportModal(true)}
            className="bg-orange-600 hover:bg-orange-500 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Plan</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN WORKSPACE CONTAINER */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* LEFT SIDEBAR: Building Elements Library */}
        <aside className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col z-10 flex-shrink-0 shadow-lg">
          
          {/* Library Tabs */}
          <div className="flex border-b border-slate-800 p-1 bg-slate-950/50">
            <button 
              onClick={() => setLeftSidebarTab('library')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                leftSidebarTab === 'library' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Elements
            </button>
            <button 
              onClick={() => setLeftSidebarTab('templates')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                leftSidebarTab === 'templates' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Templates
            </button>
          </div>

          {/* Search Bar */}
          <div className="p-3 border-b border-slate-800">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
              <input 
                type="text"
                placeholder="Search furniture, doors, walls..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-lg pl-8 pr-3 py-1.5 outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Library Contents */}
          <div className="flex-1 overflow-y-auto p-3 space-y-5 custom-scrollbar">
            
            {leftSidebarTab === 'library' && (
              <>
                {/* 1. ROOMS & ZONES */}
                <div>
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <Box className="w-3.5 h-3.5 text-indigo-400" />
                    Rooms & Zones
                  </h3>
                  <div className="grid grid-cols-2 gap-1.5">
                    {['Living Room', 'Bedroom', 'Kitchen', 'Bathroom', 'Dining Room'].map((sub) => (
                      <button
                        key={sub}
                        onClick={() => handleAddElement('room', sub)}
                        className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 hover:border-indigo-500/50 rounded-lg text-left text-xs text-slate-200 font-medium transition-all flex flex-col gap-1 cursor-pointer"
                      >
                        <span className="font-bold">{sub}</span>
                        <span className="text-[10px] text-slate-400">Add Room Box</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. WALLS & STRUCTURES */}
                <div>
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <Ruler className="w-3.5 h-3.5 text-amber-400" />
                    Walls & Openings
                  </h3>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button onClick={() => handleAddElement('wall', 'Straight Wall')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-semibold text-slate-200 cursor-pointer">
                      🧱 Straight Wall
                    </button>
                    <button onClick={() => handleAddElement('door', 'Single Door')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-semibold text-slate-200 cursor-pointer">
                      🚪 Single Door
                    </button>
                    <button onClick={() => handleAddElement('door', 'Double Door')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-semibold text-slate-200 cursor-pointer">
                      🚪 Double Door
                    </button>
                    <button onClick={() => handleAddElement('window', 'Sliding Window')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-semibold text-slate-200 cursor-pointer">
                      🪟 Glass Window
                    </button>
                    <button onClick={() => handleAddElement('staircase', 'Staircase')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-semibold text-slate-200 cursor-pointer">
                      🪜 Staircase
                    </button>
                    <button onClick={() => handleAddElement('pool', 'Swimming Pool')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-semibold text-slate-200 cursor-pointer">
                      🏊 Swimming Pool
                    </button>
                  </div>
                </div>

                {/* 3. FURNITURE LIBRARY */}
                <div>
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                    Furniture Items
                  </h3>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button onClick={() => handleAddElement('furniture', 'King Bed')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🛏️ King Bed
                    </button>
                    <button onClick={() => handleAddElement('furniture', 'Sectional Sofa')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🛋️ Sectional Sofa
                    </button>
                    <button onClick={() => handleAddElement('furniture', 'Dining Table')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🪑 Dining Set
                    </button>
                    <button onClick={() => handleAddElement('furniture', 'Office Desk')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🖥️ Office Desk
                    </button>
                    <button onClick={() => handleAddElement('furniture', 'Car')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🚗 Garage Car
                    </button>
                    <button onClick={() => handleAddElement('furniture', 'Tree')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🌳 Garden Tree
                    </button>
                  </div>
                </div>

                {/* 4. ANNOTATIONS & TOOLS */}
                <div>
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-emerald-400" />
                    Annotations
                  </h3>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button onClick={() => handleAddElement('dimension', 'Dimension Ruler')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      📐 Dimension Line
                    </button>
                    <button onClick={() => handleAddElement('text', 'Text Label')} className="p-2 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/50 rounded-lg text-left text-xs font-medium text-slate-200 cursor-pointer">
                      🔤 Custom Label
                    </button>
                  </div>
                </div>
              </>
            )}

            {leftSidebarTab === 'templates' && (
              <div className="space-y-2">
                {Object.entries(PRESET_TEMPLATES).map(([key, item]) => (
                  <button
                    key={key}
                    onClick={() => handleLoadTemplate(key)}
                    className="w-full p-3 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-xl text-left transition-all group flex items-center justify-between cursor-pointer"
                  >
                    <div>
                      <h4 className="font-bold text-xs text-white group-hover:text-indigo-300">{item.name}</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">{item.elements.length} Structural Elements</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400" />
                  </button>
                ))}
              </div>
            )}

          </div>
        </aside>

        {/* CENTER: Infinite Interactive Drawing Canvas */}
        <main 
          className="flex-1 bg-slate-950 relative overflow-hidden flex flex-col select-none"
          onWheel={handleWheel}
        >
          {/* Top Ruler Bar */}
          {showRulers && (
            <div className="h-6 bg-slate-900 border-b border-slate-800 flex items-center text-[10px] font-mono text-slate-500 px-6 relative overflow-hidden z-10">
              <div className="absolute left-0 top-0 bottom-0 w-6 bg-slate-950 border-r border-slate-800"></div>
              <div className="flex gap-12 font-bold text-slate-400">
                {Array.from({ length: 30 }).map((_, i) => (
                  <span key={i} style={{ transform: `translateX(${(i * 10 * zoom) + panOffset.x}px)` }} className="absolute">
                    {i * 10}{unit}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="flex-1 flex relative overflow-hidden">
            
            {/* Left Ruler Bar */}
            {showRulers && (
              <div className="w-6 bg-slate-900 border-r border-slate-800 relative z-10 font-mono text-[10px] text-slate-500">
                {Array.from({ length: 30 }).map((_, i) => (
                  <span key={i} style={{ top: `${(i * 10 * zoom) + panOffset.y}px` }} className="absolute left-1">
                    {i * 10}
                  </span>
                ))}
              </div>
            )}

            {/* SVG Interactive Canvas */}
            <svg 
              ref={canvasRef}
              className={`w-full h-full ${activeTool === 'pan' || isPanning ? 'cursor-grab active:cursor-grabbing' : 'cursor-crosshair'}`}
              onMouseDown={handleCanvasMouseDown}
            >
              <defs>
                {/* Grid Pattern */}
                <pattern id="gridPattern" width={zoom * gridSize} height={zoom * gridSize} patternUnits="userSpaceOnUse" x={panOffset.x} y={panOffset.y}>
                  <path d={`M ${zoom * gridSize} 0 L 0 0 0 ${zoom * gridSize}`} fill="none" stroke="#334155" strokeWidth="0.5" strokeOpacity="0.4" />
                </pattern>

                {/* Major Grid Pattern */}
                <pattern id="majorGridPattern" width={zoom * gridSize * 5} height={zoom * gridSize * 5} patternUnits="userSpaceOnUse" x={panOffset.x} y={panOffset.y}>
                  <rect width={zoom * gridSize * 5} height={zoom * gridSize * 5} fill="url(#gridPattern)" />
                  <path d={`M ${zoom * gridSize * 5} 0 L 0 0 0 ${zoom * gridSize * 5}`} fill="none" stroke="#475569" strokeWidth="1" strokeOpacity="0.6" />
                </pattern>
              </defs>

              {/* Grid Background */}
              {showGrid && (
                <rect width="100%" height="100%" fill="url(#majorGridPattern)" />
              )}

              {/* World Origin Marker */}
              <g transform={`translate(${panOffset.x}, ${panOffset.y})`}>
                <line x1="-15" y1="0" x2="15" y2="0" stroke="#ef4444" strokeWidth="2" />
                <line x1="0" y1="-15" x2="0" y2="15" stroke="#22c55e" strokeWidth="2" />
                <circle cx="0" cy="0" r="3" fill="#38bdf8" />
              </g>

              {/* RENDER ALL CANVAS FLOOR ELEMENTS SORTED BY LAYER Z-INDEX */}
              {(() => {
                const layerIndexMap = new Map<string, number>(layers.map((l, idx) => [l.elementId, idx]));
                
                // Sort elements so index 0 layer is rendered last (top of z-index stack)
                const sortedElements = [...elements].sort((a, b) => {
                  const idxA = layerIndexMap.get(a.id) ?? 999;
                  const idxB = layerIndexMap.get(b.id) ?? 999;
                  return idxB - idxA;
                });

                return sortedElements.map((el) => {
                  const layer = layers.find(l => l.elementId === el.id);
                  const isVisible = (el.visible !== false) && (!layer || layer.visible !== false);
                  if (!isVisible) return null;

                  const isSelected = selectedIds.includes(el.id);
                  const isLocked = (el.locked === true) || (layer?.locked === true);
                  const x = el.x * zoom + panOffset.x;
                  const y = el.y * zoom + panOffset.y;
                  const w = el.width * zoom;
                  const h = el.height * zoom;

                  const textureObj = TEXTURES[el.fillTexture || 'plaster'];
                  const fillColor = textureObj ? textureObj.fill : (el.color || '#f8fafc');

                  return (
                    <g 
                      key={el.id}
                      transform={`translate(${x}, ${y}) rotate(${el.rotation})`}
                      onMouseDown={(e) => handleElementMouseDown(e, el)}
                      className={`${isLocked ? 'cursor-not-allowed' : 'cursor-pointer'} group`}
                    >
                      {/* Room / Zone Polygon */}
                      {['room', 'balcony', 'garage', 'garden', 'pool'].includes(el.type) && (
                        <rect 
                          width={w}
                          height={h}
                          fill={fillColor}
                          fillOpacity={el.opacity ?? 0.9}
                          stroke={isSelected ? '#38bdf8' : (el.strokeColor || '#0f172a')}
                          strokeWidth={isSelected ? 3 : 2}
                          rx={el.type === 'pool' ? 12 : 2}
                        />
                      )}

                      {/* Wall Line */}
                      {el.type === 'wall' && (
                        <rect 
                          width={w}
                          height={Math.max(6, (el.thickness || 8))}
                          fill="#334155"
                          stroke={isSelected ? '#38bdf8' : '#0f172a'}
                          strokeWidth={isSelected ? 3 : 1}
                        />
                      )}

                      {/* Door Arc & Frame */}
                      {el.type === 'door' && (
                        <g>
                          <rect width={w} height={10} fill="#ffffff" stroke="#0f172a" strokeWidth="2" />
                          {/* Swing Arc */}
                          <path 
                            d={`M 0 0 A ${w} ${w} 0 0 1 ${w} ${w}`}
                            fill="none"
                            stroke="#ef4444"
                            strokeWidth="1.5"
                            strokeDasharray="3,3"
                          />
                        </g>
                      )}

                      {/* Window Glass Line */}
                      {el.type === 'window' && (
                        <g>
                          <rect width={w} height={8} fill="#e0f2fe" stroke="#0284c7" strokeWidth="2" />
                          <line x1="0" y1="4" x2={w} y2="4" stroke="#0284c7" strokeWidth="1" />
                        </g>
                      )}

                      {/* Furniture Item Vector Render */}
                      {el.type === 'furniture' && (
                        <g>
                          <rect width={w} height={h} fill="#ffffff" stroke={isSelected ? '#38bdf8' : '#475569'} strokeWidth="1.5" rx="4" />
                          {el.subType === 'King Bed' && (
                            <g>
                              <rect x="4" y="4" width={w - 8} height="12" fill="#cbd5e1" rx="2" />
                              <rect x="8" y="20" width={w - 16} height={h - 24} fill="#f1f5f9" rx="2" />
                            </g>
                          )}
                          {el.subType === 'Sectional Sofa' && (
                            <rect x="4" y="4" width={w - 8} height={h - 8} fill="#e2e8f0" rx="6" />
                          )}
                        </g>
                      )}

                      {/* Staircase Steps */}
                      {el.type === 'staircase' && (
                        <g>
                          <rect width={w} height={h} fill="#e2e8f0" stroke="#0f172a" strokeWidth="2" />
                          {Array.from({ length: 6 }).map((_, idx) => (
                            <line key={idx} x1="0" y1={(h/6)*idx} x2={w} y2={(h/6)*idx} stroke="#64748b" strokeWidth="1" />
                          ))}
                        </g>
                      )}

                      {/* Label & Dimension overlay */}
                      {showRoomLabels && (
                        <text 
                          x={w / 2} 
                          y={h / 2 - 4} 
                          fill="#0f172a" 
                          fontSize="11" 
                          fontWeight="bold" 
                          textAnchor="middle" 
                          pointerEvents="none"
                        >
                          {el.name}
                        </text>
                      )}

                      {showDimensions && (
                        <text 
                          x={w / 2} 
                          y={h / 2 + 10} 
                          fill="#64748b" 
                          fontSize="9" 
                          fontFamily="monospace"
                          textAnchor="middle" 
                          pointerEvents="none"
                        >
                          {convertFromFeet(el.width)} × {convertFromFeet(el.height)} ({convertSqFt(el.width * el.height)})
                        </text>
                      )}

                      {/* Selection Bounding Handles */}
                      {isSelected && !isLocked && (
                        <g>
                          {/* Outer Highlight Box */}
                          <rect 
                            width={w} 
                            height={h} 
                            fill="rgba(56, 189, 248, 0.08)" 
                            stroke="#38bdf8" 
                            strokeWidth="2.5" 
                            strokeDasharray="5,5" 
                            className="pointer-events-none"
                          />

                          {/* Rotation Arm & Handle */}
                          <line x1={w / 2} y1="0" x2={w / 2} y2="-22" stroke="#38bdf8" strokeWidth="2" strokeDasharray="2,2" />
                          <circle 
                            cx={w / 2} 
                            cy="-22" 
                            r="7" 
                            fill="#38bdf8" 
                            stroke="#ffffff" 
                            strokeWidth="2" 
                            className="cursor-grab active:cursor-grabbing hover:scale-125 transition-transform" 
                            onMouseDown={(e) => handleRotateHandleMouseDown(e, el)}
                          >
                            <title>Click & Drag to Rotate</title>
                          </circle>

                          {/* 8-point Resize Handles */}
                          {/* NW - Top Left */}
                          <rect x="-4" y="-4" width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-nwse-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'nw', el)} />
                          {/* N - Top Center */}
                          <rect x={w / 2 - 4} y="-4" width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-ns-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'n', el)} />
                          {/* NE - Top Right */}
                          <rect x={w - 4} y="-4" width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-nesw-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'ne', el)} />
                          {/* E - Middle Right */}
                          <rect x={w - 4} y={h / 2 - 4} width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-ew-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'e', el)} />
                          {/* SE - Bottom Right */}
                          <rect x={w - 4} y={h - 4} width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-nwse-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'se', el)} />
                          {/* S - Bottom Center */}
                          <rect x={w / 2 - 4} y={h - 4} width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-ns-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 's', el)} />
                          {/* SW - Bottom Left */}
                          <rect x="-4" y={h - 4} width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-nesw-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'sw', el)} />
                          {/* W - Middle Left */}
                          <rect x="-4" y={h / 2 - 4} width="8" height="8" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" className="cursor-ew-resize" onMouseDown={(e) => handleResizeHandleMouseDown(e, 'w', el)} />
                        </g>
                      )}

                      {/* Locked Overlay when Selected */}
                      {isSelected && isLocked && (
                        <g className="pointer-events-none">
                          <rect 
                            width={w} 
                            height={h} 
                            fill="rgba(245, 158, 11, 0.08)" 
                            stroke="#f59e0b" 
                            strokeWidth="2" 
                            strokeDasharray="4,4" 
                          />
                        </g>
                      )}
                    </g>
                  );
                });
              })()}
            </svg>

            {/* Bottom Floating MiniMap Overlay */}
            <div className="absolute right-4 bottom-4 w-40 h-28 bg-slate-900/90 border border-slate-800 rounded-xl p-1 shadow-2xl backdrop-blur pointer-events-none hidden md:block">
              <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider px-1 mb-1 flex items-center justify-between">
                <span>MiniMap View</span>
                <span className="text-indigo-400">{elements.length} objs</span>
              </div>
              <div className="w-full h-20 bg-slate-950 rounded border border-slate-800/80 relative overflow-hidden">
                {elements.map(el => (
                  <div 
                    key={el.id} 
                    style={{
                      left: `${(el.x / 100) * 100}%`,
                      top: `${(el.y / 100) * 100}%`,
                      width: `${Math.max(4, (el.width / 100) * 100)}%`,
                      height: `${Math.max(4, (el.height / 100) * 100)}%`
                    }}
                    className={`absolute rounded-sm ${selectedIds.includes(el.id) ? 'bg-sky-400 ring-2 ring-sky-300' : 'bg-slate-700/80'}`}
                  ></div>
                ))}
              </div>
            </div>

          </div>
        </main>

        {/* RIGHT SIDEBAR: Selected Object Properties & Layer Manager */}
        <aside className="w-80 bg-slate-900 border-l border-slate-800 flex flex-col z-10 flex-shrink-0 shadow-lg">
          
          {/* Tabs */}
          <div className="flex border-b border-slate-800 p-1 bg-slate-950/50">
            <button 
              onClick={() => setRightSidebarTab('properties')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                rightSidebarTab === 'properties' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Properties
            </button>
            <button 
              onClick={() => setRightSidebarTab('layers')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                rightSidebarTab === 'layers' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Layers ({layers.length})
            </button>
          </div>

          {/* Properties Panel */}
          <div className="flex-1 overflow-y-auto p-4 space-y-5 custom-scrollbar">
            
            {rightSidebarTab === 'properties' && (
              <>
                {selectedElement ? (
                  <div className="space-y-4">
                    
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div>
                        <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">
                          {selectedElement.type}
                        </span>
                        <input 
                          type="text" 
                          value={selectedElement.name}
                          onChange={(e) => {
                            setElements(elements.map(el => el.id === selectedElement.id ? { ...el, name: e.target.value } : el));
                          }}
                          className="block bg-slate-950 border border-slate-800 font-bold text-sm text-white px-2 py-1 rounded mt-1 outline-none focus:border-indigo-500 w-full"
                        />
                      </div>
                      <button 
                        onClick={() => {
                          const updated = elements.filter(el => el.id !== selectedElement.id);
                          recordState(updated);
                          setSelectedIds([]);
                        }}
                        className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors cursor-pointer"
                        title="Delete Element"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Dimensions & Controls */}
                    <div className="space-y-3">
                      <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Dimensions</h4>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] text-slate-400 block font-semibold mb-1">Width ({unit})</label>
                          <input 
                            type="number"
                            min="1"
                            max="100"
                            value={selectedElement.width}
                            onChange={(e) => {
                              const v = parseFloat(e.target.value) || 1;
                              setElements(elements.map(el => el.id === selectedElement.id ? { ...el, width: v } : el));
                            }}
                            className="w-full bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-white px-2.5 py-1.5 rounded outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 block font-semibold mb-1">Length ({unit})</label>
                          <input 
                            type="number"
                            min="1"
                            max="100"
                            value={selectedElement.height}
                            onChange={(e) => {
                              const v = parseFloat(e.target.value) || 1;
                              setElements(elements.map(el => el.id === selectedElement.id ? { ...el, height: v } : el));
                            }}
                            className="w-full bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-white px-2.5 py-1.5 rounded outline-none"
                          />
                        </div>
                      </div>

                      {/* Position X & Y */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <label className="text-[10px] text-slate-400 block font-semibold mb-1">Position X</label>
                          <input 
                            type="number"
                            value={selectedElement.x}
                            onChange={(e) => {
                              const v = parseFloat(e.target.value) || 0;
                              setElements(elements.map(el => el.id === selectedElement.id ? { ...el, x: v } : el));
                            }}
                            className="w-full bg-slate-950 border border-slate-800 text-xs font-mono text-white px-2.5 py-1.5 rounded outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 block font-semibold mb-1">Position Y</label>
                          <input 
                            type="number"
                            value={selectedElement.y}
                            onChange={(e) => {
                              const v = parseFloat(e.target.value) || 0;
                              setElements(elements.map(el => el.id === selectedElement.id ? { ...el, y: v } : el));
                            }}
                            className="w-full bg-slate-950 border border-slate-800 text-xs font-mono text-white px-2.5 py-1.5 rounded outline-none"
                          />
                        </div>
                      </div>

                    </div>

                    {/* Rotation Dial */}
                    <div className="pt-2">
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Rotation Angle</label>
                        <span className="text-xs font-mono font-bold text-indigo-400">{selectedElement.rotation}°</span>
                      </div>
                      <div className="flex gap-2 items-center">
                        <button 
                          onClick={() => {
                            setElements(elements.map(el => el.id === selectedElement.id ? { ...el, rotation: (el.rotation + 90) % 360 } : el));
                          }}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCw className="w-3.5 h-3.5" /> +90°
                        </button>
                        <input 
                          type="range"
                          min="0"
                          max="360"
                          step="15"
                          value={selectedElement.rotation}
                          onChange={(e) => {
                            setElements(elements.map(el => el.id === selectedElement.id ? { ...el, rotation: parseInt(e.target.value) } : el));
                          }}
                          className="flex-1 accent-indigo-500 cursor-pointer"
                        />
                      </div>
                    </div>

                    {/* Floor Textures */}
                    <div className="pt-2 space-y-2">
                      <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Texture & Material</label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {Object.entries(TEXTURES).map(([key, tex]) => (
                          <button
                            key={key}
                            onClick={() => {
                              setElements(elements.map(el => el.id === selectedElement.id ? { ...el, fillTexture: key } : el));
                            }}
                            className={`p-1.5 rounded-lg border text-left flex items-center gap-2 cursor-pointer transition-all ${
                              selectedElement.fillTexture === key ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-800 bg-slate-950'
                            }`}
                          >
                            <span className="w-4 h-4 rounded" style={{ background: tex.preview }}></span>
                            <span className="text-[11px] text-slate-200 truncate font-medium">{tex.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="text-center py-16 px-4">
                    <Sliders className="w-10 h-10 text-slate-700 mx-auto mb-3" />
                    <h4 className="font-bold text-slate-300 text-sm">No Object Selected</h4>
                    <p className="text-xs text-slate-500 mt-1">Click on any room, wall or furniture on the grid canvas to modify its properties.</p>
                  </div>
                )}
              </>
            )}

            {rightSidebarTab === 'layers' && (
              <div className="space-y-3">
                {/* Header & Add Layer Action */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-300">Room Layers</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-slate-800 text-indigo-400 font-bold">
                      {layers.length}
                    </span>
                  </div>
                  <button
                    onClick={handleAddNewRoomLayer}
                    className="flex items-center gap-1 text-[11px] font-bold text-indigo-400 bg-indigo-500/10 hover:bg-indigo-500/20 px-2 py-1 rounded-lg border border-indigo-500/30 transition-colors cursor-pointer"
                    title="Add new room block layer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Room</span>
                  </button>
                </div>

                {layers.length === 0 ? (
                  <div className="text-center py-10 px-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <Layers className="w-8 h-8 text-slate-700 mx-auto mb-2" />
                    <p className="text-xs text-slate-400 font-medium">No Layers Available</p>
                    <button
                      onClick={handleAddNewRoomLayer}
                      className="mt-3 text-xs font-bold text-indigo-400 bg-indigo-600/20 hover:bg-indigo-600/30 px-3 py-1.5 rounded-lg border border-indigo-500/40 transition-colors cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create Room Layer</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[calc(100vh-220px)] overflow-y-auto pr-0.5">
                    {layers.map((layer, index) => {
                      const isSelected = selectedIds.includes(layer.elementId);
                      const isEditing = editingLayerId === layer.id;

                      return (
                        <div 
                          key={layer.id} 
                          onClick={() => handleSelectLayer(layer)}
                          className={`p-2.5 rounded-xl border transition-all cursor-pointer group ${
                            isSelected 
                              ? 'bg-indigo-950/60 border-indigo-500/80 shadow-md shadow-indigo-950/50 ring-1 ring-indigo-500/30' 
                              : 'bg-slate-950 border-slate-800/90 hover:border-slate-700 hover:bg-slate-900/50'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-2">
                            {/* Color tag & Name or Edit input */}
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <span 
                                className="w-3 h-3 rounded-full flex-shrink-0 border border-white/20" 
                                style={{ backgroundColor: layer.color }} 
                              />

                              {isEditing ? (
                                <div className="flex items-center gap-1 flex-1" onClick={(e) => e.stopPropagation()}>
                                  <input 
                                    type="text" 
                                    value={editingLayerName} 
                                    onChange={(e) => setEditingLayerName(e.target.value)}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        handleRenameLayer(layer.id, editingLayerName);
                                        setEditingLayerId(null);
                                      } else if (e.key === 'Escape') {
                                        setEditingLayerId(null);
                                      }
                                    }}
                                    autoFocus
                                    className="bg-slate-900 border border-indigo-500 text-xs text-white px-1.5 py-0.5 rounded font-medium outline-none w-full"
                                  />
                                  <button
                                    onClick={() => {
                                      handleRenameLayer(layer.id, editingLayerName);
                                      setEditingLayerId(null);
                                    }}
                                    className="p-1 bg-indigo-600 text-white rounded hover:bg-indigo-500 transition-colors"
                                  >
                                    <Check className="w-3 h-3" />
                                  </button>
                                </div>
                              ) : (
                                <span 
                                  onDoubleClick={(e) => {
                                    e.stopPropagation();
                                    setEditingLayerId(layer.id);
                                    setEditingLayerName(layer.name);
                                  }}
                                  className={`text-xs font-bold truncate flex-1 ${
                                    isSelected ? 'text-white' : 'text-slate-200'
                                  }`}
                                  title="Double click to rename layer"
                                >
                                  {layer.name}
                                </span>
                              )}
                            </div>

                            {/* Selection Status Badge */}
                            {isSelected && (
                              <span className="text-[9px] font-bold text-sky-400 bg-sky-500/10 border border-sky-500/30 px-1.5 py-0.5 rounded-full uppercase tracking-wider flex-shrink-0">
                                Active
                              </span>
                            )}
                          </div>

                          {/* Layer Toolbar Controls */}
                          <div 
                            className="flex items-center justify-between pt-1.5 border-t border-slate-800/80 text-slate-400"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {/* Z-Index Reorder Buttons */}
                            <div className="flex items-center gap-0.5">
                              <button
                                onClick={() => handleMoveLayer(index, 'up')}
                                disabled={index === 0}
                                className="p-1 hover:text-white hover:bg-slate-800 rounded disabled:opacity-20 disabled:hover:bg-transparent transition-colors"
                                title="Move Layer Up (Bring Forward)"
                              >
                                <ChevronUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleMoveLayer(index, 'down')}
                                disabled={index === layers.length - 1}
                                className="p-1 hover:text-white hover:bg-slate-800 rounded disabled:opacity-20 disabled:hover:bg-transparent transition-colors"
                                title="Move Layer Down (Send Backward)"
                              >
                                <ChevronDown className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Actions Toolbar */}
                            <div className="flex items-center gap-1">
                              {/* Visibility Toggle */}
                              <button 
                                onClick={() => handleToggleLayerVisibility(layer.id)}
                                className={`p-1 rounded transition-colors ${
                                  layer.visible ? 'hover:text-white hover:bg-slate-800' : 'text-slate-600 bg-slate-900 hover:text-slate-400'
                                }`}
                                title={layer.visible ? 'Hide Layer' : 'Show Layer'}
                              >
                                {layer.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5 text-slate-500" />}
                              </button>

                              {/* Lock Toggle */}
                              <button 
                                onClick={() => handleToggleLayerLock(layer.id)}
                                className={`p-1 rounded transition-colors ${
                                  layer.locked ? 'text-amber-400 bg-amber-500/10 border border-amber-500/30' : 'hover:text-white hover:bg-slate-800'
                                }`}
                                title={layer.locked ? 'Unlock Layer' : 'Lock Layer'}
                              >
                                {layer.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                              </button>

                              {/* Rename Button */}
                              <button 
                                onClick={() => {
                                  setEditingLayerId(layer.id);
                                  setEditingLayerName(layer.name);
                                }}
                                className="p-1 hover:text-white hover:bg-slate-800 rounded transition-colors"
                                title="Rename Layer"
                              >
                                <FileText className="w-3.5 h-3.5" />
                              </button>

                              {/* Duplicate Button */}
                              <button 
                                onClick={() => handleDuplicateLayer(layer.id)}
                                className="p-1 hover:text-white hover:bg-slate-800 rounded transition-colors"
                                title="Duplicate Layer"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>

                              {/* Delete Button */}
                              <button 
                                onClick={() => handleDeleteLayer(layer.id)}
                                className="p-1 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors"
                                title="Delete Layer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

          </div>
        </aside>

      </div>

      {/* 3. BOTTOM STATUS BAR */}
      <footer className="h-8 bg-slate-950 border-t border-slate-800 flex items-center justify-between px-4 text-[11px] font-mono text-slate-400 z-20 flex-shrink-0">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="text-slate-500">Position:</span>
            <span className="text-slate-200 font-bold">{convertFromFeet(mouseGridPos.x)}, {convertFromFeet(mouseGridPos.y)}</span>
          </span>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden sm:inline flex items-center gap-1">
            <span className="text-slate-500">Grid Snap:</span>
            <span className="text-emerald-400 font-bold">{snapToGrid ? `On (${gridSize}ft)` : 'Off'}</span>
          </span>
        </div>

        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="text-slate-500">Total Footprint:</span>
            <span className="text-orange-400 font-bold">{convertSqFt(totalFloorAreaSqFt)}</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1">
            <span className="text-slate-500">Rooms:</span>
            <span className="text-indigo-300 font-bold">{roomCount}</span>
          </span>
        </div>
      </footer>

      {/* Toast Notification Popup */}
      {toastMessage && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-4 py-2 rounded-xl shadow-2xl font-semibold text-xs z-50 flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Export Options Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl space-y-5">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-orange-400" />
                Export 2D Floor Plan Blueprint
              </h3>
              <button onClick={() => setShowExportModal(false)} className="text-slate-400 hover:text-white font-bold text-lg">×</button>
            </div>

            <div className="space-y-3">
              <button 
                onClick={() => handleExportImage('png')}
                className="w-full p-3.5 bg-slate-800 hover:bg-slate-700/80 border border-slate-700/60 rounded-xl text-left flex items-center justify-between transition-all group cursor-pointer"
              >
                <div>
                  <h4 className="font-bold text-sm text-white group-hover:text-orange-300">High-Res PNG Image</h4>
                  <p className="text-xs text-slate-400">Crisp transparent vector layout image</p>
                </div>
                <ImageIcon className="w-5 h-5 text-slate-400 group-hover:text-orange-400" />
              </button>

              <button 
                onClick={() => handleExportImage('jpg')}
                className="w-full p-3.5 bg-slate-800 hover:bg-slate-700/80 border border-slate-700/60 rounded-xl text-left flex items-center justify-between transition-all group cursor-pointer"
              >
                <div>
                  <h4 className="font-bold text-sm text-white group-hover:text-orange-300">JPEG Document Image</h4>
                  <p className="text-xs text-slate-400">Standard print layout image format</p>
                </div>
                <ImageIcon className="w-5 h-5 text-slate-400 group-hover:text-orange-400" />
              </button>

              <button 
                onClick={handleExportJSON}
                className="w-full p-3.5 bg-slate-800 hover:bg-slate-700/80 border border-slate-700/60 rounded-xl text-left flex items-center justify-between transition-all group cursor-pointer"
              >
                <div>
                  <h4 className="font-bold text-sm text-white group-hover:text-orange-300">CAD JSON Vector Data</h4>
                  <p className="text-xs text-slate-400">Full blueprint schema file for CAD software</p>
                </div>
                <FileText className="w-5 h-5 text-slate-400 group-hover:text-orange-400" />
              </button>
            </div>

            <div className="pt-2 text-center">
              <button onClick={() => setShowExportModal(false)} className="text-xs font-semibold text-slate-400 hover:text-white">Cancel</button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
