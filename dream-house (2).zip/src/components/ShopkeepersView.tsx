import React from 'react';
import { User, Mail, Phone, X } from 'lucide-react';
import { AdminUser } from '../types';
import OnlineBadge from './OnlineBadge';

interface ShopkeepersViewProps {
  shopkeepers: AdminUser[];
  presenceMap?: Record<string, boolean>;
}

export default function ShopkeepersView({ shopkeepers, presenceMap }: ShopkeepersViewProps) {
  return (
    <div className="p-6 md:p-10 max-w-[1280px] mx-auto space-y-8 animate-fadeIn">
      <h2 className="text-3xl font-bold text-[#041627]">Our Shopkeepers</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {shopkeepers.length > 0 ? (
          shopkeepers.map((shopkeeper) => (
            <div key={shopkeeper.email} className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between min-w-0">
              <div>
                <div className="flex items-center gap-4 mb-4 min-w-0">
                  <div className="relative shrink-0">
                    <img 
                      src={shopkeeper.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"} 
                      alt={shopkeeper.fullName} 
                      className="w-16 h-16 rounded-full object-cover border border-slate-200" 
                    />
                    <OnlineBadge email={shopkeeper.email} presenceMap={presenceMap} className="bottom-0.5 right-0.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-lg font-bold text-[#041627] break-words overflow-wrap-anywhere whitespace-normal leading-tight">{shopkeeper.fullName}</h4>
                    <p className="text-sm text-[#8192a7]">Shopkeeper</p>
                  </div>
                </div>
                <div className="space-y-2 text-sm text-[#44474c] min-w-0">
                  <div className="flex items-center gap-2 min-w-0">
                    <Mail className="w-4 h-4 text-[#fd8b00] shrink-0" />
                    <span className="truncate flex-1" title={shopkeeper.email}>{shopkeeper.email}</span>
                  </div>
                  <div className="flex items-center gap-2 min-w-0">
                    <Phone className="w-4 h-4 text-[#fd8b00] shrink-0" />
                    <span className="truncate flex-1" title={shopkeeper.phone || 'N/A'}>{shopkeeper.phone || 'N/A'}</span>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 col-span-full text-[#44474c]">
            No shopkeepers found.
          </div>
        )}
      </div>
    </div>
  );
}
