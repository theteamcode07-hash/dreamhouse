import React, { useState } from 'react';
import { Star, Plus, CheckCircle2, Store, Heart, Package } from 'lucide-react';
import { Product, SellerInfo } from '../types';

interface MaterialProductCardProps {
  product: Product;
  searchQuery: string;
  onAddToCart: (product: Product) => void;
  onOpenSellerProfile: (seller: SellerInfo) => void;
  onOpenProductDetails: (product: Product) => void;
  getSellerForProduct: (prod: Product) => SellerInfo;
  highlightText: (text: string, highlight: string) => any;
}

const MaterialProductCard: React.FC<MaterialProductCardProps> = ({
  product,
  searchQuery,
  onAddToCart,
  onOpenSellerProfile,
  onOpenProductDetails,
  getSellerForProduct,
  highlightText
}) => {
  const seller = getSellerForProduct(product);

  // Unit State Management for Compact Unit Selection
  const allowedUnits = product.allowedUnits && product.allowedUnits.length > 0
    ? product.allowedUnits
    : [product.unit || 'Piece'];

  const [selectedUnit, setSelectedUnit] = useState<string>(allowedUnits[0]);

  // Dynamically resolve price and stock based on selected unit
  const activePrice = product.unitPrices && product.unitPrices[selectedUnit] !== undefined
    ? product.unitPrices[selectedUnit]
    : product.price;

  const activeOriginalPrice = product.originalPrice; // display base original price if any

  const activeStock = product.unitStocks && product.unitStocks[selectedUnit] !== undefined
    ? product.unitStocks[selectedUnit]
    : product.availableQuantity;

  return (
    <div
      onClick={() => onOpenProductDetails({
        ...product,
        unit: selectedUnit,
        price: activePrice,
        availableQuantity: activeStock
      })}
      className="group bg-white rounded-xl border border-slate-200/60 overflow-hidden shadow-xs hover:shadow-md hover:border-slate-300 hover:-translate-y-0.5 transition-all duration-300 flex flex-col h-[280px] relative select-none cursor-pointer w-full"
      id={`product-card-${product.id}`}
    >
      {/* 1. Product Image & Floating Badges */}
      <div className="relative h-[100px] w-full bg-slate-50 flex items-center justify-center p-2 border-b border-slate-100 overflow-hidden shrink-0">
        <img
          src={product.image || 'https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?w=150'}
          alt={product.name}
          className="max-h-full max-w-full object-contain mix-blend-multiply group-hover:scale-102 transition-transform duration-500 ease-out"
          referrerPolicy="no-referrer"
        />

        {/* Badges Container */}
        <div className="absolute top-1.5 left-1.5 flex flex-col gap-0.5 z-10 pointer-events-none">
          {product.isBestSeller && (
            <span className="bg-[#fd8b00] text-white text-[7px] font-black px-1 py-0.5 rounded uppercase tracking-wider shadow-xs">
              Best Seller
            </span>
          )}
          {product.freeDelivery && (
            <span className="bg-emerald-500 text-white text-[7px] font-black px-1 py-0.5 rounded uppercase tracking-wider shadow-xs">
              Free Freight
            </span>
          )}
        </div>
      </div>

      {/* 2. Card Content Wrapper */}
      <div className="p-2.5 flex-1 flex flex-col justify-between overflow-hidden bg-white">
        
        {/* Main Info Block */}
        <div className="space-y-0.5">
          {/* Category, Brand */}
          <div className="flex items-center justify-between text-[9px] font-bold text-slate-400 uppercase tracking-wider truncate">
            <span>
              {highlightText(product.category, searchQuery)} {product.brand ? `• ${product.brand}` : ''}
            </span>
          </div>

          {/* Product Name - Single line truncate for maximum compactness and consistent layout */}
          <h3 className="text-[12px] font-black text-slate-900 leading-tight truncate h-4 group-hover:text-amber-600 transition-colors" title={product.name}>
            {highlightText(product.name, searchQuery)}
          </h3>

          {/* Compact Star Rating & Stock Level Status */}
          <div className="flex items-center justify-between text-[10px] font-bold pt-0.5">
            {/* Rating Tag */}
            <div className="flex items-center gap-0.5 text-amber-500">
              <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
              <span className="text-slate-700 text-[10px] font-extrabold">{seller.rating?.toFixed(1) || '4.8'}</span>
            </div>

            {/* Compact Stock Status */}
            {(() => {
              if (activeStock !== undefined) {
                if (activeStock > 0) {
                  return (
                    <span className="text-emerald-600 font-extrabold flex items-center gap-0.5 bg-emerald-50 px-1 py-0.5 rounded text-[9px] truncate max-w-[95px]">
                      <span className="w-1 h-1 rounded-full bg-emerald-500 shrink-0"></span>
                      <span className="truncate">{activeStock} Left</span>
                    </span>
                  );
                } else {
                  return (
                    <span className="text-rose-500 font-extrabold flex items-center gap-0.5 bg-rose-50 px-1 py-0.5 rounded text-[9px] shrink-0">
                      <span className="w-1 h-1 rounded-full bg-rose-500 shrink-0"></span>
                      <span>Sold Out</span>
                    </span>
                  );
                }
              }
              return (
                <span className="text-emerald-600 font-extrabold flex items-center gap-0.5 bg-emerald-50 px-1 py-0.5 rounded text-[9px] shrink-0">
                  <span className="w-1 h-1 rounded-full bg-emerald-500 shrink-0"></span>
                  <span>In Stock</span>
                </span>
              );
            })()}
          </div>
        </div>

        {/* Interactive Actions block */}
        <div className="space-y-1.5">
          {/* Price and Unit row */}
          <div className="flex items-center justify-between gap-1 border-t border-slate-100 pt-1">
            <div className="flex flex-col min-w-0">
              <div className="flex items-baseline gap-0.5 flex-wrap">
                <span className="text-[12px] sm:text-[13px] font-black text-slate-900 leading-none truncate">
                  Rs. {activePrice.toLocaleString('en-US')}
                </span>
                {activeOriginalPrice && activeOriginalPrice > activePrice && (
                  <span className="text-[9px] text-slate-400 line-through font-medium truncate">
                    Rs. {activeOriginalPrice.toLocaleString('en-US')}
                  </span>
                )}
              </div>
            </div>

            {/* Unit Selector */}
            {allowedUnits.length > 1 ? (
              <select
                value={selectedUnit}
                onClick={(e) => e.stopPropagation()}
                onChange={(e) => {
                  e.stopPropagation();
                  setSelectedUnit(e.target.value);
                }}
                className="text-[9px] font-black text-amber-600 bg-amber-50 hover:bg-amber-100 border border-amber-200/50 rounded px-1.5 py-0.5 outline-none cursor-pointer transition-colors shrink-0"
              >
                {allowedUnits.map((u) => (
                  <option key={u} value={u}>
                    / {u}
                  </option>
                ))}
              </select>
            ) : (
              <span className="text-[9px] font-black text-amber-600 bg-amber-50/60 border border-amber-200/30 rounded px-1.5 py-0.5 shrink-0">
                / {selectedUnit}
              </span>
            )}
          </div>

          {/* Add to Cart Action Button - Reduced height to py-1.5, span full card width */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart({
                ...product,
                unit: selectedUnit,
                price: activePrice,
                availableQuantity: activeStock
              });
            }}
            disabled={activeStock !== undefined && activeStock <= 0}
            className={`w-full font-bold text-[10px] py-1.5 rounded-lg transition-all active:scale-95 flex items-center justify-center gap-1 shadow-xs cursor-pointer shrink-0 ${
              activeStock !== undefined && activeStock <= 0
                ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed shadow-none'
                : 'bg-slate-900 hover:bg-[#fd8b00] hover:text-white text-white border border-transparent'
            }`}
          >
            <Plus className="w-3 h-3 text-amber-400 shrink-0" />
            <span>{activeStock !== undefined && activeStock <= 0 ? 'SOLD OUT' : 'ADD TO CART'}</span>
          </button>

          {/* Seller compact row */}
          <div
            onClick={(e) => {
              e.stopPropagation();
              onOpenSellerProfile(seller);
            }}
            className="pt-1.5 border-t border-slate-100 flex items-center justify-between group/seller cursor-pointer transition-colors shrink-0"
            title={`View profile for ${seller.shopName || seller.name}`}
          >
            <div className="flex items-center gap-1 min-w-0">
              <div className="relative shrink-0">
                <img
                  src={seller.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                  alt={seller.shopName || seller.name}
                  className="w-4 h-4 rounded-full object-cover border border-slate-200"
                  referrerPolicy="no-referrer"
                />
                {seller.isVerified && (
                  <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600 bg-white rounded-full absolute -bottom-0.5 -right-0.5" />
                )}
              </div>
              <span className="text-[9px] font-bold text-slate-700 group-hover/seller:text-amber-600 transition-colors truncate max-w-[65px] sm:max-w-[75px]" title={seller.shopName || seller.name}>
                {seller.shopName || seller.name}
              </span>
            </div>

            {/* Compact Seller tag */}
            <div className="flex items-center gap-0.5 text-amber-500 text-[7px] font-bold shrink-0 bg-amber-50/50 px-1 py-0.5 rounded border border-amber-200/30">
              <Store className="w-2 h-2" />
              <span className="uppercase tracking-wider">Seller</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

export default MaterialProductCard;
