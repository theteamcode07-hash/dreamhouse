import React, { useState, useEffect } from 'react';
import { 
  LayoutGrid, Ruler, FolderKanban, MessageSquare, ShoppingCart, Settings, 
  HelpCircle, LogOut, Bell, ShoppingBag, Truck, CheckCircle, MessageCircle, Send, X, ArrowUpRight,
  Wrench, Compass, Users, Printer, Trash2, Clock, CreditCard, ChevronRight, AlertTriangle, Eye, EyeOff, Camera,
  Plus, Star, RefreshCw, Megaphone
} from 'lucide-react';
import { Order, WebsiteConfig, AdminUser, Product } from '../types';
import ExpertsView from './ExpertsView';
import MessagePortal from './MessagePortal';
import SharedProfileSettings from './SharedProfileSettings';
import TopExpertsAndSellers from './TopExpertsAndSellers';
import AnnouncementsView from './AnnouncementsView';
import { updatePassword, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, query, collection, where, getDocs, onSnapshot, updateDoc, increment } from 'firebase/firestore';
import { subscribeToUserMessages } from '../lib/messaging';
import { subscribeToPresence } from '../lib/presence';

const alert = (msg: string) => {
  try {
    window.alert(msg);
  } catch (e) {
    console.warn("Alert blocked in sandbox:", msg);
  }
};

interface UserDashboardProps {
  users: AdminUser[];
  username: string;
  userAvatar?: string;
  cartCount: number;
  orders: Order[];
  onNavigateToTab: (tab: string) => void;
  onLogout: () => void;
  websiteConfig?: WebsiteConfig;
  userEmail?: string;
  userPhone?: string;
  registrationDate?: string;
  accountStatus?: string;
  emailVerified?: string;
  onUpdateProfile?: (updatedData: { fullName?: string; phone?: string; avatar?: string }) => void;
  products?: Product[];
  onAddToCart?: (product: Product) => void;
  onCancelOrder?: (orderId: string, reason?: string, cancelledBy?: 'Client' | 'Seller' | 'Admin' | 'Customer') => Promise<void> | void;
  onBuyAgain?: (items: any[]) => void;
}

export default function UserDashboard({ 
  users,
  username = 'Alex', 
  userAvatar,
  cartCount, 
  orders = [],
  onNavigateToTab, 
  onLogout,
  websiteConfig,
  userEmail = '',
  userPhone = '',
  registrationDate = '',
  accountStatus = 'Active',
  emailVerified = 'Verified',
  onUpdateProfile,
  products = [],
  onAddToCart,
  onCancelOrder,
  onBuyAgain
}: UserDashboardProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'experts' | 'profile' | 'messages' | 'announcements'>('dashboard');
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadAnnouncementsCount, setUnreadAnnouncementsCount] = useState(0);
  const [presenceMap, setPresenceMap] = useState<Record<string, boolean>>({});
  const [initialMessageRecipientEmail, setInitialMessageRecipientEmail] = useState<string | null>(null);

  const currentUid = auth.currentUser?.uid || '';
  const cleanUserEmail = (userEmail || auth.currentUser?.email || '').toLowerCase().trim();

  // Strictly filter orders that belong ONLY to this client/homeowner
  const myOrders = React.useMemo(() => {
    if (!cleanUserEmail && !currentUid) return [];
    return orders.filter((o) => {
      const cEmail = (o.clientEmail || o.customerEmail || '').toLowerCase().trim();
      const cId = o.clientId || '';
      return (cleanUserEmail && cEmail === cleanUserEmail) || (currentUid && cId === currentUid);
    });
  }, [orders, cleanUserEmail, currentUid]);

  // Presence listener
  useEffect(() => {
    const unsub = subscribeToPresence((pMap) => setPresenceMap(pMap));
    return () => unsub();
  }, []);

  // Unread messages listener
  useEffect(() => {
    const email = userEmail || auth.currentUser?.email || '';
    if (!email) return;
    const unsub = subscribeToUserMessages(email, (msgs) => {
      const count = msgs.filter(m => (m.recipientEmail || m.recipientId)?.toLowerCase() === email.toLowerCase() && !m.read).length;
      setUnreadCount(count);
    });
    return () => unsub();
  }, [userEmail]);

  // Unread announcements listener
  useEffect(() => {
    const email = (userEmail || auth.currentUser?.email || '').trim().toLowerCase();
    const activeUid = currentUid || auth.currentUser?.uid || '';

    if (!activeUid || !email) {
      setUnreadAnnouncementsCount(0);
      return;
    }

    let allAnns: any[] = [];
    let readIds = new Set<string>();

    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      allAnns = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      recalc();
    });

    const unsubReads = onSnapshot(collection(db, 'announcement_reads'), (snapshot) => {
      readIds = new Set();
      snapshot.docs.forEach(d => {
        const data = d.data();
        if ((data.userId && data.userId === activeUid) || (data.userEmail && data.userEmail.toLowerCase() === email)) {
          readIds.add(data.announcementId);
        }
      });
      recalc();
    });

    function recalc() {
      const unread = allAnns.filter(item => {
        const target = item.targetAudience || item.targetRole || 'All';
        const isTargeted = 
          target === 'All' ||
          target === 'homeowner' ||
          (target === 'individual' && ((item.targetUserEmail || '').toLowerCase() === email || item.targetUserId === activeUid));
        if (!isTargeted) return false;
        if (item.scheduleTime && new Date(item.scheduleTime) > new Date()) return false;
        
        // Only show/count announcements published on or after user account creation date
        if (registrationDate) {
          const itemDate = new Date(item.createdAt || item.scheduleTime || 0);
          const userDate = new Date(registrationDate);
          if (!isNaN(itemDate.getTime()) && !isNaN(userDate.getTime())) {
            if (itemDate < userDate) {
              return false;
            }
          }
        }

        return !readIds.has(item.id);
      }).length;
      setUnreadAnnouncementsCount(unread);
    }

    return () => {
      unsubAnnouncements();
      unsubReads();
    };
  }, [userEmail, registrationDate, currentUid, auth.currentUser?.uid]);

  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantMessage, setAssistantMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{sender: 'user' | 'system', text: string}>>([
    { sender: 'system', text: `Hello ${username}! I'm your ${websiteConfig?.siteName || "Dream House"} AI Assistant. How can I assist you with your Modern Villa Revamp project today?` }
  ]);

  // Sync first message with current websiteConfig.siteName dynamically if it updates
  React.useEffect(() => {
    setChatHistory(prev => {
      if (prev.length > 0 && prev[0].sender === 'system') {
        const site = websiteConfig?.siteName || 'Dream House';
        const updatedText = `Hello ${username}! I'm your ${site} AI Assistant. How can I assist you with your Modern Villa Revamp project today?`;
        if (prev[0].text !== updatedText) {
          const newHistory = [...prev];
          newHistory[0] = { ...newHistory[0], text: updatedText };
          return newHistory;
        }
      }
      return prev;
    });
  }, [websiteConfig?.siteName, username]);
  
  
  // Expert Gated Reviews & Completed Projects State
  const [expertContracts, setExpertContracts] = useState<any[]>([]);
  const [clientReviews, setClientReviews] = useState<any[]>([]);
  const [selectedContractForReview, setSelectedContractForReview] = useState<any | null>(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewFormRating, setReviewFormRating] = useState(5);
  const [reviewFormTitle, setReviewFormTitle] = useState('');
  const [reviewFormText, setReviewFormText] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewFormError, setReviewFormError] = useState<string | null>(null);
  const [reviewFormSuccess, setReviewFormSuccess] = useState<string | null>(null);

  // Firestore listeners for expert contracts and client reviews
  useEffect(() => {
    if (!userEmail) return;
    const cleanEmail = userEmail.trim().toLowerCase();

    // 1. Listen to contracts for this client
    const contractsRef = collection(db, 'expert_contracts');
    const qContracts = query(contractsRef, where('clientEmail', '==', cleanEmail));
    const unsubContracts = onSnapshot(qContracts, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });
      setExpertContracts(list);
    }, (error) => {
      console.error("Error listening to expert contracts:", error);
    });

    // 2. Listen to reviews written by this client
    const reviewsRef = collection(db, 'expert_reviews');
    const qReviews = query(reviewsRef, where('reviewerEmail', '==', cleanEmail));
    const unsubReviews = onSnapshot(qReviews, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });
      setClientReviews(list);
    }, (error) => {
      console.error("Error listening to client reviews:", error);
    });

    return () => {
      unsubContracts();
      unsubReviews();
    };
  }, [userEmail]);

  // Handler to simulate an Ongoing expert contract for testing in sandbox
  const handleSimulateContract = async () => {
    if (!userEmail) return;
    try {
      const experts = users.filter(u => u.accountType === 'Expert');
      if (experts.length === 0) {
        alert("No registered experts found in the system to create a contract with.");
        return;
      }
      
      const randomExpert = experts[Math.floor(Math.random() * experts.length)];
      const contractId = `contract-${Date.now()}`;
      
      await setDoc(doc(db, 'expert_contracts', contractId), {
        clientEmail: userEmail.toLowerCase(),
        expertEmail: randomExpert.email.toLowerCase(),
        expertName: randomExpert.fullName || randomExpert.email || "Expert Consultant",
        projectName: "Residential Structural Blueprint Review",
        status: "Ongoing",
        createdAt: new Date().toISOString()
      });
      
      alert(`Simulated new Ongoing expert contract with ${randomExpert.fullName || randomExpert.email}!`);
    } catch (e: any) {
      console.error("Simulation error:", e);
      alert(`Simulation failed: ${e.message}`);
    }
  };

  // Submit/Update rating and review
  const handleSubmitReviewFromClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userEmail || !selectedContractForReview) return;
    if (!reviewFormText.trim()) {
      setReviewFormError("Please write a review comment.");
      return;
    }

    setIsSubmittingReview(true);
    setReviewFormError(null);
    setReviewFormSuccess(null);

    try {
      const expertEmail = selectedContractForReview.expertEmail.toLowerCase();
      const reviewId = `rev-${selectedContractForReview.id}`;
      
      const reviewData = {
        contractId: selectedContractForReview.id,
        expertEmail,
        reviewerEmail: userEmail.toLowerCase(),
        reviewerName: username || "Dream House Client",
        reviewerPhoto: userAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
        rating: reviewFormRating,
        reviewTitle: reviewFormTitle || "",
        reviewText: reviewFormText,
        projectName: selectedContractForReview.projectName || "Residential Structural Review",
        reviewDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        createdAt: new Date().toISOString(),
        helpfulCount: 0
      };

      await setDoc(doc(db, 'expert_reviews', reviewId), reviewData);
      setReviewFormSuccess("Thank you! Your rating and review have been successfully saved.");

      // Recalculate expert's overall rating in database
      const reviewsRef = collection(db, 'expert_reviews');
      const q = query(reviewsRef, where('expertEmail', '==', expertEmail));
      const querySnapshot = await getDocs(q);
      
      let totalRating = 0;
      let count = 0;
      querySnapshot.forEach((docSnap) => {
        const d = docSnap.data();
        totalRating += Number(d.rating || 0);
        count++;
      });

      const newAvg = count > 0 ? Number((totalRating / count).toFixed(1)) : reviewFormRating;
      const newTotal = count > 0 ? count : 1;

      // Update structural rating and reviewsCount directly inside accounts collection
      const accountsRef = collection(db, 'accounts');
      const qAcc = query(accountsRef, where('email', '==', expertEmail));
      const accSnapshot = await getDocs(qAcc);
      if (!accSnapshot.empty) {
        const expertDocId = accSnapshot.docs[0].id;
        await updateDoc(doc(db, 'accounts', expertDocId), {
          rating: newAvg,
          reviews: newTotal,
          reviewsCount: newTotal
        });
      }

      setTimeout(() => {
        setShowReviewModal(false);
        setSelectedContractForReview(null);
        setReviewFormSuccess(null);
      }, 1500);

    } catch (err: any) {
      console.error("Failed to submit client review:", err);
      setReviewFormError(`Failed to save review: ${err.message}`);
    } finally {
      setIsSubmittingReview(false);
    }
  };

  // Track order state
  const [orderTrackingOpen, setOrderTrackingOpen] = useState(false);
  const [selectedOrderForDetail, setSelectedOrderForDetail] = useState<Order | null>(null);
  const [activeOrderTab, setActiveOrderTab] = useState<'active' | 'delivered' | 'cancelled'>('active');
  const [showCancelReasonModal, setShowCancelReasonModal] = useState(false);
  const [cancellationReasonOption, setCancellationReasonOption] = useState('');
  const [customCancellationReason, setCustomCancellationReason] = useState('');
  const [cancellationError, setCancellationError] = useState<string | null>(null);
  const [orderIdToCancel, setOrderIdToCancel] = useState<string | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assistantMessage.trim()) return;
    
    const userMsg = assistantMessage;
    const updatedHistory = [...chatHistory, { sender: 'user', text: userMsg }];
    setChatHistory(updatedHistory);
    setAssistantMessage('');

    // Responsive simulation of advice
    setTimeout(() => {
      let reply = "I'm checking that with our project supervisors. We can adjust the structural blueprints to match your requested layout changes.";
      if (userMsg.toLowerCase().includes('shop') || userMsg.toLowerCase().includes('order')) {
        reply = "Your order #4429-A of Premium Oak Flooring is currently loaded for delivery tomorrow at 10:00 AM. You can track this in the Orders panel.";
      } else if (userMsg.toLowerCase().includes('architect') || userMsg.toLowerCase().includes('pro')) {
        reply = "Sarah Jenkins (Interior Drafting lead) is currently waiting for your feedback on Phase 1 blueprints. I can schedule a quick review meeting for you!";
      } else if (userMsg.toLowerCase().includes('draft') || userMsg.toLowerCase().includes('plan')) {
        reply = "You can access our interactive 2D/3D Floor Plan Builder from the left sidebar to draft new rooms and specify custom measurements!";
      }
      setChatHistory(prev => [...prev, { sender: 'system', text: reply }]);
    }, 1000);
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] font-sans flex h-screen overflow-hidden">
      
      {/* SideNavBar (Desktop sidebar) */}
      <nav className={`fixed left-0 top-0 h-full w-[280px] bg-[#1a2b3c] text-white shadow-md flex flex-col py-6 z-30 transition-transform duration-300 md:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} overflow-y-auto no-scrollbar`}>
        <div className="px-6 mb-8 flex justify-between items-center">
          <div>
            <h2 className="text-lg font-bold font-sans text-[#eff4ff]">Project Workspace</h2>
            <p className="text-xs text-[#8192a7] mt-0.5 font-sans">Modern Villa Revamp</p>
          </div>
          <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Profile Card */}
        <div 
          onClick={() => { setActiveTab('profile'); setMobileMenuOpen(false); }}
          className="mb-6 flex items-center gap-3 bg-[#041627]/30 p-3 rounded-lg mx-4 border border-[#8192a7]/10 shrink-0 cursor-pointer hover:bg-[#041627]/50 transition-colors"
        >
          <img 
            src={userAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
            alt={username} 
            className="w-10 h-10 rounded-full object-cover border-2 border-[#fd8b00]/30 shadow-sm"
          />
          <div className="min-w-0">
            <h3 className="text-xs font-bold text-white truncate">{username}</h3>
            <p className="text-[10px] text-[#8192a7] font-semibold tracking-wide uppercase">Client / Homeowner</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-1.5 px-3">
          <button 
            onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
            className={`flex items-center gap-4 py-3 px-4 rounded-r transition-all text-sm font-semibold w-full text-left ${activeTab === 'dashboard' ? 'bg-[#f8f9ff] text-[#041627] border-l-4 border-[#fd8b00] translate-x-1' : 'text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white'}`}
          >
            <LayoutGrid className="w-5 h-5" />
            Dashboard
          </button>

          <button 
            onClick={() => { onNavigateToTab('shop'); setMobileMenuOpen(false); }}
            className="flex items-center gap-4 text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white py-3 px-4 transition-all text-sm font-semibold w-full text-left"
          >
            <ShoppingBag className="w-5 h-5" />
            Materials Shop
          </button>

          <button 
            onClick={() => { setActiveTab('experts'); setMobileMenuOpen(false); }}
            className={`flex items-center gap-4 py-3 px-4 rounded-r transition-all text-sm font-semibold w-full text-left ${activeTab === 'experts' ? 'bg-[#f8f9ff] text-[#041627] border-l-4 border-[#fd8b00] translate-x-1' : 'text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white'}`}
          >
            <Users className="w-5 h-5" />
            Experts
          </button>

          <button 
            onClick={() => { setActiveTab('messages'); setMobileMenuOpen(false); }}
            className={`flex items-center justify-between py-3 px-4 rounded-r transition-all text-sm font-semibold w-full text-left ${activeTab === 'messages' ? 'bg-[#f8f9ff] text-[#041627] border-l-4 border-[#fd8b00] translate-x-1' : 'text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white'}`}
          >
            <span className="flex items-center gap-4">
              <MessageSquare className="w-5 h-5" />
              Messages
            </span>
            {unreadCount > 0 && (
              <span className="bg-[#fd8b00] text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          <button 
            onClick={() => { setActiveTab('announcements'); setMobileMenuOpen(false); }}
            className={`flex items-center justify-between py-3 px-4 rounded-r transition-all text-sm font-semibold w-full text-left ${activeTab === 'announcements' ? 'bg-[#f8f9ff] text-[#041627] border-l-4 border-[#fd8b00] translate-x-1' : 'text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white'}`}
          >
            <span className="flex items-center gap-4">
              <Megaphone className="w-5 h-5" />
              Announcements
            </span>
            {unreadAnnouncementsCount > 0 && (
              <span className="bg-[#fd8b00] text-white text-[10px] font-bold rounded-full px-2 py-0.5 animate-pulse">
                {unreadAnnouncementsCount}
              </span>
            )}
          </button>

          <button 
            onClick={() => { setActiveTab('profile'); setMobileMenuOpen(false); }}
            className={`flex items-center gap-4 py-3 px-4 rounded-r transition-all text-sm font-semibold w-full text-left ${activeTab === 'profile' ? 'bg-[#f8f9ff] text-[#041627] border-l-4 border-[#fd8b00] translate-x-1' : 'text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white'}`}
          >
            <Settings className="w-5 h-5" />
            Client Profile
          </button>
        </div>

        <div className="mt-6 flex flex-col gap-1 border-t border-[#8192a7]/20 pt-4 px-3">
          <button 
            onClick={onLogout}
            className="flex items-center gap-4 text-red-300 hover:bg-[#1a2b3c]/80 py-2.5 px-4 transition-all text-sm font-semibold w-full text-left"
          >
            <LogOut className="w-5 h-5" />
            Sign Out Workspace
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 md:ml-[280px] flex flex-col h-full bg-[#f8f9ff] dark:bg-slate-950 relative overflow-hidden">
        
        {/* TopNavBar */}
        <header className="bg-white dark:bg-slate-900 border-b border-[#c4c6cd]/50 dark:border-slate-800 shadow-sm flex justify-between items-center w-full px-6 md:px-10 h-20 z-10">
          <div className="flex items-center gap-3">
            <button className="md:hidden text-[#041627] dark:text-white" onClick={() => setMobileMenuOpen(true)}>
              <LayoutGrid className="w-6 h-6" />
            </button>
            {websiteConfig?.logoUrl ? (
              <img 
                alt={`${websiteConfig?.siteName || "Dream House"} Logo`} 
                className="h-8 w-8 object-contain rounded"
                src={websiteConfig.logoUrl}
              />
            ) : null}
            <div className="text-xl font-bold font-sans text-[#041627] dark:text-white">{websiteConfig?.siteName || "Dream House"}</div>
          </div>
          

          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => onNavigateToTab('cart')} 
              className="text-[#44474c] dark:text-slate-300 hover:bg-[#eff4ff] dark:hover:bg-slate-800 p-2.5 rounded-full relative transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#fd8b00] text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
              <img 
                src={userAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                alt={username} 
                className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-800 shadow-sm"
              />
              <span className="hidden sm:inline text-xs font-bold text-[#041627] dark:text-slate-200">{username}</span>
            </div>
          </div>
        </header>

        {/* Scrollable Canvas content */}
        <main className={`flex-1 ${activeTab === 'messages' ? 'h-[calc(100vh-70px)] overflow-hidden p-4 md:p-6 flex flex-col' : 'overflow-y-auto p-6 md:p-10'}`}>
          {activeTab === 'dashboard' ? (
            <div className="max-w-[1280px] mx-auto space-y-10">
              
              {/* Welcome Banner */}
              <section className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-gradient-to-r from-white to-[#eff4ff] p-6 rounded-xl border border-[#c4c6cd]/40">
                <div>
                  <h1 className="text-3xl font-bold font-sans text-[#0b1c30]">Welcome back, {username}.</h1>
                  <p className="text-[#44474c] mt-1.5 text-base">Here is the latest on your Modern Villa Revamp project.</p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => onNavigateToTab('floor_plans')}
                    className="bg-[#1a2b3c] text-white px-5 py-3 rounded-lg shadow-sm hover:bg-[#041627] hover:shadow-md transition-all text-sm font-semibold"
                  >
                    Floor Plans
                  </button>
                  <button 
                    onClick={() => onNavigateToTab('shop')}
                    className="bg-[#fd8b00] text-white px-5 py-3 rounded-lg shadow-sm hover:bg-[#e07b00] hover:shadow-md transition-all text-sm font-semibold"
                  >
                    Go to Shop
                  </button>
                </div>
              </section>



              {/* Order History Section */}
              <section className="bg-white rounded-xl shadow-sm p-6 border border-[#c4c6cd]/40 hover:border-[#041627]/50 transition-all">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                  <div>
                    <h3 className="text-xl font-bold font-sans text-[#041627]">Order History</h3>
                    <p className="text-xs text-[#44474c] mt-1">Real-time status of your heavy-freight and materials orders</p>
                  </div>
                  <div className="flex items-center gap-2 bg-[#f8f9ff] px-3 py-1.5 rounded-lg border border-[#c4c6cd]/30 text-xs font-semibold text-[#041627]">
                    <ShoppingBag className="w-4 h-4 text-[#fd8b00]" />
                    <span>{myOrders.length} Total {myOrders.length === 1 ? 'Order' : 'Orders'}</span>
                  </div>
                </div>

                {/* Navigation Tabs for Active vs Cancelled Orders */}
                <div className="flex gap-4 border-b border-slate-100 pb-4 mb-5">
                  <button 
                    onClick={() => setActiveOrderTab('active')}
                    className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                      activeOrderTab === 'active' 
                        ? 'text-[#fd8b00]' 
                        : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    Active Orders ({myOrders.filter(o => ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(o.status)).length})
                    {activeOrderTab === 'active' && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#fd8b00] rounded" />
                    )}
                  </button>
                  <button 
                    onClick={() => setActiveOrderTab('delivered')}
                    className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                      activeOrderTab === 'delivered' 
                        ? 'text-green-600' 
                        : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    Delivered Orders ({myOrders.filter(o => o.status === 'Delivered').length})
                    {activeOrderTab === 'delivered' && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-600 rounded" />
                    )}
                  </button>
                  <button 
                    onClick={() => setActiveOrderTab('cancelled')}
                    className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                      activeOrderTab === 'cancelled' 
                        ? 'text-red-600' 
                        : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    Cancelled Orders ({myOrders.filter(o => o.status === 'Cancelled').length})
                    {activeOrderTab === 'cancelled' && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600 rounded" />
                    )}
                  </button>
                </div>

                 {myOrders.filter((ord) => {
                   if (activeOrderTab === 'active') {
                     return ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(ord.status);
                   } else if (activeOrderTab === 'delivered') {
                     return ord.status === 'Delivered';
                   } else {
                     return ord.status === 'Cancelled';
                   }
                 }).length === 0 ? (
                  <div className="text-center py-10 border-2 border-dashed border-[#c4c6cd]/40 rounded-xl bg-[#f8f9ff]/50">
                    <ShoppingBag className="w-12 h-12 text-[#8192a7] mx-auto mb-3 opacity-60" />
                    <p className="text-sm font-bold text-[#041627]">No Orders Found</p>
                    <p className="text-xs text-[#44474c] mt-1">No {activeOrderTab} orders found in your project ledger.</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse min-w-[600px]">
                      <thead>
                        <tr className="border-b border-[#c4c6cd]/30 text-[#44474c] uppercase font-bold tracking-wider text-[11px]">
                          <th className="py-3.5 px-4">Order ID</th>
                          <th className="py-3.5 px-4">Recipient / Customer</th>
                          <th className="py-3.5 px-4">Date</th>
                          <th className="py-3.5 px-4">Total Amount</th>
                          <th className="py-3.5 px-4">Status</th>
                          <th className="py-3.5 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#c4c6cd]/15">
                        {myOrders
                          .filter((ord) => {
                            if (activeOrderTab === 'active') {
                              return ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(ord.status);
                            } else if (activeOrderTab === 'delivered') {
                              return ord.status === 'Delivered';
                            } else {
                              return ord.status === 'Cancelled';
                            }
                          })
                          .map((ord) => (
                          <tr 
                            key={ord.id} 
                            onClick={() => setSelectedOrderForDetail(ord)}
                            className="hover:bg-[#f8f9ff]/70 transition-colors cursor-pointer group"
                            title="Click to view full Invoice & Tracking Timeline"
                          >
                            <td className="py-4 px-4 font-mono font-bold text-[#fd8b00] text-sm">
                              {ord.id}
                            </td>
                            <td className="py-4 px-4 font-semibold text-[#041627] text-sm">
                              {ord.customer}
                            </td>
                            <td className="py-4 px-4 text-[#44474c] text-sm">
                              {ord.date}
                            </td>
                            <td className="py-4 px-4 font-bold text-[#041627] text-sm">
                              Rs. {(ord.amount ?? ord.totalPrice ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-4 px-4">
                              <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${
                                ord.status === 'Processing' || ord.status === 'Pending'
                                  ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                  : ord.status === 'Shipped'
                                    ? 'bg-blue-100 text-blue-800 border border-blue-200'
                                    : ord.status === 'Cancelled'
                                      ? 'bg-red-100 text-red-800 border border-red-200'
                                      : 'bg-green-100 text-green-800 border border-green-200'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
                                  ord.status === 'Processing' || ord.status === 'Pending'
                                    ? 'bg-amber-500'
                                    : ord.status === 'Shipped'
                                      ? 'bg-blue-500'
                                      : ord.status === 'Cancelled'
                                        ? 'bg-red-500'
                                        : 'bg-green-500'
                                }`} />
                                {ord.status}
                              </span>
                            </td>
                            <td className="py-4 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                              <button
                                onClick={() => setSelectedOrderForDetail(ord)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#041627] hover:bg-[#1a2b3c] text-white text-[10px] sm:text-xs font-bold rounded-lg transition-all cursor-pointer shadow-sm active:scale-95 hover:shadow-md"
                              >
                                <span>View Receipt</span>
                                <ChevronRight className="w-3.5 h-3.5 text-amber-400 group-hover:translate-x-0.5 transition-transform" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              {/* Hired Experts & Project History Section */}
              <section id="hired-experts-section" className="bg-white rounded-xl shadow-sm p-6 border border-[#c4c6cd]/40 hover:border-[#041627]/50 transition-all space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="text-xl font-bold font-sans text-[#041627]">Hired Experts & Project History</h3>
                    <p className="text-xs text-[#44474c] mt-1">Track status, sign-off finished blueprints, and manage consultant reviews</p>
                  </div>
                  <button 
                    type="button"
                    onClick={handleSimulateContract}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#fd8b00]/10 border border-[#fd8b00]/30 hover:bg-[#fd8b00]/20 text-[#fd8b00] text-xs font-bold rounded-lg transition-all cursor-pointer active:scale-95 animate-pulse"
                    id="simulate-contract-btn"
                  >
                    <Plus className="w-4 h-4 shrink-0" />
                    <span>Simulate Active Expert Contract</span>
                  </button>
                </div>

                {expertContracts.length === 0 ? (
                  <div className="text-center py-10 border-2 border-dashed border-[#c4c6cd]/40 rounded-xl bg-[#f8f9ff]/50" id="no-contracts-placeholder">
                    <Users className="w-12 h-12 text-[#8192a7] mx-auto mb-3 opacity-60" />
                    <p className="text-sm font-bold text-[#041627]">No Expert Contracts Found</p>
                    <p className="text-xs text-[#44474c] mt-1">You haven't initiated any professional service contracts. Browse experts below to begin!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="contracts-grid">
                    {expertContracts.map((contract) => {
                      const associatedReview = clientReviews.find(r => r.contractId === contract.id);
                      return (
                        <div 
                          key={contract.id} 
                          className="bg-slate-50 border border-slate-200/60 rounded-xl p-5 hover:border-[#fd8b00]/35 transition-all flex flex-col justify-between space-y-4 shadow-2xs"
                          id={`contract-card-${contract.id}`}
                        >
                          <div className="space-y-2">
                            <div className="flex justify-between items-start gap-2">
                              <h4 className="font-bold text-[#041627] text-sm leading-tight">{contract.projectName}</h4>
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                contract.status === 'Completed' 
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/50' 
                                  : 'bg-amber-50 text-amber-700 border border-amber-200/50'
                              }`}>
                                {contract.status}
                              </span>
                            </div>
                            <div className="text-xs text-[#44474c] space-y-1">
                              <p className="font-semibold text-slate-700 flex items-center gap-1.5">
                                <Users className="w-3.5 h-3.5 text-[#fd8b00]" />
                                Consultant: <span className="text-[#041627]">{contract.expertName}</span>
                              </p>
                              <p className="text-[10px] text-slate-400">
                                Date Hired: {new Date(contract.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>

                          {/* Action area */}
                          <div className="border-t border-slate-100/80 pt-3 flex items-center justify-between gap-4 flex-wrap">
                            <div>
                              {associatedReview ? (
                                <div className="space-y-1">
                                  <div className="flex items-center gap-0.5 text-amber-400">
                                    {Array.from({ length: 5 }).map((_, i) => (
                                      <Star key={i} className={`w-3.5 h-3.5 ${i < associatedReview.rating ? 'fill-current' : 'text-slate-250'}`} />
                                    ))}
                                  </div>
                                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Submitted {associatedReview.reviewDate}</p>
                                </div>
                              ) : contract.status === 'Completed' ? (
                                <span className="text-[10px] text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded-md border border-amber-100">
                                  Pending Review
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400 font-medium">
                                  Contract is active
                                </span>
                              )}
                            </div>

                            <div className="flex gap-2">
                              {contract.status === 'Ongoing' && (
                                <button
                                  onClick={async () => {
                                    try {
                                      const docRef = doc(db, 'expert_contracts', contract.id);
                                      await updateDoc(docRef, { status: 'Completed', completedAt: new Date().toISOString() });
                                      setSelectedContractForReview(contract);
                                      setReviewFormRating(5);
                                      setReviewFormTitle('');
                                      setReviewFormText('');
                                      setShowReviewModal(true);
                                    } catch (e: any) {
                                      alert(`Failed to complete contract: ${e.message}`);
                                    }
                                  }}
                                  className="px-3 py-1.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-[11px] font-bold rounded-lg transition-all cursor-pointer shadow-sm active:scale-95"
                                  id={`complete-btn-${contract.id}`}
                                >
                                  Mark as Completed
                                </button>
                              )}

                              {contract.status === 'Completed' && (
                                <button
                                  onClick={() => {
                                    setSelectedContractForReview(contract);
                                    if (associatedReview) {
                                      setReviewFormRating(associatedReview.rating);
                                      setReviewFormTitle(associatedReview.reviewTitle || '');
                                      setReviewFormText(associatedReview.reviewText || '');
                                    } else {
                                      setReviewFormRating(5);
                                      setReviewFormTitle('');
                                      setReviewFormText('');
                                    }
                                    setShowReviewModal(true);
                                  }}
                                  className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all cursor-pointer shadow-sm active:scale-95 ${
                                    associatedReview 
                                      ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' 
                                      : 'bg-[#041627] hover:bg-[#1a2b3c] text-white'
                                  }`}
                                  id={`rate-btn-${contract.id}`}
                                >
                                  {associatedReview ? 'View / Edit Review' : 'Rate Your Expert'}
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Top Experts and Top Sellers Sections */}
              <TopExpertsAndSellers
                users={users}
                products={products}
                onMessageUser={(email) => {
                  setInitialMessageRecipientEmail(email);
                  setActiveTab('messages');
                }}
                onAddToCart={onAddToCart}
                currentUserEmail={userEmail}
                currentUserName={username}
                currentUserAvatar={userAvatar}
                presenceMap={presenceMap}
              />

            </div>
          ) : activeTab === 'experts' ? (
            <ExpertsView 
              presenceMap={presenceMap}
              currentUserEmail={userEmail}
              currentUserName={username}
              currentUserAvatar={userAvatar}
              experts={users.filter(u => u.accountType === 'Expert' && u.status === 'Active').map(u => ({
                id: u.id,
                name: u.fullName,
                role: u.professionType || 'Expert',
                yearsOfExperience: u.yearsOfExperience || 0,
                skills: u.skillsOrTags || [],
                location: u.location || 'Kathmandu, Nepal',
                contact: u.email,
                availability: u.status === 'Active' ? 'Available' : 'Busy',
                rating: u.rating ?? 5.0,
                reviews: u.reviews ?? 0,
                photo: u.avatar,
                bio: u.bio || ''
              }))}
              onMessageExpert={(expertEmail) => {
                setInitialMessageRecipientEmail(expertEmail);
                setActiveTab('messages');
              }}
            />
          ) : activeTab === 'messages' ? (
            <MessagePortal 
              currentRole="homeowner" 
              currentUserEmail={userEmail} 
              currentUserName={username} 
              currentUserAvatar={userAvatar}
              initialContactEmail={initialMessageRecipientEmail}
              onClearInitialContactEmail={() => setInitialMessageRecipientEmail(null)}
              presenceMap={presenceMap}
            />
          ) : activeTab === 'announcements' ? (
            <AnnouncementsView 
              userId={auth.currentUser?.uid || 'client_user'}
              userEmail={userEmail || auth.currentUser?.email || ''}
              userRole="homeowner"
              userName={username}
              userCreatedAt={registrationDate}
            />
          ) : (
            <SharedProfileSettings
              roleName="Client / Homeowner"
              username={username}
              userEmail={userEmail}
              userPhone={userPhone}
              userAvatar={userAvatar}
              registrationDate={registrationDate}
              emailVerified={emailVerified}
              accountStatus={accountStatus}
              onSave={(data) => {
                if (onUpdateProfile) onUpdateProfile(data);
              }}
            />
          )}
        </main>



        {/* Tracking Status Modal popup */}
        {orderTrackingOpen && (
          <div className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full relative">
              <button className="absolute top-4 right-4 text-[#44474c] hover:text-[#041627]" onClick={() => setOrderTrackingOpen(false)}>
                <X className="w-5 h-5" />
              </button>
              
              <h3 className="text-lg font-bold font-sans text-[#041627] mb-4">Track Materials Order</h3>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <CheckCircle className="w-6 h-6 text-[#fd8b00]" />
                    <div className="w-0.5 h-10 bg-[#fd8b00]"></div>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#041627]">Order Dispatched</h4>
                    <p className="text-xs text-[#44474c]">Warehouse Logistics Center - 2:00 PM</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-6 h-6 rounded-full bg-[#fd8b00] flex items-center justify-center text-white text-[10px] font-bold">2</div>
                    <div className="w-0.5 h-10 bg-[#c4c6cd]"></div>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#041627]">Freight Load Secured</h4>
                    <p className="text-xs text-[#44474c]">Heavy Transit Carrier - 4:30 PM</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <Truck className="w-6 h-6 text-[#44474c]/50" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#041627]/60">Estimated Arrival</h4>
                    <p className="text-xs text-[#44474c]">Tomorrow at 10:00 AM</p>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setOrderTrackingOpen(false)}
                className="mt-6 w-full py-2.5 bg-[#041627] text-white rounded font-semibold text-sm hover:bg-[#1a2b3c] transition-colors"
              >
                Close Tracking Panel
              </button>
            </div>
          </div>
        )}

        {/* Interactive Invoice & Tracking Detail Modal */}
        {selectedOrderForDetail && (
          <div className="fixed inset-0 bg-[#041627]/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto no-scrollbar scrollbar-none animate-fadeIn">
            <div 
              className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col max-h-[90vh] sm:max-h-[85vh] animate-scaleUp text-[#0b1c30]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className={`${selectedOrderForDetail.status === 'Cancelled' ? 'bg-red-950 border-b border-red-900' : 'bg-[#1a2b3c]'} text-white p-4 sm:p-5 flex justify-between items-center shrink-0`}>
                <div className="flex items-center gap-3">
                  <div className={`p-2 ${selectedOrderForDetail.status === 'Cancelled' ? 'bg-red-600' : 'bg-[#fd8b00]'} rounded-xl text-white`}>
                    {selectedOrderForDetail.status === 'Cancelled' ? <AlertTriangle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold tracking-tight">Order {selectedOrderForDetail.id}</h3>
                      <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full text-white uppercase tracking-wider ${selectedOrderForDetail.status === 'Cancelled' ? 'bg-red-600' : 'bg-[#fd8b00]'}`}>
                        {selectedOrderForDetail.status === 'Cancelled' ? '❌ Cancelled' : (selectedOrderForDetail.paymentStatus || 'Paid')}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-medium">Placed on {selectedOrderForDetail.date}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedOrderForDetail(null)}
                  className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Scrollable Body - Scrollbar completely hidden while scrolling remains 100% functional */}
              <div 
                className="p-4 sm:p-6 overflow-y-auto overflow-x-hidden flex-1 space-y-6 text-[#0b1c30] no-scrollbar scrollbar-none [ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
                style={{
                  msOverflowStyle: 'none',
                  scrollbarWidth: 'none',
                }}
              >
                
                {selectedOrderForDetail.status === 'Cancelled' && (
                  <div className="bg-red-50 border border-red-100 rounded-2xl p-6 flex items-start gap-4 shadow-sm animate-in fade-in zoom-in-95 duration-200">
                    <div className="p-3 bg-red-600 text-white rounded-full shrink-0 shadow-md">
                      <Trash2 className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-base font-extrabold text-red-900 tracking-tight">Order Cancelled</h3>
                      <p className="text-xs text-red-800 font-bold">This order has been cancelled successfully. This order can no longer be processed.</p>
                      <p className="text-[10px] text-slate-500 mt-1 font-medium">All allocated material stocks have been safely restored to vendor catalogs.</p>
                    </div>
                  </div>
                )}

                {/* STATUS TRACKING PROGRESS TIMELINE */}
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-[#fd8b00]" /> Real-Time Fulfillment Tracking
                  </h4>

                  {selectedOrderForDetail.status === 'Cancelled' ? (
                    <div className="relative pt-2 pb-6">
                      {/* Progress Bar Line */}
                      <div className="absolute top-[26px] left-[15%] right-[15%] h-1 bg-slate-200 -z-0">
                        <div className="h-full bg-red-500 w-full transition-all duration-500" />
                      </div>

                      {/* Timeline Nodes */}
                      <div className="flex justify-between relative z-10">
                        {[
                          { label: 'Order Placed', desc: 'Awaiting vendor', completed: true },
                          { label: 'Order Confirmed', desc: 'Logistics set', completed: true },
                          { label: 'Order Cancelled', desc: 'Fulfillment stopped', completed: false, isCancelNode: true }
                        ].map((step, idx) => {
                          return (
                            <div key={idx} className="flex flex-col items-center w-[30%] text-center">
                              <div 
                                className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all ${
                                  step.isCancelNode 
                                    ? 'bg-red-500 border-red-500 text-white ring-4 ring-red-100' 
                                    : 'bg-emerald-500 border-emerald-500 text-white'
                                }`}
                              >
                                {step.isCancelNode ? <X className="w-5 h-5 font-bold" /> : <CheckCircle className="w-5 h-5" />}
                              </div>
                              <span className={`text-[11px] font-bold mt-2 ${step.isCancelNode ? 'text-red-600' : 'text-emerald-600'}`}>
                                {step.label}
                              </span>
                              <span className="text-[9px] text-slate-400 mt-0.5 leading-tight hidden xs:block font-medium">
                                {step.desc}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="relative pt-2 pb-6">
                      {/* Progress Bar Line */}
                      <div className="absolute top-[26px] left-[10%] right-[10%] h-1 bg-slate-200 -z-0">
                        <div 
                          className="h-full bg-emerald-500 transition-all duration-500"
                          style={{
                            width: `${
                              selectedOrderForDetail.status === 'Pending' ? '0%' :
                              selectedOrderForDetail.status === 'Confirmed' ? '33%' :
                              selectedOrderForDetail.status === 'Processing' ? '33%' :
                              selectedOrderForDetail.status === 'Shipped' ? '66%' :
                              selectedOrderForDetail.status === 'Delivered' ? '100%' : '0%'
                            }`
                          }}
                        />
                      </div>

                      {/* Timeline Nodes */}
                      <div className="flex justify-between relative z-10">
                        {[
                          { label: 'Pending', desc: 'Awaiting vendor' },
                          { label: 'Processing', desc: 'Preparing logistics' },
                          { label: 'Shipped', desc: 'In heavy transit' },
                          { label: 'Delivered', desc: 'Arrived at jobsite' }
                        ].map((step, idx) => {
                          const statusWeights: Record<string, number> = { 'Pending': 1, 'Confirmed': 2, 'Processing': 2, 'Shipped': 3, 'Delivered': 4 };
                          const currentWeight = statusWeights[selectedOrderForDetail.status] || 1;
                          const stepWeight = idx + 1;
                          const isCompleted = currentWeight >= stepWeight;
                          const isActive = currentWeight === stepWeight;

                          return (
                            <div key={idx} className="flex flex-col items-center w-[20%] text-center">
                              <div 
                                className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all ${
                                  isCompleted ? 'bg-emerald-500 border-emerald-500 text-white' : 
                                  'bg-white border-slate-200 text-slate-400'
                                } ${isActive ? 'ring-4 ring-emerald-100' : ''}`}
                              >
                                {isCompleted ? <CheckCircle className="w-5 h-5" /> : <span className="text-xs font-bold">{idx + 1}</span>}
                              </div>
                              <span className={`text-[11px] font-bold mt-2 ${isCompleted ? 'text-[#041627]' : 'text-slate-400'}`}>
                                {step.label}
                              </span>
                              <span className="text-[9px] text-slate-400 mt-0.5 leading-tight hidden xs:block font-medium">
                                {step.desc}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* RICH CANCELLATION METADATA AND REFUND LEDGER DETAILS */}
                {selectedOrderForDetail.status === 'Cancelled' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Cancellation details */}
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-red-500" /> Cancellation Ledger
                      </h4>
                      <div className="text-xs space-y-2.5">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Order ID:</span>
                          <span className="font-mono font-bold text-slate-700">{selectedOrderForDetail.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Order Date:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.date}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Cancelled At:</span>
                          <span className="font-bold text-red-600">
                            {selectedOrderForDetail.cancelledAt ? new Date(selectedOrderForDetail.cancelledAt).toLocaleString() : 'Just now'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Cancelled By:</span>
                          <span className="font-bold text-slate-700 px-2 py-0.5 rounded bg-slate-200 text-[10px]">
                            {selectedOrderForDetail.cancelledBy || 'Client'}
                          </span>
                        </div>
                        <div className="pt-2 border-t border-slate-100">
                          <span className="text-slate-400 font-semibold block mb-1">Cancellation Reason:</span>
                          <p className="bg-red-50/50 text-red-700 border border-red-100 p-2 rounded-xl text-xs font-bold leading-relaxed">
                            {selectedOrderForDetail.cancellationReason || "No explicit reason specified."}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Payment/Refund details */}
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                        <CreditCard className="w-4 h-4 text-emerald-500" /> Secure Refund Ledger
                      </h4>
                      <div className="text-xs space-y-2.5">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Payment Status:</span>
                          <span className="font-bold text-slate-700">
                            {selectedOrderForDetail.paymentMethod === 'Cash on Delivery' || selectedOrderForDetail.paymentMethod === 'COD' ? 'No Payment Required' : 'Paid'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Payment Method:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.paymentMethod || 'Online Credit Card'}</span>
                        </div>
                        {selectedOrderForDetail.paymentMethod === 'Cash on Delivery' || selectedOrderForDetail.paymentMethod === 'COD' ? (
                          <div className="pt-4 text-center">
                            <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-slate-600 font-bold text-xs">
                              No Payment Required
                            </span>
                            <p className="text-[10px] text-slate-400 mt-2 font-medium">Since the trade was Cash on Delivery, no electronic refunds are necessary.</p>
                          </div>
                        ) : (
                          <div className="space-y-2 pt-2 border-t border-slate-100">
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-semibold">Refund Status:</span>
                              <span className={`font-extrabold px-2 py-0.5 rounded text-[10px] uppercase tracking-wide ${
                                selectedOrderForDetail.refundStatus === 'Refunded' 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : 'bg-amber-100 text-amber-800 animate-pulse'
                              }`}>
                                {selectedOrderForDetail.refundStatus || 'Refund Initiated'}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400 font-semibold">Est. Processing Time:</span>
                              <span className="font-bold text-slate-700">
                                {selectedOrderForDetail.refundStatus === 'Refunded' ? 'Credited Successfully' : (selectedOrderForDetail.refundEstimatedTime || 'Instant Simulation (5s)')}
                              </span>
                            </div>
                            <p className="text-[10px] text-[#fd8b00] bg-amber-50/50 border border-amber-100 p-2 rounded-xl mt-2 font-semibold">
                              {selectedOrderForDetail.refundStatus === 'Refunded' 
                                ? 'Your account has been fully credited. Please allow up to 1-2 business days for your banking institution to reflect the ledger balance.' 
                                : 'Our automated billing gateway has initiated the refund protocol. You will be notified in 5 seconds when credit settlement clears.'}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* PDF-LIKE INVOICE LAYOUT CONTAINER (FOR DOWNLOAD/PRINTING) */}
                <div id="print-invoice-area" className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-sm">
                  
                  {/* Invoice Branding Header */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-slate-100">
                    <div>
                      <h2 className="text-xl font-black tracking-tight text-[#041627]">
                        {websiteConfig?.siteName || "DREAM HOUSE"}
                      </h2>
                      <p className="text-[10px] text-[#fd8b00] font-bold uppercase tracking-wider mt-0.5">Heavy Logistics Invoice</p>
                    </div>
                    <div className="text-left sm:text-right">
                      <p className="text-xs font-extrabold text-[#041627] uppercase tracking-wide">Invoice Slip</p>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">Ref: {selectedOrderForDetail.id}</p>
                    </div>
                  </div>

                  {/* Addresses Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs pb-6 border-b border-slate-100">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Bill To</span>
                      <p className="font-bold text-[#041627] mt-1.5">{selectedOrderForDetail.customer}</p>
                      <p className="text-slate-500 mt-1 font-medium">{selectedOrderForDetail.clientEmail || 'client@example.com'}</p>
                      <p className="text-slate-500 font-medium">Kathmandu, Nepal</p>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Ship To (Jobsite)</span>
                      <p className="font-semibold text-slate-800 mt-1.5 leading-relaxed">
                        {selectedOrderForDetail.shippingAddress || 'Jobsite #12 - Kathmandu Metropolitan, Nepal'}
                      </p>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Supplier Vendor</span>
                      <p className="font-bold text-[#041627] mt-1.5">{selectedOrderForDetail.shopkeeperName || 'ProBuild Materials Inc.'}</p>
                      <p className="text-slate-500 mt-1 font-medium">{selectedOrderForDetail.shopkeeperId || 'shopkeeper@gmail.com'}</p>
                      <p className="text-slate-500 font-medium border border-emerald-500/20 bg-emerald-50/50 px-2 py-0.5 rounded inline-block mt-1 font-bold text-[9px] text-emerald-700">
                        Verified Material Provider
                      </p>
                    </div>
                  </div>

                  {/* Itemized Materials Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-100 text-slate-400 font-bold uppercase text-[10px] tracking-wider">
                          <th className="pb-3 w-12">Preview</th>
                          <th className="pb-3">Material Description</th>
                          <th className="pb-3 text-center">Qty</th>
                          <th className="pb-3 text-right">Unit Price</th>
                          <th className="pb-3 text-right">Total Price</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50 text-[#0b1c30] font-medium">
                        {selectedOrderForDetail.items && selectedOrderForDetail.items.length > 0 ? (
                          selectedOrderForDetail.items.map((item: any, idx: number) => (
                            <tr key={idx} className="hover:bg-slate-50/30">
                              <td className="py-3 pr-2">
                                <img 
                                  src={item.productImage || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&auto=format&fit=crop&q=80'} 
                                  alt={item.productName} 
                                  className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                                  referrerPolicy="no-referrer"
                                />
                              </td>
                              <td className="py-3 font-bold text-slate-800">
                                {item.productName}
                                <p className="text-[9px] text-slate-400 font-medium mt-0.5">Category: Building Supplies</p>
                              </td>
                              <td className="py-3 text-center font-bold text-slate-900">{item.quantity}</td>
                              <td className="py-3 text-right font-mono text-slate-500">Rs. {(item.unitPrice ?? 0).toFixed(2)}</td>
                              <td className="py-3 text-right font-bold text-slate-950 font-mono">Rs. {(item.totalPrice ?? (item.unitPrice * item.quantity)).toFixed(2)}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td className="py-3 pr-2">
                              <img 
                                src={selectedOrderForDetail.productImage || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&auto=format&fit=crop&q=80'} 
                                alt={selectedOrderForDetail.productName} 
                                className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                                referrerPolicy="no-referrer"
                              />
                            </td>
                            <td className="py-3 font-bold text-slate-800">
                              {selectedOrderForDetail.productName}
                              <p className="text-[9px] text-slate-400 font-medium mt-0.5">Single Item Supply</p>
                            </td>
                            <td className="py-3 text-center font-bold text-slate-900">{selectedOrderForDetail.quantity}</td>
                            <td className="py-3 text-right font-mono text-slate-500">Rs. {(selectedOrderForDetail.unitPrice ?? 0).toFixed(2)}</td>
                            <td className="py-3 text-right font-bold text-slate-950 font-mono">Rs. {((selectedOrderForDetail.unitPrice ?? 0) * (selectedOrderForDetail.quantity ?? 1)).toFixed(2)}</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Calculations Row */}
                  <div className="pt-6 border-t border-slate-100 flex justify-end">
                    <div className="w-full sm:w-64 space-y-2 text-xs">
                      <div className="flex justify-between text-slate-500 font-medium">
                        <span>Subtotal:</span>
                        <span className="font-mono text-slate-800">
                          Rs. {((selectedOrderForDetail.amount ?? selectedOrderForDetail.totalPrice ?? 0) - (selectedOrderForDetail.freight ?? 45.00)).toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-500 font-medium">
                        <span>Flat Heavy Freight:</span>
                        <span className="font-mono text-slate-800">
                          Rs. {(selectedOrderForDetail.freight ?? 45.00).toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-500 font-medium">
                        <span>VAT Taxes (13%):</span>
                        <span className="font-mono text-emerald-600 font-bold">Inclusive</span>
                      </div>
                      <div className="flex justify-between pt-2 border-t border-slate-100 text-sm font-extrabold text-[#041627]">
                        <span>Grand Total:</span>
                        <span className="font-mono font-black text-[#fd8b00]">
                          Rs. {(selectedOrderForDetail.totalPrice ?? selectedOrderForDetail.amount ?? 0).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Ledger Footer Warning */}
                  <div className="bg-slate-50 border border-slate-100 rounded-xl p-3.5 text-[10px] text-slate-500 leading-relaxed font-medium">
                    <p className="font-bold text-slate-700 flex items-center gap-1.5 mb-1">
                      <CreditCard className="w-3.5 h-3.5 text-[#fd8b00]" /> Secure Transaction Receipt
                    </p>
                    This document serves as an electronic payment ledger receipt for contractors and project managers. Trade settlements are verified directly with the vendor. No card data or credit references are permanently recorded in active database clusters.
                  </div>
                </div>
              </div>

              {/* Modal Bottom Actions Footer */}
              <div className="bg-slate-50 p-4 border-t border-slate-100 shrink-0">
                {selectedOrderForDetail.status === 'Cancelled' ? (
                  <div className="flex flex-col sm:flex-row justify-between items-center gap-3 w-full">
                    <button 
                      onClick={() => {
                        if (onAddToCart) {
                          const items = selectedOrderForDetail.items || [];
                          if (items.length > 0) {
                            items.forEach((item: any) => {
                              const prod = products.find(p => p.id === item.productId) || {
                                id: item.productId,
                                name: item.productName,
                                price: item.unitPrice,
                                image: item.productImage || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&auto=format&fit=crop&q=80',
                                category: 'Building Supplies',
                                allowedUnits: [item.unit || 'Piece'],
                                unit: item.unit || 'Piece',
                                availableQuantity: 999,
                                delivery: true,
                                location: 'Kathmandu',
                                contact: '',
                                warranty: '',
                                specs: '',
                                tags: []
                              } as Product;
                              onAddToCart(prod);
                            });
                          } else {
                            const prod = products.find(p => p.id === selectedOrderForDetail.productId) || {
                              id: selectedOrderForDetail.productId,
                              name: selectedOrderForDetail.productName,
                              price: selectedOrderForDetail.unitPrice,
                              image: selectedOrderForDetail.productImage || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&auto=format&fit=crop&q=80',
                              category: 'Building Supplies',
                              allowedUnits: [selectedOrderForDetail.unit || 'Piece'],
                              unit: selectedOrderForDetail.unit || 'Piece',
                              availableQuantity: 999,
                              delivery: true,
                              location: 'Kathmandu',
                              contact: '',
                              warranty: '',
                              specs: '',
                              tags: []
                            } as Product;
                            onAddToCart(prod);
                          }
                          setSelectedOrderForDetail(null);
                          onNavigateToTab('shop');
                        }
                      }}
                      className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-2 active:scale-95"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      <span>Buy Again</span>
                    </button>

                    <button 
                      onClick={() => {
                        setSelectedOrderForDetail(null);
                        setActiveTab('dashboard');
                      }}
                      className="w-full sm:w-auto px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <span>Back to Home</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col xs:flex-row justify-between gap-3 w-full">
                    {/* Left Action: Cancellation */}
                    <div>
                      {(selectedOrderForDetail.status === 'Processing' || selectedOrderForDetail.status === 'Pending') && onCancelOrder && (
                        <button 
                          onClick={() => {
                            setOrderIdToCancel(selectedOrderForDetail.id);
                            setCancellationReasonOption('');
                            setCustomCancellationReason('');
                            setCancellationError(null);
                            setShowCancelReasonModal(true);
                          }}
                          className="w-full xs:w-auto px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Cancel Order</span>
                        </button>
                      )}
                    </div>

                    {/* Right Action: Print, Close */}
                    <div className="flex gap-2.5 justify-end">
                      <button 
                        onClick={() => {
                          const printContents = document.getElementById("print-invoice-area")?.innerHTML;
                          if (printContents) {
                            const printWindow = window.open('', '', 'height=600,width=800');
                            if (printWindow) {
                              printWindow.document.write('<html><head><title>Print Invoice</title>');
                              printWindow.document.write('<style>body{font-family:sans-serif;padding:40px;} table{width:100%;border-collapse:collapse;} th,td{border-bottom:1px solid #ddd;padding:10px;text-align:left;} img{display:none;} .text-right{text-align:right;} .font-bold{font-weight:bold;} .flex{display:flex;justify-content:space-between;} .grid{display:grid;grid-template-cols:1fr 1fr 1fr;gap:20px;} .space-y-6 > * + * {margin-top:24px;} .pb-6{padding-bottom:24px;border-bottom:1px solid #eee;} .pt-6{padding-top:24px;border-top:1px solid #eee;} .border-t{border-top:1px solid #eee;} .font-black{font-weight:900;} .bg-slate-50{background-color:#f8fafc;padding:15px;border-radius:10px;}</style>');
                              printWindow.document.write('</head><body>');
                              printWindow.document.write(printContents);
                              printWindow.document.write('</body></html>');
                              printWindow.document.close();
                              printWindow.focus();
                              setTimeout(() => {
                                printWindow.print();
                                printWindow.close();
                              }, 500);
                            }
                          }
                        }}
                        className="px-4 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                      >
                        <Printer className="w-4 h-4" />
                        <span>Print Invoice</span>
                      </button>
                      <button 
                        onClick={() => setSelectedOrderForDetail(null)}
                        className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Beautiful Custom Cancellation Reason Dialog Modal */}
        {showCancelReasonModal && (
          <div className="fixed inset-0 bg-[#041627]/60 backdrop-blur-sm z-55 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-md w-full animate-scaleUp text-[#0b1c30]">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 bg-red-100 text-red-600 rounded-xl">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-[#041627]">Cancel Supply Order</h3>
                  <p className="text-[11px] text-slate-400 font-medium">Please select the reason for cancelling order #{orderIdToCancel}</p>
                </div>
              </div>

              <div className="space-y-4 my-6">
                <div>
                  <label className="block text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-2">Select Reason</label>
                  <select 
                    value={cancellationReasonOption} 
                    onChange={(e) => {
                      setCancellationReasonOption(e.target.value);
                      setCancellationError(null);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#fd8b00] focus:bg-white transition-all cursor-pointer"
                  >
                    <option value="">Select a reason...</option>
                    <option value="Found cheaper elsewhere">Found cheaper elsewhere</option>
                    <option value="Project scope changed / materials no longer needed">Project scope changed / materials no longer needed</option>
                    <option value="Incorrect material quantity/specs selected">Incorrect material quantity/specs selected</option>
                    <option value="Vendor delivery delay">Vendor delivery delay</option>
                    <option value="Other (Specify reason below)">Other (Specify reason below)</option>
                  </select>
                </div>

                {cancellationReasonOption.includes('Other') && (
                  <div className="animate-in fade-in slide-in-from-top-1 duration-250">
                    <label className="block text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-2">Custom Reason</label>
                    <textarea 
                      placeholder="Please elaborate on why you are cancelling..."
                      value={customCancellationReason}
                      onChange={(e) => {
                        setCustomCancellationReason(e.target.value);
                        setCancellationError(null);
                      }}
                      className="w-full h-20 px-3.5 py-2.5 text-xs font-semibold rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:bg-white transition-all resize-none"
                    />
                  </div>
                )}

                {cancellationError && (
                  <p className="text-xs font-bold text-red-600 mt-2 animate-pulse" id="cancellation-error-msg">
                    {cancellationError}
                  </p>
                )}
              </div>

              <div className="flex gap-2.5 justify-end">
                <button 
                  disabled={isCancelling}
                  onClick={() => {
                    setShowCancelReasonModal(false);
                    setOrderIdToCancel(null);
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Close
                </button>
                <button 
                  disabled={isCancelling}
                  onClick={async () => {
                    const finalReason = cancellationReasonOption.includes('Other') ? customCancellationReason : cancellationReasonOption;
                    if (!cancellationReasonOption || !finalReason.trim()) {
                      setCancellationError("Please select a cancellation reason.");
                      alert("Please select a cancellation reason.");
                      return;
                    }

                    if (orderIdToCancel && onCancelOrder) {
                      setIsCancelling(true);
                      setCancellationError(null);
                      try {
                        await onCancelOrder(orderIdToCancel, finalReason, 'Client');
                        
                        // Also update local selected detail state to reflect cancellation immediately
                        if (selectedOrderForDetail && selectedOrderForDetail.id === orderIdToCancel) {
                          const isOnline = selectedOrderForDetail.paymentMethod !== 'Cash on Delivery' && selectedOrderForDetail.paymentMethod !== 'COD';
                          setSelectedOrderForDetail(prev => prev ? {
                            ...prev,
                            status: 'Cancelled',
                            cancelledAt: new Date().toISOString(),
                            cancelledBy: 'Client',
                            cancellationReason: finalReason,
                            refundStatus: isOnline ? 'Refund Initiated' : undefined,
                            refundEstimatedTime: isOnline ? '3-5 Business Days' : undefined
                          } : null);
                        }

                        // Close modal ONLY on success
                        setShowCancelReasonModal(false);
                        setOrderIdToCancel(null);
                        setCustomCancellationReason('');
                        setCancellationError(null);
                      } catch (err: any) {
                        console.error("Complete Firebase order cancellation error:", err);
                        setCancellationError(err.message || "Failed to cancel order. Please try again.");
                      } finally {
                        setIsCancelling(false);
                      }
                    }
                  }}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  {isCancelling ? 'Cancelling...' : 'Confirm Cancellation'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* "Rate Your Expert" Review Modal */}
        {showReviewModal && selectedContractForReview && (
          <div className="fixed inset-0 bg-[#041627]/60 backdrop-blur-sm z-[99] flex items-center justify-center p-4" id="rate-expert-modal-container">
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 max-w-lg w-full animate-in zoom-in-95 duration-200 text-[#0b1c30]" id="rate-expert-modal">
              
              <div className="flex justify-between items-start gap-4 border-b border-slate-100 pb-3 mb-4">
                <div>
                  <h3 className="text-lg font-bold text-[#041627]">Rate Your Expert</h3>
                  <p className="text-xs text-slate-400 font-medium mt-0.5">
                    Share your experience with <span className="font-bold text-[#fd8b00]">{selectedContractForReview.expertName}</span>
                  </p>
                </div>
                <button 
                  onClick={() => {
                    setShowReviewModal(false);
                    setSelectedContractForReview(null);
                    setReviewFormError(null);
                    setReviewFormSuccess(null);
                  }}
                  className="p-1 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  id="close-review-modal-btn"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmitReviewFromClient} className="space-y-4" id="review-submission-form">
                
                {/* 1. Rating Stars Selector */}
                <div className="space-y-1.5 text-center py-3 bg-slate-50 rounded-xl border border-slate-100">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Your Star Rating</label>
                  <div className="flex items-center justify-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((starNum) => (
                      <button
                        key={starNum}
                        type="button"
                        onClick={() => setReviewFormRating(starNum)}
                        className="text-amber-400 hover:scale-110 active:scale-95 transition-transform duration-100 p-1 cursor-pointer focus:outline-none"
                        id={`star-btn-${starNum}`}
                      >
                        <Star className={`w-10 h-10 ${starNum <= reviewFormRating ? 'fill-current text-amber-400' : 'text-slate-250'}`} />
                      </button>
                    ))}
                  </div>
                  <span className="text-xs font-bold text-slate-600 block mt-1">{reviewFormRating} out of 5 stars</span>
                </div>

                {/* 2. Review Title */}
                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-slate-500 uppercase tracking-wider">Review Title (Optional)</label>
                  <input 
                    type="text"
                    value={reviewFormTitle}
                    onChange={(e) => setReviewFormTitle(e.target.value)}
                    placeholder="e.g. 'Exceptional blueprints!', 'Highly professional services'"
                    className="w-full px-3.5 py-2.5 text-xs font-semibold rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[#fd8b00] focus:bg-white transition-all"
                    id="review-title-input"
                  />
                </div>

                {/* 3. Review Comment */}
                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-slate-500 uppercase tracking-wider">Review Comments (Required)</label>
                  <textarea 
                    value={reviewFormText}
                    onChange={(e) => setReviewFormText(e.target.value)}
                    placeholder="Provide details about the expert's punctuality, draft accuracy, communication, and blueprint quality..."
                    rows={4}
                    className="w-full px-3.5 py-2.5 text-xs font-semibold rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[#fd8b00] focus:bg-white transition-all resize-none"
                    id="review-comment-textarea"
                    required
                  />
                </div>

                {reviewFormError && (
                  <p className="text-xs font-bold text-red-600 mt-2 animate-pulse" id="review-error-msg">
                    {reviewFormError}
                  </p>
                )}

                {reviewFormSuccess && (
                  <p className="text-xs font-bold text-emerald-600 mt-2 animate-pulse" id="review-success-msg">
                    {reviewFormSuccess}
                  </p>
                )}

                <div className="flex gap-2.5 justify-end pt-2">
                  <button 
                    type="button"
                    disabled={isSubmittingReview}
                    onClick={() => {
                      setShowReviewModal(false);
                      setSelectedContractForReview(null);
                      setReviewFormError(null);
                      setReviewFormSuccess(null);
                    }}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition-all cursor-pointer disabled:opacity-50"
                    id="cancel-submit-review-btn"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={isSubmittingReview}
                    className="px-5 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-sm active:scale-95 disabled:opacity-50 flex items-center gap-1.5"
                    id="submit-review-btn"
                  >
                    {isSubmittingReview ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <span>Submit Review</span>
                    )}
                  </button>
                </div>

              </form>

            </div>
          </div>
        )}

      </div>
    </div>
  );
}

function ClientProfileTab({
  username,
  userAvatar,
  userEmail = '',
  userPhone = '',
  registrationDate = '',
  accountStatus = 'Active',
  emailVerified = 'Verified',
  onUpdateProfile
}: {
  username: string;
  userAvatar?: string;
  userEmail?: string;
  userPhone?: string;
  registrationDate?: string;
  accountStatus?: string;
  emailVerified?: string;
  onUpdateProfile?: (updatedData: { fullName?: string; phone?: string; avatar?: string }) => void;
}) {
  const [fullName, setFullName] = useState(username);
  const [phone, setPhone] = useState(userPhone);
  const [avatar, setAvatar] = useState(userAvatar);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Password reset states
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [isSubmittingPassword, setIsSubmittingPassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess(false);

    if (!currentPassword) {
      setPasswordError('Please enter your current password.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    const user = auth.currentUser;
    if (!user || !user.email) {
      setPasswordError('You must be logged in to change your password.');
      return;
    }

    setIsSubmittingPassword(true);
    try {
      const credential = EmailAuthProvider.credential(user.email, currentPassword);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, newPassword);
      
      // Update Firestore password field to prevent old password from working via fallback login
      try {
        const updateData = { password: newPassword, passwordLastChangedAt: new Date().toISOString() };
        await setDoc(doc(db, 'accounts', user.uid), updateData, { merge: true });
        
        // Also check if they exist in 'users' collection
        const qUsers = query(collection(db, 'users'), where('email', '==', user.email.toLowerCase()));
        const usersSnap = await getDocs(qUsers);
        for (const uDoc of usersSnap.docs) {
          await setDoc(doc(db, 'users', uDoc.id), updateData, { merge: true });
        }
      } catch (e) {
        console.warn("Could not sync password to Firestore", e);
      }
      
      setPasswordSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setTimeout(() => {
        setIsChangingPassword(false);
        setPasswordSuccess(false);
      }, 3000);
    } catch (error: any) {
      console.error('Password change error:', error);
      if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        setPasswordError('Incorrect current password.');
      } else {
        setPasswordError(error.message || 'Failed to update password.');
      }
    } finally {
      setIsSubmittingPassword(false);
    }
  };

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const compressAndResizeImage = (file: File, callback: (base64: string) => void) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 150;
          const MAX_HEIGHT = 150;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            callback(compressedBase64);
          } else {
            callback(event.target?.result as string);
          }
        } catch (e) {
          console.error("Canvas compression failed, using original reader result", e);
          callback(event.target?.result as string);
        }
      };
      img.onerror = () => {
        callback(event.target?.result as string);
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      callback("");
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      compressAndResizeImage(file, (base64Url) => {
        setAvatar(base64Url);
        // Immediately save to Firebase/local state
        if (onUpdateProfile) {
          onUpdateProfile({
            fullName: fullName.trim(),
            phone: phone.trim(),
            avatar: base64Url
          });
        }
      });
    }
  };

  const handleSave = () => {
    if (!fullName.trim()) {
      alert("Full Name cannot be empty.");
      return;
    }
    if (onUpdateProfile) {
      onUpdateProfile({
        fullName: fullName.trim(),
        phone: phone.trim(),
        avatar: avatar
      });
    }
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#041627]">Client Profile Settings</h1>
          <p className="text-xs text-[#44474c] mt-1">Manage your identity, view your verified registration metadata, and personalize your workspace profile picture.</p>
        </div>
        <span className="text-xs bg-emerald-50 text-emerald-700 py-1.5 px-3 rounded-lg font-bold border border-emerald-200">
          Account Status: {accountStatus}
        </span>
      </div>

      {saveSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-lg flex items-center gap-3 text-sm font-semibold animate-fadeIn">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Profile updated successfully! Changes propagated across the platform in real-time.</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column - Profile picture */}
        <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm flex flex-col items-center text-center justify-between min-h-[320px]">
          <div className="space-y-4 flex flex-col items-center w-full">
            <h3 className="text-sm font-bold text-[#041627] uppercase tracking-wider">Profile Photo</h3>
            
            {/* Centered Profile Picture Container with thin orange border and subtle shadow */}
            <div className="relative mx-auto w-32 h-32 flex items-center justify-center">
              <img 
                src={avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                alt={fullName}
                className="w-32 h-32 rounded-full object-cover border-2 border-[#fd8b00] shadow-md transition-transform duration-200"
                referrerPolicy="no-referrer"
              />
              {/* Camera button on bottom right */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 p-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-full shadow-md transition-all duration-200 hover:scale-110 cursor-pointer flex items-center justify-center border-2 border-white"
                id="upload-camera-icon"
                title="Change Photo"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            
            <input 
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/png, image/jpeg, image/webp"
              className="hidden"
            />

            {/* Choose Photo Button */}
            <div className="w-full">
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-xs font-bold text-[#fd8b00] hover:underline"
                id="choose-photo-btn"
              >
                Choose Photo
              </button>
              
              {/* User actual information instead of instructions */}
              <div className="mt-3 text-center">
                <div className="text-sm font-bold text-[#041627]">{fullName}</div>
                <div className="text-xs text-[#8192a7] truncate max-w-[200px] mx-auto mt-0.5">{userEmail}</div>
              </div>
            </div>
          </div>

          {/* Workspace Role at bottom */}
          <div className="pt-4 w-full border-t border-gray-100 mt-4">
            <div className="text-[10px] text-[#8192a7] font-bold uppercase tracking-wider mb-1">Workspace Role</div>
            <div className="inline-block text-xs font-bold bg-amber-50 text-amber-700 py-1 px-3 rounded-full border border-amber-200">
              Client / Homeowner
            </div>
          </div>
        </div>

        {/* Right Column - Form */}
        <div className="md:col-span-2 bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm space-y-6">
          <h3 className="text-sm font-bold text-[#041627] uppercase tracking-wider pb-3 border-b border-gray-100">
            Personal Credentials
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">Full Name</label>
              <input 
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full text-xs p-3 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00] font-sans font-medium"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">Phone Number</label>
              <input 
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs p-3 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00] font-mono font-medium"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">Email Address</label>
              <div className="relative">
                <input 
                  type="email"
                  value={userEmail}
                  disabled
                  className="w-full text-xs p-3 bg-gray-50 border border-[#c4c6cd]/60 text-gray-500 rounded cursor-not-allowed font-medium"
                />
                <span className="absolute right-3 top-3 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {emailVerified}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">Registration Timestamp</label>
              <input 
                type="text"
                value={registrationDate}
                disabled
                className="w-full text-xs p-3 bg-gray-50 border border-[#c4c6cd]/60 text-gray-500 rounded cursor-not-allowed font-mono"
              />
            </div>
          </div>


          {isChangingPassword ? (
            <div className="mt-8 pt-6 border-t border-gray-100 animate-fadeIn">
              <h3 className="text-sm font-bold text-[#041627] uppercase tracking-wider mb-4 flex items-center justify-between">
                <span>Change Password</span>
                <button 
                  type="button" 
                  onClick={() => {
                    setIsChangingPassword(false);
                    setPasswordError('');
                    setPasswordSuccess(false);
                    setCurrentPassword('');
                    setNewPassword('');
                    setConfirmNewPassword('');
                    setShowPassword(false);
                  }}
                  className="text-[#8192a7] hover:text-[#041627] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </h3>
              
              <form onSubmit={handlePasswordChange} className="space-y-4 max-w-sm">
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">Current Password</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="w-full text-xs p-3 pr-10 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00] font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">New Password</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full text-xs p-3 pr-10 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00] font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1.5">Confirm New Password</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"}
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      className="w-full text-xs p-3 pr-10 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00] font-sans"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {passwordError && (
                  <div className="p-3 bg-red-50 text-red-600 border border-red-100 rounded text-xs text-left">
                    {passwordError}
                  </div>
                )}
                {passwordSuccess && (
                  <div className="p-3 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-xs text-left flex items-center gap-2 font-semibold">
                    <CheckCircle className="w-4 h-4" />
                    Password updated successfully!
                  </div>
                )}

                <button 
                  type="submit"
                  disabled={isSubmittingPassword}
                  className="w-full py-2.5 bg-[#041627] hover:bg-[#0b1c30] text-white rounded text-xs font-bold transition-all shadow-md disabled:opacity-50"
                >
                  {isSubmittingPassword ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            </div>
          ) : (
            <div className="pt-4 flex justify-between gap-3 border-t border-gray-100">
              <button 
                type="button"
                onClick={() => setIsChangingPassword(true)}
                className="px-6 py-3 bg-white border border-[#c4c6cd] hover:border-[#fd8b00] hover:text-[#fd8b00] text-[#44474c] rounded-lg font-semibold text-xs transition-all flex items-center gap-2"
              >
                Change Password
              </button>
              <button 
                type="button"
                onClick={handleSave}
                className="px-6 py-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-lg font-semibold text-xs shadow-sm hover:shadow transition-all"
              >
                Save Profile Changes
              </button>
            </div>
          )}

        </div>
      </div>

    </div>
  );
}
