import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Star, MapPin, Briefcase, ChevronLeft, ChevronRight, MessageSquare, 
  UserCheck, Building2, CheckCircle2, Award, Clock, Phone, Mail, 
  X, ShoppingBag, Send, ThumbsUp, Heart, Layers, ShieldCheck, Check,
  Globe, Shield, Edit3, Maximize, AlertTriangle, MessageCircle
} from 'lucide-react';
import { AdminUser, Product, SellerInfo } from '../types';
import { collection, onSnapshot, query, where, getDocs, updateDoc, doc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import SellerProfileModal from './SellerProfileModal';
import SellerChatModal from './SellerChatModal';
import OnlineBadge from './OnlineBadge';

export interface ExpertItem {
  id: string;
  name: string;
  profession: string;
  yearsOfExperience: number;
  rating: number;
  reviewsCount: number;
  completedProjects: number;
  location: string;
  tagline: string;
  skills: string[];
  certifications: string[];
  photo: string;
  coverPhoto: string;
  contact: string;
  phone: string;
  availability: 'Available' | 'Busy';
  bio: string;
}

export interface SellerItem {
  id: string;
  name: string; // Owner name
  shopName: string;
  avatar: string;
  bannerUrl: string;
  isVerified: boolean;
  rating: number;
  reviewsCount: number;
  productsCount: number;
  location: string;
  description: string;
  email: string;
  phone: string;
  yearsOfExperience: number;
  categories: string[];
}

const DEFAULT_EXPERTS: ExpertItem[] = [
  {
    id: 'exp-top-1',
    name: 'David Chen',
    profession: 'Structural Engineer',
    yearsOfExperience: 12,
    rating: 4.9,
    reviewsCount: 86,
    completedProjects: 54,
    location: 'Austin, TX',
    tagline: 'Specializing in heavy structural analysis, foundation design, and seismic retrofitting.',
    skills: ['Structural Analysis', 'Concrete Engineering', 'FEA Modeling', 'Seismic Design', 'Building Code Review'],
    certifications: ['PE Certified Structural Engineer', 'LEED AP BD+C', 'NSPE Fellow'],
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?w=1000&auto=format&fit=crop&q=80',
    contact: 'david.chen@structural.com',
    phone: '+1 (555) 392-1100',
    availability: 'Available',
    bio: 'Over 12 years of experience leading complex structural engineering projects for high-end residential estates and commercial developments. Passionate about structural integrity, code compliance, and innovative material efficiency.'
  },
  {
    id: 'exp-top-2',
    name: 'Sarah Jenkins',
    profession: 'Architect & Interior Specialist',
    yearsOfExperience: 9,
    rating: 5.0,
    reviewsCount: 112,
    completedProjects: 68,
    location: 'Los Angeles, CA',
    tagline: 'Creating modern luxury interior spaces, custom spatial layouts, and architectural blueprints.',
    skills: ['3D Spatial Rendering', 'Bespoke Lighting', 'Interior Drafting', 'Material Curation', 'Sustainable Finishes'],
    certifications: ['NCIDQ Certified Designer', 'AIA Associate Member', 'ASID Professional'],
    photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1000&auto=format&fit=crop&q=80',
    contact: 'sarah.jenkins@designstudio.com',
    phone: '+1 (555) 482-9922',
    availability: 'Available',
    bio: 'Renowned architect and interior planner focusing on open-concept modern floor plans, daylighting optimization, and bespoke material palettes that harmonize form and function.'
  },
  {
    id: 'exp-top-3',
    name: 'Marcus Vance',
    profession: 'Master Electrician',
    yearsOfExperience: 15,
    rating: 4.9,
    reviewsCount: 94,
    completedProjects: 120,
    location: 'Houston, TX',
    tagline: 'Commercial and high-capacity residential electrical wiring, solar integrations, and smart power grids.',
    skills: ['High-Voltage Systems', 'Smart Home Automation', 'Solar Inverters', 'Circuit Load Testing', 'Backup Generators'],
    certifications: ['Master Electrician License #49201', 'OSHA 30 Construction Certified', 'IEC Master Tech'],
    photo: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&auto=format&fit=crop&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1000&auto=format&fit=crop&q=80',
    contact: 'marcus.vance@powergrid.com',
    phone: '+1 (555) 883-2041',
    availability: 'Available',
    bio: 'Licensed Master Electrician with 15 years in utility-scale wiring, smart home automation infrastructure, and renewable energy integration. Known for zero-defect compliance and safe execution.'
  },
  {
    id: 'exp-top-4',
    name: 'Elena Rostova',
    profession: 'Senior Landscape Architect',
    yearsOfExperience: 11,
    rating: 4.8,
    reviewsCount: 64,
    completedProjects: 42,
    location: 'Seattle, WA',
    tagline: 'Eco-friendly exterior architectural landscaping, hardscaping, and outdoor living suite designs.',
    skills: ['Hardscape Design', 'Native Ecology Plan', 'Irrigation Engineering', 'Outdoor Living Suites', 'Terracing'],
    certifications: ['Registered Landscape Architect (RLA)', 'CLARB Certified', 'Sustainable Sites Accredited'],
    photo: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1558904541-efa8c196b27d?w=1000&auto=format&fit=crop&q=80',
    contact: 'elena.rostova@ecoscape.com',
    phone: '+1 (555) 912-7833',
    availability: 'Available',
    bio: 'Dedicated landscape architect specializing in sustainable site development, custom stone terracing, native drought-tolerant greenery, and luxury outdoor entertainment amenities.'
  },
  {
    id: 'exp-top-5',
    name: 'Robert Martinez',
    profession: 'Master Plumber & MEP Specialist',
    yearsOfExperience: 14,
    rating: 4.9,
    reviewsCount: 78,
    completedProjects: 95,
    location: 'Dallas, TX',
    tagline: 'Advanced hydronic piping, backflow prevention, and heavy MEP installation for luxury estates.',
    skills: ['Hydronic Heating', 'MEP Coordination', 'Backflow Prevention', 'Water Filtration', 'Gas Line Piping'],
    certifications: ['Master Plumber License #88219', 'MedGas Certified', 'ASSE Backflow Specialist'],
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1000&auto=format&fit=crop&q=80',
    contact: 'robert.martinez@mepsolutions.com',
    phone: '+1 (555) 301-4455',
    availability: 'Available',
    bio: 'Master Plumber and MEP system designer. Specializes in luxury residential plumbing rough-ins, radiant floor heating loops, rainwater harvesting, and high-volume gas supply manifolds.'
  }
];

const DEFAULT_SELLERS: SellerItem[] = [
  {
    id: 'seller-1',
    name: 'Demo Shopkeeper',
    shopName: 'ProBuild Materials Inc.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1000&auto=format&fit=crop&q=80',
    isVerified: true,
    rating: 4.9,
    reviewsCount: 142,
    productsCount: 18,
    location: '102 Industrial Parkway, Austin, TX',
    description: 'Premier supplier of contractor-grade construction materials, red clay bricks, certified rebar, and Portland cement.',
    email: 'shopkeeper@gmail.com',
    phone: '+1 (555) 987-6543',
    yearsOfExperience: 12,
    categories: ['Bricks', 'Cement', 'Iron Rod', 'Aggregates']
  },
  {
    id: 'seller-2',
    name: 'Marcus Vance',
    shopName: 'Apex Heavy Building Supply',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&auto=format&fit=crop&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1000&auto=format&fit=crop&q=80',
    isVerified: true,
    rating: 4.8,
    reviewsCount: 98,
    productsCount: 24,
    location: '45 Commerce Way, Houston, TX',
    description: 'Authorized distributor for heavy structural steel, Grade 60 rebar, framing lumber, and industrial hardware.',
    email: 'apex.supplies@dreamhouse.com',
    phone: '+1 (800) 555-0192',
    yearsOfExperience: 10,
    categories: ['Steel & Rebar', 'Framing Lumber', 'Safety Gear', 'Fasteners']
  },
  {
    id: 'seller-3',
    name: 'Eleanor Hayes',
    shopName: 'BuildCraft Timber & Masonry',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1000&auto=format&fit=crop&q=80',
    isVerified: true,
    rating: 5.0,
    reviewsCount: 215,
    productsCount: 32,
    location: '78 Timber Ridge Road, Seattle, WA',
    description: 'Specializing in premium Baltic birch plywood, engineered timber, and architectural masonry products.',
    email: 'buildcraft@dreamhouse.com',
    phone: '+1 (888) 444-2300',
    yearsOfExperience: 15,
    categories: ['Plywood', 'Hardwood Timber', 'Stone Veneer', 'Custom Trim']
  },
  {
    id: 'seller-4',
    name: 'Arthur Pendelton',
    shopName: 'Prime Hardware Depot',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=1000&auto=format&fit=crop&q=80',
    isVerified: true,
    rating: 4.9,
    reviewsCount: 164,
    productsCount: 45,
    location: '302 Distribution Blvd, Dallas, TX',
    description: 'High-grade power tools, electrical fixtures, commercial plumbing hardware, and jobsite fasteners.',
    email: 'prime.depot@dreamhouse.com',
    phone: '+1 (555) 720-1928',
    yearsOfExperience: 14,
    categories: ['Power Tools', 'Plumbing Fixtures', 'Electrical Supplies', 'Safety']
  }
];

interface TopExpertsAndSellersProps {
  users?: AdminUser[];
  products?: Product[];
  onMessageUser?: (userEmail: string) => void;
  onAddToCart?: (product: Product) => void;
  currentUserEmail?: string;
  currentUserName?: string;
  currentUserAvatar?: string;
  presenceMap?: Record<string, boolean>;
}

export default function TopExpertsAndSellers({
  users = [],
  products = [],
  onMessageUser,
  onAddToCart,
  currentUserEmail = 'homeowner@gmail.com',
  currentUserName = 'Alex',
  currentUserAvatar,
  presenceMap
}: TopExpertsAndSellersProps) {
  // Lists state
  const [experts, setExperts] = useState<ExpertItem[]>([]);
  const [sellers, setSellers] = useState<SellerItem[]>([]);

  // Modals state
  const [selectedExpertForModal, setSelectedExpertForModal] = useState<ExpertItem | null>(null);
  const [selectedSellerForModal, setSelectedSellerForModal] = useState<SellerInfo | null>(null);
  const [chatSellerModal, setChatSellerModal] = useState<SellerInfo | null>(null);
  const [hireExpertInquiry, setHireExpertInquiry] = useState<ExpertItem | null>(null);
  const [followedShops, setFollowedShops] = useState<Record<string, boolean>>({});

  // Redesigned Expert Profile Modal states
  const [activeProfileTab, setActiveProfileTab] = useState<'about' | 'portfolio' | 'reviews'>('about');
  const [portfolioProjects, setPortfolioProjects] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [isEligible, setIsEligible] = useState(false);
  const [userHasReviewed, setUserHasReviewed] = useState(false);
  const [existingUserReview, setExistingUserReview] = useState<any>(null);
  
  // Review form state
  const [formRating, setFormRating] = useState(5);
  const [formText, setFormText] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewSuccess, setReviewSuccess] = useState<string | null>(null);

  // Lightbox and Image Gallery State
  const [activeLightboxProject, setActiveLightboxProject] = useState<any | null>(null);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [isFullscreenPhoto, setIsFullscreenPhoto] = useState(false);

  // Scroll Refs & Button visibility
  const expertsScrollRef = useRef<HTMLDivElement>(null);
  const sellersScrollRef = useRef<HTMLDivElement>(null);

  const [expertsCanScrollLeft, setExpertsCanScrollLeft] = useState(false);
  const [expertsCanScrollRight, setExpertsCanScrollRight] = useState(false);
  const [sellersCanScrollLeft, setSellersCanScrollLeft] = useState(false);
  const [sellersCanScrollRight, setSellersCanScrollRight] = useState(false);

  useEffect(() => {
    const unsubExperts = onSnapshot(collection(db, 'topExperts'), (snapshot) => {
      const list: ExpertItem[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        list.push({ id: docSnap.id, ...data } as ExpertItem);
      });
      setExperts(list.slice(0, 3));
    }, (err) => {
      console.warn('[TopExpertsAndSellers] error loading experts:', err);
    });

    const unsubSellers = onSnapshot(collection(db, 'topSellers'), (snapshot) => {
      const list: SellerItem[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        list.push({ id: docSnap.id, ...data } as SellerItem);
      });
      setSellers(list.slice(0, 3));
    }, (err) => {
      console.warn('[TopExpertsAndSellers] error loading sellers:', err);
    });

    return () => {
      unsubExperts();
      unsubSellers();
    };
  }, []);

  // Escape key handler to close modals
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isFullscreenPhoto) {
          setIsFullscreenPhoto(false);
        } else if (activeLightboxProject) {
          setActiveLightboxProject(null);
        } else if (selectedExpertForModal) {
          setSelectedExpertForModal(null);
        } else if (hireExpertInquiry) {
          setHireExpertInquiry(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedExpertForModal, activeLightboxProject, isFullscreenPhoto, hireExpertInquiry]);

  // Real-time Firebase subscriptions for Expert Portfolio & Reviews
  useEffect(() => {
    if (!selectedExpertForModal) {
      setPortfolioProjects([]);
      setReviews([]);
      setIsEligible(false);
      setUserHasReviewed(false);
      setExistingUserReview(null);
      setReviewError(null);
      setReviewSuccess(null);
      return;
    }
    setActiveProfileTab('about');

    const expertEmail = selectedExpertForModal.contact.toLowerCase();

    // 1. Subscribe to expert's portfolio projects from Firestore
    const projectsRef = collection(db, 'expert_portfolio');
    const qProjects = query(projectsRef, where('expertEmail', '==', expertEmail));
    const unsubProjects = onSnapshot(qProjects, (snapshot) => {
      const projectsList: any[] = [];
      snapshot.forEach((docSnap) => {
        projectsList.push({ id: docSnap.id, ...docSnap.data() });
      });

      if (projectsList.length === 0) {
        // Automatically seed high-quality projects for this expert if none exist in Firebase yet
        const role = (selectedExpertForModal.profession || '').toLowerCase();
        let seedData: any[] = [];

        if (role.includes('architect')) {
          seedData = [
            {
              expertEmail,
              title: "The Glass House Pavilion",
              category: "Architectural Design",
              location: "Budhanilkantha, Kathmandu",
              completionYear: "2024",
              coverImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80",
              description: "A premium minimalist 3-bedroom modern residence featuring double-glazed glass panels, steel frames, and sustainable solar roofs.",
              images: [
                "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 1,45,00,000",
              completionDate: "February 20, 2024",
              clientFeedback: "The architectural flow and light distribution are extraordinary. Extremely professional delivery.",
              technologies: "Tempered Glass, Structural Steel, Teak Wood Floorboards, Smart Solar Inverters"
            },
            {
              expertEmail,
              title: "Lalitpur Heritage Loft Revamp",
              category: "Restoration & Design",
              location: "Patan, Lalitpur",
              completionYear: "2025",
              coverImage: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&auto=format&fit=crop&q=80",
              description: "Restored a classic Nepalese Newari brick building into a high-end luxury loft with a duplex steel mezzanine floor and automated lighting controls.",
              images: [
                "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 85,00,000",
              completionDate: "January 15, 2025",
              clientFeedback: "Brought traditional Nepali aesthetics together with state-of-the-art modular living in a masterful manner.",
              technologies: "Traditional Newari Brick, Structural Mezzanine, Modular Smart Kitchen, Recessed LEDs"
            }
          ];
        } else if (role.includes('engineer')) {
          seedData = [
            {
              expertEmail,
              title: "Hillside Villa Foundation",
              category: "Structural Engineering",
              location: "Dhulikhel, Kavre",
              completionYear: "2023",
              coverImage: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&auto=format&fit=crop&q=80",
              description: "Engineered deep-pile foundations and specialized retaining structures on unstable sloped terrain to support a multi-level luxury villa.",
              images: [
                "https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 65,00,000",
              completionDate: "November 10, 2023",
              clientFeedback: "Phenomenal attention to seismic detailing and soil report compliance. Highly recommend!",
              technologies: "M30 Grade Concrete, Fe500 reinforcement steel bars, micro-piling structures"
            },
            {
              expertEmail,
              title: "Pokhara Lakefront Retaining Pier",
              category: "Hydraulic Engineering",
              location: "Lakeside, Pokhara",
              completionYear: "2024",
              coverImage: "https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=800&auto=format&fit=crop&q=80",
              description: "Designed a durable, erosion-resistant retaining sea-wall and concrete pier system utilizing eco-gabions and anti-corrosive concrete additives.",
              images: [
                "https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1518005020951-eccb494ad742?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 95,00,000",
              completionDate: "May 18, 2024",
              clientFeedback: "Protected our lakefront property flawlessly against seasonal water surges and soil erosion.",
              technologies: "Anti-Corrosive Concrete, PVC Coated Gabion Wire Mesh, Geo-textiles"
            }
          ];
        } else {
          seedData = [
            {
              expertEmail,
              title: "Luxury Bathroom Sanctuary",
              category: "Plumbing & Design",
              location: "Jhamsikhel, Lalitpur",
              completionYear: "2024",
              coverImage: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800&auto=format&fit=crop&q=80",
              description: "Installed complex high-pressure concealed piping, premium German water-heating manifolds, and luxurious multi-shower fixtures.",
              images: [
                "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&auto=format&fit=crop&q=80"
              ],
              budget: "Rs. 28,00,000",
              completionDate: "July 29, 2024",
              clientFeedback: "Extremely tidy piping work and perfectly balanced water pressure. Flawless execution.",
              technologies: "PEX Piping, Grohe Concealed Manifolds, Dual-Boiler Heat Pumps"
            }
          ];
        }

        seedData.forEach(async (proj) => {
          const docId = `proj-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
          await setDoc(doc(db, 'expert_portfolio', docId), proj);
        });
      } else {
        setPortfolioProjects(projectsList);
      }
    });

    // 2. Subscribe to expert's reviews from Firestore
    const reviewsRef = collection(db, 'expert_reviews');
    const qReviews = query(reviewsRef, where('expertEmail', '==', expertEmail));
    const unsubReviews = onSnapshot(qReviews, (snapshot) => {
      const reviewsList: any[] = [];
      snapshot.forEach((docSnap) => {
        reviewsList.push({ id: docSnap.id, ...docSnap.data() });
      });

      if (reviewsList.length === 0) {
        // Automatically seed high-quality default reviews from Firestore if empty
        const defaultReviews = [
          {
            expertEmail,
            reviewerEmail: "sarah.j@example.com",
            reviewerName: "Sarah Jenkins",
            reviewerPhoto: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
            rating: 5,
            reviewText: `Absolutely incredible working with ${selectedExpertForModal.name}! Super professional, prompt in communication, and delivered perfect results ahead of schedule.`,
            reviewDate: "July 12, 2026",
            createdAt: new Date().toISOString()
          },
          {
            expertEmail,
            reviewerEmail: "marcus.b@example.com",
            reviewerName: "Marcus Brody",
            reviewerPhoto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
            rating: 5,
            reviewText: `Highly recommended. They caught several critical design details that saved us thousands in construction costs. A true master of the craft!`,
            reviewDate: "June 25, 2026",
            createdAt: new Date().toISOString()
          }
        ];

        defaultReviews.forEach(async (rev) => {
          const docId = `rev-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
          await setDoc(doc(db, 'expert_reviews', docId), rev);
        });
      } else {
        // Sort reviews: newest first
        reviewsList.sort((a, b) => new Date(b.createdAt || b.reviewDate).getTime() - new Date(a.createdAt || a.reviewDate).getTime());
        setReviews(reviewsList);
      }
    });

    // 3. Subscribe to contract/eligibility verification
    let unsubContracts = () => {};
    let unsubUserReview = () => {};
    
    if (currentUserEmail) {
      const contractsRef = collection(db, 'expert_contracts');
      const qContracts = query(contractsRef, 
        where('clientEmail', '==', currentUserEmail.toLowerCase()), 
        where('expertEmail', '==', expertEmail),
        where('status', '==', 'Completed')
      );
      unsubContracts = onSnapshot(qContracts, (snapshot) => {
        setIsEligible(!snapshot.empty);
      });

      // 4. Check if user already submitted a review
      const qUserReview = query(reviewsRef,
        where('expertEmail', '==', expertEmail),
        where('reviewerEmail', '==', currentUserEmail.toLowerCase())
      );
      unsubUserReview = onSnapshot(qUserReview, (snapshot) => {
        if (!snapshot.empty) {
          setUserHasReviewed(true);
          const firstReview = snapshot.docs[0].data();
          setExistingUserReview({ id: snapshot.docs[0].id, ...firstReview });
          setFormRating(firstReview.rating);
          setFormText(firstReview.reviewText);
        } else {
          setUserHasReviewed(false);
          setExistingUserReview(null);
          setFormRating(5);
          setFormText('');
        }
      });
    } else {
      setIsEligible(false);
      setUserHasReviewed(false);
      setExistingUserReview(null);
    }

    return () => {
      unsubProjects();
      unsubReviews();
      unsubContracts();
      unsubUserReview();
    };
  }, [selectedExpertForModal, currentUserEmail]);

  // Demo contract helper to let testing users instantly unlock eligibility in Firestore
  const handleUnlockReviewForm = async () => {
    if (!currentUserEmail || !selectedExpertForModal) return;
    try {
      const contractId = `contract-${Date.now()}`;
      await setDoc(doc(db, 'expert_contracts', contractId), {
        id: contractId,
        clientEmail: currentUserEmail.toLowerCase(),
        expertEmail: selectedExpertForModal.contact.toLowerCase(),
        status: 'Completed',
        projectName: 'Villa Remodeling Project',
        createdAt: new Date().toISOString()
      });
      setIsEligible(true);
    } catch (e: any) {
      console.error("Failed to unlock review form:", e);
    }
  };

  // Submission handler for Reviews (saves, calculates averages, and updates expert's root document)
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserEmail || !selectedExpertForModal) return;
    if (!formText.trim()) {
      setReviewError("Please write a review comment.");
      return;
    }

    setIsSubmittingReview(true);
    setReviewError(null);
    setReviewSuccess(null);

    try {
      const expertEmail = selectedExpertForModal.contact.toLowerCase();
      const reviewData = {
        expertEmail,
        reviewerEmail: currentUserEmail.toLowerCase(),
        reviewerName: currentUserName || "Dream House Client",
        reviewerPhoto: currentUserAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
        rating: formRating,
        reviewText: formText,
        reviewDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        createdAt: new Date().toISOString()
      };

      if (userHasReviewed && existingUserReview) {
        // Edit existing review
        await setDoc(doc(db, 'expert_reviews', existingUserReview.id), reviewData, { merge: true });
        setReviewSuccess("Your review has been successfully updated!");
      } else {
        // Submit a new review
        const reviewId = `rev-${Date.now()}`;
        await setDoc(doc(db, 'expert_reviews', reviewId), reviewData);
        setReviewSuccess("Thank you! Your review has been successfully submitted.");
      }

      // Query all reviews to recalculate the immediate overall average rating
      const reviewsRef = collection(db, 'expert_reviews');
      const q = query(reviewsRef, where('expertEmail', '==', expertEmail));
      const querySnapshot = await getDocs(q);
      
      let totalRating = 0;
      let count = 0;
      querySnapshot.forEach((docSnap) => {
        const d = docSnap.data();
        totalRating += Number(d.rating || 0);
        count++;
      });

      const newAvg = count > 0 ? Number((totalRating / count).toFixed(1)) : formRating;
      const newTotal = count > 0 ? count : 1;

      // Update structural rating and reviewsCount directly inside accounts collection
      const accountsRef = collection(db, 'accounts');
      const qAcc = query(accountsRef, where('email', '==', expertEmail));
      const accSnapshot = await getDocs(qAcc);
      if (!accSnapshot.empty) {
        const expertDocId = accSnapshot.docs[0].id;
        await updateDoc(doc(db, 'accounts', expertDocId), {
          rating: newAvg,
          reviews: newTotal,
          reviewsCount: newTotal
        });
      }

    } catch (err: any) {
      console.error("Error submitting review:", err);
      setReviewError("Failed to submit review. Please try again.");
    } finally {
      setIsSubmittingReview(false);
    }
  };

  // Calculate rating breakdown stats based on current reviews collection state
  const getRatingBreakdown = () => {
    const counts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    if (reviews.length === 0) return { breakdown: { 5: 100, 4: 0, 3: 0, 2: 0, 1: 0 }, total: 0, average: 5.0 };

    let sum = 0;
    reviews.forEach(r => {
      const ratingKey = Math.min(5, Math.max(1, Math.round(r.rating || 5))) as 5|4|3|2|1;
      counts[ratingKey]++;
      sum += (r.rating || 5);
    });

    const breakdown = {
      5: Math.round((counts[5] / reviews.length) * 100),
      4: Math.round((counts[4] / reviews.length) * 100),
      3: Math.round((counts[3] / reviews.length) * 100),
      2: Math.round((counts[2] / reviews.length) * 100),
      1: Math.round((counts[1] / reviews.length) * 100),
    };

    return {
      breakdown,
      total: reviews.length,
      average: Number((sum / reviews.length).toFixed(1))
    };
  };

  const ratingStats = getRatingBreakdown();

  // Update Scroll Buttons status
  const checkScrollState = useCallback(() => {
    if (expertsScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = expertsScrollRef.current;
      setExpertsCanScrollLeft(scrollLeft > 5);
      setExpertsCanScrollRight(scrollLeft < scrollWidth - clientWidth - 5);
    }
    if (sellersScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = sellersScrollRef.current;
      setSellersCanScrollLeft(scrollLeft > 5);
      setSellersCanScrollRight(scrollLeft < scrollWidth - clientWidth - 5);
    }
  }, []);

  useEffect(() => {
    checkScrollState();

    const expEl = expertsScrollRef.current;
    const selEl = sellersScrollRef.current;

    if (expEl) expEl.addEventListener('scroll', checkScrollState, { passive: true });
    if (selEl) selEl.addEventListener('scroll', checkScrollState, { passive: true });

    window.addEventListener('resize', checkScrollState);

    return () => {
      if (expEl) expEl.removeEventListener('scroll', checkScrollState);
      if (selEl) selEl.removeEventListener('scroll', checkScrollState);
      window.removeEventListener('resize', checkScrollState);
    };
  }, [experts, sellers, checkScrollState]);

  // Smooth scroll handler
  const scrollRow = (ref: React.RefObject<HTMLDivElement | null>, direction: 'left' | 'right') => {
    if (!ref.current) return;
    const scrollAmount = Math.max(ref.current.clientWidth * 0.75, 300);
    ref.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth'
    });
  };

  const toggleFollowShop = (shopId: string) => {
    setFollowedShops(prev => ({
      ...prev,
      [shopId]: !prev[shopId]
    }));
  };

  return (
    <div className="space-y-10 py-2">

      {/* =========================================================================
          SECTION 1: TOP EXPERTS ROW
      ========================================================================= */}
      <section className="space-y-4">
        {/* Section Header */}
        <div className="flex justify-between items-end gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#fd8b00]/10 text-[#fd8b00] border border-[#fd8b00]/20 mb-1">
              <Award className="w-3.5 h-3.5" />
              <span>Highest Rated Professionals</span>
            </div>
            <h3 className="text-2xl font-extrabold font-sans text-[#0b1c30]">Top Experts</h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Work with certified structural engineers, architects, master electricians, and skilled trade leaders.
            </p>
          </div>

          {/* Navigation Scroll Arrows */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => scrollRow(expertsScrollRef, 'left')}
              disabled={!expertsCanScrollLeft}
              aria-label="Scroll experts left"
              className={`p-2.5 rounded-full border transition-all duration-200 cursor-pointer ${
                expertsCanScrollLeft
                  ? 'bg-white dark:bg-slate-800 text-[#041627] dark:text-slate-100 border-slate-200 dark:border-slate-700 shadow-sm hover:bg-[#fd8b00] hover:text-white hover:border-[#fd8b00] active:scale-95'
                  : 'bg-slate-100 dark:bg-slate-800/50 text-slate-300 dark:text-slate-600 border-slate-200/50 dark:border-slate-800 cursor-not-allowed opacity-50'
              }`}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scrollRow(expertsScrollRef, 'right')}
              disabled={!expertsCanScrollRight}
              aria-label="Scroll experts right"
              className={`p-2.5 rounded-full border transition-all duration-200 cursor-pointer ${
                expertsCanScrollRight
                  ? 'bg-white dark:bg-slate-800 text-[#041627] dark:text-slate-100 border-slate-200 dark:border-slate-700 shadow-sm hover:bg-[#fd8b00] hover:text-white hover:border-[#fd8b00] active:scale-95'
                  : 'bg-slate-100 dark:bg-slate-800/50 text-slate-300 dark:text-slate-600 border-slate-200/50 dark:border-slate-800 cursor-not-allowed opacity-50'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Horizontal Scroll Row */}
        {experts.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 min-h-[200px] w-full">
            <p className="text-slate-500 dark:text-slate-400 font-medium">No Top Experts Available</p>
          </div>
        ) : (
          <div 
            ref={expertsScrollRef}
            className="flex gap-5 overflow-x-auto pb-4 pt-1 px-1 scrollbar-none no-scrollbar snap-x snap-mandatory"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
          {experts.map((exp) => (
            <div
              key={exp.id}
              className="snap-start shrink-0 w-[300px] sm:w-[320px] bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-sm hover:shadow-xl hover:border-[#fd8b00]/60 transition-all duration-300 flex flex-col justify-between group overflow-hidden"
            >
              {/* Profile Image & Content (No Cover Image) */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <div className="relative shrink-0">
                      <img 
                        src={exp.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} 
                        alt={exp.name} 
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-200 dark:border-slate-700 shadow-sm bg-slate-100"
                      />
                      <OnlineBadge email={exp.contact} presenceMap={presenceMap} className="bottom-1 right-1" />
                    </div>
                    <div className="flex flex-col items-end gap-1.5">
                      <div className="flex items-center gap-1 bg-amber-400/90 text-slate-900 text-xs font-black px-2 py-0.5 rounded-full shadow-xs">
                        <Star className="w-3.5 h-3.5 fill-current text-slate-900" />
                        <span>{exp.rating.toFixed(1)}</span>
                      </div>
                      <span className="text-[10px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                        {exp.yearsOfExperience} Yrs Exp
                      </span>
                    </div>
                  </div>

                  <span className="px-2.5 py-0.5 bg-[#fd8b00]/10 text-[#fd8b00] rounded-full text-[10px] font-bold border border-[#fd8b00]/20 inline-block mb-1.5">
                    {exp.availability === 'Available' ? '🟢 Available' : '🔴 On Project'}
                  </span>

                  <h4 className="text-base font-extrabold text-[#041627] dark:text-white group-hover:text-[#fd8b00] transition-colors leading-snug break-words overflow-wrap-anywhere whitespace-normal">
                    {exp.name}
                  </h4>
                  <p className="text-xs font-bold text-[#fd8b00] mt-0.5">
                    {exp.profession}
                  </p>

                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-2 leading-relaxed italic">
                    "{exp.tagline}"
                  </p>

                  {/* Metrics Pills */}
                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex items-center gap-1.5 font-medium truncate">
                      <MapPin className="w-3.5 h-3.5 text-[#fd8b00] shrink-0" />
                      <span className="truncate">{exp.location}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-semibold text-slate-800 dark:text-slate-200 shrink-0">
                      <Briefcase className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{exp.completedProjects} Projects</span>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="grid grid-cols-2 gap-2 mt-5 pt-3 border-t border-slate-100 dark:border-slate-700/60">
                  <button
                    onClick={() => setSelectedExpertForModal(exp)}
                    className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-[#041627] dark:text-white font-bold text-xs rounded-xl transition-all text-center cursor-pointer active:scale-95"
                  >
                    View Profile
                  </button>
                  <button
                    onClick={() => {
                      if (onMessageUser) {
                        onMessageUser(exp.contact);
                      } else {
                        setSelectedExpertForModal(exp);
                      }
                    }}
                    className="py-2.5 px-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Message</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
          </div>
        )}
      </section>

      {/* =========================================================================
          SECTION 2: TOP SELLERS ROW
      ========================================================================= */}
      <section className="space-y-4 pt-4 border-t border-slate-200/60 dark:border-slate-800">
        {/* Section Header */}
        <div className="flex justify-between items-end gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/10 text-blue-600 border border-blue-500/20 mb-1">
              <Building2 className="w-3.5 h-3.5" />
              <span>Verified Material Suppliers</span>
            </div>
            <h3 className="text-2xl font-extrabold font-sans text-[#0b1c30]">Top Sellers</h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Source heavy construction materials, bricks, cement, rebar, and hardware directly from verified dealers.
            </p>
          </div>

          {/* Navigation Scroll Arrows */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => scrollRow(sellersScrollRef, 'left')}
              disabled={!sellersCanScrollLeft}
              aria-label="Scroll sellers left"
              className={`p-2.5 rounded-full border transition-all duration-200 cursor-pointer ${
                sellersCanScrollLeft
                  ? 'bg-white dark:bg-slate-800 text-[#041627] dark:text-slate-100 border-slate-200 dark:border-slate-700 shadow-sm hover:bg-[#fd8b00] hover:text-white hover:border-[#fd8b00] active:scale-95'
                  : 'bg-slate-100 dark:bg-slate-800/50 text-slate-300 dark:text-slate-600 border-slate-200/50 dark:border-slate-800 cursor-not-allowed opacity-50'
              }`}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scrollRow(sellersScrollRef, 'right')}
              disabled={!sellersCanScrollRight}
              aria-label="Scroll sellers right"
              className={`p-2.5 rounded-full border transition-all duration-200 cursor-pointer ${
                sellersCanScrollRight
                  ? 'bg-white dark:bg-slate-800 text-[#041627] dark:text-slate-100 border-slate-200 dark:border-slate-700 shadow-sm hover:bg-[#fd8b00] hover:text-white hover:border-[#fd8b00] active:scale-95'
                  : 'bg-slate-100 dark:bg-slate-800/50 text-slate-300 dark:text-slate-600 border-slate-200/50 dark:border-slate-800 cursor-not-allowed opacity-50'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Horizontal Scroll Row */}
        {sellers.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 min-h-[200px] w-full">
            <p className="text-slate-500 dark:text-slate-400 font-medium">No Top Sellers Available</p>
          </div>
        ) : (
          <div 
            ref={sellersScrollRef}
            className="flex gap-5 overflow-x-auto pb-4 pt-1 px-1 scrollbar-none no-scrollbar snap-x snap-mandatory"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
          {sellers.map((seller) => {
            const sellerInfoAdapter: SellerInfo = {
              id: seller.id,
              name: seller.name,
              shopName: seller.shopName,
              avatar: seller.avatar,
              isVerified: seller.isVerified,
              rating: seller.rating,
              reviewsCount: seller.reviewsCount,
              email: seller.email,
              phone: seller.phone,
              location: seller.location,
              bio: seller.description,
              yearsOfExperience: seller.yearsOfExperience
            };

            return (
              <div
                key={seller.id}
                className="snap-start shrink-0 w-[300px] sm:w-[320px] bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-sm hover:shadow-xl hover:border-blue-500/60 transition-all duration-300 flex flex-col justify-between group overflow-hidden"
              >
                {/* Profile Avatar & Details (No Banner Image) */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-3">
                      <div className="relative shrink-0">
                        <img 
                          src={seller.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'} 
                          alt={seller.shopName} 
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-200 dark:border-slate-700 shadow-sm bg-slate-100"
                        />
                        <OnlineBadge email={seller.email} presenceMap={presenceMap} className="bottom-0.5 right-0.5" />
                        {seller.isVerified && (
                          <div className="absolute -top-1 -right-1 bg-emerald-500 text-white p-0.5 rounded-full border-2 border-white" title="Verified Seller">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col items-end gap-1.5">
                        <div className="flex items-center gap-1 bg-amber-400 text-slate-900 text-xs font-black px-2 py-0.5 rounded-full shadow-xs">
                          <Star className="w-3.5 h-3.5 fill-current text-slate-900" />
                          <span>{seller.rating.toFixed(1)}</span>
                        </div>
                        <span className="text-[10px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded-full">
                          {seller.productsCount} Products
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap w-full min-w-0">
                      <h4 className="text-base font-extrabold text-[#041627] dark:text-white group-hover:text-blue-600 transition-colors leading-snug break-words overflow-wrap-anywhere whitespace-normal">
                        {seller.shopName}
                      </h4>
                      {seller.isVerified && (
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.2 rounded-full border border-emerald-300 shrink-0">
                          Verified
                        </span>
                      )}
                    </div>

                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5 break-words overflow-wrap-anywhere whitespace-normal">
                      Owner: <span className="text-slate-700 dark:text-slate-300 font-bold">{seller.name}</span>
                    </p>

                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-2 leading-relaxed">
                      {seller.description}
                    </p>

                    {/* Location & Categories */}
                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <div className="flex items-center gap-1.5 font-medium truncate">
                        <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span className="truncate">{seller.location}</span>
                      </div>
                      <div className="flex items-center gap-1 flex-wrap">
                        {seller.categories.slice(0, 3).map(cat => (
                          <span key={cat} className="px-2 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold rounded-md">
                            {cat}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Action Buttons */}
                  <div className="grid grid-cols-2 gap-2 mt-5 pt-3 border-t border-slate-100 dark:border-slate-700/60">
                    <button
                      onClick={() => setSelectedSellerForModal(sellerInfoAdapter)}
                      className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-[#041627] dark:text-white font-bold text-xs rounded-xl transition-all text-center cursor-pointer active:scale-95"
                    >
                      View Shop
                    </button>
                    <button
                      onClick={() => setChatSellerModal(sellerInfoAdapter)}
                      className="py-2.5 px-3 bg-[#1a2b3c] hover:bg-[#041627] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Message</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          </div>
        )}
      </section>

      {/* =========================================================================
          DETAILED EXPERT PROFILE MODAL
      ========================================================================= */}
      {selectedExpertForModal && (
        <div 
          className="fixed inset-0 z-50 bg-[#041627]/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in"
          onClick={() => setSelectedExpertForModal(null)}
        >
          <div 
            className="bg-white dark:bg-slate-800 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-700 my-auto flex flex-col md:flex-row h-full max-h-[90vh] md:max-h-[85vh] animate-scale-up relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Global Absolute Close Button */}
            <button 
              className="absolute top-4 right-4 text-[#44474c] hover:text-[#041627] dark:text-slate-400 dark:hover:text-white z-30 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-full p-1.5 shadow-xs border border-slate-200/60 dark:border-slate-700 cursor-pointer"
              onClick={() => setSelectedExpertForModal(null)}
              title="Close Profile (Esc)"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left Column: Basic Details & Contact info (Fixed non-scrollable compact panel) */}
            <div className="w-full md:w-1/3 bg-slate-50 dark:bg-slate-950/30 border-b md:border-b-0 md:border-r border-slate-200/60 dark:border-slate-800 p-4 sm:p-5 flex flex-col items-center text-center overflow-hidden shrink-0 justify-between">
              <div className="flex flex-col items-center text-center w-full">
                <div className="relative mb-2 mt-1 sm:mt-2">
                  <img 
                    src={selectedExpertForModal.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} 
                    alt={selectedExpertForModal.name}
                    className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-white dark:border-slate-800 shadow-md bg-slate-100"
                    referrerPolicy="no-referrer"
                  />
                  <span className={`absolute bottom-1 right-1 block h-3.5 w-3.5 rounded-full ring-2 ring-white dark:ring-slate-800 ${
                    selectedExpertForModal.availability === 'Available' ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                  }`} />
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-[#041627] dark:text-white break-words overflow-wrap-anywhere whitespace-normal w-full px-2 leading-tight text-center">
                  {selectedExpertForModal.name}
                </h3>
                <p className="text-xs sm:text-sm font-semibold text-[#fd8b00] mt-0.5">
                  {selectedExpertForModal.profession}
                </p>

                <div className="w-full border-t border-slate-200/60 dark:border-slate-800 my-3" />

                {/* Info Metrics */}
                <div className="w-full text-left space-y-2.5 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      <MapPin className="w-3.5 h-3.5 text-[#fd8b00]" />
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 font-bold uppercase block leading-none mb-0.5">Location</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 text-xs">{selectedExpertForModal.location}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      <Phone className="w-3.5 h-3.5 text-[#fd8b00]" />
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 font-bold uppercase block leading-none mb-0.5">Phone Contact</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 text-xs">{selectedExpertForModal.phone || '9822514112'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      <Mail className="w-3.5 h-3.5 text-[#fd8b00]" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[9px] text-slate-400 font-bold uppercase block leading-none mb-0.5">Email Address</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 text-xs truncate block" title={selectedExpertForModal.contact}>
                        {selectedExpertForModal.contact}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="w-full mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800">
                <button 
                  onClick={() => {
                    setSelectedExpertForModal(null);
                    if (onMessageUser) onMessageUser(selectedExpertForModal.contact);
                  }}
                  className="w-full py-2.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-xl font-bold text-xs sm:text-sm shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer active:scale-95 duration-100"
                >
                  <MessageCircle className="w-4 h-4" />
                  Message Expert
                </button>
              </div>
            </div>

            {/* Right Column: Detailed Redesigned Layout (Scrollable with hidden scrollbar) */}
            <div 
              className="w-full md:w-2/3 p-5 sm:p-6 md:p-8 overflow-y-auto overflow-x-hidden space-y-6 sm:space-y-8 bg-white dark:bg-slate-900 no-scrollbar scrollbar-none [ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
              style={{
                msOverflowStyle: 'none',
                scrollbarWidth: 'none',
              }}
            >
              
              {/* TOP SECTION: Expert Description */}
              <section className="space-y-4">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-2">
                  <h4 className="text-lg font-bold text-[#041627] dark:text-white flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-[#fd8b00]" /> About the Expert
                  </h4>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950/20 rounded-xl p-5 border border-slate-100 dark:border-slate-800">
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {selectedExpertForModal.bio || "No bio description has been provided by this expert yet."}
                  </p>
                </div>

                {/* Professional details grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Profession</span>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{selectedExpertForModal.profession}</p>
                  </div>

                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Experience</span>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{selectedExpertForModal.yearsOfExperience} Years of Practice</p>
                  </div>

                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Languages Spoken</span>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Nepali, English, Newari/Hindi</p>
                  </div>

                  <div className="space-y-1 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800 shadow-2xs">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Availability Status</span>
                    <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
                      Ready for Projects ({selectedExpertForModal.availability})
                    </p>
                  </div>
                </div>

                {/* Certifications and Skills */}
                <div className="space-y-3">
                  <div>
                    <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider">Specializations & Skills</span>
                    <div className="flex flex-wrap gap-2 mt-1.5">
                      {selectedExpertForModal.skills && selectedExpertForModal.skills.length > 0 ? (
                        selectedExpertForModal.skills.map(skill => (
                          <span key={skill} className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/20 text-[#fd8b00] dark:text-amber-400 text-xs font-semibold rounded-lg border border-amber-200/50 dark:border-amber-900/30">
                            {skill}
                          </span>
                        ))
                      ) : (
                        ['Seismic Safety Design', '3D BIM Modeling', 'Local Regulatory Codes Compliance', 'Cost Estimation Planning'].map(skill => (
                          <span key={skill} className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/20 text-[#fd8b00] dark:text-amber-400 text-xs font-semibold rounded-lg border border-amber-200/50 dark:border-amber-900/30">
                            {skill}
                          </span>
                        ))
                      )}
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider">Accredited Certifications</span>
                    <div className="flex flex-wrap gap-2 mt-1.5">
                      {selectedExpertForModal.certifications && selectedExpertForModal.certifications.length > 0 ? (
                        selectedExpertForModal.certifications.map(cert => (
                          <span key={cert} className="px-2.5 py-1 bg-slate-100 dark:bg-slate-850 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1">
                            <Award className="w-3.5 h-3.5 text-amber-500" />
                            {cert}
                          </span>
                        ))
                      ) : (
                        ['Nepal Engineering Council (NEC) Member', 'Sustainable Built Environment LEED-AP Certificate'].map(cert => (
                          <span key={cert} className="px-2.5 py-1 bg-slate-100 dark:bg-slate-850 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1">
                            <Award className="w-3.5 h-3.5 text-amber-500" />
                            {cert}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </section>

              {/* CENTER SECTION: Completed Projects Portfolio */}
              <section className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-6">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-2 flex justify-between items-center">
                  <h4 className="text-lg font-bold text-[#041627] dark:text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-[#fd8b00]" /> Completed Projects Portfolio
                  </h4>
                  <span className="text-xs font-bold text-slate-400">{portfolioProjects.length} Verified Projects</span>
                </div>

                {portfolioProjects.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl">
                    <p className="text-sm text-slate-400 font-medium">No completed projects have been uploaded yet.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {portfolioProjects.map((project) => (
                      <div 
                        key={project.id} 
                        onClick={() => {
                          setActiveLightboxProject(project);
                          setCurrentPhotoIndex(0);
                          setIsFullscreenPhoto(false);
                        }}
                        className="group relative bg-slate-50 dark:bg-slate-950/20 border border-slate-200/50 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col h-full animate-fade-in"
                      >
                        {/* Cover image with fallback */}
                        <div className="relative aspect-video w-full overflow-hidden bg-slate-200 dark:bg-slate-800">
                          <img 
                            src={project.coverImage || "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80"} 
                            alt={project.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute top-2 right-2 bg-[#fd8b00] text-white text-[9px] font-extrabold px-2 py-0.5 rounded shadow-sm">
                            {project.category || "Design"}
                          </div>
                        </div>

                        <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                          <div>
                            <h5 className="font-bold text-slate-800 dark:text-white text-sm line-clamp-1 group-hover:text-[#fd8b00] transition-colors">
                              {project.title}
                            </h5>
                            <p className="text-[11px] text-slate-400 mt-0.5 font-medium flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-[#fd8b00]" /> {project.location || "Nepal"} ({project.completionYear || "2024"})
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-300 leading-relaxed mt-2 line-clamp-2">
                              {project.description}
                            </p>
                          </div>
                          
                          <div className="pt-2 flex items-center justify-between text-[11px] font-semibold text-[#fd8b00] border-t border-slate-100 dark:border-slate-800/60 mt-2">
                            <span>Budget: {project.budget || "N/A"}</span>
                            <span className="flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                              Explore details <ChevronRight className="w-3 h-3" />
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              {/* BOTTOM SECTION: Ratings & Reviews */}
              <section className="space-y-6 border-t border-slate-100 dark:border-slate-800 pt-6">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-2">
                  <h4 className="text-lg font-bold text-[#041627] dark:text-white flex items-center gap-2">
                    <Star className="w-5 h-5 text-[#fd8b00] fill-[#fd8b00]" /> Customer Ratings & Reviews
                  </h4>
                </div>

                {/* Rating statistics block */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-slate-50 dark:bg-slate-950/20 border border-slate-200/40 dark:border-slate-800/60 rounded-2xl p-5">
                  <div className="flex flex-col items-center justify-center text-center space-y-1 sm:border-r border-slate-200 dark:border-slate-800">
                    <span className="text-5xl font-extrabold text-slate-800 dark:text-white">
                      {ratingStats.average.toFixed(1)}
                    </span>
                    <div className="flex gap-0.5 text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-4 h-4 ${i < Math.round(ratingStats.average) ? 'fill-current' : 'text-slate-200 dark:text-slate-700'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">{ratingStats.total} Total Reviews</span>
                  </div>

                  <div className="sm:col-span-2 flex flex-col justify-center space-y-1.5 pl-2">
                    {[5, 4, 3, 2, 1].map((starNum) => {
                      const percent = ratingStats.breakdown[starNum as 5|4|3|2|1] || 0;
                      return (
                        <div key={starNum} className="flex items-center gap-2 text-xs">
                          <span className="w-3 font-semibold text-slate-500">{starNum}★</span>
                          <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-amber-400 to-[#fd8b00] rounded-full transition-all duration-500" 
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                          <span className="w-8 text-right font-medium text-slate-400">{percent}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Reviews List */}
                <div className="space-y-4">
                  <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">All Customer Reviews ({reviews.length})</h5>
                  
                  {reviews.length === 0 ? (
                    <p className="text-sm text-slate-400 italic">No reviews submitted yet.</p>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 space-y-4">
                      {reviews.map((rev) => (
                        <div key={rev.id} className="pt-4 first:pt-0 flex gap-3.5 items-start">
                          <img 
                            src={rev.reviewerPhoto || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                            alt={rev.reviewerName}
                            className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-800"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0 space-y-1.5">
                            <div className="flex items-center justify-between">
                              <h6 className="text-xs font-bold text-slate-800 dark:text-slate-200">{rev.reviewerName}</h6>
                              <span className="text-[10px] text-slate-400 font-mono font-medium">{rev.reviewDate}</span>
                            </div>
                            <div className="flex items-center gap-0.5 text-amber-400">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`w-3.5 h-3.5 ${i < rev.rating ? 'fill-current' : 'text-slate-200 dark:text-slate-800'}`} 
                                />
                              ))}
                            </div>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed italic bg-slate-50 dark:bg-slate-950/10 p-2.5 rounded-lg border border-slate-100/50 dark:border-slate-800/40">
                              "{rev.reviewText}"
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* RATE THIS EXPERT FORM */}
                <div className="bg-slate-50 dark:bg-slate-950/20 border border-slate-200/40 dark:border-slate-800/60 rounded-2xl p-5 space-y-4">
                  <h5 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                    <Edit3 className="w-4 h-4 text-[#fd8b00]" /> {userHasReviewed ? 'Update Your Feedback' : 'Rate This Expert'}
                  </h5>

                  {isEligible ? (
                    <form onSubmit={handleSubmitReview} className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Your Score Selection</label>
                        <div className="flex items-center gap-2">
                          {[1, 2, 3, 4, 5].map((starNum) => (
                            <button
                              key={starNum}
                              type="button"
                              onClick={() => setFormRating(starNum)}
                              className="text-amber-400 hover:scale-110 active:scale-95 transition-transform duration-150 p-1 cursor-pointer focus:outline-none"
                            >
                              <Star className={`w-8 h-8 ${starNum <= formRating ? 'fill-current' : 'text-[#e2e8f0] dark:text-slate-700'}`} />
                            </button>
                          ))}
                          <span className="text-sm font-bold text-slate-500 ml-2">{formRating} out of 5 stars</span>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Feedback Comments</label>
                        <textarea
                          rows={3}
                          value={formText}
                          onChange={(e) => setFormText(e.target.value)}
                          placeholder="Please share your experience working with this expert on your remodeling project..."
                          className="w-full p-3 bg-white dark:bg-slate-900 text-sm rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-[#fd8b00] focus:border-[#fd8b00] text-[#0b1c30] dark:text-slate-100"
                        />
                      </div>

                      {reviewError && (
                        <div className="bg-red-50 dark:bg-red-950/10 border border-red-100 dark:border-red-900/30 text-red-800 dark:text-red-400 text-xs p-3 rounded-lg flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 shrink-0" />
                          <span>{reviewError}</span>
                        </div>
                      )}

                      {reviewSuccess && (
                        <div className="bg-green-50 dark:bg-green-950/10 border border-green-150 dark:border-green-900/30 text-green-800 dark:text-green-400 text-xs p-3 rounded-lg flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>{reviewSuccess}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={isSubmittingReview}
                        className="w-full py-2.5 bg-[#fd8b00] hover:bg-[#e07b00] disabled:bg-slate-300 text-white rounded-lg font-bold text-sm shadow-sm transition-all cursor-pointer active:scale-98"
                      >
                        {isSubmittingReview ? "Saving to Cloud..." : (userHasReviewed ? "Update Review Details" : "Submit Verification Review")}
                      </button>
                    </form>
                  ) : (
                    <div className="bg-amber-50 dark:bg-amber-950/15 border border-amber-200 dark:border-amber-900/30 rounded-xl p-4 text-center">
                      <p className="text-xs text-amber-800 dark:text-amber-300 font-medium leading-relaxed">
                        To preserve system integrity, review submission is restricted to clients with completed verified contracts with this expert.
                      </p>
                      {currentUserEmail ? (
                        <div className="mt-3.5 space-y-2">
                          <p className="text-[10px] text-slate-400">Sandbox Testing Mode Enabled:</p>
                          <button
                            type="button"
                            onClick={handleUnlockReviewForm}
                            className="px-4 py-1.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-[11px] font-extrabold rounded-lg shadow-xs transition-all cursor-pointer active:scale-95"
                          >
                            Simulate Completed Contract (Unlock Form)
                          </button>
                        </div>
                      ) : (
                        <p className="text-[10px] text-slate-400 mt-2">Please login as a client to leave reviews.</p>
                      )}
                    </div>
                  )}
                </div>

              </section>

            </div>
          </div>
        </div>
      )}

      {/* DETAILED GALLERY/LIGHTBOX MODAL OVERLAY */}
      {activeLightboxProject && (
        <div 
          className="fixed inset-0 bg-black/95 z-55 flex items-center justify-center p-4 backdrop-blur-md overflow-hidden animate-fadeIn text-white"
          onClick={() => setActiveLightboxProject(null)}
        >
          {/* Close Button */}
          <button 
            onClick={() => setActiveLightboxProject(null)}
            className="absolute top-6 right-6 p-2.5 bg-white/10 hover:bg-white/20 rounded-full transition-colors z-20 cursor-pointer text-white"
            title="Close Lightbox (Esc)"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Lightbox container */}
          <div 
            className="w-full max-w-5xl flex flex-col md:flex-row h-full max-h-[90vh] md:max-h-[80vh] bg-neutral-900 rounded-2xl overflow-hidden shadow-2xl relative animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Left Image Slider Area */}
            <div className="w-full md:w-3/5 bg-black flex flex-col items-center justify-center relative select-none h-2/3 md:h-full">
              
              {/* Main Photo Display with Referrer Policy */}
              <div className="relative w-full h-full flex items-center justify-center p-4">
                <img 
                  src={(activeLightboxProject.images && activeLightboxProject.images.length > 0) ? activeLightboxProject.images[currentPhotoIndex] : activeLightboxProject.coverImage} 
                  alt={activeLightboxProject.title}
                  className={`max-w-full max-h-full object-contain transition-all duration-300 rounded ${
                    isFullscreenPhoto ? 'scale-110 cursor-zoom-out' : 'cursor-zoom-in'
                  }`}
                  onClick={() => setIsFullscreenPhoto(!isFullscreenPhoto)}
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Slider Arrows */}
              {activeLightboxProject.images && activeLightboxProject.images.length > 1 && (
                <>
                  <button 
                    onClick={() => setCurrentPhotoIndex(prev => (prev === 0 ? activeLightboxProject.images.length - 1 : prev - 1))}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 hover:scale-105 active:scale-95 transition-all text-white p-3 rounded-full cursor-pointer z-10"
                    title="Previous Photo"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setCurrentPhotoIndex(prev => (prev === activeLightboxProject.images.length - 1 ? 0 : prev + 1))}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 hover:scale-105 active:scale-95 transition-all text-white p-3 rounded-full cursor-pointer z-10"
                    title="Next Photo"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              {/* Photos Navigation Indicators */}
              {activeLightboxProject.images && activeLightboxProject.images.length > 1 && (
                <div className="absolute bottom-4 flex gap-1.5 z-10">
                  {activeLightboxProject.images.map((_, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setCurrentPhotoIndex(idx)}
                      className={`h-1.5 rounded-full transition-all cursor-pointer ${
                        idx === currentPhotoIndex ? 'w-6 bg-[#fd8b00]' : 'w-2 bg-white/40 hover:bg-white/60'
                      }`}
                    />
                  ))}
                </div>
              )}

              {/* Fullscreen Button */}
              <button 
                onClick={() => setIsFullscreenPhoto(!isFullscreenPhoto)}
                className="absolute top-4 left-4 p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors cursor-pointer text-white z-10"
                title="Toggle Zoom Mode"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>

            {/* Right Details Column */}
            <div className="w-full md:w-2/5 p-6 md:p-8 bg-neutral-900 overflow-y-auto flex flex-col justify-between border-t md:border-t-0 md:border-l border-white/10 h-1/3 md:h-full scrollbar-thin">
              <div className="space-y-5">
                <div>
                  <span className="text-[10px] text-amber-500 font-extrabold uppercase tracking-wider">{activeLightboxProject.category || "Design Construction"}</span>
                  <h3 className="text-xl font-bold text-white mt-1 leading-tight">{activeLightboxProject.title}</h3>
                  <p className="text-xs text-neutral-400 mt-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#fd8b00]" /> {activeLightboxProject.location || "Nepal"}
                  </p>
                </div>

                <div className="border-t border-white/10 pt-4 space-y-3">
                  <div className="text-xs text-neutral-300 leading-relaxed">
                    <span className="text-[10px] text-neutral-500 font-bold uppercase block mb-1">Project Summary</span>
                    {activeLightboxProject.description}
                  </div>

                  {activeLightboxProject.technologies && (
                    <div className="text-xs text-neutral-300 leading-relaxed">
                      <span className="text-[10px] text-neutral-500 font-bold uppercase block mb-1">Materials & Tech Used</span>
                      <p className="font-semibold text-neutral-100">{activeLightboxProject.technologies}</p>
                    </div>
                  )}

                  {activeLightboxProject.clientFeedback && (
                    <div className="bg-neutral-800/50 rounded-xl p-3.5 border border-white/5 space-y-1">
                      <span className="text-[9px] text-amber-500 font-bold uppercase tracking-wider flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Client Testimonial
                      </span>
                      <p className="text-xs text-neutral-300 italic leading-relaxed">
                        "{activeLightboxProject.clientFeedback}"
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-white/10 pt-4 mt-6 grid grid-cols-2 gap-4">
                <div className="space-y-0.5">
                  <span className="text-[9px] text-neutral-500 font-bold uppercase block">Budget Total</span>
                  <p className="text-xs font-bold text-emerald-400">{activeLightboxProject.budget || "N/A"}</p>
                </div>
                <div className="space-y-0.5">
                  <span className="text-[9px] text-neutral-500 font-bold uppercase block">Completion Date</span>
                  <p className="text-xs font-bold text-white">{activeLightboxProject.completionDate || activeLightboxProject.completionYear || "2024"}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SELLER PROFILE MODAL WRAPPER
      ========================================================================= */}
      {selectedSellerForModal && (
        <SellerProfileModal
          seller={selectedSellerForModal}
          allProducts={products}
          isOpen={!!selectedSellerForModal}
          onClose={() => setSelectedSellerForModal(null)}
          onAddToCart={(product) => {
            if (onAddToCart) onAddToCart(product);
          }}
          onOpenChat={(seller) => {
            setSelectedSellerForModal(null);
            setChatSellerModal(seller);
          }}
        />
      )}

      {/* =========================================================================
          SELLER CHAT MODAL WRAPPER
      ========================================================================= */}
      {chatSellerModal && (
        <SellerChatModal
          seller={chatSellerModal}
          isOpen={!!chatSellerModal}
          onClose={() => setChatSellerModal(null)}
          currentUserEmail={currentUserEmail}
          currentUserName={currentUserName}
          currentUserAvatar={currentUserAvatar}
          presenceMap={presenceMap}
        />
      )}

      {/* =========================================================================
          HIRE INQUIRY MODAL
      ========================================================================= */}
      {hireExpertInquiry && (
        <div className="fixed inset-0 z-50 bg-[#041627]/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl border border-slate-200 dark:border-slate-700 relative animate-scale-up">
            <button 
              onClick={() => setHireExpertInquiry(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <img src={hireExpertInquiry.photo || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} alt={hireExpertInquiry.name} className="w-12 h-12 rounded-full object-cover border-2 border-[#fd8b00]" />
              <div>
                <h3 className="text-base font-bold text-[#041627] dark:text-white">Hire {hireExpertInquiry.name}</h3>
                <p className="text-xs text-[#fd8b00] font-semibold">{hireExpertInquiry.profession}</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 mb-4 leading-relaxed">
              Send a direct inquiry for structural consultations, blueprint drafting, or site inspections.
            </p>

            <form onSubmit={(e) => {
              e.preventDefault();
              const name = hireExpertInquiry.name;
              const email = hireExpertInquiry.contact;
              setHireExpertInquiry(null);
              try { window.alert(`Inquiry successfully submitted to ${name}!`); } catch (err) {}
              if (onMessageUser) onMessageUser(email);
            }} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">Project Scope / Details</label>
                <textarea 
                  required
                  rows={3}
                  placeholder="Describe your floor plan, structural requirements, or consultation date..."
                  className="w-full p-3 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-[#fd8b00]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                Submit Hire Request
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
