import React, { useState, useEffect } from 'react';
import { 
  X, User, Mail, Phone, MapPin, Calendar, Shield, Clock, 
  CheckCircle, AlertTriangle, Lock, Edit3, Trash2, Send, 
  ShoppingBag, Star, Briefcase, Store, Award, ChevronRight, 
  FileText, Key, Eye, UserCheck, UserX, RefreshCw, Sparkles, Building,
  Sun, Moon
} from 'lucide-react';
import { doc, onSnapshot, setDoc, deleteDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { AdminUser, Order, Product } from '../types';
import { optimizeImage } from '../lib/fileUploader';
import { useTheme } from '../lib/theme';

interface AdminUserProfileModalProps {
  user: AdminUser;
  onClose: () => void;
  onUpdateUser?: (updatedUser: AdminUser) => void;
  onSuspendUser?: (id: string) => void;
  onReactivateUser?: (id: string) => void;
  onDeleteUser?: (id: string) => void;
  onSendMessage?: (email: string) => void;
  showToast?: (msg: string, type?: 'success' | 'error') => void;
}

export default function AdminUserProfileModal({
  user: initialUser,
  onClose,
  onUpdateUser,
  onSuspendUser,
  onReactivateUser,
  onDeleteUser,
  onSendMessage,
  showToast = (msg) => console.log(msg)
}: AdminUserProfileModalProps) {
  const { theme, toggleTheme } = useTheme();
  const [currentUserData, setCurrentUserData] = useState<AdminUser>(initialUser);
  const [activeSubTab, setActiveSubTab] = useState<'info' | 'role' | 'orders' | 'reviews'>('info');
  
  // Real-time Firestore subscriptions for specific User Profile
  const [userOrders, setUserOrders] = useState<Order[]>([]);
  const [userProducts, setUserProducts] = useState<Product[]>([]);
  const [userReviews, setUserReviews] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Edit Mode state
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<AdminUser>>({});
  const [isSaving, setIsSaving] = useState(false);

  // Password reset state
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [isSubmittingPass, setIsSubmittingPass] = useState(false);

  // 1. Real-time account document subscription
  useEffect(() => {
    setIsLoading(true);
    const userDocId = initialUser.id || initialUser.uid || `acc-${initialUser.email}`;
    
    // Subscribe to accounts collection
    const unsubDoc = onSnapshot(doc(db, 'accounts', userDocId), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setCurrentUserData(prev => ({
          ...prev,
          ...data,
          id: docSnap.id,
          uid: docSnap.id,
          fullName: data.fullName || prev.fullName,
          email: data.email || prev.email,
          phone: data.phone || prev.phone,
          accountType: data.accountType || prev.accountType,
          status: data.status || prev.status,
          avatar: data.avatar || prev.avatar,
          address: data.address || prev.address || '',
          province: data.province || prev.province || '',
          district: data.district || prev.district || '',
          municipality: data.municipality || prev.municipality || '',
          bio: data.bio || data.about || prev.bio || '',
          about: data.about || data.bio || prev.about || '',
          yearsOfExperience: data.yearsOfExperience ?? prev.yearsOfExperience,
          skillsOrTags: data.skillsOrTags || data.skills || prev.skillsOrTags || [],
          professionalTitle: data.professionalTitle || data.professionType || prev.professionalTitle || '',
          certifications: data.certifications || prev.certifications || '',
          shopName: data.shopName || prev.shopName || '',
          shopDescription: data.shopDescription || data.businessDescription || prev.shopDescription || '',
          businessCategory: data.businessCategory || prev.businessCategory || '',
          shopAddress: data.shopAddress || prev.shopAddress || '',
          businessRegistrationNumber: data.businessRegistrationNumber || prev.businessRegistrationNumber || '',
          username: data.username || data.handle || (data.email ? data.email.split('@')[0] : '') || prev.username || '',
          coverPhoto: data.coverPhoto || data.coverImage || prev.coverPhoto || '',
          languages: data.languages || prev.languages || 'Nepali, English',
          availability: data.availability || data.workAvailability || prev.availability || 'Available',
          lastActive: data.lastActive || data.lastLogin || prev.lastActive || 'Recently Active',
        }));
      }
      setIsLoading(false);
    }, (err) => {
      console.warn("Account snapshot error:", err);
      setIsLoading(false);
    });

    return () => unsubDoc();
  }, [initialUser.id, initialUser.email]);

  // 2. Fetch Orders for this user (as customer or seller)
  useEffect(() => {
    if (!currentUserData.email) return;
    const emailLower = currentUserData.email.toLowerCase();

    const unsubOrders = onSnapshot(collection(db, 'orders'), (snapshot) => {
      const ordersList: Order[] = [];
      snapshot.forEach((docSnap) => {
        const oData = docSnap.data() as Order;
        const matchesClient = oData.clientEmail?.toLowerCase() === emailLower || oData.customerEmail?.toLowerCase() === emailLower;
        const matchesShopkeeper = oData.shopkeeperId?.toLowerCase() === emailLower || oData.shopkeeperName?.toLowerCase().includes(currentUserData.fullName.toLowerCase());
        
        if (matchesClient || matchesShopkeeper) {
          ordersList.push({ id: docSnap.id, ...oData });
        }
      });
      setUserOrders(ordersList);
    });

    return () => unsubOrders();
  }, [currentUserData.email, currentUserData.fullName]);

  // 3. Fetch Products for Shopkeeper
  useEffect(() => {
    if (currentUserData.accountType !== 'Shopkeeper' || !currentUserData.email) return;
    const emailLower = currentUserData.email.toLowerCase();

    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const prods: Product[] = [];
      snapshot.forEach((docSnap) => {
        const pData = docSnap.data() as Product;
        if (pData.seller?.email?.toLowerCase() === emailLower || (pData as any).ownerId?.toLowerCase() === emailLower) {
          prods.push({ id: docSnap.id, ...pData });
        }
      });
      setUserProducts(prods);
    });

    return () => unsubProducts();
  }, [currentUserData.accountType, currentUserData.email]);

  // 4. Fetch Reviews for Expert or Seller
  useEffect(() => {
    if (!currentUserData.email) return;
    const emailLower = currentUserData.email.toLowerCase();

    const qRev = query(collection(db, 'expert_reviews'), where('expertEmail', '==', emailLower));
    const unsubRev = onSnapshot(qRev, (snapshot) => {
      const revs: any[] = [];
      snapshot.forEach((docSnap) => {
        revs.push({ id: docSnap.id, ...docSnap.data() });
      });
      setUserReviews(revs);
    });

    return () => unsubRev();
  }, [currentUserData.email]);

  // Start Edit Mode
  // Start Edit Mode
  const handleStartEdit = () => {
    setEditForm({
      fullName: currentUserData.fullName,
      email: currentUserData.email,
      phone: currentUserData.phone,
      username: currentUserData.username || (currentUserData.email ? currentUserData.email.split('@')[0] : ''),
      accountType: currentUserData.accountType,
      address: currentUserData.address || '',
      province: currentUserData.province || '',
      district: currentUserData.district || '',
      municipality: currentUserData.municipality || '',
      bio: currentUserData.bio || currentUserData.about || '',
      yearsOfExperience: currentUserData.yearsOfExperience || 0,
      skillsOrTags: currentUserData.skillsOrTags || [],
      professionalTitle: currentUserData.professionalTitle || currentUserData.professionType || '',
      certifications: currentUserData.certifications || '',
      shopName: currentUserData.shopName || '',
      shopDescription: currentUserData.shopDescription || '',
      businessCategory: currentUserData.businessCategory || '',
      shopAddress: currentUserData.shopAddress || '',
      businessRegistrationNumber: currentUserData.businessRegistrationNumber || '',
      avatar: currentUserData.avatar,
      coverPhoto: currentUserData.coverPhoto || '',
      languages: currentUserData.languages || 'Nepali, English',
      availability: currentUserData.availability || 'Available',
    });
    setIsEditing(true);
  };

  // Save Profile Edit Changes to Firestore
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;

    setIsSaving(true);
    try {
      const docId = currentUserData.id || currentUserData.uid || `acc-${currentUserData.email}`;
      const updatePayload: Record<string, any> = {
        fullName: editForm.fullName || currentUserData.fullName,
        email: editForm.email || currentUserData.email,
        phone: editForm.phone || currentUserData.phone,
        username: editForm.username || '',
        accountType: editForm.accountType || currentUserData.accountType,
        address: editForm.address || '',
        province: editForm.province || '',
        district: editForm.district || '',
        municipality: editForm.municipality || '',
        bio: editForm.bio || '',
        about: editForm.bio || '',
        avatar: editForm.avatar || currentUserData.avatar,
        coverPhoto: editForm.coverPhoto || '',
        languages: editForm.languages || '',
        availability: editForm.availability || '',
        yearsOfExperience: Number(editForm.yearsOfExperience) || 0,
        skillsOrTags: editForm.skillsOrTags || [],
        skills: editForm.skillsOrTags || [],
        professionalTitle: editForm.professionalTitle || '',
        professionType: editForm.professionalTitle || '',
        certifications: editForm.certifications || '',
        shopName: editForm.shopName || '',
        shopDescription: editForm.shopDescription || '',
        businessCategory: editForm.businessCategory || '',
        shopAddress: editForm.shopAddress || '',
        businessRegistrationNumber: editForm.businessRegistrationNumber || '',
        updatedAt: new Date().toISOString()
      };

      // Save to accounts collection
      await setDoc(doc(db, 'accounts', docId), updatePayload, { merge: true });

      // Save to users collection if document exists or by email
      const qUsers = query(collection(db, 'users'), where('email', '==', currentUserData.email.toLowerCase()));
      const usersSnap = await getDocs(qUsers);
      for (const uDoc of usersSnap.docs) {
        await setDoc(doc(db, 'users', uDoc.id), updatePayload, { merge: true });
      }

      // Sync with Firebase Auth
      try {
        await fetch('/api/admin/update-user-profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uid: docId,
            email: updatePayload.email,
            fullName: updatePayload.fullName,
            avatar: updatePayload.avatar
          })
        });
      } catch (authErr) {
        console.warn("Auth sync notice:", authErr);
      }

      // Update local state
      const updatedObj = { ...currentUserData, ...updatePayload };
      setCurrentUserData(updatedObj);
      if (onUpdateUser) onUpdateUser(updatedObj);

      setIsEditing(false);
      showToast('User profile updated successfully in Firestore and Firebase Auth!', 'success');
    } catch (err: any) {
      console.error("Failed to save profile edit:", err);
      showToast('Failed to save profile: ' + (err.message || 'Firestore error'), 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Handle Account Approval
  const handleApprove = async () => {
    try {
      const docId = currentUserData.id || currentUserData.uid;
      const nowIso = new Date().toISOString();
      const updateData = {
        status: 'Active',
        accountStatus: 'Active',
        approvalStatus: 'Approved',
        approvedAt: nowIso,
        statusLastUpdated: new Date().toLocaleString('en-US')
      };

      await setDoc(doc(db, 'accounts', docId), updateData, { merge: true });

      try {
        await fetch('/api/admin/approve-user', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: docId,
            userEmail: currentUserData.email,
            userName: currentUserData.fullName,
            userRole: currentUserData.accountType
          })
        });
      } catch (e) {}

      setCurrentUserData(prev => ({
        ...prev,
        status: 'Active',
        accountStatus: 'Active',
        approvalStatus: 'Approved'
      }));
      showToast(`User account approved and activated. Email notification sent to ${currentUserData.email}!`, 'success');
    } catch (err: any) {
      showToast('Approval failed: ' + err.message, 'error');
    }
  };

  // Handle Account Rejection
  const handleReject = async () => {
    if (!window.confirm(`Are you sure you want to REJECT registration for "${currentUserData.fullName}"?`)) return;
    try {
      const docId = currentUserData.id || currentUserData.uid;
      const nowIso = new Date().toISOString();
      const updateData = {
        status: 'Rejected',
        accountStatus: 'Rejected',
        approvalStatus: 'Rejected',
        rejectedAt: nowIso,
        statusLastUpdated: new Date().toLocaleString('en-US')
      };

      await setDoc(doc(db, 'accounts', docId), updateData, { merge: true });

      try {
        await fetch('/api/admin/reject-user', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: docId,
            userEmail: currentUserData.email,
            userName: currentUserData.fullName
          })
        });
      } catch (e) {}

      setCurrentUserData(prev => ({
        ...prev,
        status: 'Rejected',
        accountStatus: 'Rejected',
        approvalStatus: 'Rejected'
      }));
      showToast(`User account registration rejected.`, 'success');
    } catch (err: any) {
      showToast('Rejection failed: ' + err.message, 'error');
    }
  };

  // Handle Status Toggle (Suspend / Activate)
  const handleToggleStatus = async () => {
    const newStatus = currentUserData.status === 'Active' ? 'Suspended' : 'Active';
    try {
      const docId = currentUserData.id || currentUserData.uid;
      const updateData = {
        status: newStatus,
        statusLastUpdated: new Date().toLocaleString('en-US')
      };

      await setDoc(doc(db, 'accounts', docId), updateData, { merge: true });

      const qUsers = query(collection(db, 'users'), where('email', '==', currentUserData.email.toLowerCase()));
      const usersSnap = await getDocs(qUsers);
      for (const uDoc of usersSnap.docs) {
        await setDoc(doc(db, 'users', uDoc.id), updateData, { merge: true });
      }

      setCurrentUserData(prev => ({ ...prev, status: newStatus as any }));
      showToast(`User account status set to ${newStatus}`, 'success');

      if (newStatus === 'Suspended' && onSuspendUser) onSuspendUser(docId);
      if (newStatus === 'Active' && onReactivateUser) onReactivateUser(docId);
    } catch (err: any) {
      showToast('Status update failed: ' + err.message, 'error');
    }
  };

  // Handle Admin Password Change
  const handleAdminResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      showToast('Password must be at least 6 characters.', 'error');
      return;
    }

    setIsSubmittingPass(true);
    try {
      const docId = currentUserData.id || currentUserData.uid;
      const passPayload = { 
        password: newPassword, 
        passwordLastChangedAt: new Date().toISOString() 
      };

      await setDoc(doc(db, 'accounts', docId), passPayload, { merge: true });

      const qUsers = query(collection(db, 'users'), where('email', '==', currentUserData.email.toLowerCase()));
      const usersSnap = await getDocs(qUsers);
      for (const uDoc of usersSnap.docs) {
        await setDoc(doc(db, 'users', uDoc.id), passPayload, { merge: true });
      }

      showToast(`Password updated for ${currentUserData.fullName} in Firestore credential vault!`, 'success');
      setNewPassword('');
      setIsResettingPassword(false);
    } catch (err: any) {
      showToast('Failed to reset password: ' + err.message, 'error');
    } finally {
      setIsSubmittingPass(false);
    }
  };

  // Handle Delete Account
  const handleDeleteAccount = async () => {
    if (!window.confirm(`Are you sure you want to PERMANENTLY delete user "${currentUserData.fullName}" (${currentUserData.email})? This action cannot be undone.`)) {
      return;
    }

    try {
      const docId = currentUserData.id || currentUserData.uid;
      const targetEmail = currentUserData.email ? currentUserData.email.trim().toLowerCase() : '';

      // 1. Mark account as Deleted and recoverable in Firestore accounts and users collections
      const deletePayload = {
        status: 'Deleted',
        accountStatus: 'Deleted',
        isDeleted: true,
        deletedAt: new Date().toISOString(),
        deletedBy: 'Admin',
        deletedReason: 'Deleted by Administrator',
        recoverable: true,
        recoveryAvailable: 'Yes',
        recoveryExpiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      };

      try {
        if (docId) {
          await deleteDoc(doc(db, 'accounts', docId)).catch(() => {});
          await deleteDoc(doc(db, 'users', docId)).catch(() => {});
          await deleteDoc(doc(db, 'carts', docId)).catch(() => {});
          await deleteDoc(doc(db, 'topExperts', docId)).catch(() => {});
          await deleteDoc(doc(db, 'topSellers', docId)).catch(() => {});
        }
        if (targetEmail) {
          await deleteDoc(doc(db, 'carts', targetEmail)).catch(() => {});
          await deleteDoc(doc(db, 'presence', targetEmail)).catch(() => {});

          const qAcc = query(collection(db, 'accounts'), where('email', '==', targetEmail));
          const snapAcc = await getDocs(qAcc);
          for (const d of snapAcc.docs) {
            await deleteDoc(doc(db, 'accounts', d.id)).catch(() => {});
          }

          const qUsers = query(collection(db, 'users'), where('email', '==', targetEmail));
          const snapUsers = await getDocs(qUsers);
          for (const d of snapUsers.docs) {
            await deleteDoc(doc(db, 'users', d.id)).catch(() => {});
          }

          const secondaryColsToClean = [
            { name: 'shopkeepers', field: 'email' },
            { name: 'experts', field: 'contact' },
            { name: 'topExperts', field: 'contact' },
            { name: 'topExperts', field: 'email' },
            { name: 'topSellers', field: 'email' },
            { name: 'carts', field: 'email' }
          ];

          for (const col of secondaryColsToClean) {
            try {
              const q = query(collection(db, col.name), where(col.field, '==', targetEmail));
              const snap = await getDocs(q);
              for (const d of snap.docs) {
                await deleteDoc(doc(db, col.name, d.id)).catch(() => {});
              }
            } catch (e) {}
          }

          // Clean messages involving user
          try {
            const msgsSnap = await getDocs(collection(db, 'messages'));
            for (const mDoc of msgsSnap.docs) {
              const mData = mDoc.data();
              if (mData.senderEmail?.toLowerCase() === targetEmail || mData.recipientEmail?.toLowerCase() === targetEmail || mData.senderId === docId || mData.recipientId === docId) {
                await deleteDoc(doc(db, 'messages', mDoc.id)).catch(() => {});
              }
            }
          } catch (e) {}

          // Clean notifications involving user
          try {
            const notifSnap = await getDocs(collection(db, 'notifications'));
            for (const nDoc of notifSnap.docs) {
              const nData = nDoc.data();
              if (nData.userEmail?.toLowerCase() === targetEmail || nData.targetUserEmail?.toLowerCase() === targetEmail || nData.userId === docId) {
                await deleteDoc(doc(db, 'notifications', nDoc.id)).catch(() => {});
              }
            }
          } catch (e) {}
        }
      } catch (clientErr: any) {
        console.warn("[AdminUserProfileModal] Client-side deletion warn:", clientErr.message);
      }

      // Trigger centralized backend cascade delete API
      const response = await fetch('/api/admin/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: docId, email: targetEmail }),
      });
      const result = await response.json();
      console.log("[Admin Cascade Delete API] Response:", result);

      if (onDeleteUser) onDeleteUser(docId);
      try {
        ['dreamhouse_admin_users', 'dreamhouse_accounts', 'dreamhouse_experts'].forEach(key => {
          const raw = localStorage.getItem(key);
          if (raw) {
            const list = JSON.parse(raw);
            if (Array.isArray(list)) {
              const updated = list.filter((item: any) => 
                item && 
                item.id !== docId && 
                (!targetEmail || item.email?.toLowerCase() !== targetEmail) &&
                (!targetEmail || item.contact?.toLowerCase() !== targetEmail)
              );
              localStorage.setItem(key, JSON.stringify(updated));
            }
          }
        });
      } catch (e) {}
      if (showToast) {
        showToast('User account and all associated data permanently deleted.', 'success');
      }
      onClose();
    } catch (err: any) {
      if (showToast) {
        showToast('Failed to delete account: ' + err.message, 'error');
      }
    }
  };

  const roleBadgeColor = 
    currentUserData.accountType === 'Admin' ? 'bg-purple-100 text-purple-800 border-purple-200' :
    currentUserData.accountType === 'Expert' ? 'bg-amber-100 text-amber-800 border-amber-200' :
    currentUserData.accountType === 'Shopkeeper' ? 'bg-emerald-100 text-emerald-800 border-emerald-200' :
    'bg-blue-100 text-blue-800 border-blue-200';

  const statusBadgeColor = 
    currentUserData.status === 'Active' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
    currentUserData.status === 'Pending' ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse' :
    'bg-rose-100 text-rose-800 border-rose-300';

  return (
    <div className="fixed inset-0 bg-[#041627]/75 z-50 flex items-center justify-center p-3 md:p-6 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full border border-slate-200 my-auto overflow-hidden relative flex flex-col max-h-[92vh]">
        
        {/* Sticky Top Bar Header */}
        <div className="bg-[#0b1c30] text-white p-4 md:p-6 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#fd8b00]/20 rounded-xl border border-[#fd8b00]/30 text-[#fd8b00]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold tracking-tight">User Account Control & Profile</h2>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded-full border border-white/20 text-slate-200">
                  Firebase ID: {currentUserData.uid || currentUserData.id}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">Real-time sync enabled with Firestore database</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors cursor-pointer"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-amber-300" />
              ) : (
                <Moon className="w-5 h-5 text-slate-200" />
              )}
            </button>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Close Profile Window"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          
          {/* Header Card Profile Summary with Cover Photo */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden shadow-sm relative">
            {/* Cover Photo Banner */}
            <div className="h-32 sm:h-40 w-full bg-gradient-to-r from-[#041627] via-[#0a2e52] to-[#fd8b00]/80 relative overflow-hidden">
              {currentUserData.coverPhoto ? (
                <img 
                  src={currentUserData.coverPhoto} 
                  alt="Cover Banner" 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#fd8b00_1px,transparent_1px)] [background-size:16px_16px]" />
              )}
            </div>

            <div className="p-5 pt-0 flex flex-col md:flex-row items-center md:items-start gap-5 -mt-12 sm:-mt-14 relative z-10">
              {/* Profile Avatar */}
              <div className="relative group shrink-0">
                <img 
                  src={currentUserData.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                  alt={currentUserData.fullName}
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-white shadow-xl bg-white"
                  referrerPolicy="no-referrer"
                />
                <span className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white ${
                  currentUserData.status === 'Active' ? 'bg-emerald-500' : currentUserData.status === 'Pending' ? 'bg-amber-500' : 'bg-rose-500'
                }`} title={`Status: ${currentUserData.status}`} />
              </div>

              {/* Profile Info Summary */}
              <div className="flex-1 text-center md:text-left space-y-2 mt-2 md:mt-14">
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
                  <h3 className="text-xl sm:text-2xl font-black text-[#041627]">{currentUserData.fullName}</h3>
                  <span className="text-xs text-slate-500 font-mono font-semibold">
                    @{currentUserData.username || (currentUserData.email ? currentUserData.email.split('@')[0] : 'user')}
                  </span>
                  <span className={`px-3 py-0.5 rounded-full text-xs font-bold border ${roleBadgeColor}`}>
                    {currentUserData.accountType}
                  </span>
                  <span className={`px-3 py-0.5 rounded-full text-xs font-bold border ${statusBadgeColor}`}>
                    {currentUserData.status}
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                    currentUserData.emailVerified === 'Verified' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                  }`}>
                    {currentUserData.emailVerified || 'Verified'}
                  </span>
                </div>

                <div className="text-xs text-slate-600 flex flex-wrap items-center justify-center md:justify-start gap-x-4 gap-y-1 font-medium">
                  <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-slate-400" /> {currentUserData.email}</span>
                  <span className="flex items-center gap-1.5 font-mono"><Phone className="w-3.5 h-3.5 text-slate-400" /> {currentUserData.phone}</span>
                  <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-slate-400" /> {currentUserData.address || currentUserData.district || 'Location not specified'}</span>
                </div>

                <div className="pt-2 text-[11px] text-slate-500 flex flex-wrap items-center justify-center md:justify-start gap-4 border-t border-slate-200/80 font-mono">
                  <span>Joined: {currentUserData.registrationDateTime || currentUserData.registrationDate}</span>
                  <span>•</span>
                  <span>Last Active: {currentUserData.lastActive || currentUserData.lastLogin}</span>
                </div>
              </div>

              {/* Top Quick Actions Bar */}
              <div className="flex flex-wrap md:flex-col gap-2 shrink-0 w-full md:w-auto pt-2 md:pt-14 border-t md:border-t-0 border-slate-200">
              <button 
                onClick={handleStartEdit}
                className="flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-xl text-xs font-bold shadow transition-all cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" /> Edit Profile
              </button>

              <button 
                onClick={() => setIsResettingPassword(true)}
                className="flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold shadow transition-all cursor-pointer"
              >
                <Key className="w-3.5 h-3.5" /> Change Password
              </button>

              {onSendMessage && (
                <button 
                  onClick={() => { onClose(); onSendMessage(currentUserData.email); }}
                  className="flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow transition-all cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> Send Message
                </button>
              )}
            </div>
          </div>
        </div>

          {/* Edit Profile Form Overlay */}
          {isEditing && (
            <form onSubmit={handleSaveProfile} className="bg-amber-50/80 border-2 border-[#fd8b00]/40 rounded-2xl p-5 space-y-4 shadow-md animate-in slide-in-from-top-2">
              <div className="flex items-center justify-between pb-3 border-b border-amber-200/80">
                <h4 className="text-sm font-extrabold text-[#041627] flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-[#fd8b00]" /> Edit User Information (Firestore Admin Edit)
                </h4>
                <button 
                  type="button" 
                  onClick={() => setIsEditing(false)} 
                  className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                >
                  Cancel
                </button>
              </div>

              {/* Photo Upload in Edit */}
              <div className="flex items-center gap-4 py-2 border-b border-amber-200/50">
                <img src={editForm.avatar || currentUserData.avatar} alt="Avatar preview" className="w-12 h-12 rounded-full object-cover border border-[#fd8b00]" />
                <label className="cursor-pointer bg-white border border-slate-300 hover:border-[#fd8b00] px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-all shadow-sm">
                  <span>Choose New Photo</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        try {
                          const opt = await optimizeImage(file, 512, 0.85);
                          setEditForm({ ...editForm, avatar: opt.dataUrl });
                        } catch {
                          const reader = new FileReader();
                          reader.onload = () => setEditForm({ ...editForm, avatar: reader.result as string });
                          reader.readAsDataURL(file);
                        }
                      }
                    }}
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Name</label>
                  <input 
                    type="text" 
                    value={editForm.fullName || ''} 
                    onChange={e => setEditForm({ ...editForm, fullName: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Username</label>
                  <input 
                    type="text" 
                    value={editForm.username || ''} 
                    onChange={e => setEditForm({ ...editForm, username: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                    placeholder="e.g. john_doe"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                  <input 
                    type="email" 
                    value={editForm.email || ''} 
                    onChange={e => setEditForm({ ...editForm, email: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
                  <input 
                    type="text" 
                    value={editForm.phone || ''} 
                    onChange={e => setEditForm({ ...editForm, phone: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Languages</label>
                  <input 
                    type="text" 
                    value={editForm.languages || ''} 
                    onChange={e => setEditForm({ ...editForm, languages: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                    placeholder="e.g. Nepali, English"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Availability Status</label>
                  <select 
                    value={editForm.availability || 'Available'} 
                    onChange={e => setEditForm({ ...editForm, availability: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  >
                    <option value="Available">Available / Active</option>
                    <option value="Busy">Busy / On Leave</option>
                    <option value="Full-Time">Full-Time</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Street Address</label>
                  <input 
                    type="text" 
                    value={editForm.address || ''} 
                    onChange={e => setEditForm({ ...editForm, address: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Province</label>
                  <input 
                    type="text" 
                    value={editForm.province || ''} 
                    onChange={e => setEditForm({ ...editForm, province: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">District</label>
                  <input 
                    type="text" 
                    value={editForm.district || ''} 
                    onChange={e => setEditForm({ ...editForm, district: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Municipality / Rural Muni</label>
                  <input 
                    type="text" 
                    value={editForm.municipality || ''} 
                    onChange={e => setEditForm({ ...editForm, municipality: e.target.value })}
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  />
                </div>

                {/* Role specific edit fields */}
                {currentUserData.accountType === 'Expert' && (
                  <>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Professional Title</label>
                      <input 
                        type="text" 
                        value={editForm.professionalTitle || ''} 
                        onChange={e => setEditForm({ ...editForm, professionalTitle: e.target.value })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Years of Experience</label>
                      <input 
                        type="number" 
                        value={editForm.yearsOfExperience || 0} 
                        onChange={e => setEditForm({ ...editForm, yearsOfExperience: Number(e.target.value) })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Certifications</label>
                      <input 
                        type="text" 
                        value={editForm.certifications || ''} 
                        onChange={e => setEditForm({ ...editForm, certifications: e.target.value })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                      />
                    </div>
                  </>
                )}

                {currentUserData.accountType === 'Shopkeeper' && (
                  <>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Shop Name</label>
                      <input 
                        type="text" 
                        value={editForm.shopName || ''} 
                        onChange={e => setEditForm({ ...editForm, shopName: e.target.value })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Business Category</label>
                      <input 
                        type="text" 
                        value={editForm.businessCategory || ''} 
                        onChange={e => setEditForm({ ...editForm, businessCategory: e.target.value })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Business Reg No.</label>
                      <input 
                        type="text" 
                        value={editForm.businessRegistrationNumber || ''} 
                        onChange={e => setEditForm({ ...editForm, businessRegistrationNumber: e.target.value })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Shop Description</label>
                      <input 
                        type="text" 
                        value={editForm.shopDescription || ''} 
                        onChange={e => setEditForm({ ...editForm, shopDescription: e.target.value })}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-xl font-medium"
                        placeholder="Brief overview of the shop and products..."
                      />
                    </div>
                  </>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 text-xs">Bio / About Description</label>
                <textarea 
                  rows={2} 
                  value={editForm.bio || ''} 
                  onChange={e => setEditForm({ ...editForm, bio: e.target.value })}
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#fd8b00]/30"
                  placeholder="Tell us about this user..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={isSaving}
                  className="px-5 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-extrabold text-xs rounded-xl shadow transition-all cursor-pointer"
                >
                  {isSaving ? 'Saving to Firestore...' : 'Save Changes'}
                </button>
              </div>
            </form>
          )}

          {/* Reset Password Form Overlay */}
          {isResettingPassword && (
            <form onSubmit={handleAdminResetPassword} className="bg-sky-50/90 border border-sky-200 rounded-2xl p-4 space-y-3 shadow-md animate-in slide-in-from-top-2">
              <div className="flex items-center justify-between pb-2 border-b border-sky-200">
                <h4 className="text-xs font-bold text-[#041627] flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-sky-600" /> Reset Password for {currentUserData.fullName}
                </h4>
                <button type="button" onClick={() => setIsResettingPassword(false)} className="text-slate-400 hover:text-slate-600 text-xs">Cancel</button>
              </div>
              
              <div className="flex gap-3 items-center">
                <input 
                  type="text" 
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="Enter new password (min 6 chars)"
                  className="flex-1 p-2.5 bg-white border border-sky-300 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-sky-400"
                />
                <button 
                  type="submit" 
                  disabled={isSubmittingPass}
                  className="px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow transition-all cursor-pointer whitespace-nowrap"
                >
                  {isSubmittingPass ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            </form>
          )}

          {/* Navigation Sub-Tabs */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <button 
              onClick={() => setActiveSubTab('info')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeSubTab === 'info' ? 'bg-[#041627] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <User className="w-3.5 h-3.5" /> Personal & Contact Info
            </button>

            <button 
              onClick={() => setActiveSubTab('role')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeSubTab === 'role' ? 'bg-[#041627] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {currentUserData.accountType === 'Expert' ? <Award className="w-3.5 h-3.5" /> : currentUserData.accountType === 'Shopkeeper' ? <Store className="w-3.5 h-3.5" /> : <Briefcase className="w-3.5 h-3.5" />}
              {currentUserData.accountType} Details
            </button>

            <button 
              onClick={() => setActiveSubTab('orders')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeSubTab === 'orders' ? 'bg-[#041627] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" /> Orders ({userOrders.length})
            </button>

            <button 
              onClick={() => setActiveSubTab('reviews')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeSubTab === 'reviews' ? 'bg-[#041627] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Star className="w-3.5 h-3.5 text-amber-500" /> Reviews ({userReviews.length})
            </button>
          </div>

          {/* TAB 1: Personal & Contact Info */}
          {activeSubTab === 'info' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
              
              {/* Personal Information Card */}
              <div className="bg-white border border-slate-200/90 rounded-2xl p-5 space-y-3.5 shadow-sm">
                <h4 className="text-xs font-extrabold text-[#041627] uppercase tracking-wider pb-2 border-b border-slate-100 flex items-center gap-2">
                  <User className="w-4 h-4 text-[#fd8b00]" /> Personal Information
                </h4>

                <div className="space-y-2.5">
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Full Name</span>
                    <span className="font-bold text-[#041627]">{currentUserData.fullName}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Username</span>
                    <span className="font-mono text-indigo-700 font-semibold">@{currentUserData.username || (currentUserData.email ? currentUserData.email.split('@')[0] : 'user')}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Firebase UID</span>
                    <span className="font-mono text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[10px]">{currentUserData.uid || currentUserData.id}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Workspace Role</span>
                    <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${roleBadgeColor}`}>{currentUserData.accountType}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Account Status</span>
                    <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${statusBadgeColor}`}>{currentUserData.status}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Email Verification</span>
                    <span className={`font-semibold px-2 py-0.5 rounded text-[10px] ${
                      currentUserData.emailVerified === 'Verified' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>{currentUserData.emailVerified || 'Verified'}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Registration Date & Time</span>
                    <span className="font-mono text-slate-700">{currentUserData.registrationDateTime || currentUserData.registrationDate}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Last Active</span>
                    <span className="font-mono text-slate-700">{currentUserData.lastActive || currentUserData.lastLogin || 'Just now'}</span>
                  </div>

                  <div className="flex justify-between py-1">
                    <span className="text-slate-500 font-bold">Availability</span>
                    <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px] border border-emerald-200">{currentUserData.availability || 'Available'}</span>
                  </div>
                </div>
              </div>

              {/* Contact & Address Information Card */}
              <div className="bg-white border border-slate-200/90 rounded-2xl p-5 space-y-3.5 shadow-sm">
                <h4 className="text-xs font-extrabold text-[#041627] uppercase tracking-wider pb-2 border-b border-slate-100 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#fd8b00]" /> Contact & Address Details
                </h4>

                <div className="space-y-2.5">
                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Email Address</span>
                    <span className="font-medium text-[#041627]">{currentUserData.email}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Phone Number</span>
                    <span className="font-mono text-[#041627]">{currentUserData.phone}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Languages</span>
                    <span className="font-medium text-slate-800">{currentUserData.languages || 'Nepali, English'}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Street Address</span>
                    <span className="font-medium text-slate-800">{currentUserData.address || 'N/A'}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">Province</span>
                    <span className="font-medium text-slate-800">{currentUserData.province || 'N/A'}</span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-500 font-bold">District</span>
                    <span className="font-medium text-slate-800">{currentUserData.district || 'N/A'}</span>
                  </div>

                  <div className="flex justify-between py-1">
                    <span className="text-slate-500 font-bold">Municipality / Rural Muni</span>
                    <span className="font-medium text-slate-800">{currentUserData.municipality || 'N/A'}</span>
                  </div>
                </div>
              </div>

              {/* Bio / About Section */}
              <div className="col-span-full bg-white border border-slate-200/90 rounded-2xl p-5 shadow-sm">
                <h4 className="text-xs font-extrabold text-[#041627] uppercase tracking-wider mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#fd8b00]" /> Bio / About Me
                </h4>
                <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 font-medium whitespace-pre-wrap">
                  {currentUserData.bio || currentUserData.about || 'No description provided by the user yet.'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: Role Specific Details */}
          {activeSubTab === 'role' && (
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-sm text-xs space-y-4">
              {currentUserData.accountType === 'Expert' && (
                <div className="space-y-4">
                  <h4 className="text-sm font-extrabold text-[#041627] border-b pb-2 flex items-center gap-2">
                    <Award className="w-4 h-4 text-[#fd8b00]" /> Professional Expert Profile
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/60">
                      <span className="text-slate-500 font-bold block mb-1">Professional Title</span>
                      <span className="text-sm font-black text-amber-900">{currentUserData.professionalTitle || currentUserData.professionType || 'Architect / Engineer'}</span>
                    </div>

                    <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/60">
                      <span className="text-slate-500 font-bold block mb-1">Years of Experience</span>
                      <span className="text-sm font-black text-amber-900">{currentUserData.yearsOfExperience || 0} Years</span>
                    </div>

                    <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/60">
                      <span className="text-slate-500 font-bold block mb-1">Overall Rating</span>
                      <span className="text-sm font-black text-amber-900 flex items-center gap-1">
                        <Star className="w-4 h-4 fill-amber-500 text-amber-500" /> {currentUserData.rating || 5.0} ({currentUserData.reviews || userReviews.length} reviews)
                      </span>
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-700 font-bold block mb-2">Skills & Specializations</span>
                    <div className="flex flex-wrap gap-1.5">
                      {(currentUserData.skillsOrTags || ['Blueprint Design', 'Structural Audit', '3D Floor Plan']).map((skill, idx) => (
                        <span key={idx} className="bg-slate-100 text-slate-800 font-semibold px-3 py-1 rounded-full text-xs border border-slate-200">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-700 font-bold block mb-1">Certifications & Licenses</span>
                    <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-700 font-medium">
                      {currentUserData.certifications || 'Verified Professional Partner Certificate #DH-EXP-2026'}
                    </p>
                  </div>
                </div>
              )}

              {currentUserData.accountType === 'Shopkeeper' && (
                <div className="space-y-4">
                  <h4 className="text-sm font-extrabold text-[#041627] border-b pb-2 flex items-center gap-2">
                    <Store className="w-4 h-4 text-emerald-600" /> Vendor / Shopkeeper Business Profile
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200/60">
                      <span className="text-slate-500 font-bold block mb-1">Shop Name</span>
                      <span className="text-sm font-black text-emerald-900">{currentUserData.shopName || `${currentUserData.fullName}'s Building Hardware`}</span>
                    </div>

                    <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200/60">
                      <span className="text-slate-500 font-bold block mb-1">Business Category</span>
                      <span className="text-sm font-black text-emerald-900">{currentUserData.businessCategory || 'Heavy Construction Materials'}</span>
                    </div>

                    <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200/60">
                      <span className="text-slate-500 font-bold block mb-1">Listed Products Count</span>
                      <span className="text-sm font-black text-emerald-900">{userProducts.length} Active Items</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <span className="text-slate-700 font-bold block mb-1">Shop Address</span>
                      <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-700 font-medium">
                        {currentUserData.shopAddress || currentUserData.address || 'Main Road Hardware Hub'}
                      </p>
                    </div>

                    <div>
                      <span className="text-slate-700 font-bold block mb-1">Business Registration Number</span>
                      <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-700 font-mono font-medium">
                        {currentUserData.businessRegistrationNumber || 'PAN / VAT # 601928374'}
                      </p>
                    </div>
                  </div>

                  {currentUserData.shopDescription && (
                    <div>
                      <span className="text-slate-700 font-bold block mb-1">Shop Description & Offerings</span>
                      <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-700 font-medium">
                        {currentUserData.shopDescription}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {(currentUserData.accountType === 'Homeowner' || currentUserData.accountType === 'Admin') && (
                <div className="space-y-4">
                  <h4 className="text-sm font-extrabold text-[#041627] border-b pb-2 flex items-center gap-2">
                    <User className="w-4 h-4 text-blue-600" /> Client Workspace Capabilities
                  </h4>
                  <p className="text-slate-600 font-medium">
                    This user account has standard homeowner client privileges, allowing them to browse material catalogs, request custom expert consultations, generate floor plans, and track orders.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Orders List */}
          {activeSubTab === 'orders' && (
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-sm text-xs space-y-4">
              <div className="flex justify-between items-center border-b pb-3">
                <h4 className="font-extrabold text-[#041627] flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-[#fd8b00]" /> Connected Order Records ({userOrders.length})
                </h4>
              </div>

              {userOrders.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 rounded-xl border border-slate-200">
                  <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-bold text-slate-700">No orders associated with this account email.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                  {userOrders.map((ord) => (
                    <div key={ord.id} className="py-3 flex items-center justify-between gap-4 hover:bg-slate-50 px-2 rounded-lg transition-colors">
                      <div>
                        <div className="font-extrabold text-[#041627] flex items-center gap-2">
                          <span>Order #{ord.id.slice(-8)}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 font-bold">{ord.status}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 font-medium">
                          {ord.productName || (ord.items ? `${ord.items.length} items` : 'Materials purchase')} • {ord.date}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-extrabold text-[#fd8b00]">NPR {(ord.totalPrice || ord.amount || 0).toLocaleString()}</div>
                        <div className="text-[10px] text-slate-400">{ord.paymentMethod || 'Online Payment'}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: Reviews List */}
          {activeSubTab === 'reviews' && (
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-sm text-xs space-y-4">
              <h4 className="font-extrabold text-[#041627] flex items-center gap-2 border-b pb-3">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" /> Feedback & Ratings ({userReviews.length})
              </h4>

              {userReviews.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 rounded-xl border border-slate-200">
                  <Star className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-bold text-slate-700">No reviews logged for this user yet.</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-72 overflow-y-auto">
                  {userReviews.map((rev) => (
                    <div key={rev.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-[#041627]">{rev.reviewerName || 'Anonymous Client'}</span>
                        <div className="flex items-center gap-1 text-amber-500 font-bold text-xs">
                          <Star className="w-3.5 h-3.5 fill-amber-500" /> {rev.rating || 5} / 5
                        </div>
                      </div>
                      <p className="text-slate-600 text-[11px] font-medium">{rev.reviewText || rev.comment}</p>
                      <div className="text-[10px] text-slate-400 font-mono">{rev.createdAt || rev.date || 'Recent'}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer Admin Action Controls */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-2">
            {(currentUserData.status === 'Pending' || currentUserData.accountStatus === 'Pending') ? (
              <>
                <button 
                  type="button"
                  onClick={handleApprove}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow transition-all cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" /> Approve & Activate Account
                </button>
                <button 
                  type="button"
                  onClick={handleReject}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs shadow transition-all cursor-pointer"
                >
                  <UserX className="w-4 h-4" /> Reject Registration
                </button>
              </>
            ) : (
              <button 
                type="button"
                onClick={handleToggleStatus}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs shadow-sm transition-all cursor-pointer ${
                  currentUserData.status === 'Active' 
                    ? 'bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-300' 
                    : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-300'
                }`}
              >
                {currentUserData.status === 'Active' ? (
                  <><UserX className="w-4 h-4 text-rose-600" /> Suspend Account</>
                ) : (
                  <><UserCheck className="w-4 h-4 text-emerald-600" /> Activate Account</>
                )}
              </button>
            )}

            <button 
              type="button"
              onClick={handleDeleteAccount}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-200 hover:bg-rose-600 hover:text-white text-slate-700 rounded-xl font-bold text-xs transition-all cursor-pointer"
              title="Delete Account"
            >
              <Trash2 className="w-4 h-4" /> Delete Account
            </button>
          </div>

          <button 
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 bg-[#041627] hover:bg-[#0b1c30] text-white font-extrabold text-xs rounded-xl shadow transition-all cursor-pointer"
          >
            Close Profile
          </button>
        </div>

      </div>
    </div>
  );
}
