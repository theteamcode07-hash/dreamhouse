import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Search, Check, X } from 'lucide-react';

interface SearchableDropdownProps {
  id: string;
  label: string;
  options: string[];
  selectedValue: string;
  onChange: (value: string) => void;
  placeholder: string;
  disabled?: boolean;
}

export default function SearchableDropdown({
  id,
  label,
  options,
  selectedValue,
  onChange,
  placeholder,
  disabled = false
}: SearchableDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(-1);
  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Filter options based on search query memoized to prevent infinite renders
  const filteredOptions = useMemo(() => {
    return options.filter(option =>
      option.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [options, searchQuery]);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle opening of dropdown and focus the search input
  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      setActiveIndex(-1);
      // Small timeout to let the input render before focusing
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
  }, [isOpen]);

  // Adjust active index within limits safely
  useEffect(() => {
    if (filteredOptions.length === 0) {
      setActiveIndex(prev => prev !== -1 ? -1 : prev);
    } else if (activeIndex >= filteredOptions.length) {
      setActiveIndex(filteredOptions.length - 1);
    }
  }, [filteredOptions.length, activeIndex]);

  // Scroll the highlighted item into view
  useEffect(() => {
    if (isOpen && activeIndex >= 0 && listRef.current) {
      const activeElement = listRef.current.children[activeIndex] as HTMLElement;
      if (activeElement) {
        const listHeight = listRef.current.clientHeight;
        const elemTop = activeElement.offsetTop;
        const elemHeight = activeElement.offsetHeight;

        if (elemTop + elemHeight > listRef.current.scrollTop + listHeight) {
          listRef.current.scrollTop = elemTop + elemHeight - listHeight;
        } else if (elemTop < listRef.current.scrollTop) {
          listRef.current.scrollTop = elemTop;
        }
      }
    }
  }, [activeIndex, isOpen]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (disabled) return;

    if (!isOpen) {
      if (e.key === 'Enter' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        setIsOpen(true);
      }
      return;
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setActiveIndex(prev => (prev + 1) % filteredOptions.length);
        break;
      case 'ArrowUp':
        e.preventDefault();
        setActiveIndex(prev => (prev - 1 + filteredOptions.length) % filteredOptions.length);
        break;
      case 'Enter':
        e.preventDefault();
        if (activeIndex >= 0 && activeIndex < filteredOptions.length) {
          handleSelect(filteredOptions[activeIndex]);
        } else if (filteredOptions.length > 0) {
          // Fallback select the first option if nothing is highlighted
          handleSelect(filteredOptions[0]);
        }
        break;
      case 'Escape':
        e.preventDefault();
        setIsOpen(false);
        break;
      case 'Tab':
        // Let normal tab behavior close the dropdown and move focus
        setIsOpen(false);
        break;
      default:
        break;
    }
  };

  const handleSelect = (val: string) => {
    onChange(val);
    setIsOpen(false);
    setSearchQuery('');
  };

  return (
    <div className="relative w-full text-left font-sans" ref={containerRef} id={`searchable-dropdown-container-${id}`}>
      <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1.5">
        {label}
      </label>

      {/* Trigger Button */}
      <button
        id={id}
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        onKeyDown={handleKeyDown}
        className={`w-full text-xs p-3.5 border rounded-xl flex items-center justify-between transition-all bg-slate-50 dark:bg-slate-800 font-semibold text-slate-800 dark:text-slate-100 focus:outline-none ${
          disabled 
            ? 'opacity-50 cursor-not-allowed bg-slate-100 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700' 
            : isOpen 
              ? 'border-[#fd8b00] ring-2 ring-[#fd8b00]/10 bg-white dark:bg-slate-900' 
              : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
        }`}
      >
        <span className={selectedValue ? 'text-slate-800 dark:text-slate-100' : 'text-slate-400 dark:text-slate-400 font-medium'}>
          {selectedValue || placeholder}
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isOpen ? 'transform rotate-180 text-[#fd8b00]' : ''}`} />
      </button>

      {/* Dropdown Options Portal */}
      <AnimatePresence>
        {isOpen && !disabled && (
          <motion.div
            initial={{ opacity: 0, y: 5, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 5, scale: 0.98 }}
            transition={{ duration: 0.15, ease: 'easeOut' }}
            className="absolute z-50 w-full mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl overflow-hidden max-h-72 flex flex-col"
          >
            {/* Search input container */}
            <div className="p-2 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-slate-400 shrink-0 ml-1.5" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setActiveIndex(0); // reset highlight to first filtered item
                }}
                onKeyDown={handleKeyDown}
                placeholder="Search..."
                className="w-full text-xs bg-transparent border-none focus:outline-none py-1.5 pr-2 text-slate-800 dark:text-slate-100 font-medium placeholder-slate-400 dark:placeholder-slate-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* List options */}
            <div
              ref={listRef}
              className="overflow-y-auto max-h-52 divide-y divide-slate-50 dark:divide-slate-800"
            >
              {filteredOptions.length > 0 ? (
                filteredOptions.map((option, idx) => {
                  const isSelected = option === selectedValue;
                  const isHighlighted = idx === activeIndex;

                  return (
                    <div
                      key={option}
                      onClick={() => handleSelect(option)}
                      onMouseEnter={() => setActiveIndex(idx)}
                      className={`px-4 py-2.5 text-xs font-semibold cursor-pointer flex items-center justify-between transition-colors ${
                        isSelected 
                          ? 'bg-amber-50/50 dark:bg-amber-950/30 text-[#fd8b00]' 
                          : isHighlighted 
                            ? 'bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100' 
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span className="truncate">{option}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#fd8b00] shrink-0" />}
                    </div>
                  );
                })
              ) : (
                <div className="px-4 py-4 text-xs font-medium text-slate-400 dark:text-slate-500 text-center">
                  No results found
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
