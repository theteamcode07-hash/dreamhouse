import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, CreditCard, ShoppingBag, ShieldCheck, CheckCircle2, AlertTriangle, 
  MapPin, Loader2, DollarSign, Wallet, ArrowRight
} from 'lucide-react';
import { CartItem, Product, Order } from '../types';
import { NEPAL_PROVINCES, getMunicipalitiesForDistrict } from '../lib/nepalAddressData';
import SearchableDropdown from './SearchableDropdown';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';

interface CheckoutPageProps {
  cartItems: CartItem[];
  products: Product[];
  username: string;
  userEmail: string;
  userPhone?: string;
  userAddress?: string;
  couponDiscount?: number;
  appliedCoupon?: string | null;
  onUpdateQty: (id: string, qty: number) => void;
  onRemoveFromCart: (id: string) => void;
  onPlaceOrder: (orderDetails: Omit<Order, 'id'>, paymentDetails: any) => Promise<string>;
  onBackToCart: () => void;
}

export default function CheckoutPage({
  cartItems,
  products,
  username,
  userEmail,
  userPhone = '',
  userAddress = '',
  couponDiscount = 0,
  appliedCoupon = null,
  onUpdateQty,
  onRemoveFromCart,
  onPlaceOrder,
  onBackToCart
}: CheckoutPageProps) {
  // Loading & Error States
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Customer Shipping Details State
  const [fullName, setFullName] = useState(username || '');
  const [email, setEmail] = useState(userEmail || '');
  const [phone, setPhone] = useState(userPhone);
  const [address, setAddress] = useState('');
  const [province, setProvince] = useState('');
  const [district, setDistrict] = useState('');
  const [municipality, setMunicipality] = useState('');
  const [country, setCountry] = useState('Nepal');

  // Keep state updated when user logs in or profile updates
  useEffect(() => {
    if (username) setFullName(username);
    if (userEmail) setEmail(userEmail);
    if (userPhone) setPhone(userPhone);
  }, [username, userEmail, userPhone]);

  // Parse existing concatenated address string into structured fields
  const parseAddressString = (addrStr: string) => {
    if (!addrStr) return;
    
    // Check if it's the foreign or default address, keep empty and set defaults for province/district/municipality
    if (addrStr.includes('4508 Oakwood Lane') || addrStr === 'Jobsite #12 - Kathmandu Metropolitan, Nepal' || addrStr.trim() === '') {
      setAddress('');
      setProvince('Bagmati Province');
      setDistrict('Kathmandu');
      setMunicipality('Kathmandu Metropolitan City');
      return;
    }

    const parts = addrStr.split(',').map(s => s.trim());
    if (parts.length >= 4) {
      // Expected structure: Street Address, Municipality, District, Province, Country
      const countryPart = parts[parts.length - 1];
      const provincePart = parts[parts.length - 2];
      const districtPart = parts[parts.length - 3];
      const municipalityPart = parts[parts.length - 4];
      const streetParts = parts.slice(0, parts.length - 4);
      const streetPart = streetParts.join(', ');

      const matchedProvince = NEPAL_PROVINCES.find(
        p => p.name.toLowerCase() === provincePart.toLowerCase() || p.name.toLowerCase().includes(provincePart.toLowerCase())
      );
      if (matchedProvince) {
        setProvince(matchedProvince.name);
        
        const matchedDistrict = matchedProvince.districts.find(
          d => d.toLowerCase() === districtPart.toLowerCase()
        );
        if (matchedDistrict) {
          setDistrict(matchedDistrict);
          
          const municipalities = getMunicipalitiesForDistrict(matchedDistrict);
          const matchedMun = municipalities.find(
            m => m.toLowerCase() === municipalityPart.toLowerCase() || m.toLowerCase().includes(municipalityPart.toLowerCase())
          );
          if (matchedMun) {
            setMunicipality(matchedMun);
          } else {
            setMunicipality(municipalityPart);
          }
        } else {
          setDistrict(districtPart);
          setMunicipality(municipalityPart);
        }
        setAddress(streetPart || '');
      } else {
        // Fallback for non-Nepal or old style address
        setProvince('Bagmati Province');
        setDistrict('Kathmandu');
        setMunicipality('Kathmandu Metropolitan City');
        setAddress(addrStr.split(',')[0] || '');
      }
    } else {
      setProvince('Bagmati Province');
      setDistrict('Kathmandu');
      setMunicipality('Kathmandu Metropolitan City');
      setAddress(addrStr || '');
    }
  };

  // Real-time loading of saved address from Firebase Firestore
  useEffect(() => {
    if (!email) return;

    const fetchSavedAddress = async () => {
      try {
        const docRef = doc(db, 'user_addresses', email.toLowerCase());
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data) {
            if (data.province) setProvince(data.province);
            if (data.district) setDistrict(data.district);
            if (data.municipality) setMunicipality(data.municipality);
            if (data.streetAddress) setAddress(data.streetAddress);
            if (data.country) setCountry(data.country || 'Nepal');
          }
        } else if (userAddress) {
          parseAddressString(userAddress);
        }
      } catch (err) {
        console.warn("Failed to load address from Firestore:", err);
        if (userAddress) {
          parseAddressString(userAddress);
        }
      }
    };

    fetchSavedAddress();
  }, [email, userAddress]);

  const handleProvinceChange = (newProvince: string) => {
    setProvince(newProvince);
    setDistrict('');
    setMunicipality('');
  };

  const handleDistrictChange = (newDistrict: string) => {
    setDistrict(newDistrict);
    setMunicipality('');
  };

  // Selected Payment Method
  const [paymentMethod, setPaymentMethod] = useState<'esewa' | 'khalti' | 'bank'>('esewa');

  // Pre-generated Order ID for QR code display
  const [orderId] = useState(() => `#ORD-${Math.floor(Math.random() * 8900) + 1000}`);
  const [showPaymentConfirmModal, setShowPaymentConfirmModal] = useState(false);
  const [paymentConfirmDetails, setPaymentConfirmDetails] = useState<{ sellerName: string; amount: number; orderId: string; method: string } | null>(null);

  // eSewa & Khalti form state
  const [walletPhone, setWalletPhone] = useState('');
  const [walletPin, setWalletPin] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  // Load and filter items for the active shop
  const activeShopName = localStorage.getItem('dreamhouse_checkout_shop');
  const checkoutItems = activeShopName 
    ? cartItems.filter(item => (item.seller?.shopName || 'ProBuild Materials Inc.') === activeShopName)
    : cartItems;

  const [sellersPaymentSettings, setSellersPaymentSettings] = useState<Record<string, any>>({});

  const uniqueSellers = React.useMemo(() => {
    const sellersMap = new Map<string, { email: string; shopName: string }>();
    checkoutItems.forEach(item => {
      const email = (item.seller?.email || 'shopkeeper@gmail.com').trim().toLowerCase();
      const shopName = item.seller?.shopName || 'ProBuild Materials Inc.';
      if (!sellersMap.has(email)) {
        sellersMap.set(email, { email, shopName });
      }
    });
    return Array.from(sellersMap.values());
  }, [checkoutItems]);

  useEffect(() => {
    if (uniqueSellers.length === 0) {
      setSellersPaymentSettings({});
      return;
    }

    const unsubs = uniqueSellers.map(seller => {
      return onSnapshot(doc(db, 'payment_settings', seller.email), (docSnap) => {
        setSellersPaymentSettings(prev => ({
          ...prev,
          [seller.email]: docSnap.exists() ? docSnap.data() : null
        }));
      });
    });

    return () => {
      unsubs.forEach(unsub => unsub());
    };
  }, [uniqueSellers]);

  // Calculations (recalculated in real-time)
  const totalItemCount = checkoutItems.length;
  const subtotal = checkoutItems.reduce((acc, item) => acc + item.price * item.qty, 0);
  
  // Free freight if applied coupon is FREEFREIGHT, otherwise $45
  const shippingFee = checkoutItems.length === 0 ? 0 : (appliedCoupon === 'FREEFREIGHT' ? 0 : 45.00);
  const estimatedTax = subtotal * 0.13;
  const serviceCharge = checkoutItems.length > 0 ? 15.00 : 0;
  
  // Custom discount calculation based on coupon
  let discount = 0;
  if (appliedCoupon === 'DREAMHOUSE10') {
    discount = subtotal * 0.10;
  } else if (appliedCoupon === 'PROBUILD50') {
    discount = Math.min(subtotal, 50);
  } else if (appliedCoupon === 'FREEFREIGHT') {
    discount = 45.00;
  }

  const grandTotal = Math.max(0, subtotal + shippingFee + estimatedTax - discount + serviceCharge);

  // Validate basic fields before opening confirmation modal
  const validateAndConfirmQRPayment = (sellerName: string) => {
    setErrorMessage(null);

    // Front-end validation of basic fields
    const trimmedAddress = address.trim();
    if (!trimmedAddress) {
      setErrorMessage('Recipient jobsite address is required for material delivery.');
      return;
    }
    if (!fullName.trim()) {
      setErrorMessage('Recipient full name is required.');
      return;
    }
    if (!phone.trim() || phone.length < 7) {
      setErrorMessage('A valid contact phone number is required.');
      return;
    }
    if (!province) {
      setErrorMessage('Province is required.');
      return;
    }
    if (!district) {
      setErrorMessage('District is required.');
      return;
    }
    if (!municipality) {
      setErrorMessage('Municipality is required.');
      return;
    }

    // Verify quantities are supported by stock
    for (const item of cartItems) {
      const prod = products.find(p => p.id === item.id);
      const stock = prod?.availableQuantity ?? 100;
      if (item.qty > stock) {
        setErrorMessage(`Invalid quantity for ${item.name}. Only ${stock} units are available in stock.`);
        return;
      }
    }

    // Verify that the selected payment method is available and configured for all unique sellers
    for (const seller of uniqueSellers) {
      const settings = sellersPaymentSettings[seller.email.trim().toLowerCase()];
      if (paymentMethod === 'esewa') {
        if (!settings || !settings.esewaEnabled || !settings.esewaQrCode) {
          setErrorMessage(`eSewa payment is currently unavailable for ${seller.shopName}. Please select another payment method.`);
          return;
        }
      } else if (paymentMethod === 'khalti') {
        if (!settings || !settings.khaltiEnabled || !settings.khaltiQrCode) {
          setErrorMessage(`Khalti payment is currently unavailable for ${seller.shopName}. Please select another payment method.`);
          return;
        }
      } else if (paymentMethod === 'bank') {
        if (!settings || !settings.bankEnabled || !settings.bankQrCode) {
          setErrorMessage(`Bank transfer payment is currently unavailable for ${seller.shopName}. Please select another payment method.`);
          return;
        }
      }
    }

    setPaymentConfirmDetails({
      sellerName,
      amount: grandTotal,
      orderId,
      method: paymentMethod === 'esewa' ? 'eSewa' : paymentMethod === 'khalti' ? 'Khalti' : 'Bank Transfer'
    });
    setShowPaymentConfirmModal(true);
  };

  // Submit QR payment order to Firestore and mark as Pending Verification
  const submitQROrder = async () => {
    setShowPaymentConfirmModal(false);
    setIsSubmitting(true);
    setErrorMessage(null);

    const randomPayId = `PAY-${Math.floor(Math.random() * 89000) + 10000}`;
    const randomTxnId = `TXN-${paymentMethod.toUpperCase()}-${Math.floor(Math.random() * 890000) + 100000}`;

    const firstItem = cartItems[0];
    const shopkeeperId = firstItem?.seller?.email || 'shopkeeper@gmail.com';
    const shopkeeperName = firstItem?.seller?.shopName || 'ProBuild Materials Inc.';

    const orderPayload: any = {
      id: orderId, // Use our pre-generated order ID
      customer: fullName,
      clientId: email,
      clientName: fullName,
      clientEmail: email,
      customerPhone: phone,
      productId: firstItem?.id || '',
      productName: cartItems.length === 1 
        ? firstItem?.name || 'Material Order' 
        : `${firstItem?.name || 'Material'} (+${cartItems.length - 1} items)`,
      productImage: firstItem?.image || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=500&auto=format&fit=crop&q=80',
      quantity: totalItemCount,
      unitPrice: firstItem?.price || 0,
      totalPrice: grandTotal,
      amount: grandTotal,
      shopkeeperId: shopkeeperId,
      shopkeeperName: shopkeeperName,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      status: 'Pending', // Default status: Pending
      paymentStatus: 'Pending Verification', // Mark payment as Pending Verification until merchant approves
      paymentMethod: paymentMethod.toUpperCase(),
      paymentId: randomPayId,
      transactionId: randomTxnId,
      paidAmount: grandTotal,
      paymentTime: new Date().toISOString(),
      shippingAddress: `${address}, ${municipality}, ${district}, ${province}, ${country}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      items: cartItems.map(item => ({
        productId: item.id,
        productName: item.name,
        productImage: item.image,
        quantity: item.qty,
        unitPrice: item.price,
        totalPrice: item.price * item.qty,
        shopkeeperId: item.seller?.email || 'shopkeeper@gmail.com',
        shopkeeperName: item.seller?.shopName || 'ProBuild Materials Inc.',
        unit: 'piece'
      }))
    };

    try {
      // Save address to Firestore
      try {
        await setDoc(doc(db, 'user_addresses', email.toLowerCase()), {
          province,
          district,
          municipality,
          streetAddress: address,
          country,
          formattedAddress: `${address}, ${municipality}, ${district}, ${province}, ${country}`,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (addrErr) {
        console.warn("Auto-saving address to Firestore failed, proceeding with order:", addrErr);
      }

      // Save a dedicated payment request for safety
      try {
        await setDoc(doc(db, 'payment_requests', orderId), {
          orderId,
          customerName: fullName,
          customerEmail: email,
          customerPhone: phone,
          shopkeeperId,
          shopkeeperName,
          amount: grandTotal,
          paymentMethod: paymentMethod.toUpperCase(),
          status: 'Pending Verification',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      } catch (payReqErr) {
        console.warn("Saving payment request collection failed:", payReqErr);
      }

      // Call prop callback to place order in Firebase
      await onPlaceOrder(orderPayload, {
        paymentMethod: paymentMethod.toUpperCase(),
        transactionId: randomTxnId,
        paymentId: randomPayId,
        amount: grandTotal,
        paymentStatus: 'Pending Verification'
      });
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage(err.message || 'Payment processor failed to save.');
    }
  };

  // Submit Order and Process Payment Simulation
  const handleConfirmOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Front-end validation of basic fields
    const trimmedAddress = address.trim();
    if (!trimmedAddress) {
      setErrorMessage('Recipient jobsite address is required for material delivery.');
      return;
    }

    if (!fullName || !email || !phone || !province || !district || !municipality || !country) {
      setErrorMessage('Please complete all client information fields, including Province, District, and Municipality.');
      return;
    }

    if (cartItems.length === 0) {
      setErrorMessage('Your cart is empty. Cannot proceed with order.');
      return;
    }

    // Validate quantities are supported by stock
    for (const item of cartItems) {
      const prod = products.find(p => p.id === item.id);
      const stock = prod?.availableQuantity ?? 100;
      if (item.qty > stock) {
        setErrorMessage(`Invalid quantity for ${item.name}. Only ${stock} units are available in stock.`);
        return;
      }
    }

    // All payment methods are now QR/Confirmation based
    const activeSeller = uniqueSellers[0];
    validateAndConfirmQRPayment(activeSeller?.shopName || 'the shopkeeper');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16 font-sans">
      {/* Top Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <button 
            onClick={onBackToCart}
            disabled={isSubmitting}
            className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors bg-slate-100 hover:bg-slate-200 px-4 py-2.5 rounded-xl cursor-pointer disabled:opacity-50"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Shopping Cart</span>
          </button>
          
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-500" />
            <h1 className="text-xl font-bold text-slate-900">Secure Gateway Checkout</h1>
          </div>

          <div className="flex items-center gap-2 text-xs font-black text-slate-400">
            <span>256-BIT ENCRYPTION</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <form onSubmit={handleConfirmOrder} className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* Left Column: Customer Information & Payment (65%) */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Display error messages if any */}
            {errorMessage && (
              <div className="bg-red-50 border border-red-200 text-red-800 rounded-2xl p-4 text-xs font-semibold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Section 1: Customer Information */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h2 className="text-base font-black text-slate-950 font-sans mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#fd8b00]" />
                <span>1. Customer & Shipping Destination</span>
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1.5">Recipient Full Name</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-slate-50 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1.5">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-slate-50 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1.5">Contact Phone Number</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-slate-50 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1.5">Jobsite/Street Address</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    required
                    placeholder="House No. 12, New Baneshwor"
                    className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] bg-slate-50 font-semibold"
                  />
                </div>
                <SearchableDropdown
                  id="province-dropdown"
                  label="Province / State"
                  options={NEPAL_PROVINCES.map(p => p.name)}
                  selectedValue={province}
                  onChange={handleProvinceChange}
                  placeholder="Select Province"
                />
                <SearchableDropdown
                  id="district-dropdown"
                  label="District"
                  options={province ? (NEPAL_PROVINCES.find(p => p.name === province)?.districts || []) : []}
                  selectedValue={district}
                  onChange={handleDistrictChange}
                  placeholder={province ? "Select District" : "Select Province first"}
                  disabled={!province}
                />
                <SearchableDropdown
                  id="municipality-dropdown"
                  label="Municipality / Rural Municipality / Metropolitan City"
                  options={district ? getMunicipalitiesForDistrict(district) : []}
                  selectedValue={municipality}
                  onChange={setMunicipality}
                  placeholder={district ? "Select Municipality" : "Select District first"}
                  disabled={!district}
                />
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1.5">Country</label>
                  <input
                    type="text"
                    value={country}
                    readOnly
                    disabled
                    className="w-full text-xs p-3.5 border border-slate-200 rounded-xl bg-slate-100 font-semibold text-slate-500 cursor-not-allowed"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Payment Method */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h2 className="text-base font-black text-slate-950 font-sans mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-[#fd8b00]" />
                <span>2. Secured Payment Information</span>
              </h2>

              {/* Toggle Buttons */}
              <div className="grid grid-cols-3 gap-3 mb-6">
                <button
                  type="button"
                  onClick={() => { setPaymentMethod('esewa'); setErrorMessage(null); }}
                  className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                    paymentMethod === 'esewa' 
                      ? 'border-[#fd8b00] bg-amber-50/50 text-[#fd8b00]' 
                      : 'border-slate-200 bg-white hover:border-slate-300 text-slate-600'
                  }`}
                >
                  <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center font-black text-[10px]">eS</div>
                  <span className="text-xs font-bold truncate">eSewa Nepal</span>
                </button>
                <button
                  type="button"
                  onClick={() => { setPaymentMethod('khalti'); setErrorMessage(null); }}
                  className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                    paymentMethod === 'khalti' 
                      ? 'border-[#fd8b00] bg-amber-50/50 text-[#fd8b00]' 
                      : 'border-slate-200 bg-white hover:border-slate-300 text-slate-600'
                  }`}
                >
                  <div className="w-6 h-6 rounded-full bg-purple-700 text-white flex items-center justify-center font-black text-[10px]">Kh</div>
                  <span className="text-xs font-bold truncate">Khalti Nepal</span>
                </button>
                <button
                  type="button"
                  onClick={() => { setPaymentMethod('bank'); setErrorMessage(null); }}
                  className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                    paymentMethod === 'bank' 
                      ? 'border-[#fd8b00] bg-amber-50/50 text-[#fd8b00]' 
                      : 'border-slate-200 bg-white hover:border-slate-300 text-slate-600'
                  }`}
                >
                  <div className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black text-[10px]">BK</div>
                  <span className="text-xs font-bold truncate">Bank Payment</span>
                </button>
              </div>

              {/* Dynamic form content based on selected method */}
              <AnimatePresence mode="wait">
                <div className="space-y-6">
                  {uniqueSellers.map((seller) => {
                    const emailClean = seller.email.trim().toLowerCase();
                    const settings = sellersPaymentSettings[emailClean];

                    let isAvailable = false;
                    let qrUrl = '';

                    if (paymentMethod === 'esewa') {
                      isAvailable = !!(settings?.esewaEnabled && settings?.esewaQrCode);
                      qrUrl = settings?.esewaQrCode || '';
                    } else if (paymentMethod === 'khalti') {
                      isAvailable = !!(settings?.khaltiEnabled && settings?.khaltiQrCode);
                      qrUrl = settings?.khaltiQrCode || '';
                    } else if (paymentMethod === 'bank') {
                      isAvailable = !!(settings?.bankEnabled && (settings?.bankQrCode || (settings?.bankName && settings?.accountName && settings?.accountNumber)));
                      qrUrl = settings?.bankQrCode || '';
                    }

                    return (
                      <div key={seller.email} className="p-6 border border-slate-200 rounded-2xl bg-white shadow-xs space-y-6">
                        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                          <div>
                            <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider">Secure QR Checkout</span>
                            <h4 className="text-base font-black text-slate-900">{seller.shopName}</h4>
                          </div>
                          <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">{seller.email}</span>
                        </div>

                        {!isAvailable ? (
                          <div className="p-4 rounded-xl border border-rose-100 bg-rose-50 text-rose-800 text-xs font-semibold flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                            <span>This payment method is currently unavailable for this shop.</span>
                          </div>
                        ) : (
                          <div className="flex flex-col md:flex-row gap-6 items-center">
                            {/* QR Code */}
                            {qrUrl && (
                              <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-2xl border border-slate-200 shadow-xs max-w-xs shrink-0 w-full sm:w-auto">
                                <img
                                  src={qrUrl}
                                  alt={`${paymentMethod === 'esewa' ? 'eSewa' : paymentMethod === 'khalti' ? 'Khalti' : 'Bank'} QR`}
                                  className="w-44 h-44 object-contain rounded-lg shadow-xs"
                                  referrerPolicy="no-referrer"
                                />
                                <span className="text-[10px] font-extrabold text-slate-400 mt-2.5 uppercase tracking-wider">Scan to Transfer</span>
                              </div>
                            )}

                            {/* Information Board */}
                            <div className="flex-1 w-full space-y-4">
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-semibold">
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Shop Name</span>
                                  <span className="text-slate-800 font-black">{seller.shopName}</span>
                                </div>
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Payment Method</span>
                                  <span className="text-slate-800 font-black flex items-center gap-1.5">
                                    {paymentMethod === 'esewa' ? (
                                      <>
                                        <span className="w-5 h-5 rounded bg-emerald-600 text-white flex items-center justify-center text-[9px] font-black">eS</span>
                                        eSewa Nepal
                                      </>
                                    ) : paymentMethod === 'khalti' ? (
                                      <>
                                        <span className="w-5 h-5 rounded bg-purple-700 text-white flex items-center justify-center text-[9px] font-black">Kh</span>
                                        Khalti Nepal
                                      </>
                                    ) : (
                                      <>
                                        <span className="w-5 h-5 rounded bg-amber-500 text-slate-950 flex items-center justify-center text-[9px] font-black">BK</span>
                                        Bank Transfer
                                      </>
                                    )}
                                  </span>
                                </div>
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Amount to Pay</span>
                                  <span className="text-[#fd8b00] font-black text-sm">Rs. {grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Order ID</span>
                                  <span className="font-mono text-slate-800 font-bold">{orderId}</span>
                                </div>

                                {paymentMethod === 'bank' && (
                                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 sm:col-span-2">
                                    <div className="space-y-1.5 text-xs font-medium">
                                      <div className="flex justify-between border-b border-slate-200/40 pb-1.5">
                                        <span className="text-slate-400 font-semibold">Bank Name:</span>
                                        <span className="font-black text-slate-800">{settings?.bankName || 'N/A'}</span>
                                      </div>
                                      <div className="flex justify-between border-b border-slate-200/40 py-1.5">
                                        <span className="text-slate-400 font-semibold">Account Holder Name:</span>
                                        <span className="font-black text-slate-800">{settings?.accountName || 'N/A'}</span>
                                      </div>
                                      {settings?.accountNumber && (
                                        <div className="flex justify-between pt-1.5">
                                          <span className="text-slate-400 font-semibold">Account Number:</span>
                                          <span className="font-mono font-black text-[#fd8b00]">{settings?.accountNumber}</span>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>

                              <div className="p-3.5 bg-blue-50/50 border border-blue-100 rounded-xl text-[11px] text-blue-800 leading-relaxed font-medium">
                                {paymentMethod === 'bank' ? (
                                  <span>
                                    Please transfer <strong className="text-blue-950 font-black">Rs. {grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong> via Mobile/Internet Banking by scanning the Fonepay QR or using the bank account details above. Once done, click below to notify the merchant.
                                  </span>
                                ) : (
                                  <span>
                                    Please scan the QR code above using your mobile payment app and transfer <strong className="text-blue-950 font-black">Rs. {grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>. Double check the merchant profile name matches <strong className="text-blue-950 font-black">{seller.shopName}</strong>. Once done, click below to notify the merchant.
                                  </span>
                                )}
                              </div>

                              {/* Completed Button below QR */}
                              <button
                                type="button"
                                onClick={() => validateAndConfirmQRPayment(seller.shopName)}
                                className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl transition-all shadow-md active:scale-95 cursor-pointer flex items-center justify-center gap-2"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                                <span>I Have Completed Payment</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </AnimatePresence>
            </div>

            {/* Section 3: Review Order Items (with Quantity modifier) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h2 className="text-base font-black text-slate-950 font-sans mb-4 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#fd8b00]" />
                <span>3. Review Cart Items before Payment</span>
              </h2>

              <div className="divide-y divide-slate-100 space-y-4">
                {cartItems.map((item) => {
                  const matched = products.find(p => p.id === item.id);
                  const maxStock = matched?.availableQuantity ?? 100;

                  return (
                    <div key={item.id} className="flex gap-4 pt-4 first:pt-0">
                      <img 
                        src={item.image || 'https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?w=150'} 
                        alt={item.name} 
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 object-cover rounded-lg border border-slate-100 shrink-0" 
                      />
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <div className="flex justify-between items-start gap-2">
                          <div>
                            <h4 className="text-xs font-black text-slate-900 truncate">{item.name}</h4>
                            <p className="text-[10px] text-slate-400 mt-0.5">{item.seller?.shopName || 'ProBuild Materials'}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-black text-slate-950 block">Rs. {(item.price * item.qty).toFixed(2)}</span>
                            <span className="text-[10px] text-slate-400">Rs. {item.price.toFixed(2)} ea</span>
                          </div>
                        </div>

                        {/* Quantity controls within checkout */}
                        <div className="flex items-center justify-between gap-4 mt-2">
                          <span className="text-[11px] text-slate-400">Qty:</span>
                          <div className="flex items-center bg-slate-100 border border-slate-200 rounded-lg overflow-hidden h-8">
                            <button
                              type="button"
                              onClick={() => {
                                if (item.qty <= 1) {
                                  onRemoveFromCart(item.id);
                                } else {
                                  onUpdateQty(item.id, item.qty - 1);
                                }
                              }}
                              className="px-2 text-slate-500 hover:bg-slate-200 h-full flex items-center justify-center cursor-pointer"
                              title="Decrease"
                            >
                              -
                            </button>
                            <input
                              type="text"
                              readOnly
                              value={item.qty}
                              className="w-8 text-center font-bold text-xs bg-transparent border-none text-slate-800"
                              title="Qty"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (item.qty >= maxStock) {
                                  alert(`Stock limit reached (${maxStock} remaining)`);
                                } else {
                                  onUpdateQty(item.id, item.qty + 1);
                                }
                              }}
                              className="px-2 text-slate-500 hover:bg-slate-200 h-full flex items-center justify-center cursor-pointer"
                              title="Increase"
                            >
                              +
                            </button>
                          </div>
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right Column: Checkout Summary (35%) */}
          <div className="space-y-6">
            
            {/* Summary Details */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h3 className="text-base font-black text-slate-950 font-sans mb-4">Calculation Checklist</h3>
              
              <div className="space-y-3 pb-4 border-b border-slate-100">
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Cart Subtotal ({totalItemCount} Items)</span>
                  <span className="font-bold text-slate-800">Rs. {subtotal.toFixed(2)}</span>
                </div>
                
                {discount > 0 && (
                  <div className="flex justify-between text-xs text-red-600 font-semibold">
                    <span>Discount Coupon ({appliedCoupon})</span>
                    <span>-Rs. {discount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between text-xs text-slate-500">
                  <span>Freight Carrier Delivery</span>
                  <span className="font-bold text-slate-800">
                    {shippingFee === 0 ? <span className="text-emerald-600 font-extrabold">FREE</span> : `Rs. ${shippingFee.toFixed(2)}`}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-slate-500">
                  <span>Estimated Tax (13% VAT)</span>
                  <span className="font-bold text-slate-800">Rs. {estimatedTax.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-xs text-slate-500">
                  <span>Jobsite Unloading Service</span>
                  <span className="font-bold text-slate-800">Rs. {serviceCharge.toFixed(2)}</span>
                </div>
              </div>

              <div className="pt-4 mb-6">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-black text-slate-950">Grand Total</span>
                  <span className="text-2xl font-black text-slate-950">
                    Rs. {grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Confirm Button */}
              <button
                type="submit"
                disabled={isSubmitting || cartItems.length === 0}
                className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-extrabold py-4 rounded-xl shadow-md transition-all hover:scale-[1.01] active:scale-95 flex items-center justify-center gap-2.5 text-sm cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Secure Payment...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Pay Rs. {grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </>
                )}
              </button>

              <p className="text-[10px] text-slate-400 mt-3 text-center leading-relaxed">
                By completing transaction, you agree to the Dream House building material cargo carrier terms of shipment and logistic standards.
              </p>
            </div>

            {/* Safety & Compliance Badge */}
            <div className="bg-slate-100 rounded-xl p-4 border border-slate-200/50 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Verified PCI-DSS Gateway</span>
              </div>
              <p className="text-[10px] text-slate-500 leading-relaxed">
                Card numbers, security PINs, or CVV codes are processed securely and never saved inside our Firebase cloud database for security.
              </p>
            </div>

          </div>

        </form>
      </main>

      {/* QR Code Confirmation Modal Dialog */}
      <AnimatePresence>
        {showPaymentConfirmModal && paymentConfirmDetails && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPaymentConfirmModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="relative w-full max-w-md bg-white rounded-3xl border border-slate-100 shadow-2xl p-6 overflow-hidden z-10"
            >
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-14 h-14 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <h3 className="text-lg font-black text-slate-950 font-sans">Confirm Payment Notification</h3>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Are you sure you have scanned and completed the QR payment transfer?
                  </p>
                </div>

                <div className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-2.5 text-xs text-left font-medium">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Shop Name:</span>
                    <span className="font-black text-slate-900">{paymentConfirmDetails.sellerName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Total Amount:</span>
                    <span className="font-black text-[#fd8b00] text-sm">Rs. {paymentConfirmDetails.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Order ID:</span>
                    <span className="font-mono font-bold text-slate-700">{paymentConfirmDetails.orderId}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Payment Gateway:</span>
                    <span className="font-bold text-slate-800">{paymentConfirmDetails.method} Manual QR</span>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 border border-amber-100 rounded-xl text-[10px] text-amber-800 text-left leading-normal font-semibold">
                  Note: Your order status will be saved as <strong className="text-amber-950 font-black">Pending Verification</strong>. The merchant will review the deposit and activate your order shortly.
                </div>

                <div className="grid grid-cols-2 gap-3 w-full pt-2">
                  <button
                    type="button"
                    onClick={() => setShowPaymentConfirmModal(false)}
                    className="py-3 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    Go Back
                  </button>
                  <button
                    type="button"
                    onClick={submitQROrder}
                    className="py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition-colors shadow-xs hover:shadow-md cursor-pointer"
                  >
                    Yes, I Have Paid
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
