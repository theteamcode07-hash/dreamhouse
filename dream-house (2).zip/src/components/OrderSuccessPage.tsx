import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle, Calendar, FileText, ArrowRight, Home, ShoppingBag, ShieldCheck } from 'lucide-react';
import { Order } from '../types';

interface OrderSuccessPageProps {
  orderId: string;
  transactionId?: string;
  paymentMethod?: string;
  amount?: number;
  shippingAddress?: string;
  onNavigateToTab: (tab: string) => void;
  onContinueShopping: () => void;
}

export default function OrderSuccessPage({
  orderId,
  transactionId = 'TXN-8742910',
  paymentMethod = 'CREDIT CARD',
  amount = 0,
  shippingAddress = 'Kathmandu Metropolitan, Nepal',
  onNavigateToTab,
  onContinueShopping
}: OrderSuccessPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center py-16 px-4 font-sans">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="bg-white rounded-3xl shadow-xl border border-slate-200 p-8 md:p-12 max-w-2xl w-full text-center space-y-8"
      >
        {/* Animated Checkmark Icon */}
        <div className="relative mx-auto w-24 h-24 flex items-center justify-center bg-emerald-50 rounded-full border border-emerald-100">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
          >
            <CheckCircle className="w-12 h-12 text-emerald-500" />
          </motion.div>
          <div className="absolute inset-0 border-2 border-dashed border-emerald-500/20 rounded-full animate-spin [animation-duration:12s]" />
        </div>

        {/* Success Header */}
        <div>
          <span className="text-[10px] font-black tracking-widest text-emerald-600 bg-emerald-100 px-3 py-1 rounded-full uppercase">
            Payment Securely Authorized
          </span>
          <h1 className="text-2xl md:text-3xl font-black text-slate-950 font-sans mt-3">
            Thank You For Your Order!
          </h1>
          <p className="text-slate-500 text-sm mt-1 max-w-md mx-auto">
            Your payment has been successfully processed, and cargo shipment logistics are being synchronized.
          </p>
        </div>

        {/* Transaction Summary Card */}
        <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 text-left space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-200/50">
            <span className="text-xs font-black text-slate-400 uppercase">Order Details</span>
            <span className="text-xs font-black text-emerald-600">CONFIRMED</span>
          </div>

          <div className="grid grid-cols-2 gap-y-3 gap-x-6 text-xs">
            <div>
              <p className="text-slate-400">Order Reference</p>
              <p className="font-bold text-slate-800 font-mono mt-0.5">{orderId}</p>
            </div>
            <div>
              <p className="text-slate-400">Transaction ID</p>
              <p className="font-bold text-slate-800 font-mono mt-0.5">{transactionId}</p>
            </div>
            <div>
              <p className="text-slate-400">Payment Gateway</p>
              <p className="font-bold text-slate-800 mt-0.5">{paymentMethod}</p>
            </div>
            <div>
              <p className="text-slate-400">Authorized Amount</p>
              <p className="font-bold text-slate-800 mt-0.5">
                Rs. {amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          <div className="border-t border-slate-200/50 pt-3 text-xs">
            <p className="text-slate-400">Shipping Destination</p>
            <p className="font-semibold text-slate-700 mt-1 leading-relaxed">{shippingAddress}</p>
          </div>
        </div>

        {/* Estimated Arrival Banner */}
        <div className="border border-amber-200/60 bg-amber-50/50 rounded-xl p-4 flex items-center gap-3.5 text-left">
          <Calendar className="w-5 h-5 text-[#fd8b00] shrink-0" />
          <div className="text-xs">
            <p className="font-bold text-[#fd8b00]">Estimated Delivery Arrival</p>
            <p className="text-slate-600 mt-0.5">July 28 - July 30 (2-3 standard logistics days)</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => onNavigateToTab('dashboard')}
            className="w-full bg-[#fd8b00] hover:bg-[#e07b00] text-white font-extrabold py-4 rounded-xl shadow-md transition-transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 text-sm cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Track Order History</span>
          </button>
          
          <button
            onClick={onContinueShopping}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 rounded-xl shadow-md transition-transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 text-sm cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Continue Shopping</span>
          </button>
        </div>

        {/* Safety Seal */}
        <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 font-semibold pt-4">
          <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
          <span>Cargo Shipment Logistics Standard Certified</span>
        </div>

      </motion.div>
    </div>
  );
}
