import React, { useState, useEffect, useMemo } from 'react';
import { 
  Save, Search, Filter, Image as ImageIcon, Type, Sliders, 
  RotateCcw, CheckCircle2, AlertTriangle, Loader2, Sparkles, HelpCircle 
} from 'lucide-react';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import ImageUploader from './ImageUploader';

interface PlatformConfigEditorProps {
  platformConfig: any;
  updatePlatformConfigAndSync: (config: any) => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

interface AssetDefinition {
  id: string;
  label: string;
  type: 'text' | 'textarea' | 'image';
  category: 'Branding' | 'Hero' | 'Contact & Legal';
  format: 'text' | 'image';
  description: string;
  placeholder?: string;
}

const ASSET_DEFINITIONS: AssetDefinition[] = [
  { 
    id: 'websiteName', 
    label: 'Website Name', 
    type: 'text', 
    category: 'Branding', 
    format: 'text',
    description: 'Main brand name displayed in page titles, header branding, and platform metadata.',
    placeholder: 'e.g., Dream House'
  },
  { 
    id: 'websiteLogo', 
    label: 'Website Logo', 
    type: 'image', 
    category: 'Branding', 
    format: 'image',
    description: 'Navbar header logo displayed across the top navigation bar on all pages.'
  },
  { 
    id: 'footerLogo', 
    label: 'Footer Logo', 
    type: 'image', 
    category: 'Branding', 
    format: 'image',
    description: 'Official brand emblem shown at the bottom section of the footer.'
  },
  { 
    id: 'heroBackground', 
    label: 'Hero Canvas Background Image', 
    type: 'image', 
    category: 'Hero', 
    format: 'image',
    description: 'High-resolution backdrop image for the primary homepage hero section.'
  },
  { 
    id: 'heroHeading', 
    label: 'Hero Title Heading', 
    type: 'text', 
    category: 'Hero', 
    format: 'text',
    description: 'Main headline text displayed prominently on the homepage hero banner.',
    placeholder: 'e.g., Design & Build Your Ultimate Dream House'
  },
  { 
    id: 'heroDescription', 
    label: 'Hero Subtitle Description', 
    type: 'textarea', 
    category: 'Hero', 
    format: 'text',
    description: 'Secondary introductory tagline explaining the platform value proposition.',
    placeholder: 'e.g., Connect with certified structural engineers, top architects, and suppliers...'
  },
  { 
    id: 'contactEmail', 
    label: 'Contact Email', 
    type: 'text', 
    category: 'Contact & Legal', 
    format: 'text',
    description: 'Official public support email address displayed in contact sections.',
    placeholder: 'e.g., support@dreamhouse.com'
  },
  { 
    id: 'contactPhone', 
    label: 'Contact Phone', 
    type: 'text', 
    category: 'Contact & Legal', 
    format: 'text',
    description: 'Official customer care phone line shown on support cards.',
    placeholder: 'e.g., +1 (555) 019-2834'
  },
];

export default function PlatformConfigEditor({ 
  platformConfig, 
  updatePlatformConfigAndSync, 
  showToast 
}: PlatformConfigEditorProps) {
  const [localConfig, setLocalConfig] = useState<Record<string, any>>(() => ({ ...platformConfig }));
  const [initialServerConfig, setInitialServerConfig] = useState<Record<string, any>>(() => ({ ...platformConfig }));
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [formatFilter, setFormatFilter] = useState('All');
  const [sortOption, setSortOption] = useState('Category');

  // Real-time Firestore sync
  useEffect(() => {
    setIsLoading(true);
    const unsub = onSnapshot(doc(db, 'website_config', 'main'), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setInitialServerConfig(data);
        // Only update local state if user hasn't modified locally yet
        setLocalConfig(prev => {
          // If equal to current initial server config, update to new remote snapshot
          if (JSON.stringify(prev) === JSON.stringify(initialServerConfig)) {
            return data;
          }
          return prev;
        });
      }
      setIsLoading(false);
    }, (err) => {
      console.error('Error listening to website_config:', err);
      setIsLoading(false);
    });

    return () => unsub();
  }, []);

  // Compute if localConfig differs from server state
  const hasUnsavedChanges = useMemo(() => {
    return JSON.stringify(localConfig) !== JSON.stringify(initialServerConfig);
  }, [localConfig, initialServerConfig]);

  // Prevent accidental navigation when there are unsaved changes
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  // Handle Save
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isSaving) return;

    setIsSaving(true);
    try {
      // Map legacy/synced fields for complete cross-component compatibility
      const fullyMappedConfig = {
        ...localConfig,
        siteName: localConfig.websiteName || 'Dream House',
        logoUrl: localConfig.websiteLogo || '',
        footerLogo: localConfig.footerLogo || '',
        heroBannerUrl: localConfig.heroBackground || '',
        heroTitle: localConfig.heroHeading || '',
        heroSubtitle: localConfig.heroDescription || '',
        contactEmail: localConfig.contactEmail || '',
        contactPhone: localConfig.contactPhone || ''
      };

      // Save to Firebase Firestore
      await setDoc(doc(db, 'website_config', 'main'), fullyMappedConfig, { merge: true });

      // Update parent component state and sync globally
      updatePlatformConfigAndSync(fullyMappedConfig);

      setInitialServerConfig(fullyMappedConfig);
      showToast('Homepage content published and updated globally across all devices!', 'success');
    } catch (err: any) {
      console.error('Failed to save homepage content to Firestore:', err);
      showToast('Failed to save changes: ' + (err?.message || 'Database connection error'), 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Handle Reset / Discard
  const handleReset = () => {
    setLocalConfig({ ...initialServerConfig });
    showToast('Unsaved changes discarded.', 'success');
  };

  // Filter & Sort definitions
  const filteredAssets = useMemo(() => {
    let result = ASSET_DEFINITIONS.filter(def => {
      const matchSearch = 
        def.label.toLowerCase().includes(searchTerm.toLowerCase()) || 
        def.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        def.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCat = categoryFilter === 'All' || def.category === categoryFilter;
      const matchFormat = formatFilter === 'All' || def.format === formatFilter;
      return matchSearch && matchCat && matchFormat;
    });

    if (sortOption === 'Alphabetical') {
      result.sort((a, b) => a.label.localeCompare(b.label));
    } else if (sortOption === 'Category') {
      result.sort((a, b) => a.category.localeCompare(b.category));
    }

    return result;
  }, [searchTerm, categoryFilter, formatFilter, sortOption]);

  const categories = ['All', 'Branding', 'Hero', 'Contact & Legal'];

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-slate-200/80 shadow-sm">
        <Loader2 className="w-10 h-10 animate-spin text-[#fd8b00] mb-4" />
        <h3 className="text-base font-bold text-slate-800">Loading Homepage CMS Content...</h3>
        <p className="text-xs text-slate-500 mt-1">Connecting to Firestore real-time database</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* Sticky Top Header Bar */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border border-slate-200/90 p-4 rounded-2xl shadow-sm flex flex-wrap items-center justify-between gap-4 transition-all">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-[#041627] tracking-tight">Homepage Content Management</h2>
            <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Sparkles className="w-3 h-3" /> Live CMS Engine
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Single source of truth for global branding, hero graphics, and contact details.
          </p>
        </div>

        <div className="flex items-center gap-3 ml-auto">
          {hasUnsavedChanges ? (
            <div className="flex items-center gap-2">
              <span className="hidden md:inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
                <AlertTriangle className="w-4 h-4 text-amber-600 animate-pulse" /> Unsaved changes
              </span>
              <button 
                type="button" 
                onClick={handleReset}
                disabled={isSaving}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Discard
              </button>
            </div>
          ) : (
            <span className="hidden md:inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Synced with Firestore
            </span>
          )}

          <button 
            type="submit" 
            disabled={isSaving || !hasUnsavedChanges}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer
              ${hasUnsavedChanges 
                ? 'bg-[#fd8b00] hover:bg-[#e07b00] text-white shadow-[#fd8b00]/20 hover:scale-[1.02]' 
                : 'bg-slate-100 text-slate-400 border border-slate-200 opacity-80 cursor-not-allowed shadow-none'}
            `}
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" /> Save Changes
              </>
            )}
          </button>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl p-4 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs font-medium">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search assets..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm transition-all"
            />
          </div>
          
          {/* Category Filter */}
          <div className="relative">
             <Filter className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
             <select 
               value={categoryFilter}
               onChange={e => setCategoryFilter(e.target.value)}
               className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm appearance-none cursor-pointer text-slate-700 transition-all"
             >
               {categories.map(c => <option key={c} value={c}>{c === 'All' ? 'All Categories' : c}</option>)}
             </select>
          </div>

          {/* Format Filter */}
          <div className="relative">
             <ImageIcon className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
             <select 
               value={formatFilter}
               onChange={e => setFormatFilter(e.target.value)}
               className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm appearance-none cursor-pointer text-slate-700 transition-all"
             >
               <option value="All">All Formats (Image/Text)</option>
               <option value="image">Images Only</option>
               <option value="text">Text Only</option>
             </select>
          </div>

          {/* Sort Option */}
          <div className="relative">
             <Sliders className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
             <select 
               value={sortOption}
               onChange={e => setSortOption(e.target.value)}
               className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm appearance-none cursor-pointer text-slate-700 transition-all"
             >
               <option value="Category">Sort by Category</option>
               <option value="Alphabetical">Sort Alphabetically</option>
             </select>
          </div>
        </div>
      </div>

      {/* Uniform Responsive Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-fr">
        {filteredAssets.map(def => {
          const isModified = JSON.stringify(localConfig[def.id]) !== JSON.stringify(initialServerConfig[def.id]);
          
          return (
            <div 
              key={def.id} 
              className={`bg-white border rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between h-full relative group
                ${isModified ? 'border-[#fd8b00]/50 ring-1 ring-[#fd8b00]/20' : 'border-slate-200/80 hover:border-slate-300'}
              `}
            >
              <div>
                {/* Header of Card */}
                <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    {def.format === 'image' ? (
                      <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                        <ImageIcon className="w-4 h-4" />
                      </div>
                    ) : (
                      <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
                        <Type className="w-4 h-4" />
                      </div>
                    )}
                    <h3 className="font-bold text-[#041627] text-xs leading-snug">{def.label}</h3>
                  </div>

                  <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full flex-shrink-0">
                    {def.category}
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 mb-4 line-clamp-2 min-h-[32px]">
                  {def.description}
                </p>
              </div>

              {/* Input Control Area */}
              <div className="flex-1 flex flex-col justify-center">
                {def.format === 'image' ? (
                  <ImageUploader 
                    label="" 
                    value={localConfig[def.id] || ''} 
                    onChange={url => setLocalConfig(prev => ({ ...prev, [def.id]: url }))}
                    onRemove={() => setLocalConfig(prev => ({ ...prev, [def.id]: '' }))}
                    disabled={isSaving}
                  />
                ) : def.type === 'textarea' ? (
                  <div className="flex-1 flex flex-col justify-center">
                    <textarea 
                      rows={4}
                      value={localConfig[def.id] || ''}
                      placeholder={def.placeholder}
                      disabled={isSaving}
                      onChange={e => setLocalConfig(prev => ({ ...prev, [def.id]: e.target.value }))}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm transition-all resize-none"
                    />
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col justify-center">
                    <input 
                      type="text"
                      value={localConfig[def.id] || ''}
                      placeholder={def.placeholder}
                      disabled={isSaving}
                      onChange={e => setLocalConfig(prev => ({ ...prev, [def.id]: e.target.value }))}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm transition-all"
                    />
                  </div>
                )}
              </div>

              {/* Card Footer Status */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-medium">
                <span>Field Key: <code className="text-slate-600 font-mono">{def.id}</code></span>
                {isModified ? (
                  <span className="text-amber-600 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" /> Modified
                  </span>
                ) : (
                  <span className="text-slate-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Saved
                  </span>
                )}
              </div>
            </div>
          );
        })}

        {filteredAssets.length === 0 && (
          <div className="col-span-full py-16 text-center text-slate-500 bg-slate-50/80 rounded-2xl border border-slate-200/80">
            <Search className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">No content items match your filters.</p>
            <p className="text-xs text-slate-400 mt-1">Try resetting search keywords or category selections.</p>
          </div>
        )}
      </div>
    </form>
  );
}
