import React, { useState, useEffect } from 'react';
import { 
  Star, ThumbsUp, Search, Filter, MessageSquare, CheckCircle, 
  ChevronDown, Award, CheckCircle2, AlertTriangle, ArrowUpDown, RefreshCw 
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, updateDoc, increment } from 'firebase/firestore';

interface Review {
  id: string;
  expertEmail: string;
  reviewerEmail: string;
  reviewerName: string;
  reviewerPhoto: string;
  rating: number;
  reviewTitle?: string;
  reviewText: string;
  reviewDate: string;
  createdAt: string;
  projectName?: string;
  helpfulCount?: number;
}

interface Contract {
  id: string;
  clientEmail: string;
  expertEmail: string;
  status: string;
  projectName: string;
  createdAt: string;
  completedAt?: string;
}

interface ExpertReviewsViewProps {
  userEmail: string;
}

export default function ExpertReviewsView({ userEmail }: ExpertReviewsViewProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [ratingFilter, setRatingFilter] = useState<string>('All'); // 'All', '5', '4', '3', '2', '1', 'Comments'
  const [sortBy, setSortBy] = useState<'newest' | 'highest' | 'lowest' | 'oldest'>('newest');
  const [helpfulLiked, setHelpfulLiked] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(`dreamhouse_helpful_${userEmail}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Load reviews and contracts in real-time
  useEffect(() => {
    if (!userEmail) return;

    setLoading(true);
    const cleanEmail = userEmail.trim().toLowerCase();

    // 1. Listen to reviews for this expert
    const reviewsRef = collection(db, 'expert_reviews');
    const qReviews = query(reviewsRef, where('expertEmail', '==', cleanEmail));
    
    const unsubReviews = onSnapshot(qReviews, (snapshot) => {
      const list: Review[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Review);
      });
      setReviews(list);
      setLoading(false);
    }, (error) => {
      console.error("Error loading reviews in expert view:", error);
      setLoading(false);
    });

    // 2. Listen to completed contracts for completed projects count
    const contractsRef = collection(db, 'expert_contracts');
    const qContracts = query(contractsRef, where('expertEmail', '==', cleanEmail));

    const unsubContracts = onSnapshot(qContracts, (snapshot) => {
      const list: Contract[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Contract);
      });
      setContracts(list);
    }, (error) => {
      console.error("Error loading contracts in expert view:", error);
    });

    return () => {
      unsubReviews();
      unsubContracts();
    };
  }, [userEmail]);

  // Handle helpful vote
  const handleHelpfulClick = async (reviewId: string) => {
    if (helpfulLiked[reviewId]) return; // Already liked this session/device
    try {
      const reviewDocRef = doc(db, 'expert_reviews', reviewId);
      await updateDoc(reviewDocRef, {
        helpfulCount: increment(1)
      });
      const updated = { ...helpfulLiked, [reviewId]: true };
      setHelpfulLiked(updated);
      localStorage.setItem(`dreamhouse_helpful_${userEmail}`, JSON.stringify(updated));
    } catch (e) {
      console.error("Failed to update helpful count:", e);
    }
  };

  // Calculations for stats
  const totalReviews = reviews.length;
  const completedProjectsCount = contracts.filter(c => c.status === 'Completed').length;

  const averageRating = totalReviews > 0
    ? Number((reviews.reduce((acc, curr) => acc + curr.rating, 0) / totalReviews).toFixed(1))
    : 5.0;

  // Recommendation %: Ratings 4 or 5
  const recommendedReviews = reviews.filter(r => r.rating >= 4).length;
  const recommendationPercentage = totalReviews > 0
    ? Math.round((recommendedReviews / totalReviews) * 100)
    : 100;

  // Star distributions
  const starCounts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  reviews.forEach(r => {
    const star = Math.min(5, Math.max(1, Math.round(r.rating))) as 5|4|3|2|1;
    starCounts[star]++;
  });

  // Filter and Search Reviews
  const filteredReviews = reviews.filter(rev => {
    // 1. Search Query
    const matchesSearch = 
      rev.reviewerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (rev.projectName && rev.projectName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      rev.reviewText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (rev.reviewTitle && rev.reviewTitle.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    // 2. Rating Filter
    if (ratingFilter === 'All') return true;
    if (ratingFilter === 'Comments') return rev.reviewText.trim().length > 0;
    
    return rev.rating.toString() === ratingFilter;
  });

  // Sort Reviews
  const sortedReviews = [...filteredReviews].sort((a, b) => {
    if (sortBy === 'newest') {
      return new Date(b.createdAt || b.reviewDate).getTime() - new Date(a.createdAt || a.reviewDate).getTime();
    }
    if (sortBy === 'oldest') {
      return new Date(a.createdAt || a.reviewDate).getTime() - new Date(b.createdAt || b.reviewDate).getTime();
    }
    if (sortBy === 'highest') {
      if (b.rating !== a.rating) {
        return b.rating - a.rating;
      }
      return new Date(b.createdAt || b.reviewDate).getTime() - new Date(a.createdAt || a.reviewDate).getTime();
    }
    if (sortBy === 'lowest') {
      if (a.rating !== b.rating) {
        return a.rating - b.rating;
      }
      return new Date(b.createdAt || b.reviewDate).getTime() - new Date(a.createdAt || a.reviewDate).getTime();
    }
    return 0;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-200" id="expert-reviews-root">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#041627] dark:text-white flex items-center gap-2">
            <Star className="w-6 h-6 text-[#fd8b00] fill-[#fd8b00]" />
            Ratings & Reviews
          </h1>
          <p className="text-xs text-[#44474c] dark:text-slate-400 mt-1">
            Real-time reputation metrics and client feedback summaries.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="space-y-6">
          {/* Skeleton Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-white dark:bg-slate-900 h-28 rounded-xl border border-slate-200/50 dark:border-slate-800 animate-pulse" />
            ))}
          </div>
          <div className="bg-white dark:bg-slate-900 h-64 rounded-xl border border-slate-200/50 dark:border-slate-800 animate-pulse" />
        </div>
      ) : reviews.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 rounded-2xl p-10 text-center space-y-4 max-w-2xl mx-auto shadow-sm">
          <div className="w-16 h-16 bg-amber-50 dark:bg-amber-950/20 rounded-full flex items-center justify-center mx-auto text-[#fd8b00]">
            <MessageSquare className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">No Reviews Yet</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
            No reviews available yet. Reviews from completed projects will appear here. As soon as your clients mark contracts as complete and leave their ratings, they will be visible in real time.
          </p>
        </div>
      ) : (
        <>
          {/* Metrics Dashboard Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Overall Rating */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-5 shadow-sm space-y-2 flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Overall Rating</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-slate-800 dark:text-white">{averageRating.toFixed(1)}</span>
                <span className="text-sm text-slate-400 font-medium">/ 5.0</span>
              </div>
              <div className="flex items-center gap-1 text-amber-400">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < Math.round(averageRating) ? 'fill-current' : 'text-slate-200 dark:text-slate-800'}`} 
                  />
                ))}
              </div>
            </div>

            {/* Total Reviews */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-5 shadow-sm space-y-1 flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Total Reviews</span>
              <div className="text-3xl font-extrabold text-slate-800 dark:text-white py-1">{totalReviews}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-medium">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>100% verified responses</span>
              </div>
            </div>

            {/* Total Completed Projects */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-5 shadow-sm space-y-1 flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Completed Projects</span>
              <div className="text-3xl font-extrabold text-slate-800 dark:text-white py-1">{completedProjectsCount}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-medium">
                <Award className="w-4 h-4 text-[#fd8b00] shrink-0" />
                <span>Active project history list</span>
              </div>
            </div>

            {/* Recommendation Percentage */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-5 shadow-sm space-y-1 flex flex-col justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Recommendation %</span>
              <div className="text-3xl font-extrabold text-slate-800 dark:text-white py-1">{recommendationPercentage}%</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Recommend 4★ or 5★ stars
              </div>
            </div>
          </div>

          {/* Rating Distribution Progress Bars & Detailed Chart */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-6 shadow-sm">
            <h3 className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-4">Rating Star Distribution</h3>
            <div className="space-y-3 max-w-xl">
              {[5, 4, 3, 2, 1].map((starNum) => {
                const count = starCounts[starNum as 5|4|3|2|1] || 0;
                const percent = totalReviews > 0 ? Math.round((count / totalReviews) * 100) : 0;
                return (
                  <div key={starNum} className="flex items-center gap-4 text-xs font-semibold">
                    <span className="w-8 text-slate-500 dark:text-slate-400 text-right">{starNum} ★</span>
                    <div className="flex-1 h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-[#fd8b00] transition-all duration-500 rounded-full"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                    <span className="w-12 text-slate-400 text-right font-medium">{count} ({percent}%)</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Search, Filter, & Sort Controls */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200/60 dark:border-slate-800 p-4 shadow-sm flex flex-col md:flex-row gap-4 items-center">
            {/* Search Input */}
            <div className="relative w-full md:flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search reviews by client name, project name, or comment text..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950/30 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-[#fd8b00] focus:border-[#fd8b00] text-slate-800 dark:text-slate-200"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-2 w-full md:w-auto items-center">
              <span className="text-slate-400 text-xs font-bold uppercase tracking-wider hidden sm:inline flex-shrink-0">Filters:</span>
              <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
                {['All', '5', '4', '3', '2', '1', 'Comments'].map((f) => (
                  <button
                    key={f}
                    onClick={() => setRatingFilter(f)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer whitespace-nowrap ${
                      ratingFilter === f 
                        ? 'bg-[#fd8b00] border-[#fd8b00] text-white shadow-xs' 
                        : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-750 dark:text-slate-300 dark:hover:bg-slate-700'
                    }`}
                  >
                    {f === 'All' ? 'All Reviews' : f === 'Comments' ? 'With Comments' : `${f} ★`}
                  </button>
                ))}
              </div>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2 w-full md:w-auto shrink-0 border-t md:border-t-0 pt-3 md:pt-0">
              <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded-lg text-xs px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#fd8b00] focus:border-[#fd8b00] text-slate-700 dark:bg-slate-800 dark:border-slate-750 dark:text-slate-200 cursor-pointer"
              >
                <option value="newest">Newest First</option>
                <option value="highest">Highest Rating</option>
                <option value="lowest">Lowest Rating</option>
                <option value="oldest">Oldest First</option>
              </select>
            </div>
          </div>

          {/* Reviews List */}
          <div className="space-y-4">
            {sortedReviews.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/80 rounded-2xl p-12 text-center text-slate-400 dark:text-slate-500 font-medium">
                No reviews found matching your search and filter criteria.
              </div>
            ) : (
              sortedReviews.map((rev) => (
                <div 
                  key={rev.id} 
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-5 md:p-6 shadow-xs hover:border-[#fd8b00]/30 transition-all space-y-4"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 dark:border-slate-800/50 pb-3">
                    <div className="flex items-center gap-3">
                      <img 
                        src={rev.reviewerPhoto || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                        alt={rev.reviewerName}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-800"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">{rev.reviewerName}</h4>
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-900/30">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500 fill-current shrink-0 mr-1" />
                            Verified Client
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                          Project: <span className="text-[#fd8b00] font-bold">{rev.projectName || 'Modern Villa Remodeling'}</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2">
                      <div className="flex items-center gap-0.5 text-amber-400">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-3.5 h-3.5 ${i < rev.rating ? 'fill-current' : 'text-slate-250 dark:text-slate-800'}`} 
                          />
                        ))}
                      </div>
                      <span className="text-[10px] text-slate-400 font-medium">{rev.reviewDate}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {rev.reviewTitle && (
                      <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {rev.reviewTitle}
                      </h5>
                    )}
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50/50 dark:bg-slate-950/10 p-3 rounded-xl border border-slate-100/50 dark:border-slate-800/40 italic">
                      "{rev.reviewText}"
                    </p>
                  </div>

                  <div className="flex justify-between items-center pt-2 text-xs">
                    <button
                      onClick={() => handleHelpfulClick(rev.id)}
                      disabled={helpfulLiked[rev.id]}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                        helpfulLiked[rev.id]
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-100/50 cursor-default'
                          : 'bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-500 hover:text-slate-700 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-700'
                      }`}
                    >
                      <ThumbsUp className={`w-3.5 h-3.5 ${helpfulLiked[rev.id] ? 'fill-current text-emerald-500' : ''}`} />
                      <span>{helpfulLiked[rev.id] ? 'Marked Helpful!' : 'Helpful?'}</span>
                      {rev.helpfulCount !== undefined && rev.helpfulCount > 0 && (
                        <span className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-full px-1.5 py-0.5 text-[9px]">
                          {rev.helpfulCount + (helpfulLiked[rev.id] && !reviews.find(r => r.id === rev.id)?.helpfulCount ? 1 : 0)}
                        </span>
                      )}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
