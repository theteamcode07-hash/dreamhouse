import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, ShoppingCart, Trash2, Search, CheckCircle, CheckCircle2,
  HelpCircle, ChevronRight, X, Minus, Plus, MessageSquare, Star, Store,
  MapPin, Truck, ShieldCheck, CreditCard, DollarSign, Building2, Check,
  ArrowRight, Sparkles, AlertCircle, ShoppingBag
} from 'lucide-react';
import { CartItem, Product, SellerInfo } from '../types';
import SellerProfileModal from './SellerProfileModal';
import SellerChatModal from './SellerChatModal';
import { CategoryScrollNav } from './CategoryScrollNav';
import MaterialProductCard from './MaterialProductCard';
import ProductDetailModal from './ProductDetailModal';

interface MaterialShopProps {
  products: Product[];
  cartItems: CartItem[];
  onAddToCart: (product: Product) => void;
  onRemoveFromCart: (id: string) => void;
  onUpdateQty: (id: string, qty: number) => void;
  onClearCart?: () => void;
  onCheckout: () => void;
  onBackToDashboard: () => void;
  onNavigateToCart?: () => void;
}

export default function MaterialShop({
  products,
  cartItems,
  onAddToCart,
  onRemoveFromCart,
  onUpdateQty,
  onClearCart,
  onCheckout,
  onBackToDashboard,
  onNavigateToCart
}: MaterialShopProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Cart & Checkout UI States
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [orderSuccessModal, setOrderSuccessModal] = useState<boolean>(false);
  const [placedOrderId, setPlacedOrderId] = useState<string>('');
  const [selectedProductDetails, setSelectedProductDetails] = useState<Product | null>(null);
  const [isProductDetailsOpen, setIsProductDetailsOpen] = useState<boolean>(false);

  // Toast notification state when an item is added to cart
  const [addedToast, setAddedToast] = useState<{ name: string; image: string } | null>(null);

  // Checkout Form States
  const [shippingName, setShippingName] = useState('Demo Homeowner');
  const [shippingPhone, setShippingPhone] = useState('(512) 555-0192');
  const [shippingAddress, setShippingAddress] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('Leave near front staging area. Heavy truck access via side alley.');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cod' | 'wire'>('card');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4242');

  // Seller Profile & Direct Chat Modal States
  const [selectedSeller, setSelectedSeller] = useState<SellerInfo | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [chatSeller, setChatSeller] = useState<SellerInfo | null>(null);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);

  // Auto dismiss toast notification
  useEffect(() => {
    if (addedToast) {
      const timer = setTimeout(() => setAddedToast(null), 3500);
      return () => clearTimeout(timer);
    }
  }, [addedToast]);

  // Helper to resolve seller details for any product
  const getSellerForProduct = (prod: Product): SellerInfo => {
    if (prod.seller) return prod.seller;
    return {
      id: 'seller-1',
      name: 'Demo Shopkeeper',
      shopName: 'ProBuild Materials Inc.',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      isVerified: true,
      rating: 4.9,
      reviewsCount: 142,
      email: 'shopkeeper@gmail.com',
      phone: '9876543212',
      location: '102 Industrial Parkway, Building B, Austin, TX',
      bio: 'Premier supplier of contractor-grade construction materials, red clay bricks, certified rebar, and Portland cement. Serving builders for over 12 years.',
      yearsOfExperience: 12
    };
  };

  const handleOpenSellerProfile = (seller: SellerInfo) => {
    setSelectedSeller(seller);
    setIsProfileModalOpen(true);
  };

  const handleOpenChat = (seller: SellerInfo) => {
    setChatSeller(seller);
    setIsChatModalOpen(true);
  };

  const isProductInCategory = (pCategory: string, filterCategory: string) => {
    if (filterCategory === 'All') return true;
    const cat1 = pCategory.toLowerCase().trim();
    const cat2 = filterCategory.toLowerCase().trim();
    if (cat1 === cat2) return true;
    if (cat2 === 'bricks' && cat1 === 'brick') return true;
    if (cat2 === 'iron & steel' && (cat1 === 'iron rod' || cat1 === 'metal')) return true;
    return false;
  };

  const categories = [
    'All',
    'Bricks',
    'Iron & Steel',
    'Furniture',
    'House Decoration',
    'Cement',
    'Paint',
    'Electrical',
    'Plumbing',
    'Tiles & Flooring',
    'Doors & Windows',
    'Roofing Materials',
    'Tools & Equipment',
    'Other'
  ];

  // Helper to highlight matching text in search results
  const highlightText = (text: string, search: string) => {
    if (!search.trim()) return <>{text}</>;
    try {
      const regex = new RegExp(`(${search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi');
      const parts = text.split(regex);
      return (
        <>
          {parts.map((part, i) => 
            regex.test(part) ? (
              <mark key={i} className="bg-amber-100 text-[#041627] rounded-sm font-semibold px-0.5">
                {part}
              </mark>
            ) : (
              part
            )
          )}
        </>
      );
    } catch (e) {
      return <>{text}</>;
    }
  };

  // Filtered products list (exclude draft products in customer shop)
  const filteredProducts = products.filter((p) => {
    if (p.isDraft) return false;
    const matchesCategory = isProductInCategory(p.category, selectedCategory);
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.brand && p.brand.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // Global search matches count
  const globalMatchesCount = products.filter((p) => {
    if (p.isDraft) return false;
    return isProductInCategory(p.category, selectedCategory) && (
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.brand && p.brand.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }).length;

  // Cart Calculations
  const totalItemCount = cartItems.length;
  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.qty), 0);
  
  // Freight delivery charge calculation: free if cart is empty, or $25 flat rate (or free if all items have freeDelivery)
  const hasFreeFreight = cartItems.length > 0 && cartItems.every(i => i.freeDelivery);
  const deliveryCharge = (subtotal === 0 || hasFreeFreight) ? 0 : 25.00;
  const estimatedTax = subtotal * 0.05; // 5% tax
  const grandTotal = subtotal + deliveryCharge + estimatedTax;

  const handleAddToCartWithNotification = (prod: Product) => {
    onAddToCart(prod);
    setAddedToast({ name: prod.name, image: prod.image });
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handlePlaceOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedId = `#ORD-${Math.floor(Math.random() * 899) + 100}`;
    setPlacedOrderId(generatedId);
    
    // Dispatch system order event
    onCheckout();
    setIsCheckoutOpen(false);
    setOrderSuccessModal(true);
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] flex flex-col h-screen font-sans overflow-hidden relative">
      
      {/* Top Header Navigation */}
      <header className="bg-[#1a2b3c] text-white flex justify-between items-center px-4 md:px-8 h-20 shadow-md shrink-0 z-20">
        <div className="flex items-center gap-3 md:gap-4">
          <button 
            onClick={onBackToDashboard}
            className="p-2 hover:bg-[#041627] rounded-lg transition-colors text-white cursor-pointer"
            title="Return to Dashboard"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base md:text-xl font-bold tracking-tight">Materials Marketplace</h1>
            <p className="text-[11px] md:text-xs text-[#8192a7] font-medium hidden sm:block">
              Contractor-Grade Building Supplies • Direct Vendor Logistics
            </p>
          </div>
        </div>

        {/* Top-Right Project Cart Button */}
        <button
          onClick={() => {
            if (onNavigateToCart) {
              onNavigateToCart();
            } else {
              setIsCartOpen(true);
            }
          }}
          className="flex items-center gap-2.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white px-3.5 py-2 md:px-5 md:py-2.5 rounded-xl font-bold text-xs md:text-sm shadow-md transition-all cursor-pointer active:scale-95 group relative"
          title="Open Shopping Cart"
        >
          <div className="relative">
            <ShoppingCart className="w-4 h-4 md:w-5 md:h-5 transition-transform group-hover:scale-110" />
            {totalItemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-white text-[#041627] text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center border border-[#fd8b00]">
                {totalItemCount}
              </span>
            )}
          </div>
          <span className="hidden xs:inline">Project Cart</span>
          <span className="bg-black/20 px-2 py-0.5 rounded-full text-[11px] font-extrabold">
            {totalItemCount} {totalItemCount === 1 ? 'Item' : 'Items'}
          </span>
        </button>
      </header>

      {/* Added to Cart Floating Toast Alert */}
      {addedToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#041627] text-white p-4 rounded-2xl shadow-2xl border border-amber-500/30 flex items-center gap-3.5 max-w-sm animate-slide-up">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-emerald-400">Item added to cart successfully!</p>
            <p className="text-xs text-slate-200 truncate font-medium mt-0.5">{addedToast.name}</p>
          </div>
          <button
            onClick={() => {
              setAddedToast(null);
              if (onNavigateToCart) {
                onNavigateToCart();
              } else {
                setIsCartOpen(true);
              }
            }}
            className="bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold px-3 py-1.5 rounded-lg shrink-0 transition-colors cursor-pointer shadow-sm"
          >
            View Cart
          </button>
        </div>
      )}

      {/* Full Available Width Marketplace View */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          
          {/* Filter & Search Bar Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-4 md:p-5 rounded-2xl border border-[#c4c6cd]/40 shadow-sm">
            
            {/* Category Tabs */}
            <div className="flex-1 min-w-0 w-full md:max-w-2xl lg:max-w-3xl">
              <CategoryScrollNav
                categories={categories}
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
                activeColorClass="bg-[#1a2b3c] text-white shadow-sm"
                inactiveColorClass="bg-[#f0f4fa] text-[#44474c] hover:bg-[#e2eaf5] hover:text-[#041627] dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              />
            </div>

            {/* Search Input */}
            <div className="relative w-full md:w-80 flex flex-col gap-1">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#44474c]" />
                <input
                  type="text"
                  placeholder="Search products or categories..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#f8f9ff] text-xs rounded-xl border border-[#c4c6cd] pl-10 pr-9 py-2.5 outline-none focus:border-[#fd8b00] focus:ring-1 focus:ring-[#fd8b00] transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-200/50 transition-colors"
                    title="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              {searchQuery && (
                <span className="text-[10px] text-[#44474c] px-1 font-medium">
                  Found {filteredProducts.length} match{filteredProducts.length === 1 ? '' : 'es'}
                </span>
              )}
            </div>
          </div>

          {/* Full-Width Redesigned Product Grid */}
          <div className="grid grid-cols-1 min-[370px]:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4">
            {filteredProducts.map((prod) => (
              <MaterialProductCard
                key={prod.id}
                product={prod}
                searchQuery={searchQuery}
                onAddToCart={handleAddToCartWithNotification}
                onOpenSellerProfile={handleOpenSellerProfile}
                onOpenProductDetails={(fullProd) => {
                  setSelectedProductDetails(fullProd);
                  setIsProductDetailsOpen(true);
                }}
                getSellerForProduct={getSellerForProduct}
                highlightText={highlightText}
              />
            ))}
          </div>

          {/* Empty Search State */}
          {filteredProducts.length === 0 && (
            <div className="text-center py-16 bg-white rounded-2xl border border-[#c4c6cd]/30 p-8 flex flex-col items-center justify-center space-y-4">
              <Search className="w-12 h-12 text-slate-300 animate-pulse" />
              <div>
                <p className="text-base font-bold text-[#041627]">No products found matching "{searchQuery}"</p>
                {selectedCategory !== 'All' && globalMatchesCount > 0 ? (
                  <p className="text-xs text-[#44474c] mt-1">
                    Found <strong className="text-[#fd8b00] font-bold">{globalMatchesCount}</strong> matching items in other categories.
                  </p>
                ) : (
                  <p className="text-xs text-[#44474c] mt-1">
                    Try checking your spelling or clear your current filter selection.
                  </p>
                )}
              </div>

              <div className="flex gap-3">
                {selectedCategory !== 'All' && globalMatchesCount > 0 && (
                  <button 
                    onClick={() => setSelectedCategory('All')}
                    className="px-4 py-2 bg-[#1a2b3c] text-white hover:bg-[#041627] text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                  >
                    View All Categories ({globalMatchesCount})
                  </button>
                )}
                <button 
                  onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  Reset Search
                </button>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* =========================================
          4. DEDICATED SHOPPING CART SLIDE-OUT DRAWER 
         ========================================= */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-[#041627]/60 backdrop-blur-sm flex justify-end animate-fade-in">
          {/* Backdrop Click to Close */}
          <div className="flex-1" onClick={() => setIsCartOpen(false)} />

          <div 
            className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-50 animate-slide-left border-l border-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer Header */}
            <div className="p-5 bg-[#1a2b3c] text-white flex justify-between items-center shadow-md shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#fd8b00] rounded-xl text-white">
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white leading-tight">Project Shopping Cart</h2>
                  <p className="text-[11px] text-[#8192a7]">Review items & jobsite delivery</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs bg-white/10 text-amber-400 border border-amber-400/30 px-2.5 py-1 rounded-lg font-extrabold">
                  {totalItemCount} {totalItemCount === 1 ? 'Item' : 'Items'}
                </span>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Close Cart"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3 bg-[#f8f9ff]">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4 my-auto">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-md border border-slate-200 text-[#fd8b00]">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-[#041627]">Your project cart is empty</h3>
                    <p className="text-xs text-slate-500 max-w-xs mt-1 leading-relaxed">
                      Explore contractor-grade materials and add heavy supplies to build your project order.
                    </p>
                  </div>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="px-5 py-2.5 bg-[#1a2b3c] hover:bg-[#041627] text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer"
                  >
                    Explore Materials
                  </button>
                </div>
              ) : (
                cartItems.map((item) => {
                  const seller = item.seller || { name: 'Demo Shopkeeper', shopName: 'ProBuild Materials Inc.', avatar: '', email: '' };
                  return (
                    <div 
                      key={item.id} 
                      className="p-3.5 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex gap-3.5 items-center group hover:border-[#fd8b00]/50 transition-all"
                    >
                      <img 
                        className="w-16 h-16 rounded-xl object-contain bg-slate-50 p-1.5 border border-slate-100 shrink-0" 
                        alt={item.name} 
                        src={item.image}
                      />
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-[#041627] truncate leading-tight">{item.name}</h4>
                        
                        {/* Seller Name Tag */}
                        <div className="flex items-center gap-1 mt-0.5 text-[10px] text-slate-500 font-medium">
                          <Store className="w-3 h-3 text-[#fd8b00]" />
                          <span className="truncate">{seller.shopName || seller.name || 'ProBuild Store'}</span>
                        </div>

                        <p className="text-[11px] font-bold text-[#041627] mt-1">
                          Rs. {item.price.toFixed(2)} <span className="text-[10px] text-slate-400 font-normal">/ {item.unit || 'piece'}</span>
                        </p>

                        {/* Quantity Selector */}
                        <div className="flex items-center gap-2 mt-2">
                          <button 
                            onClick={() => onUpdateQty(item.id, item.qty - 1)}
                            className="w-6 h-6 bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-[#041627] rounded-md flex items-center justify-center font-bold transition-colors cursor-pointer"
                            title="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          
                          <span className="text-xs font-mono font-bold text-[#041627] w-6 text-center">
                            {item.qty}
                          </span>

                          <button 
                            onClick={() => onUpdateQty(item.id, item.qty + 1)}
                            className="w-6 h-6 bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-[#041627] rounded-md flex items-center justify-center font-bold transition-colors cursor-pointer"
                            title="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Right Subtotal & Remove */}
                      <div className="text-right flex flex-col justify-between items-end h-full py-0.5 shrink-0">
                        <span className="text-xs font-black text-[#041627]">
                          Rs. {(item.price * item.qty).toFixed(2)}
                        </span>

                        <button 
                          onClick={() => onRemoveFromCart(item.id)}
                          className="text-slate-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 transition-colors mt-3 cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Drawer Footer & Totals */}
            {cartItems.length > 0 && (
              <div className="p-5 bg-white border-t border-slate-200 space-y-4 shrink-0 shadow-lg">
                
                {/* Clear Cart Option */}
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-medium">Order Calculations</span>
                  {onClearCart && (
                    <button
                      onClick={onClearCart}
                      className="text-xs text-red-500 hover:text-red-700 font-semibold cursor-pointer flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Clear Cart
                    </button>
                  )}
                </div>

                {/* Price Breakdown */}
                <div className="space-y-2 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                  <div className="flex justify-between text-slate-600">
                    <span>Items Subtotal</span>
                    <span className="font-mono font-bold text-slate-800">Rs. {subtotal.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span className="flex items-center gap-1">
                      Jobsite Freight Fee
                      {deliveryCharge === 0 && <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">FREE</span>}
                    </span>
                    <span className="font-mono font-bold text-slate-800">Rs. {deliveryCharge.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span>Est. Tax (5%)</span>
                    <span className="font-mono text-slate-800">Rs. {estimatedTax.toFixed(2)}</span>
                  </div>

                  <div className="border-t border-slate-200 pt-2 flex justify-between text-sm font-bold text-[#041627]">
                    <span>Grand Total</span>
                    <span className="font-mono text-base text-[#fd8b00]">Rs. {grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                {/* Buttons */}
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer text-center"
                  >
                    Continue Shopping
                  </button>

                  <button
                    onClick={handleProceedToCheckout}
                    className="py-3 px-4 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer text-center active:scale-95 flex items-center justify-center gap-1.5"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================
          6. CHECKOUT PAGE / MODAL
         ========================================= */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 bg-[#041627]/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in">
          <div 
            className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-auto animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-[#1a2b3c] text-white p-5 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#fd8b00] rounded-xl">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Project Order Checkout</h3>
                  <p className="text-[11px] text-[#8192a7]">Verify items, jobsite dispatch & payment method</p>
                </div>
              </div>

              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Checkout Content Form */}
            <form onSubmit={handlePlaceOrderSubmit} className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto bg-[#f8f9ff]">
              
              {/* Order Items Review */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-[#041627] uppercase tracking-wider flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-[#fd8b00]" />
                  1. Items Summary ({totalItemCount} Total Items)
                </h4>

                <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto pr-1">
                  {cartItems.map((item) => (
                    <div key={item.id} className="py-2 flex items-center justify-between text-xs gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img src={item.image} alt={item.name} className="w-10 h-10 object-contain rounded bg-slate-50 p-1 border shrink-0" />
                        <div className="min-w-0">
                          <p className="font-bold text-[#041627] truncate">{item.name}</p>
                          <p className="text-[10px] text-slate-500">{item.seller?.shopName || 'ProBuild Materials'}</p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <p className="font-bold text-[#041627]">Rs. {(item.price * item.qty).toFixed(2)}</p>
                        <p className="text-[10px] text-slate-400">{item.qty} x Rs. {item.price.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Shipping & Delivery Form */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-4">
                <h4 className="text-xs font-bold text-[#041627] uppercase tracking-wider flex items-center gap-2">
                  <Truck className="w-4 h-4 text-[#fd8b00]" />
                  2. Jobsite Delivery Address
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Recipient Name</label>
                    <input
                      type="text"
                      required
                      value={shippingName}
                      onChange={(e) => setShippingName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-[#fd8b00]"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Phone Number</label>
                    <input
                      type="text"
                      required
                      value={shippingPhone}
                      onChange={(e) => setShippingPhone(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-[#fd8b00]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-slate-600 font-semibold mb-1">Jobsite Street Address</label>
                    <input
                      type="text"
                      required
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      placeholder="House No. 12, New Baneshwor"
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-[#fd8b00]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-slate-600 font-semibold mb-1">Delivery Notes & Site Access</label>
                    <input
                      type="text"
                      value={deliveryNotes}
                      onChange={(e) => setDeliveryNotes(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-[#fd8b00]"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-[#041627] uppercase tracking-wider flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-[#fd8b00]" />
                  3. Select Payment Method
                </h4>

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-3 rounded-xl border font-bold text-center transition-all cursor-pointer ${
                      paymentMethod === 'card' 
                        ? 'border-[#fd8b00] bg-amber-50/80 text-[#041627]' 
                        : 'border-slate-200 bg-slate-50 text-slate-600'
                    }`}
                  >
                    Credit Card
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cod')}
                    className={`p-3 rounded-xl border font-bold text-center transition-all cursor-pointer ${
                      paymentMethod === 'cod' 
                        ? 'border-[#fd8b00] bg-amber-50/80 text-[#041627]' 
                        : 'border-slate-200 bg-slate-50 text-slate-600'
                    }`}
                  >
                    Pay on Delivery
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('wire')}
                    className={`p-3 rounded-xl border font-bold text-center transition-all cursor-pointer ${
                      paymentMethod === 'wire' 
                        ? 'border-[#fd8b00] bg-amber-50/80 text-[#041627]' 
                        : 'border-slate-200 bg-slate-50 text-slate-600'
                    }`}
                  >
                    Bank Wire
                  </button>
                </div>

                {paymentMethod === 'card' && (
                  <div className="pt-2">
                    <label className="block text-[11px] text-slate-500 font-medium mb-1">Card Number</label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs outline-none focus:border-[#fd8b00]"
                    />
                  </div>
                )}
              </div>

              {/* Price Totals & Submit */}
              <div className="bg-[#1a2b3c] text-white p-4 rounded-xl space-y-3">
                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span className="font-mono text-white">Rs. {subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Freight Delivery:</span>
                    <span className="font-mono text-white">Rs. {deliveryCharge.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax (5%):</span>
                    <span className="font-mono text-white">Rs. {estimatedTax.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-white/10 pt-2 flex justify-between font-bold text-sm text-white">
                    <span>Total Amount:</span>
                    <span className="font-mono text-amber-400 text-base">Rs. {grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold text-xs rounded-xl shadow-lg transition-all cursor-pointer text-center active:scale-95"
                >
                  Place Order Now (Rs. {grandTotal.toFixed(2)})
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Order Placed Success Modal */}
      {orderSuccessModal && (
        <div className="fixed inset-0 z-50 bg-[#041627]/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl p-6 sm:p-8 max-w-sm w-full text-center space-y-4 animate-scale-up border border-slate-200">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-[#041627]">Order Dispatched to Vendor!</h3>
              <p className="text-xs text-emerald-700 font-bold mt-1">Order Ref: {placedOrderId}</p>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                Your material supply request has been successfully placed. Your order details have been synchronized with the Shopkeeper dispatch portal.
              </p>
            </div>

            <button
              onClick={() => setOrderSuccessModal(false)}
              className="w-full py-2.5 bg-[#1a2b3c] hover:bg-[#041627] text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer"
            >
              Back to Marketplace
            </button>
          </div>
        </div>
      )}

      {/* Seller Profile Modal */}
      <SellerProfileModal
        seller={selectedSeller}
        allProducts={products}
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        onAddToCart={handleAddToCartWithNotification}
        onOpenChat={handleOpenChat}
      />

      {/* Seller Real-Time Direct Messaging Modal */}
      <SellerChatModal
        seller={chatSeller}
        isOpen={isChatModalOpen}
        onClose={() => setIsChatModalOpen(false)}
      />

      {/* Product Master Details Modal */}
      <ProductDetailModal
        product={selectedProductDetails}
        isOpen={isProductDetailsOpen}
        onClose={() => {
          setIsProductDetailsOpen(false);
          setSelectedProductDetails(null);
        }}
        onAddToCart={handleAddToCartWithNotification}
        getSellerForProduct={getSellerForProduct}
        onOpenChat={handleOpenChat}
        onOpenSellerProfile={handleOpenSellerProfile}
      />

    </div>
  );
}
