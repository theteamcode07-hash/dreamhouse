import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, ArrowLeft, Shield, Users, FolderKanban, DollarSign, BellRing, 
  Settings, LogOut, CheckCircle2, AlertTriangle, RefreshCw, ChevronRight,
  Eye, EyeOff, Save, RotateCcw, Upload, Trash2, Globe, Lock, Server, Activity,
  Search, Filter, Check, X, Edit, UserCheck, UserX, Award, ArrowUp, ArrowDown,
  Layers, ShoppingBag, CreditCard, Star, MessageSquare, Bell, FileText, BarChart2, Mail, Send, Camera
} from 'lucide-react';
import { WebsiteConfig, AdminUser, DEFAULT_WEBSITE_CONFIG } from '../types';
import { collection, getDocs, deleteDoc, doc, setDoc, query, where, onSnapshot, addDoc, arrayUnion } from 'firebase/firestore';
import { updatePassword, updateEmail, updateProfile, reauthenticateWithCredential, EmailAuthProvider, signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { optimizeImage } from '../lib/fileUploader';
import AdminEnterprisePortal from './AdminEnterprisePortal';
import AdminUserProfileModal from './AdminUserProfileModal';
import SmtpSettingsPanel from './SmtpSettingsPanel';

const alert = (msg: string) => {
  try {
    window.alert(msg);
  } catch (e) {
    console.warn("Alert blocked in sandbox:", msg);
  }
};

const confirm = (msg: string): boolean => {
  try {
    return window.confirm(msg);
  } catch (e) {
    console.warn("Confirm blocked in sandbox:", msg);
    return true; // proceed safely
  }
};

interface AdminDashboardProps {
  users: AdminUser[];
  setUsers: React.Dispatch<React.SetStateAction<AdminUser[]>>;
  onLogout: () => void;
  websiteConfig: WebsiteConfig;
  onUpdateWebsiteConfig: (newConfig: WebsiteConfig) => void;
}

export default function AdminDashboard({ users, setUsers, onLogout, websiteConfig, onUpdateWebsiteConfig }: AdminDashboardProps) {
  const isUserAdmin = (u: AdminUser) => {
    const role = String((u as any).role || (u as any).userRole || '').toLowerCase().trim();
    const type = String(u.accountType || (u as any).type || '').toLowerCase().trim();
    const email = String(u.email || '').toLowerCase().trim();
    return (
      type === 'admin' ||
      type === 'super admin' ||
      type === 'superadmin' ||
      role === 'admin' ||
      role === 'super_admin' ||
      role === 'superadmin' ||
      email === 'theteamcode07@gmail.com'
    );
  };

  const directoryUsers = users.filter(u => 
    !isUserAdmin(u) && 
    u.status !== 'Deleted' && 
    u.accountStatus !== 'Deleted' && 
    !(u as any).isDeleted
  );

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'users' | 'pending-approvals' | 'security' | 'top-rankings' | 'platform' | 'homepage' | 'categories' | 'products' | 'orders' | 'payments' | 'reviews' | 'messages' | 'notifications' | 'email-templates' | 'reports' | 'logs'>('users');
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');
  const [logs, setLogs] = useState<any[]>([]);
  const [alertOpen, setAlertOpen] = useState(false);
  const [user, setUser] = useState(() => {
    const email = localStorage.getItem('dreamhouse_current_user_email') || 'theteamcode07@gmail.com';
    return { email, displayName: 'kishor joshi' };
  });

  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Email Templates Manager States
  const DEFAULT_EMAIL_TEMPLATES = [
    {
      id: 'welcome',
      name: 'Welcome Email Template',
      subject: 'Welcome to Dream House B2B Platform',
      tokens: ['{userName}', '{email}', '{siteName}'],
      body: 'Hello {userName},\n\nWelcome to {siteName}! We are thrilled to have you on board. Your account has been successfully registered with email: {email}.\n\nExplore certified architects, engineers, and top-grade building materials today.',
      active: true
    },
    {
      id: 'approval',
      name: 'Account Approval Notice',
      subject: 'Your Application Has Been Approved!',
      tokens: ['{userName}', '{role}', '{date}'],
      body: 'Congratulations {userName},\n\nYour professional application for role "{role}" has been approved as of {date}. You can now access your professional dashboard and connect with clients.',
      active: true
    },
    {
      id: 'rejection',
      name: 'Account Rejection Notice',
      subject: 'Status Update Regarding Your Account Application',
      tokens: ['{userName}', '{reason}'],
      body: 'Dear {userName},\n\nThank you for applying to Dream House. Unfortunately, your account application could not be approved at this time.\n\nReason: {reason}\n\nYou may update your credentials and reapply anytime.',
      active: true
    },
    {
      id: 'verification',
      name: 'Account Email Verification',
      subject: 'Verify Your Email Address',
      tokens: ['{userName}', '{verificationLink}'],
      body: 'Hello {userName},\n\nPlease verify your email address by clicking the secure link below:\n\n{verificationLink}\n\nIf you did not request this, please ignore this email.',
      active: true
    },
    {
      id: 'password_reset',
      name: 'Security Password Reset',
      subject: 'Reset Your Dream House Password',
      tokens: ['{userName}', '{resetLink}'],
      body: 'Hello {userName},\n\nA password reset was requested for your account. Click the link below to set a new password:\n\n{resetLink}\n\nThis link expires in 24 hours.',
      active: true
    },
    {
      id: 'broadcast',
      name: 'Platform Broadcast Alert',
      subject: 'Important Platform Announcement',
      tokens: ['{title}', '{message}', '{date}'],
      body: 'Announcement: {title}\n\n{message}\n\nDate: {date}\n\nThank you for being part of Dream House.',
      active: true
    }
  ];

  const [emailTemplates, setEmailTemplates] = useState<any[]>(DEFAULT_EMAIL_TEMPLATES);
  const [editingTemplate, setEditingTemplate] = useState<any | null>(null);
  const [testEmailRecipient, setTestEmailRecipient] = useState('');
  const [isSendingTest, setIsSendingTest] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'email_templates'), (snapshot) => {
      if (!snapshot.empty) {
        const loaded: any[] = [];
        snapshot.forEach(docSnap => loaded.push(docSnap.data()));
        const merged = DEFAULT_EMAIL_TEMPLATES.map(def => {
          const found = loaded.find(l => l.id === def.id);
          return found || def;
        });
        setEmailTemplates(merged);
      } else {
        DEFAULT_EMAIL_TEMPLATES.forEach(async (tpl) => {
          await setDoc(doc(db, 'email_templates', tpl.id), tpl).catch(() => {});
        });
      }
    }, (err) => {
      console.warn("Error loading email templates:", err);
    });
    return () => unsub();
  }, []);

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTemplate) return;
    try {
      await setDoc(doc(db, 'email_templates', editingTemplate.id), editingTemplate);
      showToast(`Email template "${editingTemplate.name}" saved successfully!`);
      setEditingTemplate(null);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleSendTestEmail = async () => {
    if (!editingTemplate || !testEmailRecipient.trim()) {
      showToast('Please enter a valid test recipient email address.', 'error');
      return;
    }
    setIsSendingTest(true);
    try {
      const resp = await fetch('/api/admin/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipients: [testEmailRecipient.trim()],
          subject: `[TEST] ${editingTemplate.subject}`,
          title: editingTemplate.name,
          content: editingTemplate.body,
          category: 'System Update'
        })
      });
      const result = await resp.json();
      if (result.success) {
        showToast(`Test email dispatched successfully to ${testEmailRecipient}!`);
        setTestEmailRecipient('');
      } else {
        showToast(`Failed to dispatch test email: ${result.error || 'Server error'}`, 'error');
      }
    } catch (err: any) {
      showToast(`Network error: ${err.message}`, 'error');
    } finally {
      setIsSendingTest(false);
    }
  };

  // Top Rankings Manager States
  const [topExpertIds, setTopExpertIds] = useState<string[]>([]);
  const [topSellerIds, setTopSellerIds] = useState<string[]>([]);

  const [expertSearch, setExpertSearch] = useState('');
  const [sellerSearch, setSellerSearch] = useState('');

  // Sync real-time Rankings from Firestore
  useEffect(() => {
    const unsubExperts = onSnapshot(collection(db, 'topExperts'), (snapshot) => {
      const ids: string[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        ids.push(data.contact || data.email || docSnap.id);
      });
      setTopExpertIds(ids);
    }, (err) => {
      console.warn('[AdminDashboard] error loading topExperts snapshot:', err);
    });

    const unsubSellers = onSnapshot(collection(db, 'topSellers'), (snapshot) => {
      const ids: string[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        ids.push(data.email || data.contact || docSnap.id);
      });
      setTopSellerIds(ids);
    }, (err) => {
      console.warn('[AdminDashboard] error loading topSellers snapshot:', err);
    });

    return () => {
      unsubExperts();
      unsubSellers();
    };
  }, []);

  const updateTopExperts = async (newIds: string[]) => {
    setTopExpertIds(newIds);
    localStorage.setItem('dreamhouse_top_expert_ids', JSON.stringify(newIds));
    window.dispatchEvent(new Event('dreamhouse_sync_top_list'));

    try {
      // 1. Fetch all experts from the experts collection
      const expertsSnap = await getDocs(collection(db, 'experts'));
      const expertsList: any[] = [];
      expertsSnap.forEach(d => expertsList.push({ id: d.id, ...d.data() }));

      // 2. Fetch all topExperts documents and delete them so we start fresh
      const currentTopSnap = await getDocs(collection(db, 'topExperts'));
      for (const d of currentTopSnap.docs) {
        await deleteDoc(doc(db, 'topExperts', d.id));
      }

      // 3. For each selected ID in newIds, write its full details to topExperts
      for (let i = 0; i < newIds.length; i++) {
        const id = newIds[i];
        // Find in experts collection
        let detail = expertsList.find(e => e.contact === id || e.id === id);
        if (!detail) {
          // Fallback: find in users prop
          const u = users.find(user => user.email === id || user.id === id);
          detail = {
            id: u?.id || `exp-${Date.now()}-${i}`,
            name: u?.fullName || id,
            profession: u?.professionType || 'Professional Expert',
            yearsOfExperience: u?.yearsOfExperience || 8,
            rating: 5.0,
            reviewsCount: 12,
            completedProjects: 24,
            location: 'Downtown District',
            tagline: 'Certified expert offering premium architectural and building services.',
            skills: ['Building Review', 'Code Review', 'Consultation'],
            certifications: ['Verified Platform Expert'],
            photo: u?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
            coverPhoto: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?w=1000&auto=format&fit=crop&q=80',
            contact: u?.email || id,
            phone: u?.phone || '+1 (555) 000-1122',
            availability: 'Available',
            bio: `${u?.fullName || id} is a verified professional expert.`
          };
        }
        // Write to topExperts
        await setDoc(doc(db, 'topExperts', detail.id), detail);
      }
    } catch (err) {
      console.error('[AdminDashboard] error saving top experts:', err);
    }
  };

  const updateTopSellers = async (newIds: string[]) => {
    setTopSellerIds(newIds);
    localStorage.setItem('dreamhouse_top_seller_ids', JSON.stringify(newIds));
    window.dispatchEvent(new Event('dreamhouse_sync_top_list'));

    try {
      // 1. Fetch all sellers from shopkeepers collection
      const sellersSnap = await getDocs(collection(db, 'shopkeepers'));
      const sellersList: any[] = [];
      sellersSnap.forEach(d => sellersList.push({ id: d.id, ...d.data() }));

      // 2. Fetch all topSellers documents and delete them so we start fresh
      const currentTopSnap = await getDocs(collection(db, 'topSellers'));
      for (const d of currentTopSnap.docs) {
        await deleteDoc(doc(db, 'topSellers', d.id));
      }

      // 3. For each selected ID in newIds, write its full details to topSellers
      for (let i = 0; i < newIds.length; i++) {
        const id = newIds[i];
        // Find in shopkeepers collection
        let detail = sellersList.find(s => s.email === id || s.id === id);
        if (!detail) {
          // Fallback: find in users prop
          const u = users.find(user => user.email === id || user.id === id);
          detail = {
            id: u?.id || `seller-${Date.now()}-${i}`,
            name: u?.fullName || id,
            shopName: `${u?.fullName || id}'s Supply Co.`,
            avatar: u?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            bannerUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1000&auto=format&fit=crop&q=80',
            isVerified: true,
            rating: 5.0,
            reviewsCount: 38,
            productsCount: 15,
            location: 'Austin, TX',
            description: 'Premier supplier of heavy construction materials and building supplies.',
            email: u?.email || id,
            phone: u?.phone || '+1 (555) 987-6543',
            yearsOfExperience: u?.yearsOfExperience || 10,
            categories: ['Materials', 'Tools', 'Hardware']
          };
        }
        // Write to topSellers
        await setDoc(doc(db, 'topSellers', detail.id), detail);
      }
    } catch (err) {
      console.error('[AdminDashboard] error saving top sellers:', err);
    }
  };

  // Admin Settings States
  const [adminPassword, setAdminPassword] = useState({ old: '', new: '', confirm: '' });
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showResetModalPass, setShowResetModalPass] = useState(false);

  const [adminProfile, setAdminProfile] = useState({ 
    name: 'kishor joshi', 
    email: 'theteamcode07@gmail.com', 
    phone: '+977 9800000000', 
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    role: 'admin'
  });
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [securityStatusMsg, setSecurityStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const adminPhotoInputRef = useRef<HTMLInputElement>(null);

  // Real-time synchronization for admin profile
  useEffect(() => {
    const email = localStorage.getItem('dreamhouse_current_user_email') || user.email;
    const q = query(collection(db, 'accounts'), where('email', '==', email.toLowerCase()));
    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const data = snapshot.docs[0].data();
        setAdminProfile({
          name: data.fullName || data.name || user.displayName,
          email: data.email || email,
          phone: data.phone || '+977 9800000000',
          avatar: data.avatar || data.profilePhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          role: data.role || 'admin'
        });
        if (data.email) {
          localStorage.setItem('dreamhouse_current_user_email', data.email);
        }
        if (data.fullName || data.name) {
          setUser({ email: data.email || email, displayName: data.fullName || data.name });
        }
      }
    }, (err) => {
      console.warn("Admin profile real-time sync warning:", err);
    });
    return () => unsub();
  }, []);

  const handleAdminPhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 256, 0.85);
        setAdminProfile(prev => ({ ...prev, avatar: optimized.dataUrl }));
      } catch {
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setAdminProfile(prev => ({ ...prev, avatar: event.target?.result as string }));
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleSaveProfile = async () => {
    try {
      setSecurityStatusMsg(null);
      const trimmedName = adminProfile.name.trim();
      const trimmedEmail = adminProfile.email.trim().toLowerCase();
      const trimmedPhone = adminProfile.phone?.trim() || '';

      if (!trimmedName) {
        setSecurityStatusMsg({ text: "Full Name cannot be empty.", type: 'error' });
        showToast("Full Name cannot be empty.", "error");
        return;
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmedEmail)) {
        setSecurityStatusMsg({ text: "Please enter a valid email address.", type: 'error' });
        showToast("Please enter a valid email address.", "error");
        return;
      }

      setIsSavingProfile(true);

      const currentUser = auth.currentUser;
      const prevEmail = currentUser?.email || localStorage.getItem('dreamhouse_current_user_email') || 'theteamcode07@gmail.com';
      const prevName = adminProfile.name;

      if (currentUser) {
        if (currentUser.email && currentUser.email.toLowerCase() !== trimmedEmail) {
          try {
            await updateEmail(currentUser, trimmedEmail);
          } catch (authErr: any) {
            if (authErr.code === 'auth/requires-recent-login') {
              throw new Error("Updating email requires recent login. Please re-authenticate or log in again.");
            } else if (authErr.code === 'auth/email-already-in-use') {
              throw new Error("This email address is already in use by another account.");
            } else {
              throw authErr;
            }
          }
        }
        await updateProfile(currentUser, {
          displayName: trimmedName,
          photoURL: adminProfile.avatar.startsWith('data:') ? undefined : adminProfile.avatar
        });
      }

      const updatePayload = {
        fullName: trimmedName,
        name: trimmedName,
        email: trimmedEmail,
        phone: trimmedPhone,
        avatar: adminProfile.avatar,
        profilePhoto: adminProfile.avatar,
        updatedAt: new Date().toISOString(),
        lastUpdatedBy: trimmedEmail,
        lastUpdatedTime: new Date().toISOString()
      };

      const qAcc = query(collection(db, 'accounts'), where('email', '==', prevEmail.toLowerCase()));
      const accSnap = await getDocs(qAcc);
      if (!accSnap.empty) {
        for (const accountDoc of accSnap.docs) {
          await setDoc(doc(db, 'accounts', accountDoc.id), updatePayload, { merge: true });
        }
      } else if (currentUser?.uid) {
        await setDoc(doc(db, 'accounts', currentUser.uid), {
          id: currentUser.uid,
          role: 'admin',
          accountType: 'Admin',
          status: 'Active',
          ...updatePayload,
          createdAt: new Date().toISOString()
        }, { merge: true });
      } else {
        const uid = 'demo-admin-theteamcode07';
        await setDoc(doc(db, 'accounts', uid), {
          id: uid,
          role: 'admin',
          accountType: 'Admin',
          status: 'Active',
          ...updatePayload,
          createdAt: new Date().toISOString()
        }, { merge: true });
      }

      const qUsers = query(collection(db, 'users'), where('email', '==', prevEmail.toLowerCase()));
      const usersSnap = await getDocs(qUsers);
      for (const uDoc of usersSnap.docs) {
        await setDoc(doc(db, 'users', uDoc.id), updatePayload, { merge: true });
      }
      if (usersSnap.empty && currentUser?.uid) {
        await setDoc(doc(db, 'users', currentUser.uid), {
          id: currentUser.uid,
          role: 'admin',
          status: 'Active',
          ...updatePayload,
          createdAt: new Date().toISOString()
        }, { merge: true });
      }

      try {
        await addDoc(collection(db, 'activity_logs'), {
          adminId: currentUser?.uid || 'demo-admin',
          adminEmail: trimmedEmail,
          action: 'UPDATE_ADMIN_PROFILE',
          previousName: prevName,
          newName: trimmedName,
          previousEmail: prevEmail,
          newEmail: trimmedEmail,
          timestamp: new Date().toISOString(),
          device: navigator.userAgent
        });
      } catch (logErr) {
        console.warn("Audit log error:", logErr);
      }

      localStorage.setItem('dreamhouse_current_user_email', trimmedEmail);
      setUser({ email: trimmedEmail, displayName: trimmedName });

      setSecurityStatusMsg({ text: "Profile updated successfully.", type: 'success' });
      showToast("Profile updated successfully.");
    } catch (error: any) {
      console.error("Save profile error:", error);
      let errorMsg = error.message || 'Failed to update profile.';
      if (error.code === 'permission-denied') errorMsg = 'Permission denied: insufficient privileges.';
      setSecurityStatusMsg({ text: errorMsg, type: 'error' });
      showToast(errorMsg, 'error');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleChangePassword = async () => {
    try {
      setSecurityStatusMsg(null);

      const currentEmail = localStorage.getItem('dreamhouse_current_user_email') || user?.email || adminProfile.email || 'theteamcode07@gmail.com';

      if (!adminPassword.old) {
        setSecurityStatusMsg({ text: "Please enter your current password.", type: 'error' });
        alert("Please enter your current password.");
        return;
      }

      if (!adminPassword.new) {
        setSecurityStatusMsg({ text: "Please enter a new password.", type: 'error' });
        alert("Please enter a new password.");
        return;
      }

      if (adminPassword.new.length < 6) {
        setSecurityStatusMsg({ text: "New password must be at least 6 characters.", type: 'error' });
        alert("New password must be at least 6 characters.");
        return;
      }

      if (adminPassword.new !== adminPassword.confirm) {
        setSecurityStatusMsg({ text: "New passwords do not match!", type: 'error' });
        alert("New passwords do not match!");
        return;
      }

      // 1. Authenticate / Re-authenticate directly against Firebase Auth using old password
      let currentUser = auth.currentUser;
      if (!currentUser || (currentUser.email && currentUser.email.toLowerCase() !== currentEmail.toLowerCase())) {
        try {
          const cred = await signInWithEmailAndPassword(auth, currentEmail.toLowerCase(), adminPassword.old);
          currentUser = cred.user;
        } catch (authErr: any) {
          setSecurityStatusMsg({ text: "Current password is incorrect!", type: 'error' });
          alert("Current password is incorrect!");
          return;
        }
      } else {
        try {
          const credential = EmailAuthProvider.credential(currentEmail.toLowerCase(), adminPassword.old);
          await reauthenticateWithCredential(currentUser, credential);
        } catch (reauthErr: any) {
          try {
            const cred = await signInWithEmailAndPassword(auth, currentEmail.toLowerCase(), adminPassword.old);
            currentUser = cred.user;
          } catch (signInErr: any) {
            setSecurityStatusMsg({ text: "Current password is incorrect!", type: 'error' });
            alert("Current password is incorrect!");
            return;
          }
        }
      }

      // 2. Update password directly in Firebase Auth client SDK
      if (currentUser) {
        await updatePassword(currentUser, adminPassword.new);
        await currentUser.reload();
        await currentUser.getIdToken(true);
      }

      // 3. Sync to server endpoint for Firebase Admin Auth
      try {
        await fetch('/api/auth/reset-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: currentEmail, newPassword: adminPassword.new })
        });
      } catch (srvErr) {
        console.warn("Notice updating admin password via server:", srvErr);
      }

      // 4. Update Firestore account document
      const qAcc = query(collection(db, 'accounts'), where('email', '==', currentEmail.toLowerCase()));
      const accSnap = await getDocs(qAcc);
      if (!accSnap.empty) {
        for (const accountDoc of accSnap.docs) {
          await setDoc(doc(db, 'accounts', accountDoc.id), { password: adminPassword.new, passwordLastChangedAt: new Date().toISOString() }, { merge: true });
        }
      } else {
        // Fallback: create the admin doc
        const uid = currentUser?.uid || 'demo-admin-theteamcode07';
        await setDoc(doc(db, 'accounts', uid), {
          id: uid,
          fullName: adminProfile.name || 'kishor joshi',
          email: currentEmail,
          password: adminPassword.new,
          passwordLastChangedAt: new Date().toISOString(),
          role: 'admin',
          accountType: 'Admin',
          status: 'Active',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
        }, { merge: true });
      }

      // Also check if they exist in 'users' collection
      try {
        const qUsers = query(collection(db, 'users'), where('email', '==', currentEmail.toLowerCase()));
        const usersSnap = await getDocs(qUsers);
        for (const uDoc of usersSnap.docs) {
          await setDoc(doc(db, 'users', uDoc.id), { password: adminPassword.new, passwordLastChangedAt: new Date().toISOString() }, { merge: true });
        }
      } catch (e) {
        console.warn("Could not sync password to users collection in Firestore", e);
      }

      setAdminPassword({ old: '', new: '', confirm: '' });
      setSecurityStatusMsg({ text: "Admin password changed successfully! Please use your new password for your next login.", type: 'success' });
      alert("Admin password changed successfully! Next time you login, use your new password.");
    } catch (error: any) {
      console.error("Change password error:", error);
      setSecurityStatusMsg({ text: `Failed to change password: ${error.message}`, type: 'error' });
      alert(`Failed to change password: ${error.message}`);
    }
  };

  const [isResetting, setIsResetting] = useState(false);

  const handleFactoryReset = async () => {
    try {
      setIsResetting(true);
      setSecurityStatusMsg({ text: "Wiping all non-admin accounts and platform data from database & storage...", type: 'info' });

      const adminEmailLower = (adminProfile.email || 'theteamcode07@gmail.com').toLowerCase();

      // 1. Delete all non-admin account documents from Firebase Firestore (/accounts)
      try {
        const accountsSnap = await getDocs(collection(db, 'accounts'));
        for (const accountDoc of accountsSnap.docs) {
          const data = accountDoc.data();
          const role = (data.role || '').toLowerCase();
          const email = (data.email || '').toLowerCase();

          // PRESERVE ADMIN ACCOUNT ONLY
          if (role === 'admin' || email === 'theteamcode07@gmail.com' || email === adminEmailLower) {
            console.log(`[Factory Reset] Preserving admin account in Firestore: ${email}`);
            continue;
          }

          console.log(`[Factory Reset] Deleting user document from Firestore /accounts/${accountDoc.id} (${email})`);
          await deleteDoc(doc(db, 'accounts', accountDoc.id));
        }
      } catch (fsErr) {
        console.warn("[Factory Reset] Firestore /accounts wipe notice:", fsErr);
      }

      // 2. Delete all documents from other Firebase Firestore collections (products, orders, messages, experts, etc.)
      const collectionsToWipe = ['users', 'products', 'orders', 'messages', 'experts', 'projects', 'chats', 'cms', 'cms_items', 'logs', 'admin_logs', 'floor_plans'];
      for (const colName of collectionsToWipe) {
        try {
          const snap = await getDocs(collection(db, colName));
          for (const itemDoc of snap.docs) {
            const data = itemDoc.data();
            if (colName === 'users') {
              const role = (data.role || '').toLowerCase();
              const email = (data.email || '').toLowerCase();
              if (role === 'admin' || email === 'theteamcode07@gmail.com' || email === adminEmailLower) {
                continue; // keep admin in users collection if present
              }
            }
            await deleteDoc(doc(db, colName, itemDoc.id));
          }
        } catch (colErr) {
          // collection might not exist or be empty
        }
      }

      // 3. Prepare preserved Admin Account for localStorage
      const saved = localStorage.getItem('dreamhouse_accounts');
      let localAccounts = saved ? JSON.parse(saved) : [];
      if (!Array.isArray(localAccounts)) localAccounts = [];

      const existingAdmin = localAccounts.find((acc: any) => 
        (acc.role && acc.role.toLowerCase() === 'admin') || 
        (acc.email && acc.email.toLowerCase() === adminEmailLower)
      );

      const adminAccountObj = existingAdmin || {
        username: adminProfile.name || 'kishor joshi',
        fullName: adminProfile.name || 'kishor joshi',
        email: adminProfile.email || 'theteamcode07@gmail.com',
        phone: '9876543213',
        password: 'admin@123',
        role: 'admin',
        status: 'Active',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
      };

      const adminUserObj: AdminUser = {
        id: 'admin-1',
        fullName: adminProfile.name || 'kishor joshi',
        email: adminProfile.email || 'theteamcode07@gmail.com',
        phone: '9876543213',
        accountType: 'Homeowner',
        registrationDate: new Date().toISOString().split('T')[0],
        status: 'Active',
        lastLogin: 'Just now',
        avatar: adminAccountObj.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        emailVerified: 'Verified'
      };

      // 4. Clear localStorage completely & store reset state
      localStorage.clear();

      localStorage.setItem('dreamhouse_factory_reset_performed', 'true');
      localStorage.setItem('dreamhouse_accounts', JSON.stringify([adminAccountObj]));
      localStorage.setItem('dreamhouse_admin_users', JSON.stringify([adminUserObj]));
      localStorage.setItem('dreamhouse_current_user_email', adminAccountObj.email);
      localStorage.setItem('dreamhouse_products', JSON.stringify([]));
      localStorage.setItem('dreamhouse_orders', JSON.stringify([]));
      localStorage.setItem('dreamhouse_messages', JSON.stringify([]));
      localStorage.setItem('dreamhouse_experts', JSON.stringify([]));
      localStorage.setItem('dreamhouse_cms_items', JSON.stringify([]));
      localStorage.setItem('dreamhouse_admin_logs', JSON.stringify([]));
      localStorage.setItem('dreamhouse_saved_floorplans', JSON.stringify([]));

      // 5. Update React states & sync event
      setUsers([adminUserObj]);
      window.dispatchEvent(new Event('dreamhouse_sync_users'));

      setShowResetConfirm(false);
      setIsResetting(false);
      setSecurityStatusMsg({ text: "Factory reset complete! All user accounts, products, and database data deleted (Admin account preserved). Reloading...", type: 'success' });
      alert("Factory reset complete! All user accounts, products, orders, and database data have been deleted from both Firebase and the app, keeping only your Admin account.");

      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch (error: any) {
      console.error("Factory reset error:", error);
      setIsResetting(false);
      setSecurityStatusMsg({ text: `Failed to reset platform: ${error.message}`, type: 'error' });
      alert(`Failed to reset platform: ${error.message}`);
    }
  };

  // CMS Editable States
  const [cmsSiteName, setCmsSiteName] = useState(websiteConfig.siteName);
  const [cmsLogoUrl, setCmsLogoUrl] = useState(websiteConfig.logoUrl);
  const [cmsHeroBannerUrl, setCmsHeroBannerUrl] = useState(websiteConfig.heroBannerUrl);
  const [cmsHeroTitle, setCmsHeroTitle] = useState(websiteConfig.heroTitle);
  const [cmsHeroSubtitle, setCmsHeroSubtitle] = useState(websiteConfig.heroSubtitle);
  const [cmsRoleSelectorTitle, setCmsRoleSelectorTitle] = useState(websiteConfig.roleSelectorTitle);
  const [cmsRoleSelectorSubtitle, setCmsRoleSelectorSubtitle] = useState(websiteConfig.roleSelectorSubtitle);
  const [cmsJoinButtonText, setCmsJoinButtonText] = useState(websiteConfig.joinButtonText);
  const [showPublishSuccessModal, setShowPublishSuccessModal] = useState(false);

  // Image validation states (null = validating, true = valid, false = invalid)
  const [logoValid, setLogoValid] = useState<boolean | null>(true);
  const [bannerValid, setBannerValid] = useState<boolean | null>(true);
  const [logoErrorMsg, setLogoErrorMsg] = useState<string>('');
  const [bannerErrorMsg, setBannerErrorMsg] = useState<string>('');

  // User Management States (supplied via props for real-time synchronization)

  const [searchName, setSearchName] = useState('');
  const [searchEmail, setSearchEmail] = useState('');
  const [filterAccountType, setFilterAccountType] = useState('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [filterRegDate, setFilterRegDate] = useState('All'); // 'All' | 'last-7' | 'last-30' | 'last-90'
  
  // Modals / Details States
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isViewing, setIsViewing] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string, name: string } | null>(null);
  const [passwordResetModal, setPasswordResetModal] = useState<{ id: string, email: string, name: string } | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [isResettingPass, setIsResettingPass] = useState(false);
  
  // Temporary state for editing form
  const [editForm, setEditForm] = useState<{
    fullName: string;
    email: string;
    phone: string;
    accountType: 'Homeowner' | 'Expert' | 'Shopkeeper';
    status: 'Pending' | 'Active' | 'Suspended' | 'Disabled';
    avatar: string;
  } | null>(null);

  const validateImage = (url: string): Promise<boolean> => {
    return new Promise((resolve) => {
      if (!url || typeof url !== 'string') {
        resolve(false);
        return;
      }
      if (url.startsWith('data:image/')) {
        resolve(true);
        return;
      }
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        resolve(false);
        return;
      }
      
      const img = new Image();
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
      img.src = url;
    });
  };

  React.useEffect(() => {
    let isMounted = true;
    const checkLogo = async () => {
      if (!cmsLogoUrl) {
        if (isMounted) {
          setLogoValid(false);
          setLogoErrorMsg('Brand Logo URL cannot be empty.');
        }
        return;
      }
      if (isMounted) {
        setLogoValid(null);
      }
      const isValid = await validateImage(cmsLogoUrl);
      if (isMounted) {
        setLogoValid(isValid);
        setLogoErrorMsg(isValid ? '' : 'The image could not be loaded. Please ensure it is a valid image URL (starting with http/https) or upload a correct file.');
      }
    };
    checkLogo();
    return () => { isMounted = false; };
  }, [cmsLogoUrl]);

  React.useEffect(() => {
    let isMounted = true;
    const checkBanner = async () => {
      if (!cmsHeroBannerUrl) {
        if (isMounted) {
          setBannerValid(false);
          setBannerErrorMsg('Hero Banner URL cannot be empty.');
        }
        return;
      }
      if (isMounted) {
        setBannerValid(null);
      }
      const isValid = await validateImage(cmsHeroBannerUrl);
      if (isMounted) {
        setBannerValid(isValid);
        setBannerErrorMsg(isValid ? '' : 'The image could not be loaded. Please ensure it is a valid image URL (starting with http/https) or upload a correct file.');
      }
    };
    checkBanner();
    return () => { isMounted = false; };
  }, [cmsHeroBannerUrl]);

  const handlePublish = async () => {
    setLogoValid(null);
    setBannerValid(null);
    const isLogoValid = await validateImage(cmsLogoUrl);
    const isBannerValid = await validateImage(cmsHeroBannerUrl);

    setLogoValid(isLogoValid);
    setBannerValid(isBannerValid);

    if (!isLogoValid || !isBannerValid) {
      let errors = [];
      if (!isLogoValid) errors.push("• The Brand Logo image is invalid or could not be loaded.");
      if (!isBannerValid) errors.push("• The Homepage Hero Banner image is invalid or could not be loaded.");
      
      alert(`Cannot save changes:\n\n${errors.join("\n")}\n\nPlease check the image URLs or uploaded files before publishing.`);
      return;
    }

    try {
      onUpdateWebsiteConfig({
        siteName: cmsSiteName,
        logoUrl: cmsLogoUrl,
        heroBannerUrl: cmsHeroBannerUrl,
        heroTitle: cmsHeroTitle,
        heroSubtitle: cmsHeroSubtitle,
        roleSelectorTitle: cmsRoleSelectorTitle,
        roleSelectorSubtitle: cmsRoleSelectorSubtitle,
        joinButtonText: cmsJoinButtonText,
      });
      setShowPublishSuccessModal(true);
    } catch (error: any) {
      alert(`Failed to save changes: ${error?.message || 'An error occurred while saving. Existing published content was not affected.'}`);
    }
  };

  const handleCancel = () => {
    setCmsSiteName(websiteConfig.siteName);
    setCmsLogoUrl(websiteConfig.logoUrl);
    setCmsHeroBannerUrl(websiteConfig.heroBannerUrl);
    setCmsHeroTitle(websiteConfig.heroTitle);
    setCmsHeroSubtitle(websiteConfig.heroSubtitle);
    setCmsRoleSelectorTitle(websiteConfig.roleSelectorTitle);
    setCmsRoleSelectorSubtitle(websiteConfig.roleSelectorSubtitle);
    setCmsJoinButtonText(websiteConfig.joinButtonText);
    alert("Changes cancelled. Reverted back to the published website configurations.");
  };

  const handleResetToDefault = () => {
    setCmsSiteName(DEFAULT_WEBSITE_CONFIG.siteName);
    setCmsLogoUrl(DEFAULT_WEBSITE_CONFIG.logoUrl);
    setCmsHeroBannerUrl(DEFAULT_WEBSITE_CONFIG.heroBannerUrl);
    setCmsHeroTitle(DEFAULT_WEBSITE_CONFIG.heroTitle);
    setCmsHeroSubtitle(DEFAULT_WEBSITE_CONFIG.heroSubtitle);
    setCmsRoleSelectorTitle(DEFAULT_WEBSITE_CONFIG.roleSelectorTitle);
    setCmsRoleSelectorSubtitle(DEFAULT_WEBSITE_CONFIG.roleSelectorSubtitle);
    setCmsJoinButtonText(DEFAULT_WEBSITE_CONFIG.joinButtonText);
    alert("Form reset to system template default parameters. Click 'Save & Publish' to write changes live.");
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'logo' | 'banner') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          if (target === 'logo') {
            setCmsLogoUrl(reader.result);
          } else {
            setCmsHeroBannerUrl(reader.result);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Dynamic values based on timeframe selection
  const chartData = {
    weekly: [
      { label: 'Mon', value: 45 },
      { label: 'Tue', value: 58 },
      { label: 'Wed', value: 72 },
      { label: 'Thu', value: 65 },
      { label: 'Fri', value: 89 },
      { label: 'Sat', value: 35 },
      { label: 'Sun', value: 42 }
    ],
    monthly: [
      { label: 'May', value: 180 },
      { label: 'Jun', value: 240 },
      { label: 'Jul', value: 320 },
      { label: 'Aug', value: 280 },
      { label: 'Sep', value: 410 },
      { label: 'Oct', value: 480 }
    ],
    yearly: [
      { label: '2022', value: 1200 },
      { label: '2023', value: 2100 },
      { label: '2024', value: 3400 },
      { label: '2025', value: 4500 }
    ]
  };

  const currentChart = chartData[timeframe];
  const maxValue = Math.max(...currentChart.map(d => d.value));

  const handleResolveLog = (id: string) => {
    setLogs(logs.filter(l => l.id !== id));
  };

  const handleApproveUser = async (id: string, userObj?: AdminUser) => {
    const targetUser = userObj || users.find(u => u.id === id);
    const nowStr = new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    const nowIso = new Date().toISOString();
    const adminIdentifier = auth.currentUser?.uid || user.email || 'Admin';

    try {
      if (id) {
        // 1. Update Firestore permanently
        await setDoc(doc(db, 'accounts', id), {
          status: 'Active',
          accountStatus: 'Active',
          approvalStatus: 'Approved',
          approvedBy: adminIdentifier,
          approvedAt: nowIso,
          statusLastUpdated: nowStr,
          lastUpdatedBy: adminIdentifier,
          statusHistory: arrayUnion({
            status: 'Active',
            approvalStatus: 'Approved',
            updatedBy: adminIdentifier,
            updatedAt: nowIso,
            note: 'Account approved by administrator'
          }),
          approvalLogs: arrayUnion({
            action: 'Approved',
            performedBy: adminIdentifier,
            timestamp: nowIso,
            details: 'Account registration approved'
          })
        }, { merge: true });

        // 2. Trigger API endpoint for sending verification email
        try {
          await fetch('/api/admin/approve-user', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId: id,
              userEmail: targetUser?.email,
              userName: targetUser?.fullName,
              userRole: targetUser?.accountType,
              adminUid: adminIdentifier
            })
          });
        } catch (apiErr) {
          console.warn('Backend email API notice:', apiErr);
        }

        alert(`User account for "${targetUser?.fullName || 'User'}" has been successfully approved and set to Active. A verification email has been automatically sent.`);
      }
    } catch (err: any) {
      console.warn("Firestore update notice:", err.message);
      alert(`Error approving user: ${err.message}`);
    }
  };

  const handleRejectUser = async (id: string, userObj?: AdminUser) => {
    const targetUser = userObj || users.find(u => u.id === id);
    if (!confirm(`Are you sure you want to reject the registration request for "${targetUser?.fullName || 'this user'}"?`)) {
      return;
    }

    const nowStr = new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    const nowIso = new Date().toISOString();
    const adminIdentifier = auth.currentUser?.uid || user.email || 'Admin';

    try {
      if (id) {
        // 1. Update Firestore permanently
        await setDoc(doc(db, 'accounts', id), {
          status: 'Rejected',
          accountStatus: 'Rejected',
          approvalStatus: 'Rejected',
          rejectedBy: adminIdentifier,
          rejectedAt: nowIso,
          statusLastUpdated: nowStr,
          lastUpdatedBy: adminIdentifier,
          statusHistory: arrayUnion({
            status: 'Rejected',
            approvalStatus: 'Rejected',
            updatedBy: adminIdentifier,
            updatedAt: nowIso,
            note: 'Account registration rejected by administrator'
          }),
          approvalLogs: arrayUnion({
            action: 'Rejected',
            performedBy: adminIdentifier,
            timestamp: nowIso,
            details: 'Account registration rejected'
          })
        }, { merge: true });

        // 2. Trigger API endpoint
        try {
          await fetch('/api/admin/reject-user', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userId: id,
              userEmail: targetUser?.email,
              userName: targetUser?.fullName,
              adminUid: adminIdentifier
            })
          });
        } catch (apiErr) {
          console.warn('Backend reject API notice:', apiErr);
        }

        alert(`Registration request for "${targetUser?.fullName || 'User'}" has been rejected.`);
      }
    } catch (err: any) {
      console.warn("Firestore update notice:", err.message);
      alert(`Error rejecting user: ${err.message}`);
    }
  };

  const handleSuspendUser = async (id: string) => {
    const nowStr = new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    try {
      if (id) {
        await setDoc(doc(db, 'accounts', id), {
          status: 'Suspended',
          statusLastUpdated: nowStr
        }, { merge: true });
        alert("User account has been suspended.");
      }
    } catch (err: any) {
      console.warn("Firestore update notice:", err.message);
    }
  };

  const handleReactivateUser = async (id: string) => {
    const nowStr = new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    try {
      if (id) {
        await setDoc(doc(db, 'accounts', id), {
          status: 'Active',
          statusLastUpdated: nowStr
        }, { merge: true });
        alert("User account has been reactivated.");
      }
    } catch (err: any) {
      console.warn("Firestore update notice:", err.message);
    }
  };

  const handleDeleteUser = (id: string, name: string) => {
    setDeleteTarget({ id, name });
  };

  const handleResetPassword = (id: string, email: string, name: string) => {
    setPasswordResetModal({ id, email, name });
    setNewPassword('');
    setConfirmNewPassword('');
    setShowResetModalPass(false);
    setResetError(null);
  };

  const handleConfirmPasswordReset = async () => {
    if (!passwordResetModal) return;
    setResetError(null);
    
    if (!newPassword || newPassword.trim().length < 8) {
      setResetError("Password must be at least 8 characters long.");
      return;
    }
    
    if (newPassword !== confirmNewPassword) {
      setResetError("Passwords do not match.");
      return;
    }
    
    setIsResettingPass(true);

    try {
      const cleanEmail = passwordResetModal.email.trim().toLowerCase();
      const uid = passwordResetModal.id;
      
      const reqUrl = '/api/admin/reset-user-password';
      const reqBodyObj = { uid, email: cleanEmail, newPassword, name: passwordResetModal.name };
      const reqBodyStr = JSON.stringify(reqBodyObj);

      console.log(`[Admin Password Reset] Initiating request to URL: ${reqUrl}`);
      console.log(`[Admin Password Reset] Request body:`, reqBodyObj);

      const idToken = auth.currentUser ? await auth.currentUser.getIdToken() : '';
      console.log(`[Admin Password Reset] Obtained admin ID token successfully. Length: ${idToken.length}`);

      const response = await fetch(reqUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`
        },
        body: reqBodyStr,
      });

      console.log(`[Admin Password Reset] Response status: ${response.status}`);
      
      const resHeaders: Record<string, string> = {};
      response.headers.forEach((val, key) => {
        resHeaders[key] = val;
      });
      console.log(`[Admin Password Reset] Response headers:`, resHeaders);

      if (!response.ok) {
        const text = await response.text();
        console.error(`[Admin Password Reset Error] Request URL:`, reqUrl);
        console.error(`[Admin Password Reset Error] Request body:`, reqBodyStr);
        console.error(`[Admin Password Reset Error] Response status:`, response.status);
        console.error(`[Admin Password Reset Error] Response headers:`, resHeaders);
        console.error(`[Admin Password Reset Error] Raw response text:`, text);

        let parsedError: any = null;
        try {
          parsedError = JSON.parse(text);
        } catch (e) {
          // not JSON
        }

        const firebaseCode = parsedError?.code || parsedError?.error?.code || 'N/A';
        const firebaseMsg = parsedError?.message || parsedError?.error?.message || parsedError?.error || 'N/A';

        console.error(`[Admin Password Reset Error] Firebase error code:`, firebaseCode);
        console.error(`[Admin Password Reset Error] Firebase error message:`, firebaseMsg);

        throw new Error(parsedError?.error || parsedError?.message || text || 'Failed to update password via Admin API.');
      }

      const text = await response.text();
      console.log(`[Admin Password Reset Success] Request URL:`, reqUrl);
      console.log(`[Admin Password Reset Success] Request body:`, reqBodyStr);
      console.log(`[Admin Password Reset Success] Response status:`, response.status);
      console.log(`[Admin Password Reset Success] Response headers:`, resHeaders);
      console.log(`[Admin Password Reset Success] Raw response text:`, text);

      let result;
      try {
        result = JSON.parse(text);
      } catch (e: any) {
        throw new Error(`Failed to parse success JSON: ${e.message}`);
      }

      const firebaseCode = result?.code || result?.error?.code || 'N/A';
      const firebaseMsg = result?.message || result?.error?.message || 'N/A';
      console.log(`[Admin Password Reset Success] Firebase error code:`, firebaseCode);
      console.log(`[Admin Password Reset Success] Firebase error message:`, firebaseMsg);

      // Update Firestore metadata
      const updateData = {
        password: newPassword,
        passwordLastChangedAt: new Date().toISOString(),
        passwordUpdatedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        updatedBy: auth.currentUser?.uid || 'Admin',
        passwordResetBy: "Admin"
      };

      try {
        await setDoc(doc(db, 'accounts', uid), updateData, { merge: true });
        
        // Also update /users if exists
        const qUsers = query(collection(db, 'users'), where('email', '==', cleanEmail));
        const usersSnap = await getDocs(qUsers);
        for (const uDoc of usersSnap.docs) {
          await setDoc(doc(db, 'users', uDoc.id), updateData, { merge: true });
        }
      } catch (e) {
        console.warn("Could not update Firestore user document after password reset", e);
      }
      
      // Log admin action
      try {
        const targetUserObj = users.find(u => u.id === uid);
        await addDoc(collection(db, 'adminLogs'), {
          userUid: uid,
          userName: passwordResetModal.name,
          userEmail: cleanEmail,
          userRole: targetUserObj?.accountType || 'Unknown',
          adminUid: auth.currentUser?.uid || 'unknown',
          adminName: auth.currentUser?.email || 'Admin',
          timestamp: new Date().toISOString(),
          action: "Password Changed"
        });
      } catch (logErr) {
        console.warn("Failed to log admin action for password reset", logErr);
      }

      alert("Password updated successfully.");
      setPasswordResetModal(null);
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (error: any) {
      console.error("Firebase Password Reset Error:", error);
      setResetError(`Failed to reset password: ${error.message}`);
    } finally {
      setIsResettingPass(false);
    }
  };

  const handleConfirmDeleteUser = async () => {
    if (!deleteTarget) return;
    const { id, name } = deleteTarget;
    let targetEmail = '';

    const userToDelete = users.find(u => u.id === id);
    if (userToDelete && userToDelete.email) {
      targetEmail = userToDelete.email.trim().toLowerCase();
    }

    console.log(`[Admin Delete] Starting synchronized deletion for user "${name}" (ID: ${id}, Email: ${targetEmail})`);

    // 1. Instantly remove the user from Admin Panel state and localStorage
    if (setUsers) {
      setUsers(prev => prev.filter(u => u.id !== id && (!targetEmail || u.email?.toLowerCase() !== targetEmail)));
    }
    try {
      ['dreamhouse_admin_users', 'dreamhouse_accounts', 'dreamhouse_experts'].forEach(key => {
        const raw = localStorage.getItem(key);
        if (raw) {
          const list = JSON.parse(raw);
          if (Array.isArray(list)) {
            const updated = list.filter((item: any) => 
              item && 
              item.id !== id && 
              (!targetEmail || item.email?.toLowerCase() !== targetEmail) &&
              (!targetEmail || item.contact?.toLowerCase() !== targetEmail)
            );
            localStorage.setItem(key, JSON.stringify(updated));
          }
        }
      });
    } catch (e) {}

    // 2. Perform client-side Firestore status update to Deleted (soft-delete with recovery metadata)
    try {
      const cleanEmail = targetEmail ? targetEmail.trim().toLowerCase() : '';
      const deletePayload = {
        status: 'Deleted',
        accountStatus: 'Deleted',
        isDeleted: true,
        deletedAt: new Date().toISOString(),
        deletedBy: 'Admin',
        deletedReason: 'Deleted by Administrator',
        recoverable: true,
        recoveryAvailable: 'Yes',
        recoveryExpiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (id) {
        await deleteDoc(doc(db, 'accounts', id)).catch(() => {});
        await deleteDoc(doc(db, 'users', id)).catch(() => {});
        await deleteDoc(doc(db, 'carts', id)).catch(() => {});
        await deleteDoc(doc(db, 'topExperts', id)).catch(() => {});
        await deleteDoc(doc(db, 'topSellers', id)).catch(() => {});
      }
      if (cleanEmail) {
        await deleteDoc(doc(db, 'carts', cleanEmail)).catch(() => {});
        await deleteDoc(doc(db, 'presence', cleanEmail)).catch(() => {});

        const qAcc = query(collection(db, 'accounts'), where('email', '==', cleanEmail));
        const snapAcc = await getDocs(qAcc);
        for (const d of snapAcc.docs) {
          await deleteDoc(doc(db, 'accounts', d.id)).catch(() => {});
        }

        const qUsers = query(collection(db, 'users'), where('email', '==', cleanEmail));
        const snapUsers = await getDocs(qUsers);
        for (const d of snapUsers.docs) {
          await deleteDoc(doc(db, 'users', d.id)).catch(() => {});
        }

        const collectionsToClean = [
          { name: 'shopkeepers', field: 'email' },
          { name: 'experts', field: 'contact' },
          { name: 'topExperts', field: 'contact' },
          { name: 'topExperts', field: 'email' },
          { name: 'topSellers', field: 'email' },
          { name: 'carts', field: 'email' }
        ];

        for (const col of collectionsToClean) {
          try {
            const q = query(collection(db, col.name), where(col.field, '==', cleanEmail));
            const snap = await getDocs(q);
            for (const d of snap.docs) {
              await deleteDoc(doc(db, col.name, d.id)).catch(() => {});
            }
          } catch (e) {}
        }

        // Clean messages involving user
        try {
          const msgsSnap = await getDocs(collection(db, 'messages'));
          for (const mDoc of msgsSnap.docs) {
            const mData = mDoc.data();
            if (mData.senderEmail?.toLowerCase() === cleanEmail || mData.recipientEmail?.toLowerCase() === cleanEmail || mData.senderId === id || mData.recipientId === id) {
              await deleteDoc(doc(db, 'messages', mDoc.id)).catch(() => {});
            }
          }
        } catch (e) {}

        // Clean notifications involving user
        try {
          const notifSnap = await getDocs(collection(db, 'notifications'));
          for (const nDoc of notifSnap.docs) {
            const nData = nDoc.data();
            if (nData.userEmail?.toLowerCase() === cleanEmail || nData.targetUserEmail?.toLowerCase() === cleanEmail || nData.userId === id) {
              await deleteDoc(doc(db, 'notifications', nDoc.id)).catch(() => {});
            }
          }
        } catch (e) {}
      }
    } catch (clientErr: any) {
      console.warn("[AdminDashboard] Client-side deletion warn:", clientErr.message);
    }

    // 3. Call backend API to permanently delete user and perform full Firestore Cascade cleanup
    try {
      const response = await fetch('/api/admin/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: id, email: targetEmail }),
      });
      const result = await response.json();
      console.log("[Admin Delete API Cascade] Response:", result);
    } catch (apiErr: any) {
      console.error("[Admin Delete API Cascade] Error:", apiErr.message);
    }

    setDeleteTarget(null);
    alert(`User "${name}" has been deleted permanently.`);
  };

  const handleStartEdit = (user: AdminUser) => {
    setSelectedUser(user);
    setEditForm({
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      accountType: user.accountType,
      status: user.status,
      avatar: user.avatar
    });
    setIsEditing(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedUser || !editForm) return;
    if (!editForm.fullName.trim() || !editForm.email.trim()) {
      alert("Full Name and Email Address are required.");
      return;
    }
    const statusChanged = editForm.status !== selectedUser.status;
    const nowStr = new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });

    try {
      if (selectedUser.id) {
        await setDoc(doc(db, 'accounts', selectedUser.id), {
          fullName: editForm.fullName.trim(),
          email: editForm.email.trim(),
          phone: editForm.phone.trim(),
          accountType: editForm.accountType,
          role: editForm.accountType === 'Expert' ? 'professional' : editForm.accountType === 'Shopkeeper' ? 'shopkeeper' : 'homeowner',
          status: editForm.status,
          avatar: editForm.avatar,
          ...(statusChanged ? { statusLastUpdated: nowStr } : {})
        }, { merge: true });
      }
    } catch (err: any) {
      console.warn("Firestore update notice:", err.message);
    }

    setIsEditing(false);
    setSelectedUser(null);
    setEditForm(null);
    alert("User information has been updated successfully.");
  };

  const handleStartView = (user: AdminUser) => {
    setSelectedUser(user);
    setIsViewing(true);
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] flex h-screen font-sans overflow-hidden relative">
      
      {/* Toast Feedback */}
      {toast && (
        <div className={`fixed top-6 right-6 z-50 flex items-center gap-2.5 px-5 py-3 rounded-xl shadow-xl border text-sm font-bold transition-all duration-300 animate-fadeIn ${
          toast.type === 'success' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          <CheckCircle2 className={`w-5 h-5 ${toast.type === 'success' ? 'text-emerald-600' : 'text-rose-600'}`} />
          {toast.message}
        </div>
      )}
      
      {/* Sidebar Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <nav 
        onClickCapture={() => setSidebarOpen(false)}
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#1a2b3c] text-white flex flex-col p-6 shadow-md transition-transform duration-300 ease-in-out shrink-0 overflow-y-auto no-scrollbar md:translate-x-0 md:relative md:h-full ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        {/* Mobile Sidebar Close Header */}
        <div className="flex md:hidden justify-end mb-2 shrink-0">
          <button 
            onClick={() => setSidebarOpen(false)} 
            className="p-1.5 hover:bg-[#041627] rounded transition-colors text-[#8192a7] hover:text-white focus:outline-none"
            aria-label="Close navigation sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-6 flex items-center gap-3 shrink-0">
          <Shield className="w-8 h-8 text-[#fd8b00]" />
          <div>
            <h2 className="text-sm font-bold tracking-wider uppercase">Admin Portal</h2>
            <p className="text-[10px] text-[#8192a7]">Superadmin Environment</p>
          </div>
        </div>

        <div className="space-y-2 shrink-0">
          <button 
            onClick={() => setActiveTab('users')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'users' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Users className="w-4 h-4 text-[#fd8b00]" />
            Users
          </button>

          <button 
            onClick={() => setActiveTab('pending-approvals')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between transition-colors ${
              activeTab === 'pending-approvals' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <div className="flex items-center gap-3">
              <UserCheck className="w-4 h-4 text-[#fd8b00]" />
              <span>Pending Approvals</span>
            </div>
            {users.filter(u => (u.accountStatus === 'Pending' || u.status === 'Pending') && (u.accountType === 'Expert' || u.accountType === 'Shopkeeper')).length > 0 && (
              <span className="bg-[#fd8b00] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                {users.filter(u => (u.accountStatus === 'Pending' || u.status === 'Pending') && (u.accountType === 'Expert' || u.accountType === 'Shopkeeper')).length}
              </span>
            )}
          </button>

          <button 
            onClick={() => setActiveTab('security')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'security' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Shield className="w-4 h-4 text-[#fd8b00]" />
            Platform Security
          </button>


          <button 
            onClick={() => setActiveTab('top-rankings')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'top-rankings' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Award className="w-4 h-4 text-[#fd8b00]" />
            Top 3 Rankings Manager
          </button>
        </div>

        {/* Separator for Enterprise Modules (Fixed Heading) */}
        <div className="pt-4 mt-4 border-t border-[#8192a7]/20 shrink-0 mb-2">
          <p className="text-[10px] uppercase font-bold text-[#8192a7] tracking-wider">Enterprise Portals</p>
        </div>

        {/* Enterprise Portals Menu */}
        <div className="space-y-2 py-1">
          <button 
            onClick={() => setActiveTab('platform')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'platform' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Globe className="w-4 h-4 text-[#fd8b00]" />
            Platform Management
          </button>

          <button 
            onClick={() => setActiveTab('notifications')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'notifications' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Bell className="w-4 h-4 text-[#fd8b00]" />
            Notification Management
          </button>

          <button 
            onClick={() => setActiveTab('email-templates')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'email-templates' ? 'bg-[#041627] text-white font-bold' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Mail className="w-4 h-4 text-[#fd8b00]" />
            Email Templates
          </button>
        </div>

        <div className="pt-4 mt-auto border-t border-[#8192a7]/20 space-y-2 shrink-0">
          <button 
            onClick={onLogout}
            className="w-full text-left text-red-300 hover:bg-[#1a2b3c]/60 py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Exit Admin Center
          </button>
        </div>
      </nav>

      {/* Main Container Wrapper */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Mobile Header Bar */}
        <header className="bg-[#1a2b3c] text-white px-6 py-4 flex items-center justify-between md:hidden shadow-md shrink-0">
          <div className="flex items-center gap-3">
            <button 
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="p-1.5 -ml-1.5 hover:bg-[#041627] rounded-lg transition-colors focus:outline-none"
              aria-label="Open navigation sidebar"
            >
              <Menu className="w-6 h-6 text-[#fd8b00]" />
            </button>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#fd8b00]" />
              <span className="font-bold text-sm tracking-wide uppercase">Admin Portal</span>
            </div>
          </div>
          <div className="text-[10px] bg-[#041627] px-2 py-1 rounded text-[#8192a7] font-semibold font-mono">
            SUPERADMIN
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 overflow-y-auto p-4 sm:p-6 md:p-10">
          <div className="max-w-[1280px] mx-auto space-y-8">
          


          {/* USER MANAGEMENT TAB */}
          {activeTab === 'users' && (
            <div className="space-y-8 animate-fadeIn">
              {/* Header */}
              <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-[#041627]">User Management</h1>
                  <p className="text-xs text-[#44474c] mt-1">Administer all platform users, view profiles, and update account permissions.</p>
                </div>
                <div className="text-xs bg-slate-100 text-slate-700 py-1.5 px-3 rounded-lg font-mono">
                  Total Managed: {directoryUsers.length} Users
                </div>
              </div>

              {/* User Status Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
                {/* Total Registered Card */}
                <div 
                  onClick={() => {
                    setFilterStatus('All');
                    setFilterAccountType('All');
                  }}
                  className={`cursor-pointer transition-all p-4 sm:p-5 rounded-xl border shadow-sm flex items-center justify-between gap-3 min-w-0 ${
                    filterStatus === 'All' && filterAccountType === 'All'
                      ? 'border-[#fd8b00] bg-orange-50/50 ring-2 ring-[#fd8b00]/20' 
                      : 'bg-white border-[#c4c6cd]/40 hover:border-orange-300 hover:shadow-md'
                  }`}
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <p className="text-[11px] sm:text-xs font-bold text-[#44474c] uppercase tracking-wider truncate">Total Registered</p>
                    <p className="text-2xl sm:text-3xl font-extrabold text-[#041627]">{directoryUsers.length}</p>
                    <p className="text-[10px] text-slate-500/80 truncate">Show all platform users</p>
                  </div>
                  <div className={`p-2.5 sm:p-3 rounded-full shrink-0 bg-slate-100 text-[#041627]`}>
                    <Users className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                </div>

                {/* Pending Card */}
                <div 
                  onClick={() => {
                    const nextStatus = filterStatus === 'Pending' ? 'All' : 'Pending';
                    setFilterStatus(nextStatus);
                    setFilterAccountType('All');
                  }}
                  className={`cursor-pointer transition-all p-4 sm:p-5 rounded-xl border shadow-sm flex items-center justify-between gap-3 min-w-0 ${
                    filterStatus === 'Pending' 
                      ? 'border-amber-500 bg-amber-50/70 ring-2 ring-amber-500/20' 
                      : 'bg-white border-[#c4c6cd]/40 hover:border-amber-300 hover:shadow-md'
                  }`}
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <p className="text-[11px] sm:text-xs font-bold text-[#44474c] uppercase tracking-wider truncate">Pending Approvals</p>
                    <p className="text-2xl sm:text-3xl font-extrabold text-amber-600">{directoryUsers.filter(u => u.status === 'Pending' || u.accountStatus === 'Pending').length}</p>
                    <p className="text-[10px] text-amber-700/80 truncate">{filterStatus === 'Pending' ? 'Filtering active' : 'Filter by pending'}</p>
                  </div>
                  <div className={`p-2.5 sm:p-3 rounded-full shrink-0 ${filterStatus === 'Pending' ? 'bg-amber-500 text-white' : 'bg-amber-50 text-amber-500'}`}>
                    <RefreshCw className="w-5 h-5 sm:w-6 sm:h-6 animate-spin" style={{ animationDuration: '6s' }} />
                  </div>
                </div>

                {/* Active Card */}
                <div 
                  onClick={() => {
                    const nextStatus = filterStatus === 'Active' ? 'All' : 'Active';
                    setFilterStatus(nextStatus);
                    setFilterAccountType('All');
                  }}
                  className={`cursor-pointer transition-all p-4 sm:p-5 rounded-xl border shadow-sm flex items-center justify-between gap-3 min-w-0 ${
                    filterStatus === 'Active' 
                      ? 'border-green-500 bg-green-50/70 ring-2 ring-green-500/20' 
                      : 'bg-white border-[#c4c6cd]/40 hover:border-green-300 hover:shadow-md'
                  }`}
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <p className="text-[11px] sm:text-xs font-bold text-[#44474c] uppercase tracking-wider truncate">Active Users</p>
                    <p className="text-2xl sm:text-3xl font-extrabold text-green-600">{directoryUsers.filter(u => u.status === 'Active' || u.accountStatus === 'Active').length}</p>
                    <p className="text-[10px] text-green-700/80 truncate">{filterStatus === 'Active' ? 'Filtering active' : 'Filter by active'}</p>
                  </div>
                  <div className={`p-2.5 sm:p-3 rounded-full shrink-0 ${filterStatus === 'Active' ? 'bg-green-500 text-white' : 'bg-green-50 text-green-500'}`}>
                    <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                </div>

                {/* Suspended Card */}
                <div 
                  onClick={() => {
                    const nextStatus = filterStatus === 'Suspended' ? 'All' : 'Suspended';
                    setFilterStatus(nextStatus);
                    setFilterAccountType('All');
                  }}
                  className={`cursor-pointer transition-all p-4 sm:p-5 rounded-xl border shadow-sm flex items-center justify-between gap-3 min-w-0 ${
                    filterStatus === 'Suspended' 
                      ? 'border-red-500 bg-red-50/70 ring-2 ring-red-500/20' 
                      : 'bg-white border-[#c4c6cd]/40 hover:border-red-300 hover:shadow-md'
                  }`}
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <p className="text-[11px] sm:text-xs font-bold text-[#44474c] uppercase tracking-wider truncate">Suspended Accounts</p>
                    <p className="text-2xl sm:text-3xl font-extrabold text-red-600">{directoryUsers.filter(u => u.status === 'Suspended' || u.accountStatus === 'Suspended').length}</p>
                    <p className="text-[10px] text-red-700/80 truncate">{filterStatus === 'Suspended' ? 'Filtering active' : 'Filter by suspended'}</p>
                  </div>
                  <div className={`p-2.5 sm:p-3 rounded-full shrink-0 ${filterStatus === 'Suspended' ? 'bg-red-500 text-white' : 'bg-red-50 text-red-500'}`}>
                    <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                </div>

                {/* Disabled Card */}
                <div 
                  onClick={() => {
                    const nextStatus = filterStatus === 'Disabled' ? 'All' : 'Disabled';
                    setFilterStatus(nextStatus);
                    setFilterAccountType('All');
                  }}
                  className={`cursor-pointer transition-all p-4 sm:p-5 rounded-xl border shadow-sm flex items-center justify-between gap-3 min-w-0 ${
                    filterStatus === 'Disabled' 
                      ? 'border-purple-500 bg-purple-50/70 ring-2 ring-purple-500/20' 
                      : 'bg-white border-[#c4c6cd]/40 hover:border-purple-300 hover:shadow-md'
                  }`}
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <p className="text-[11px] sm:text-xs font-bold text-[#44474c] uppercase tracking-wider truncate">Disabled Accounts</p>
                    <p className="text-2xl sm:text-3xl font-extrabold text-purple-600">{directoryUsers.filter(u => u.status === 'Disabled' || u.accountStatus === 'Disabled').length}</p>
                    <p className="text-[10px] text-purple-700/80 truncate">{filterStatus === 'Disabled' ? 'Filtering active' : 'Filter by disabled'}</p>
                  </div>
                  <div className={`p-2.5 sm:p-3 rounded-full shrink-0 ${filterStatus === 'Disabled' ? 'bg-purple-500 text-white' : 'bg-purple-50 text-purple-500'}`}>
                    <Trash2 className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                </div>
              </div>

              {/* Secondary Role Filter Menu */}
              {['Pending', 'Active', 'Suspended', 'Disabled'].includes(filterStatus) && (
                <div className="bg-[#f8fafc] border border-slate-200/80 rounded-xl p-4 sm:p-5 space-y-3 sm:space-y-4 animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#fd8b00]" />
                    <span className="text-xs font-bold text-[#041627] uppercase tracking-wider">
                      Secondary Role Filter for <span className="text-[#fd8b00]">{filterStatus}</span> Status
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2.5">
                    {/* All Roles */}
                    <button
                      onClick={() => setFilterAccountType('All')}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-2.5 ${
                        filterAccountType === 'All'
                          ? 'bg-[#041627] text-white ring-2 ring-[#041627]/20'
                          : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                      }`}
                    >
                      <span>All Roles</span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        filterAccountType === 'All' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {directoryUsers.filter(u => u.status === filterStatus || u.accountStatus === filterStatus).length}
                      </span>
                    </button>

                    {/* Client (mapped to Homeowner) */}
                    {filterStatus !== 'Pending' && (
                      <button
                        onClick={() => setFilterAccountType('Homeowner')}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-2.5 ${
                          filterAccountType === 'Homeowner'
                            ? 'bg-[#fd8b00] text-white ring-2 ring-[#fd8b00]/20'
                            : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                        }`}
                      >
                        <span>Client</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          filterAccountType === 'Homeowner' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {directoryUsers.filter(u => (u.status === filterStatus || u.accountStatus === filterStatus) && u.accountType === 'Homeowner').length}
                        </span>
                      </button>
                    )}

                    {/* Expert */}
                    <button
                      onClick={() => setFilterAccountType('Expert')}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-2.5 ${
                        filterAccountType === 'Expert'
                          ? 'bg-[#fd8b00] text-white ring-2 ring-[#fd8b00]/20'
                          : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                      }`}
                    >
                      <span>Expert</span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        filterAccountType === 'Expert' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {directoryUsers.filter(u => (u.status === filterStatus || u.accountStatus === filterStatus) && u.accountType === 'Expert').length}
                      </span>
                    </button>

                    {/* Shopkeeper */}
                    <button
                      onClick={() => setFilterAccountType('Shopkeeper')}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-2.5 ${
                        filterAccountType === 'Shopkeeper'
                          ? 'bg-[#fd8b00] text-white ring-2 ring-[#fd8b00]/20'
                          : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                      }`}
                    >
                      <span>Shopkeeper</span>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        filterAccountType === 'Shopkeeper' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {directoryUsers.filter(u => (u.status === filterStatus || u.accountStatus === filterStatus) && u.accountType === 'Shopkeeper').length}
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* Filters Panel */}
              <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#041627] flex items-center gap-1.5">
                    <Filter className="w-4 h-4 text-[#fd8b00]" />
                    Filter & Search Panel
                  </h3>
                  <button 
                    onClick={() => {
                      setSearchName('');
                      setSearchEmail('');
                      setFilterAccountType('All');
                      setFilterStatus('All');
                      setFilterRegDate('All');
                    }}
                    className="text-xs font-semibold text-[#fd8b00] hover:underline"
                  >
                    Reset All Filters
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                  {/* Search Name */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-[#44474c]">Search by Name</label>
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-[#8192a7]" />
                      <input 
                        type="text"
                        value={searchName}
                        onChange={(e) => setSearchName(e.target.value)}
                        placeholder="e.g. Sarah"
                        className="w-full text-xs pl-8 pr-3 py-2 border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00]"
                      />
                    </div>
                  </div>

                  {/* Search Email */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-[#44474c]">Search by Email</label>
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-[#8192a7]" />
                      <input 
                        type="text"
                        value={searchEmail}
                        onChange={(e) => setSearchEmail(e.target.value)}
                        placeholder="e.g. benjamin.vance@example.com"
                        className="w-full text-xs pl-8 pr-3 py-2 border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00]"
                      />
                    </div>
                  </div>

                  {/* Workspace Role */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-[#44474c]">Workspace Role</label>
                    <select 
                      value={filterAccountType}
                      onChange={(e) => setFilterAccountType(e.target.value)}
                      className="w-full text-xs p-2 border border-[#c4c6cd] bg-white rounded focus:outline-none focus:border-[#fd8b00]"
                    >
                      <option value="All">All Types</option>
                      <option value="Homeowner">Homeowner</option>
                      <option value="Expert">Expert</option>
                      <option value="Shopkeeper">Shopkeeper</option>
                    </select>
                  </div>

                  {/* Account Status */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-[#44474c]">Account Status</label>
                    <select 
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="w-full text-xs p-2 border border-[#c4c6cd] bg-white rounded focus:outline-none focus:border-[#fd8b00]"
                    >
                      <option value="All">All Statuses</option>
                      <option value="Pending">Pending</option>
                      <option value="Active">Active</option>
                      <option value="Suspended">Suspended</option>
                    </select>
                  </div>

                  {/* Reg Date */}
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-[#44474c]">Registration Date</label>
                    <select 
                      value={filterRegDate}
                      onChange={(e) => setFilterRegDate(e.target.value)}
                      className="w-full text-xs p-2 border border-[#c4c6cd] bg-white rounded focus:outline-none focus:border-[#fd8b00]"
                    >
                      <option value="All">All Dates</option>
                      <option value="last-7">Last 7 Days</option>
                      <option value="last-30">Last 30 Days</option>
                      <option value="last-90">Last 90 Days</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* User List Table */}
              <div className="bg-white rounded-xl border border-[#c4c6cd]/40 shadow-sm overflow-hidden">
                <div className="p-4 bg-gray-50 border-b border-[#c4c6cd]/20 flex justify-between items-center">
                  <h3 className="text-xs font-bold text-[#041627] uppercase tracking-wider">User Directory</h3>
                  <span className="text-[11px] text-[#44474c]">Showing {
                    directoryUsers.filter(u => {
                      if (searchName && !u.fullName.toLowerCase().includes(searchName.toLowerCase())) return false;
                      if (searchEmail && !u.email.toLowerCase().includes(searchEmail.toLowerCase())) return false;
                      if (filterAccountType !== 'All' && u.accountType !== filterAccountType) return false;
                      if (filterStatus !== 'All' && (u.status !== filterStatus && u.accountStatus !== filterStatus)) return false;
                      if (filterRegDate !== 'All') {
                        const regDate = new Date(u.registrationDate);
                        const currentDate = new Date('2026-07-10');
                        const diffTime = Math.abs(currentDate.getTime() - regDate.getTime());
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                        if (filterRegDate === 'last-7' && diffDays > 7) return false;
                        if (filterRegDate === 'last-30' && diffDays > 30) return false;
                        if (filterRegDate === 'last-90' && diffDays > 90) return false;
                      }
                      return true;
                    }).length
                  } of {directoryUsers.length} entries</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-[#c4c6cd]/30 bg-slate-50/50 text-[#44474c] uppercase font-bold tracking-wider">
                        <th className="p-4 text-[10px] font-bold">Profile / Full Name</th>
                        <th className="p-4 text-[10px] font-bold">Workspace Role</th>
                        <th className="p-4 text-[10px] font-bold">Registration Date & Time</th>
                        <th className="p-4 text-[10px] font-bold">Account Status</th>
                        <th className="p-4 text-[10px] font-bold">Last Login</th>
                        <th className="p-4 text-[10px] font-bold text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#c4c6cd]/20">
                      {directoryUsers
                        .filter(u => {
                          if (searchName && !u.fullName.toLowerCase().includes(searchName.toLowerCase())) return false;
                          if (searchEmail && !u.email.toLowerCase().includes(searchEmail.toLowerCase())) return false;
                          if (filterAccountType !== 'All' && u.accountType !== filterAccountType) return false;
                          if (filterStatus !== 'All' && (u.status !== filterStatus && u.accountStatus !== filterStatus)) return false;
                          if (filterRegDate !== 'All') {
                            const regDate = new Date(u.registrationDate);
                            const currentDate = new Date('2026-07-10');
                            const diffTime = Math.abs(currentDate.getTime() - regDate.getTime());
                            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                            if (filterRegDate === 'last-7' && diffDays > 7) return false;
                            if (filterRegDate === 'last-30' && diffDays > 30) return false;
                            if (filterRegDate === 'last-90' && diffDays > 90) return false;
                          }
                          return true;
                        })
                        .map((user) => (
                          <tr key={user.id} className="hover:bg-[#f8f9ff]/50 transition-colors">
                            {/* Profile (Clickable Profile Picture & Name) */}
                            <td 
                              className="p-4 cursor-pointer group"
                              onClick={() => handleStartView(user)}
                              title={`Click to open full profile for ${user.fullName}`}
                            >
                              <div className="flex items-center gap-3">
                                <img 
                                  src={user.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                                  alt={user.fullName} 
                                  className="w-9 h-9 rounded-full object-cover border-2 border-[#c4c6cd]/30 group-hover:border-[#fd8b00] group-hover:scale-105 transition-all shrink-0 shadow-sm" 
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <span className="font-bold text-[#041627] group-hover:text-[#fd8b00] group-hover:underline transition-colors whitespace-nowrap block">
                                    {user.fullName}
                                  </span>
                                  <span className="text-[10px] text-slate-400 group-hover:text-slate-600 transition-colors block">
                                    View full details
                                  </span>
                                </div>
                              </div>
                            </td>

                            {/* Type */}
                            <td className="p-4 whitespace-nowrap">
                              <div>
                                <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-800 text-[10px] font-bold">
                                  {user.accountType}
                                </span>
                                {user.professionType && (
                                  <div className="text-[10px] text-gray-500 mt-1 font-medium">
                                    {user.professionType} {user.yearsOfExperience !== undefined ? `• ${user.yearsOfExperience} yrs` : ''}
                                  </div>
                                )}
                              </div>
                            </td>

                            {/* Reg Date */}
                            <td className="p-4 text-[#44474c]/80 font-mono whitespace-nowrap">{user.registrationDate}</td>

                             {/* Status */}
                             <td className="p-4 whitespace-nowrap">
                               <div className="relative group inline-block">
                                 <span className={`cursor-help px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                   user.status === 'Active' 
                                     ? 'bg-green-100 text-green-800' 
                                     : user.status === 'Pending' 
                                       ? 'bg-amber-100 text-amber-800 animate-pulse' 
                                       : 'bg-red-100 text-red-800'
                                 }`}>
                                   {user.status}
                                 </span>
                                 
                                 {/* Hover Tooltip */}
                                 <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:flex flex-col items-center z-50 pointer-events-none transition-all duration-200">
                                   <div className="bg-[#0b1c30] text-white text-[10px] py-1.5 px-3 rounded shadow-xl whitespace-nowrap font-medium text-center border border-white/10">
                                     <div className="font-bold opacity-75">Status Last Updated</div>
                                     <div className="mt-0.5 font-mono text-[#fd8b00]">
                                       {user.statusLastUpdated || `${user.registrationDate} 09:00:00`}
                                     </div>
                                   </div>
                                   {/* Tooltip Arrow */}
                                   <div className="w-2 h-2 bg-[#0b1c30] rotate-45 -mt-1 border-r border-b border-white/10"></div>
                                 </div>
                               </div>
                             </td>

                            {/* Last Login */}
                            <td className="p-4 text-[#44474c]/80 font-mono whitespace-nowrap">{user.lastLogin}</td>

                            {/* Actions */}
                            <td className="p-4 whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1.5">
                                {/* View */}
                                <button 
                                  onClick={() => handleStartView(user)}
                                  title="View Complete Details"
                                  className="p-1.5 hover:bg-slate-100 rounded text-slate-700 transition-colors flex items-center justify-center"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>

                                {/* Edit */}
                                <button 
                                  onClick={() => handleStartEdit(user)}
                                  title="Edit User"
                                  className="p-1.5 hover:bg-amber-50 rounded text-amber-700 transition-colors flex items-center justify-center"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>

                                {/* Reset Password */}
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleResetPassword(user.id, user.email, user.fullName);
                                  }}
                                  title="Reset Password"
                                  className="p-1.5 hover:bg-sky-50 rounded text-sky-700 transition-colors flex items-center justify-center relative z-20 pointer-events-auto cursor-pointer"
                                >
                                  <Lock className="w-3.5 h-3.5" />
                                </button>

                                {/* Approve */}
                                {user.status === 'Pending' && (
                                  <button 
                                    onClick={() => handleApproveUser(user.id)}
                                    title="Approve User"
                                    className="p-1.5 hover:bg-green-50 rounded text-green-700 transition-colors flex items-center justify-center"
                                  >
                                    <UserCheck className="w-3.5 h-3.5" />
                                  </button>
                                )}

                                {/* Suspend */}
                                {user.status === 'Active' && (
                                  <button 
                                    onClick={() => handleSuspendUser(user.id)}
                                    title="Suspend User"
                                    className="p-1.5 hover:bg-red-50 rounded text-red-700 transition-colors flex items-center justify-center"
                                  >
                                    <UserX className="w-3.5 h-3.5" />
                                  </button>
                                )}

                                {/* Reactivate */}
                                {user.status === 'Suspended' && (
                                  <button 
                                    onClick={() => handleReactivateUser(user.id)}
                                    title="Reactivate User"
                                    className="p-1.5 hover:bg-green-50 rounded text-green-700 transition-colors flex items-center justify-center"
                                  >
                                    <UserCheck className="w-3.5 h-3.5" />
                                  </button>
                                )}

                                {/* Delete */}
                                <button 
                                  onClick={() => handleDeleteUser(user.id, user.fullName)}
                                  title="Delete User"
                                  className="p-1.5 hover:bg-red-100 rounded text-red-600 transition-colors flex items-center justify-center"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}

                      {users.filter(u => {
                        if (searchName && !u.fullName.toLowerCase().includes(searchName.toLowerCase())) return false;
                        if (searchEmail && !u.email.toLowerCase().includes(searchEmail.toLowerCase())) return false;
                        if (filterAccountType !== 'All' && u.accountType !== filterAccountType) return false;
                        if (filterStatus !== 'All' && u.status !== filterStatus) return false;
                        if (filterRegDate !== 'All') {
                          const regDate = new Date(u.registrationDate);
                          const currentDate = new Date('2026-07-10');
                          const diffTime = Math.abs(currentDate.getTime() - regDate.getTime());
                          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                          if (filterRegDate === 'last-7' && diffDays > 7) return false;
                          if (filterRegDate === 'last-30' && diffDays > 30) return false;
                          if (filterRegDate === 'last-90' && diffDays > 90) return false;
                        }
                        return true;
                      }).length === 0 && (
                        <tr>
                          <td colSpan={8} className="text-center py-12 text-[#44474c] font-semibold text-xs">
                            No users match the active filter parameters.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* PENDING APPROVALS TAB */}
          {activeTab === 'pending-approvals' && (
            <div className="space-y-8 animate-fadeIn">
              {/* Header */}
              <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-[#041627] flex items-center gap-2">
                    <UserCheck className="w-6 h-6 text-[#fd8b00]" />
                    Pending Account Approvals
                  </h1>
                  <p className="text-xs text-[#44474c] mt-1">
                    Review pending Expert and Shopkeeper account registration requests requiring administrator verification. Approved accounts receive automated email notifications and instant login permission.
                  </p>
                </div>
                <div className="text-xs bg-amber-50 text-amber-800 border border-amber-200 py-1.5 px-3 rounded-lg font-bold flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-600" />
                  {users.filter(u => (u.accountStatus === 'Pending' || u.status === 'Pending') && (u.accountType === 'Expert' || u.accountType === 'Shopkeeper')).length} Pending Request(s)
                </div>
              </div>

              {/* Pending Queue */}
              {users.filter(u => (u.accountStatus === 'Pending' || u.status === 'Pending') && (u.accountType === 'Expert' || u.accountType === 'Shopkeeper')).length === 0 ? (
                <div className="bg-white p-12 rounded-xl border border-[#c4c6cd]/40 shadow-sm text-center space-y-3">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-[#041627]">No Pending Approval Requests</h3>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    All Expert and Shopkeeper registration requests have been reviewed and processed. New account registrations requiring verification will appear here in real-time.
                  </p>
                </div>
              ) : (
                <div className="bg-white rounded-xl border border-[#c4c6cd]/40 shadow-sm overflow-hidden">
                  <div className="p-4 bg-amber-50/50 border-b border-amber-200/60 flex justify-between items-center">
                    <h3 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      Pending Approval Queue
                    </h3>
                    <span className="text-[11px] font-semibold text-amber-800">
                      Showing {users.filter(u => (u.accountStatus === 'Pending' || u.status === 'Pending') && (u.accountType === 'Expert' || u.accountType === 'Shopkeeper')).length} request(s)
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-[#c4c6cd]/30 text-[#44474c]">
                          <th className="p-4 text-[10px] font-bold uppercase tracking-wider">User Profile</th>
                          <th className="p-4 text-[10px] font-bold uppercase tracking-wider">Role & Details</th>
                          <th className="p-4 text-[10px] font-bold uppercase tracking-wider">Contact Info</th>
                          <th className="p-4 text-[10px] font-bold uppercase tracking-wider">Registration Date</th>
                          <th className="p-4 text-[10px] font-bold uppercase tracking-wider">Status</th>
                          <th className="p-4 text-[10px] font-bold uppercase tracking-wider text-center">Admin Approval Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#c4c6cd]/20">
                        {users
                          .filter(u => (u.accountStatus === 'Pending' || u.status === 'Pending') && (u.accountType === 'Expert' || u.accountType === 'Shopkeeper'))
                          .map((u) => (
                            <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-4">
                                <div className="flex items-center gap-3">
                                  <img 
                                    src={u.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'} 
                                    alt={u.fullName} 
                                    className="w-10 h-10 rounded-full object-cover border border-slate-200 cursor-pointer hover:opacity-80 transition-opacity shrink-0"
                                    onClick={() => handleStartView(u)}
                                  />
                                  <div>
                                    <button 
                                      onClick={() => handleStartView(u)}
                                      className="font-bold text-xs text-[#041627] hover:text-[#fd8b00] hover:underline text-left block cursor-pointer"
                                    >
                                      {u.fullName}
                                    </button>
                                    <span className="text-[10px] text-slate-500 font-mono">ID: {u.uid || u.id}</span>
                                  </div>
                                </div>
                              </td>

                              <td className="p-4">
                                <div className="space-y-1">
                                  <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                                    u.accountType === 'Expert' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  }`}>
                                    {u.accountType}
                                  </span>
                                  {u.accountType === 'Expert' && u.professionType && (
                                    <p className="text-[11px] text-slate-600 font-medium">{u.professionType} ({u.yearsOfExperience || 1} yrs exp)</p>
                                  )}
                                  {u.accountType === 'Shopkeeper' && u.shopName && (
                                    <p className="text-[11px] text-slate-600 font-medium">{u.shopName} ({u.businessCategory || 'Store'})</p>
                                  )}
                                </div>
                              </td>

                              <td className="p-4">
                                <div className="text-xs space-y-0.5">
                                  <p className="text-[#041627] font-medium">{u.email}</p>
                                  <p className="text-slate-500 text-[11px] font-mono">{u.phone}</p>
                                </div>
                              </td>

                              <td className="p-4">
                                <span className="text-xs text-slate-600 font-mono">{u.registrationDateTime || u.registrationDate}</span>
                              </td>

                              <td className="p-4">
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 animate-pulse">
                                  <RefreshCw className="w-3 h-3 animate-spin text-amber-600" />
                                  Pending Approval
                                </span>
                              </td>

                              <td className="p-4 text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <button
                                    onClick={() => handleApproveUser(u.id, u)}
                                    className="py-1.5 px-3 bg-emerald-600 text-white rounded-lg font-bold text-xs hover:bg-emerald-700 transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                                    title="Approve Account & Activate Access"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => handleRejectUser(u.id, u)}
                                    className="py-1.5 px-3 bg-red-600 text-white rounded-lg font-bold text-xs hover:bg-red-700 transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                                    title="Reject Account Registration"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    Reject
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ADMIN SETTINGS TAB */}
          {activeTab === 'security' && (
            <div className="space-y-8">
              <div className="flex justify-between items-center bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm">
                <div>
                  <h1 className="text-2xl font-bold text-[#041627]">Admin Settings</h1>
                  <p className="text-xs text-[#44474c] mt-1">Manage your admin profile and security settings.</p>
                </div>
              </div>

              {securityStatusMsg && (
                <div className={`p-4 rounded-xl text-sm font-medium border ${
                  securityStatusMsg.type === 'success' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-red-50 text-red-800 border-red-200'
                }`}>
                  {securityStatusMsg.text}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm space-y-4">
                  <h3 className="text-base font-bold text-[#041627]">Edit Profile</h3>
                  
                  {/* Profile Photo Upload */}
                  <div className="flex items-center gap-4 py-1">
                    <img 
                      src={adminProfile.avatar} 
                      alt="Admin Profile" 
                      className="w-16 h-16 rounded-full object-cover border-2 border-[#fd8b00] shadow-md"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <button
                        type="button"
                        onClick={() => adminPhotoInputRef.current?.click()}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <Camera className="w-3.5 h-3.5 text-[#fd8b00]" />
                        Change Photo
                      </button>
                      <p className="text-[10px] text-slate-400 mt-1">PNG, JPG or WEBP (Max 2MB)</p>
                    </div>
                    <input 
                      type="file"
                      ref={adminPhotoInputRef}
                      onChange={handleAdminPhotoChange}
                      accept="image/png, image/jpeg, image/webp"
                      className="hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1 uppercase tracking-wider">Full Name</label>
                    <input 
                      type="text" 
                      placeholder="Full Name" 
                      className="w-full p-2.5 border border-slate-200 rounded-xl text-xs font-semibold text-[#041627] bg-slate-50 focus:outline-none focus:border-[#fd8b00]" 
                      value={adminProfile.name} 
                      onChange={(e) => setAdminProfile({...adminProfile, name: e.target.value})} 
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1 uppercase tracking-wider">Email Address</label>
                    <input 
                      type="email" 
                      placeholder="Email" 
                      className="w-full p-2.5 border border-slate-200 rounded-xl text-xs font-semibold text-[#041627] bg-slate-50 focus:outline-none focus:border-[#fd8b00]" 
                      value={adminProfile.email} 
                      onChange={(e) => setAdminProfile({...adminProfile, email: e.target.value})} 
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1 uppercase tracking-wider">Phone Number</label>
                    <input 
                      type="text" 
                      placeholder="Phone Number" 
                      className="w-full p-2.5 border border-slate-200 rounded-xl text-xs font-semibold text-[#041627] bg-slate-50 focus:outline-none focus:border-[#fd8b00]" 
                      value={adminProfile.phone} 
                      onChange={(e) => setAdminProfile({...adminProfile, phone: e.target.value})} 
                    />
                  </div>

                  <button 
                    type="button"
                    disabled={isSavingProfile}
                    className="w-full py-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded-xl font-bold text-xs transition-all shadow-sm cursor-pointer active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50" 
                    onClick={handleSaveProfile}
                  >
                    {isSavingProfile ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Saving Profile...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" />
                        Save Profile
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm space-y-4">
                  <h3 className="text-base font-bold text-[#041627]">Change Password</h3>
                  <div className="relative">
                    <input type={showOldPassword ? "text" : "password"} placeholder="Current Password" className="w-full p-2 border border-gray-300 rounded pr-9 text-sm text-[#041627]" value={adminPassword.old} onChange={(e) => setAdminPassword({...adminPassword, old: e.target.value})} />
                    <button type="button" className="absolute right-2 top-2.5 text-gray-500 hover:text-gray-700 cursor-pointer" onClick={() => setShowOldPassword(!showOldPassword)}>
                      {showOldPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <div className="relative">
                    <input type={showNewPassword ? "text" : "password"} placeholder="New Password" className="w-full p-2 border border-gray-300 rounded pr-9 text-sm text-[#041627]" value={adminPassword.new} onChange={(e) => setAdminPassword({...adminPassword, new: e.target.value})} />
                    <button type="button" className="absolute right-2 top-2.5 text-gray-500 hover:text-gray-700 cursor-pointer" onClick={() => setShowNewPassword(!showNewPassword)}>
                      {showNewPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <div className="relative">
                    <input type={showConfirmPassword ? "text" : "password"} placeholder="Confirm New Password" className="w-full p-2 border border-gray-300 rounded pr-9 text-sm text-[#041627]" value={adminPassword.confirm} onChange={(e) => setAdminPassword({...adminPassword, confirm: e.target.value})} />
                    <button type="button" className="absolute right-2 top-2.5 text-gray-500 hover:text-gray-700 cursor-pointer" onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                      {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <button 
                    type="button"
                    className="w-full py-2.5 bg-[#041627] hover:bg-[#0a2640] text-white rounded font-bold text-xs transition-colors shadow-sm cursor-pointer active:scale-[0.99]" 
                    onClick={handleChangePassword}
                  >
                    Change Password
                  </button>
                </div>

                <div className="bg-white rounded-xl border border-red-200 p-6 shadow-sm space-y-4">
                  <h3 className="text-base font-bold text-red-600">Platform Security</h3>
                  <p className="text-sm text-gray-600">Warning: This action will permanently remove all data, including users and site settings, except for the admin account.</p>
                  
                  {isResetting ? (
                    <div className="p-3.5 bg-red-50 border border-red-300 rounded-lg flex items-center justify-center gap-2 text-xs font-bold text-red-700 animate-pulse">
                      <RefreshCw className="w-4 h-4 animate-spin text-red-600" />
                      Deleting all user accounts & database data (preserving Admin)...
                    </div>
                  ) : showResetConfirm ? (
                    <div className="p-3 bg-red-50 border border-red-300 rounded-lg space-y-3">
                      <p className="text-xs font-semibold text-red-800">Are you sure you want to permanently reset all platform data? (All user accounts, products, and database records will be deleted; only the Admin account will be kept)</p>
                      <div className="flex items-center gap-2">
                        <button 
                          type="button"
                          className="flex-1 py-2 bg-red-600 text-white rounded font-bold text-xs hover:bg-red-700 transition-colors cursor-pointer flex items-center justify-center gap-1"
                          onClick={handleFactoryReset}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          Yes, Confirm Reset
                        </button>
                        <button 
                          type="button"
                          className="px-3 py-2 bg-gray-200 text-gray-700 rounded font-bold text-xs hover:bg-gray-300 transition-colors cursor-pointer"
                          onClick={() => setShowResetConfirm(false)}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      type="button"
                      className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded font-bold text-xs transition-colors shadow-sm cursor-pointer active:scale-[0.99] flex items-center justify-center gap-1.5"
                      onClick={() => setShowResetConfirm(true)}
                    >
                      <Trash2 className="w-4 h-4" />
                      Factory Reset
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}


          {/* TOP 3 RANKINGS & FEATURED MANAGEMENT TAB */}
          {activeTab === 'top-rankings' && (
            <div className="space-y-8">
              <div className="flex justify-between items-center bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm">
                <div>
                  <h1 className="text-2xl font-bold text-[#041627]">Top 3 Rankings & Featured Management</h1>
                  <p className="text-xs text-[#44474c] mt-1">Select, replace, reorder, and manage the Top 3 Experts and Top 3 Sellers displayed on the frontend in real time.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* TOP 3 EXPERTS MANAGER */}
                <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-base font-bold text-[#041627]">Top 3 Experts Ranking</h3>
                      <p className="text-xs text-[#44474c]">Frontend displays exactly top 3 experts in order</p>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 bg-amber-100 text-amber-800 rounded-full">
                      {topExpertIds.length} / 3 Selected
                    </span>
                  </div>

                  {/* Current Top 3 List */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Current Top 3 Ordered List</h4>
                    {topExpertIds.length === 0 ? (
                      <p className="text-xs text-slate-400 italic p-4 bg-slate-50 rounded-lg text-center">No Top Experts selected. Add experts from the list below.</p>
                    ) : (
                      topExpertIds.map((id, index) => {
                        const expObj = users.find(u => u.email === id || u.id === id) || {
                          fullName: id,
                          professionType: 'Expert',
                          email: id,
                          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                        };
                        return (
                          <div key={id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                            <div className="flex items-center gap-3">
                              <span className="w-6 h-6 bg-[#041627] text-white rounded-full flex items-center justify-center font-bold text-[10px]">
                                #{index + 1}
                              </span>
                              <img src={expObj.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} alt="" className="w-9 h-9 rounded-lg object-cover" />
                              <div>
                                <p className="font-bold text-[#041627]">{expObj.fullName || (expObj as any).name || id}</p>
                                <p className="text-[10px] text-slate-500">{expObj.professionType || (expObj as any).profession || 'Expert'}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <button
                                disabled={index === 0}
                                onClick={() => {
                                  const arr = [...topExpertIds];
                                  const temp = arr[index - 1];
                                  arr[index - 1] = arr[index];
                                  arr[index] = temp;
                                  updateTopExperts(arr);
                                }}
                                className="p-1.5 bg-white hover:bg-slate-200 rounded border border-slate-300 text-slate-700 disabled:opacity-30 cursor-pointer"
                                title="Move Up"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                disabled={index === topExpertIds.length - 1}
                                onClick={() => {
                                  const arr = [...topExpertIds];
                                  const temp = arr[index + 1];
                                  arr[index + 1] = arr[index];
                                  arr[index] = temp;
                                  updateTopExperts(arr);
                                }}
                                className="p-1.5 bg-white hover:bg-slate-200 rounded border border-slate-300 text-slate-700 disabled:opacity-30 cursor-pointer"
                                title="Move Down"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  updateTopExperts(topExpertIds.filter(item => item !== id));
                                }}
                                className="p-1.5 bg-red-50 hover:bg-red-100 rounded border border-red-200 text-red-600 cursor-pointer ml-2"
                                title="Remove from Top 3"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Add / Filter Available Experts */}
                  <div className="space-y-3 pt-4 border-t border-slate-200">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Add Approved Experts</h4>
                    <input
                      type="text"
                      placeholder="Search experts by name or email..."
                      value={expertSearch}
                      onChange={e => setExpertSearch(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-[#fd8b00]"
                    />
                    <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                      {users
                        .filter(u => u.accountType === 'Expert' && u.status === 'Active')
                        .filter(u => 
                          u.fullName.toLowerCase().includes(expertSearch.toLowerCase()) ||
                          u.email.toLowerCase().includes(expertSearch.toLowerCase()) ||
                          (u.professionType && u.professionType.toLowerCase().includes(expertSearch.toLowerCase()))
                        )
                        .map(u => {
                          const isAlreadySelected = topExpertIds.includes(u.email) || topExpertIds.includes(u.id);
                          return (
                            <div key={u.id} className="flex items-center justify-between p-2.5 bg-white rounded-lg border border-slate-200 text-xs">
                              <div className="flex items-center gap-2.5">
                                <img src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'} alt="" className="w-8 h-8 rounded-lg object-cover" />
                                <div>
                                  <p className="font-bold text-[#041627]">{u.fullName}</p>
                                  <p className="text-[10px] text-slate-500">{u.professionType || 'Expert'} • {u.email}</p>
                                </div>
                              </div>
                              <button
                                disabled={isAlreadySelected || topExpertIds.length >= 3}
                                onClick={() => {
                                  if (topExpertIds.length < 3 && !isAlreadySelected) {
                                    updateTopExperts([...topExpertIds, u.email]);
                                  }
                                }}
                                className={`px-3 py-1.5 rounded-lg font-bold text-[11px] transition-all ${
                                  isAlreadySelected 
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                                    : topExpertIds.length >= 3 
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                    : 'bg-[#fd8b00] hover:bg-[#e07b00] text-white cursor-pointer active:scale-95'
                                }`}
                              >
                                {isAlreadySelected ? 'In Top 3' : 'Add to Top 3'}
                              </button>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>

                {/* TOP 3 SELLERS MANAGER */}
                <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-base font-bold text-[#041627]">Top 3 Sellers Ranking</h3>
                      <p className="text-xs text-[#44474c]">Frontend displays exactly top 3 sellers in order</p>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 bg-blue-100 text-blue-800 rounded-full">
                      {topSellerIds.length} / 3 Selected
                    </span>
                  </div>

                  {/* Current Top 3 List */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Current Top 3 Ordered List</h4>
                    {topSellerIds.length === 0 ? (
                      <p className="text-xs text-slate-400 italic p-4 bg-slate-50 rounded-lg text-center">No Top Sellers selected. Add shopkeepers from the list below.</p>
                    ) : (
                      topSellerIds.map((id, index) => {
                        const sellerObj = users.find(u => u.email === id || u.id === id) || {
                          fullName: id,
                          email: id,
                          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
                        };
                        return (
                          <div key={id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                            <div className="flex items-center gap-3">
                              <span className="w-6 h-6 bg-[#041627] text-white rounded-full flex items-center justify-center font-bold text-[10px]">
                                #{index + 1}
                              </span>
                              <img src={sellerObj.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'} alt="" className="w-9 h-9 rounded-lg object-cover" />
                              <div>
                                <p className="font-bold text-[#041627]">{sellerObj.fullName || id}</p>
                                <p className="text-[10px] text-slate-500">Shopkeeper • {sellerObj.email}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <button
                                disabled={index === 0}
                                onClick={() => {
                                  const arr = [...topSellerIds];
                                  const temp = arr[index - 1];
                                  arr[index - 1] = arr[index];
                                  arr[index] = temp;
                                  updateTopSellers(arr);
                                }}
                                className="p-1.5 bg-white hover:bg-slate-200 rounded border border-slate-300 text-slate-700 disabled:opacity-30 cursor-pointer"
                                title="Move Up"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                disabled={index === topSellerIds.length - 1}
                                onClick={() => {
                                  const arr = [...topSellerIds];
                                  const temp = arr[index + 1];
                                  arr[index + 1] = arr[index];
                                  arr[index] = temp;
                                  updateTopSellers(arr);
                                }}
                                className="p-1.5 bg-white hover:bg-slate-200 rounded border border-slate-300 text-slate-700 disabled:opacity-30 cursor-pointer"
                                title="Move Down"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  updateTopSellers(topSellerIds.filter(item => item !== id));
                                }}
                                className="p-1.5 bg-red-50 hover:bg-red-100 rounded border border-red-200 text-red-600 cursor-pointer ml-2"
                                title="Remove from Top 3"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Add / Filter Available Sellers */}
                  <div className="space-y-3 pt-4 border-t border-slate-200">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Add Approved Shopkeepers</h4>
                    <input
                      type="text"
                      placeholder="Search shopkeepers by name or email..."
                      value={sellerSearch}
                      onChange={e => setSellerSearch(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500"
                    />
                    <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                      {users
                        .filter(u => u.accountType === 'Shopkeeper' && u.status === 'Active')
                        .filter(u => 
                          u.fullName.toLowerCase().includes(sellerSearch.toLowerCase()) ||
                          u.email.toLowerCase().includes(sellerSearch.toLowerCase())
                        )
                        .map(u => {
                          const isAlreadySelected = topSellerIds.includes(u.email) || topSellerIds.includes(u.id);
                          return (
                            <div key={u.id} className="flex items-center justify-between p-2.5 bg-white rounded-lg border border-slate-200 text-xs">
                              <div className="flex items-center gap-2.5">
                                <img src={u.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'} alt="" className="w-8 h-8 rounded-lg object-cover" />
                                <div>
                                  <p className="font-bold text-[#041627]">{u.fullName}</p>
                                  <p className="text-[10px] text-slate-500">Shopkeeper • {u.email}</p>
                                </div>
                              </div>
                              <button
                                disabled={isAlreadySelected || topSellerIds.length >= 3}
                                onClick={() => {
                                  if (topSellerIds.length < 3 && !isAlreadySelected) {
                                    updateTopSellers([...topSellerIds, u.email]);
                                  }
                                }}
                                className={`px-3 py-1.5 rounded-lg font-bold text-[11px] transition-all ${
                                  isAlreadySelected 
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                                    : topSellerIds.length >= 3 
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                    : 'bg-blue-600 hover:bg-blue-700 text-white cursor-pointer active:scale-95'
                                }`}
                              >
                                {isAlreadySelected ? 'In Top 3' : 'Add to Top 3'}
                              </button>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* EMAIL TEMPLATES & DISPATCHER TAB */}
          {activeTab === 'email-templates' && (
            <div className="space-y-8 animate-fadeIn">
              {/* Header matching screenshot */}
              <div className="bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[#fd8b00]">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h1 className="text-xl sm:text-2xl font-bold text-[#041627]">System Email Gateway & Templates</h1>
                    <p className="text-xs text-[#44474c] mt-1">Configure live SMTP credentials, customize automated notification templates, and verify real-time email delivery.</p>
                  </div>
                </div>
                <div className="text-xs bg-amber-50 text-amber-900 border border-amber-200 py-1.5 px-4 rounded-lg font-bold">
                  {emailTemplates.length} Active Templates
                </div>
              </div>

              {/* Live SMTP Gateway Configuration Panel */}
              <SmtpSettingsPanel />

              {/* Template Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {emailTemplates.map((tpl) => (
                  <div key={tpl.id} className="bg-white rounded-xl border border-[#c4c6cd]/40 shadow-sm p-6 flex flex-col justify-between hover:shadow-md transition-all">
                    <div>
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="font-bold text-slate-900 text-sm sm:text-base">{tpl.name}</h3>
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
                          Active
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 font-medium mb-4">
                        <strong className="text-slate-900">Subject:</strong> {tpl.subject}
                      </p>
                      <div className="bg-amber-50/70 border border-amber-200/60 rounded-lg p-2.5 mb-6">
                        <p className="text-[10px] font-bold uppercase tracking-wider text-amber-900 mb-1">Tokens:</p>
                        <p className="font-mono text-[11px] text-amber-800 break-words">
                          {tpl.tokens.join(', ')}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => setEditingTemplate(tpl)}
                      className="w-full py-2.5 px-4 bg-[#041627] hover:bg-[#102a43] text-white rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                    >
                      <Edit className="w-3.5 h-3.5 text-[#fd8b00]" />
                      Edit Template & Preview
                    </button>
                  </div>
                ))}
              </div>

              {/* Edit Template & Preview Modal */}
              {editingTemplate && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
                  <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 border border-slate-200 shadow-2xl relative my-8 max-h-[90vh] overflow-y-auto">
                    <button
                      onClick={() => setEditingTemplate(null)}
                      className="absolute top-4 right-4 p-2 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      <X className="w-5 h-5 text-slate-500" />
                    </button>

                    <h3 className="text-lg font-bold text-[#041627] mb-1">Edit & Preview Template</h3>
                    <p className="text-xs text-slate-500 mb-6">Modify subject, HTML/text body structure, and send instant test email previews.</p>

                    <form onSubmit={handleSaveTemplate} className="space-y-5">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Template Name</label>
                        <input
                          type="text"
                          value={editingTemplate.name}
                          onChange={(e) => setEditingTemplate({ ...editingTemplate, name: e.target.value })}
                          className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-semibold text-slate-800 focus:outline-none focus:border-[#fd8b00]"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Email Subject Line</label>
                        <input
                          type="text"
                          value={editingTemplate.subject}
                          onChange={(e) => setEditingTemplate({ ...editingTemplate, subject: e.target.value })}
                          className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-semibold text-slate-800 focus:outline-none focus:border-[#fd8b00]"
                          required
                        />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-1.5">
                          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Available Substitution Tokens</label>
                          <span className="text-[10px] text-slate-400 font-medium">Click to insert</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5 p-2.5 bg-amber-50/50 border border-amber-200 rounded-xl">
                          {editingTemplate.tokens.map((token: string) => (
                            <button
                              key={token}
                              type="button"
                              onClick={() => setEditingTemplate({ ...editingTemplate, body: editingTemplate.body + ' ' + token })}
                              className="text-[11px] font-mono font-bold bg-amber-100 text-amber-900 px-2 py-1 rounded border border-amber-200 hover:bg-amber-200 transition-colors cursor-pointer"
                            >
                              {token}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Email Body Template</label>
                        <textarea
                          rows={7}
                          value={editingTemplate.body}
                          onChange={(e) => setEditingTemplate({ ...editingTemplate, body: e.target.value })}
                          className="w-full text-xs p-3 border border-slate-200 rounded-xl bg-slate-50 font-mono text-slate-800 focus:outline-none focus:border-[#fd8b00]"
                          required
                        />
                      </div>

                      {/* Test Email Dispatch Section */}
                      <div className="pt-4 border-t border-slate-100 space-y-3 bg-slate-50 p-4 rounded-xl">
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Test Email Dispatch</label>
                        <div className="flex gap-2">
                          <input
                            type="email"
                            placeholder="Enter test recipient email..."
                            value={testEmailRecipient}
                            onChange={(e) => setTestEmailRecipient(e.target.value)}
                            className="flex-1 text-xs p-3 border border-slate-200 rounded-xl bg-white font-semibold text-slate-800 focus:outline-none focus:border-[#fd8b00]"
                          />
                          <button
                            type="button"
                            onClick={handleSendTestEmail}
                            disabled={isSendingTest}
                            className="px-4 py-3 bg-[#fd8b00] hover:bg-orange-600 text-white rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer shrink-0"
                          >
                            <Send className="w-3.5 h-3.5" />
                            {isSendingTest ? 'Sending...' : 'Send Test'}
                          </button>
                        </div>
                      </div>

                      <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setEditingTemplate(null)}
                          className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-100 transition-colors cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-6 py-2.5 rounded-xl bg-[#041627] hover:bg-[#102a43] text-white font-bold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-md"
                        >
                          <Save className="w-4 h-4 text-[#fd8b00]" />
                          Save Template Changes
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ENTERPRISE MANAGEMENT PORTALS */}
          {['platform', 'homepage', 'categories', 'products', 'orders', 'payments', 'reviews', 'messages', 'notifications', 'reports', 'logs'].includes(activeTab) && (
            <AdminEnterprisePortal activeTab={activeTab as any} adminName={user.displayName} />
          )}

        </div>
      </main>

      {/* System Alert Modal */}
      {alertOpen && (
        <div className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-sm w-full text-center relative">
            <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-base font-bold text-[#041627] mb-2">Simulated Diagnostic Ok</h3>
            <p className="text-xs text-[#44474c] leading-relaxed mb-6">
              Platform cloud server checks completed successfully. Firestore security policies, container ingress gateways, and payment pipelines are operating securely.
            </p>
            <button 
              onClick={() => setAlertOpen(false)}
              className="w-full py-2 bg-[#041627] text-white rounded text-xs font-semibold hover:bg-[#1a2b3c] transition-all"
            >
              Acknowledge Workspace
            </button>
          </div>
        </div>
      )}

      {/* Changes Published Success Modal */}
      {showPublishSuccessModal && (
        <div id="publish-success-modal" className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-sm w-full text-center relative border border-gray-100 animate-in fade-in zoom-in-95 duration-200">
            <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-base font-bold text-[#041627] mb-2">Publish Success</h3>
            <p className="text-xs text-[#44474c] leading-relaxed mb-6">
              Changes published successfully.
            </p>
            <button 
              id="publish-success-ok-btn"
              onClick={() => setShowPublishSuccessModal(false)}
              className="w-full py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded text-xs font-semibold transition-all shadow-md hover:shadow-lg"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* Delete User Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-sm w-full text-center relative border border-gray-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-12 h-12 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#041627] mb-2">Permanently Delete Account</h3>
            <p className="text-xs text-[#44474c] leading-relaxed mb-6">
              Are you sure you want to permanently delete this account? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded text-xs font-semibold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button 
                onClick={handleConfirmDeleteUser}
                className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-semibold transition-all shadow-md hover:shadow-lg cursor-pointer"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Password Reset Modal */}
      {passwordResetModal && (
        <div className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-sm w-full text-center relative border border-gray-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-12 h-12 bg-sky-50 text-sky-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-[#041627] mb-2">Reset Password for {passwordResetModal.name}</h3>
            <p className="text-xs text-[#44474c] leading-relaxed mb-4">
              Enter a new password for <span className="font-bold">{passwordResetModal.email}</span>.
            </p>
            <div className="relative mb-3">
              <input
                type={showResetModalPass ? "text" : "password"}
                className="w-full p-2.5 border border-gray-300 rounded pr-10 text-sm text-[#041627] outline-none focus:border-[#fd8b00]"
                placeholder="New Password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
              <button
                type="button"
                onClick={() => setShowResetModalPass(!showResetModalPass)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 p-1 rounded focus:outline-none cursor-pointer"
                aria-label={showResetModalPass ? "Hide password" : "Show password"}
              >
                {showResetModalPass ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <div className="relative mb-4">
              <input
                type={showResetModalPass ? "text" : "password"}
                className="w-full p-2.5 border border-gray-300 rounded pr-10 text-sm text-[#041627] outline-none focus:border-[#fd8b00]"
                placeholder="Confirm New Password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
              />
            </div>
            {resetError && (
              <div className="mb-4 p-3 bg-red-50 text-red-600 border border-red-100 rounded text-xs text-left max-h-32 overflow-y-auto">
                {resetError}
              </div>
            )}
            <div className="flex gap-3">
              <button 
                onClick={() => setPasswordResetModal(null)}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded text-xs font-semibold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button 
                onClick={handleConfirmPasswordReset}
                disabled={isResettingPass}
                className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded text-xs font-semibold transition-all shadow-md hover:shadow-lg cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isResettingPass ? '... ' : ''}Reset Password
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW USER DETAILS MODAL */}
      {isViewing && selectedUser && (
        <AdminUserProfileModal 
          user={selectedUser}
          onClose={() => { setIsViewing(false); setSelectedUser(null); }}
          onUpdateUser={(updated) => {
            setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
          }}
          onSuspendUser={(id) => {
            handleSuspendUser(id);
          }}
          onReactivateUser={(id) => {
            handleReactivateUser(id);
          }}
          onDeleteUser={(id) => {
            const u = users.find(x => x.id === id);
            handleDeleteUser(id, u ? u.fullName : 'User');
          }}
          onSendMessage={(email) => {
            setIsViewing(false);
            setSelectedUser(null);
            setActiveTab('messages');
          }}
          showToast={(msg) => alert(msg)}
        />
      )}

      {/* EDIT USER DETAILS MODAL */}
      {isEditing && selectedUser && editForm && (
        <div className="fixed inset-0 bg-[#041627]/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full relative border border-gray-100 animate-in fade-in zoom-in-95 duration-200">
            <button 
              onClick={() => { setIsEditing(false); setSelectedUser(null); setEditForm(null); }}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <h3 className="text-base font-bold text-[#041627] mb-4">Edit User Profile</h3>
            
            {/* Profile Photo Upload */}
            <div className="flex flex-col items-center justify-center space-y-2 pb-3 border-b border-gray-100 mb-4">
              <div className="relative group">
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#fd8b00]/30 shadow-md flex items-center justify-center bg-[#eff4ff] transition-all">
                  {editForm.avatar ? (
                    <img src={editForm.avatar} alt="Profile preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-gray-400">
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              <label className="cursor-pointer bg-white border border-[#fd8b00]/30 hover:border-[#fd8b00] text-[10px] font-semibold px-2.5 py-1 rounded text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
                <span>Change Photo</span>
                <input
                  type="file"
                  accept="image/jpeg,image/jpg,image/png,image/webp"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      try {
                        const opt = await optimizeImage(file, 512, 0.85);
                        setEditForm({ ...editForm, avatar: opt.dataUrl });
                      } catch {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          if (typeof reader.result === 'string') {
                            setEditForm({ ...editForm, avatar: reader.result });
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }
                  }}
                />
              </label>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-[#44474c] mb-1">Full Name</label>
                <input 
                  type="text"
                  value={editForm.fullName}
                  onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] mb-1">Email Address</label>
                <input 
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#44474c] mb-1">Phone Number</label>
                <input 
                  type="text"
                  value={editForm.phone}
                  onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                  className="w-full text-xs p-2.5 bg-white border border-[#c4c6cd] rounded focus:outline-none focus:border-[#fd8b00]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1">Account Type</label>
                  <select 
                    value={editForm.accountType}
                    onChange={(e) => setEditForm({ ...editForm, accountType: e.target.value as any })}
                    className="w-full text-xs p-2 border border-[#c4c6cd] bg-white rounded focus:outline-none focus:border-[#fd8b00]"
                  >
                    <option value="Homeowner">Homeowner</option>
                    <option value="Expert">Expert</option>
                    <option value="Shopkeeper">Shopkeeper</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#44474c] mb-1">Account Status</label>
                  <select 
                    value={editForm.status}
                    onChange={(e) => setEditForm({ ...editForm, status: e.target.value as any })}
                    className="w-full text-xs p-2 border border-[#c4c6cd] bg-white rounded focus:outline-none focus:border-[#fd8b00]"
                  >
                    <option value="Pending">Pending</option>
                    <option value="Active">Active</option>
                    <option value="Suspended">Suspended</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="pt-6 flex gap-3">
              <button 
                onClick={handleSaveEdit}
                className="flex-1 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded text-xs font-semibold shadow transition-all"
              >
                Save Changes
              </button>
              <button 
                onClick={() => { setIsEditing(false); setSelectedUser(null); setEditForm(null); }}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      </div>
    </div>
  );
}
