import React, { useState, useRef } from 'react';
import { Upload, X, Image as ImageIcon, Loader2, RefreshCw, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';
import { uploadFileFast } from '../lib/fileUploader';

interface ImageUploaderProps {
  label?: string;
  value: string;
  onChange: (url: string) => void;
  onRemove: () => void;
  maxSizeMB?: number;
  className?: string;
  imageClassName?: string;
  disabled?: boolean;
}

const SUPPORTED_FORMATS = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml', 'image/webp'];

export default function ImageUploader({ 
  label, 
  value, 
  onChange, 
  onRemove, 
  maxSizeMB = 5,
  className = '',
  imageClassName = 'max-h-36 object-contain',
  disabled = false
}: ImageUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    if (disabled) return;
    setError(null);

    // Validate format
    if (!SUPPORTED_FORMATS.includes(file.type)) {
      setError('Unsupported file type. Use PNG, JPG, JPEG, SVG, or WebP.');
      return;
    }

    // Validate size
    if (file.size > maxSizeMB * 1024 * 1024) {
      setError(`File is too large (${(file.size / (1024 * 1024)).toFixed(1)}MB). Max size is ${maxSizeMB}MB.`);
      return;
    }

    setIsUploading(true);
    setProgress(10);

    try {
      const downloadUrl = await uploadFileFast(file, {
        folder: 'platform_branding',
        maxDimension: 1920,
        quality: 0.85,
        onProgress: (p) => setProgress(p)
      });
      onChange(downloadUrl);
    } catch (err: any) {
      console.error('Image upload failed:', err);
      setError(err?.message || 'Failed to upload image. Please try again.');
    } finally {
      setIsUploading(false);
      setProgress(0);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (!disabled && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFile(e.target.files[0]);
      e.target.value = ''; // Reset input
    }
  };

  return (
    <div className={`space-y-2 flex-1 flex flex-col justify-center ${className}`}>
      {label && <label className="block text-[#041627] font-semibold text-xs">{label}</label>}
      
      {error && (
        <div className="flex items-center gap-1.5 text-red-600 text-xs font-medium bg-red-50/80 border border-red-100 p-2.5 rounded-xl">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span className="flex-1">{error}</span>
          <button type="button" onClick={() => setError(null)} className="text-red-400 hover:text-red-600">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {value ? (
        <div className="relative group rounded-xl border border-slate-200/90 bg-slate-50/50 p-3 flex flex-col items-center justify-center transition-all overflow-hidden h-40">
          <img 
            src={value} 
            alt={label || 'Asset Preview'} 
            className={`rounded-lg bg-white p-1.5 shadow-sm border border-slate-100 transition-transform group-hover:scale-105 ${imageClassName}`} 
            loading="lazy"
          />
          
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center gap-2 p-2">
            <button 
              type="button"
              disabled={disabled || isUploading}
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 bg-white hover:bg-slate-50 text-slate-900 text-xs font-bold px-3 py-2 rounded-xl shadow-md hover:scale-105 transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#fd8b00]" />
              Replace
            </button>
            <button 
              type="button"
              disabled={disabled || isUploading}
              onClick={() => {
                setError(null);
                onRemove();
              }}
              className="inline-flex items-center gap-1.5 bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-3 py-2 rounded-xl shadow-md hover:scale-105 transition-all cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Remove
            </button>
          </div>

          <div className="absolute bottom-2 left-2 bg-emerald-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 backdrop-blur-sm pointer-events-none group-hover:opacity-0 transition-opacity">
            <CheckCircle2 className="w-3 h-3" /> Configured
          </div>

          <input 
            type="file" 
            ref={fileInputRef}
            accept={SUPPORTED_FORMATS.join(',')} 
            onChange={onFileChange} 
            className="hidden" 
          />
        </div>
      ) : (
        <div 
          className={`border-2 border-dashed rounded-xl p-4 h-40 flex flex-col items-center justify-center transition-all cursor-pointer text-center relative
            ${isDragging ? 'border-[#fd8b00] bg-[#fd8b00]/10 scale-[1.01]' : 'border-slate-200 hover:border-slate-300 bg-slate-50/50 hover:bg-slate-50'}
            ${isUploading || disabled ? 'opacity-70 pointer-events-none' : ''}
          `}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onDrop={onDrop}
          onClick={() => !isUploading && !disabled && fileInputRef.current?.click()}
        >
          {isUploading ? (
            <div className="flex flex-col items-center gap-2.5 w-full max-w-[200px]">
              <Loader2 className="w-6 h-6 animate-spin text-[#fd8b00]" />
              <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                <div 
                  className="bg-[#fd8b00] h-full transition-all duration-300 rounded-full" 
                  style={{ width: `${progress}%` }} 
                />
              </div>
              <span className="text-xs font-semibold text-slate-700">{progress}% Uploading...</span>
            </div>
          ) : (
            <>
              <div className="p-2.5 rounded-xl bg-white border border-slate-100 shadow-sm text-slate-400 mb-2 group-hover:text-[#fd8b00] transition-colors">
                <ImageIcon className="w-5 h-5 text-[#fd8b00]" />
              </div>
              <p className="text-xs font-bold text-slate-700">Click or drag image to upload</p>
              <p className="text-[10px] text-slate-400 mt-1">PNG, JPG, SVG or WebP (max {maxSizeMB}MB)</p>
            </>
          )}

          <input 
            type="file" 
            ref={fileInputRef}
            accept={SUPPORTED_FORMATS.join(',')} 
            onChange={onFileChange} 
            className="hidden" 
          />
        </div>
      )}
    </div>
  );
}

