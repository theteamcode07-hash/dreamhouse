import React, { useState, useEffect } from 'react';
import { 
  X, User, Mail, Phone, MapPin, Calendar, Shield, Clock, 
  CheckCircle, AlertTriangle, Star, Briefcase, Store, Award, 
  Building, Sparkles, CheckCircle2, MessageCircle, Sun, Moon
} from 'lucide-react';
import { collection, query, where, onSnapshot, getDocs, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { subscribeToPresence } from '../lib/presence';
import { optimizeImage } from '../lib/fileUploader';
import { useTheme } from '../lib/theme';

interface UserProfileModalProps {
  userEmailOrId: string | null;
  onClose: () => void;
  presenceMap?: Record<string, boolean>;
  onSendMessage?: (email: string) => void;
}

export default function UserProfileModal({
  userEmailOrId,
  onClose,
  presenceMap: presenceMapProp,
  onSendMessage
}: UserProfileModalProps) {
  const { theme, toggleTheme } = useTheme();
  const [profileData, setProfileData] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [presenceMapState, setPresenceMapState] = useState<Record<string, boolean>>({});
  const [reviewsData, setReviewsData] = useState<{ rating: number; count: number }>({ rating: 0, count: 0 });

  // 1. Presence Listener
  useEffect(() => {
    if (presenceMapProp) {
      setPresenceMapState(presenceMapProp);
      return;
    }
    const unsub = subscribeToPresence((pMap) => setPresenceMapState(pMap));
    return () => unsub();
  }, [presenceMapProp]);

  // 2. Fetch User Profile Data from Firestore & Fallbacks
  useEffect(() => {
    if (!userEmailOrId) {
      setProfileData(null);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const identifierLower = userEmailOrId.trim().toLowerCase();

    let isSubscribed = true;

    // Helper to merge and set profile state
    const updateProfileData = (raw: any) => {
      if (!isSubscribed || !raw) return;

      const email = raw.email || raw.contact || identifierLower;
      const roleRaw = (raw.role || raw.accountType || raw.userRole || 'homeowner').toLowerCase();

      let mappedRole: 'homeowner' | 'professional' | 'shopkeeper' | 'admin' = 'homeowner';
      if (roleRaw.includes('expert') || roleRaw.includes('prof') || roleRaw.includes('architect') || roleRaw.includes('engineer')) {
        mappedRole = 'professional';
      } else if (roleRaw.includes('shop') || roleRaw.includes('seller') || roleRaw.includes('vendor')) {
        mappedRole = 'shopkeeper';
      } else if (roleRaw.includes('admin')) {
        mappedRole = 'admin';
      }

      setProfileData({
        id: raw.id || raw.uid || `user-${email}`,
        fullName: raw.fullName || raw.name || raw.username || email.split('@')[0],
        username: raw.username || (raw.fullName ? raw.fullName.toLowerCase().replace(/\s+/g, '') : email.split('@')[0]),
        email: email,
        phone: raw.phone || raw.contactNumber || raw.mobile || 'N/A',
        role: mappedRole,
        accountType: raw.accountType || (mappedRole === 'professional' ? 'Expert' : mappedRole === 'shopkeeper' ? 'Shopkeeper' : mappedRole === 'admin' ? 'Admin' : 'Homeowner'),
        avatar: raw.avatar || raw.photo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        status: raw.status || raw.accountStatus || 'Active',
        emailVerified: raw.emailVerified || 'Verified',
        registrationDate: raw.registrationDate || raw.createdAt || 'Jul 24, 2026',
        
        // Location details
        province: raw.province || raw.state || 'Bagmati Province',
        district: raw.district || 'Kathmandu',
        municipality: raw.municipality || 'Kathmandu Metropolitan',
        address: raw.address || raw.location || raw.shopAddress || 'Kathmandu, Nepal',
        
        // About / Bio
        bio: raw.bio || raw.about || raw.tagline || 'Passionate about structural designs, construction quality, and innovative home engineering.',

        // Expert specific
        professionType: raw.professionType || raw.profession || raw.role || (mappedRole === 'professional' ? 'Architect & Design Specialist' : undefined),
        yearsOfExperience: raw.yearsOfExperience ?? raw.experience ?? (mappedRole === 'professional' ? 8 : undefined),
        skillsOrTags: raw.skillsOrTags || raw.skills || (mappedRole === 'professional' ? ['3D Blueprints', 'Structural Calculations', 'Interior Design', 'Site Inspection'] : []),
        certifications: raw.certifications || (mappedRole === 'professional' ? 'PE Certified Structural Engineer, LEED AP' : undefined),

        // Shopkeeper specific
        shopName: raw.shopName || raw.businessName || (mappedRole === 'shopkeeper' ? 'ProBuild Building Supplies' : undefined),
        businessCategory: raw.businessCategory || raw.category || (mappedRole === 'shopkeeper' ? 'Hardware & Heavy Materials' : undefined),
        shopAddress: raw.shopAddress || raw.address || (mappedRole === 'shopkeeper' ? 'Ring Road Industrial Sector, Kathmandu' : undefined),
        businessRegistrationNumber: raw.businessRegistrationNumber || raw.regNo || (mappedRole === 'shopkeeper' ? 'PAN-982341882' : undefined),

        // Rating summary
        rating: raw.rating ?? 4.9,
        reviewsCount: raw.reviewsCount ?? raw.reviews ?? 14
      });
      setIsLoading(false);
    };

    // 1. Check local fallbacks first to render instantly
    let localFound: any = null;
    try {
      const accountsRaw = localStorage.getItem('dreamhouse_accounts');
      if (accountsRaw) {
        const list = JSON.parse(accountsRaw);
        if (Array.isArray(list)) {
          localFound = list.find((a: any) => a.email?.toLowerCase() === identifierLower || a.id === userEmailOrId);
        }
      }
      if (!localFound) {
        const adminUsersRaw = localStorage.getItem('dreamhouse_admin_users');
        if (adminUsersRaw) {
          const list = JSON.parse(adminUsersRaw);
          if (Array.isArray(list)) {
            localFound = list.find((a: any) => a.email?.toLowerCase() === identifierLower || a.id === userEmailOrId);
          }
        }
      }
      if (!localFound) {
        const expertsRaw = localStorage.getItem('dreamhouse_experts');
        if (expertsRaw) {
          const list = JSON.parse(expertsRaw);
          if (Array.isArray(list)) {
            localFound = list.find((e: any) => e.contact?.toLowerCase() === identifierLower || e.id === userEmailOrId);
          }
        }
      }
    } catch (e) {
      console.warn("Failed checking local profile fallbacks:", e);
    }

    if (localFound) {
      updateProfileData(localFound);
    }

    // 2. Real-time Firestore document snapshot on 'accounts'
    const qAccounts = query(collection(db, 'accounts'), where('email', '==', identifierLower));
    const unsubAccounts = onSnapshot(qAccounts, (snapshot) => {
      if (!snapshot.empty) {
        const docSnap = snapshot.docs[0];
        updateProfileData({ id: docSnap.id, ...docSnap.data() });
      } else {
        // Try querying 'experts' or 'shopkeepers' or 'users'
        const qExperts = query(collection(db, 'experts'), where('contact', '==', identifierLower));
        getDocs(qExperts).then((expSnap) => {
          if (!expSnap.empty) {
            updateProfileData({ id: expSnap.docs[0].id, ...expSnap.docs[0].data() });
          } else if (!localFound) {
            // Default placeholder if completely unknown
            updateProfileData({
              email: identifierLower,
              fullName: identifierLower.split('@')[0],
              role: 'homeowner'
            });
          }
        }).catch(() => {
          if (!localFound) setIsLoading(false);
        });
      }
    }, (err) => {
      console.warn("Firestore user query snapshot error:", err);
      if (!localFound) setIsLoading(false);
    });

    // 3. Fetch ratings & reviews for this email if applicable
    const fetchReviews = async () => {
      try {
        const qRev = query(collection(db, 'expert_reviews'), where('expertEmail', '==', identifierLower));
        const revSnap = await getDocs(qRev);
        if (!revSnap.empty) {
          const docs = revSnap.docs.map(d => d.data());
          const totalRating = docs.reduce((acc, curr) => acc + (curr.rating || 5), 0);
          const avg = Number((totalRating / docs.length).toFixed(1));
          setReviewsData({ rating: avg, count: docs.length });
        }
      } catch (e) {
        console.warn("Error fetching reviews for profile:", e);
      }
    };
    fetchReviews();

    return () => {
      isSubscribed = false;
      unsubAccounts();
    };
  }, [userEmailOrId]);

  if (!userEmailOrId) return null;

  const isOnline = profileData?.email ? (presenceMapState[profileData.email.toLowerCase()] !== undefined ? presenceMapState[profileData.email.toLowerCase()] : true) : false;

  const getRoleBadgeStyle = (role?: string) => {
    switch (role) {
      case 'professional':
      case 'expert':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'shopkeeper':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'admin':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      default:
        return 'bg-sky-500/20 text-sky-300 border-sky-500/30';
    }
  };

  const getRoleDisplayName = (role?: string) => {
    switch (role) {
      case 'professional':
      case 'expert':
        return 'Expert / Professional';
      case 'shopkeeper':
        return 'Material Shopkeeper';
      case 'admin':
        return 'Workspace Admin';
      default:
        return 'Client / Homeowner';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden relative">
        
        {/* Cover Header */}
        <div className="bg-gradient-to-r from-[#041627] via-[#102a43] to-[#041627] p-6 text-white relative shrink-0">
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer flex items-center justify-center"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-300" />
              ) : (
                <Moon className="w-4 h-4 text-slate-200" />
              )}
            </button>
            <button 
              onClick={onClose}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="Close Profile"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {isLoading ? (
            <div className="py-8 text-center text-slate-300 animate-pulse">
              <p className="text-sm font-semibold">Loading user profile details...</p>
            </div>
          ) : profileData ? (
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 relative pt-2">
              {/* Profile Photo */}
              <div className="relative shrink-0">
                <img 
                  src={profileData.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80"} 
                  alt={profileData.fullName}
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-white/20 shadow-xl bg-slate-800"
                  referrerPolicy="no-referrer"
                />
                <span className={`absolute -bottom-1 -right-1 block h-5 w-5 rounded-full ring-4 ring-[#041627] ${
                  isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                }`} title={isOnline ? 'User is Online' : 'User is Offline'} />
              </div>

              {/* Header Info */}
              <div className="flex-1 text-center sm:text-left space-y-2">
                <div>
                  <h3 className="text-2xl font-bold tracking-tight text-white flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                    {profileData.fullName}
                    {profileData.emailVerified === 'Verified' && (
                      <CheckCircle2 className="w-5 h-5 text-sky-400 shrink-0" title="Email Verified" />
                    )}
                  </h3>
                  <p className="text-xs text-slate-300 font-mono mt-0.5">@{profileData.username}</p>
                </div>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                  <span className={`text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full border ${getRoleBadgeStyle(profileData.role)}`}>
                    {getRoleDisplayName(profileData.role)}
                  </span>

                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 ${
                    isOnline ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-700/50 text-slate-300 border border-slate-600'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-400' : 'bg-slate-400'}`} />
                    {isOnline ? 'Online' : 'Offline'}
                  </span>

                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                    profileData.status === 'Active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                  }`}>
                    Account: {profileData.status}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-6 text-center text-rose-300">
              <p className="text-sm font-semibold">User profile not found.</p>
            </div>
          )}
        </div>

        {/* Scrollable Profile Body */}
        {profileData && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6 text-slate-800 dark:text-slate-100">
            
            {/* Quick Action Bar if onSendMessage provided */}
            {onSendMessage && profileData.email && (
              <div className="flex justify-end">
                <button
                  onClick={() => {
                    onSendMessage(profileData.email);
                    onClose();
                  }}
                  className="bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all shadow-md cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  Send Direct Message
                </button>
              </div>
            )}

            {/* Basic Contact & Identity Card */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-5 border border-slate-200 dark:border-slate-700/60 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <User className="w-4 h-4 text-[#fd8b00]" />
                Contact & Account Details
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="flex items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-slate-400 font-medium">Email Address</p>
                    <p className="font-semibold text-slate-800 dark:text-slate-100 truncate">{profileData.email}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-slate-400 font-medium">Phone Number</p>
                    <p className="font-semibold text-slate-800 dark:text-slate-100 truncate">{profileData.phone}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-slate-400 font-medium">Registration Date</p>
                    <p className="font-semibold text-slate-800 dark:text-slate-100">{profileData.registrationDate}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <Shield className="w-4 h-4 text-slate-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-slate-400 font-medium">Email Verification</p>
                    <p className="font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      {profileData.emailVerified}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Location Card */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-5 border border-slate-200 dark:border-slate-700/60 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#fd8b00]" />
                Location & Address
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] text-slate-400 font-medium">Province</p>
                  <p className="font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.province}</p>
                </div>
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] text-slate-400 font-medium">District</p>
                  <p className="font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.district}</p>
                </div>
                <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] text-slate-400 font-medium">Municipality</p>
                  <p className="font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.municipality}</p>
                </div>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                <p className="text-[10px] text-slate-400 font-medium">Full Address</p>
                <p className="font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.address}</p>
              </div>
            </div>

            {/* About / Bio Card */}
            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-5 border border-slate-200 dark:border-slate-700/60 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#fd8b00]" />
                About & Bio
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                {profileData.bio}
              </p>
            </div>

            {/* Role Specific Section: EXPERT */}
            {(profileData.role === 'professional' || profileData.accountType === 'Expert') && (
              <div className="bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl p-5 border border-amber-200/60 dark:border-amber-900/40 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-amber-500" />
                  Expert Professional Qualifications
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-100 dark:border-slate-800">
                    <p className="text-[10px] text-slate-400 font-medium">Speciality / Profession Title</p>
                    <p className="font-bold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.professionType || 'Architectural Consultant'}</p>
                  </div>

                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-100 dark:border-slate-800">
                    <p className="text-[10px] text-slate-400 font-medium">Years of Experience</p>
                    <p className="font-bold text-amber-600 dark:text-amber-400 text-sm mt-0.5">
                      {profileData.yearsOfExperience ?? 8}+ Years Professional
                    </p>
                  </div>
                </div>

                {/* Skills */}
                {profileData.skillsOrTags && profileData.skillsOrTags.length > 0 && (
                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-100 dark:border-slate-800 space-y-2">
                    <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Skills & Specializations</p>
                    <div className="flex flex-wrap gap-1.5">
                      {profileData.skillsOrTags.map((skill: string, idx: number) => (
                        <span key={idx} className="bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-lg border border-amber-200 dark:border-amber-800/50">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Ratings & Reviews */}
                <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-amber-100 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] text-slate-400 font-medium">Ratings & Reviews</p>
                    <div className="flex items-center gap-1.5 mt-1">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      <span className="text-sm font-black text-slate-800 dark:text-slate-100">
                        {reviewsData.count > 0 ? reviewsData.rating : profileData.rating || 4.9}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">
                        ({reviewsData.count > 0 ? reviewsData.count : profileData.reviewsCount || 14} client reviews)
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 px-2.5 py-1 rounded-full font-bold border border-emerald-200 dark:border-emerald-800">
                      Verified Expert
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Role Specific Section: SHOPKEEPER */}
            {(profileData.role === 'shopkeeper' || profileData.accountType === 'Shopkeeper') && (
              <div className="bg-emerald-50/50 dark:bg-emerald-950/20 rounded-2xl p-5 border border-emerald-200/60 dark:border-emerald-900/40 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                  <Store className="w-4 h-4 text-emerald-500" />
                  Supplier & Shop Details
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-emerald-100 dark:border-slate-800">
                    <p className="text-[10px] text-slate-400 font-medium">Shop Name</p>
                    <p className="font-bold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.shopName || 'ProBuild Material Hub'}</p>
                  </div>

                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-emerald-100 dark:border-slate-800">
                    <p className="text-[10px] text-slate-400 font-medium">Business Category</p>
                    <p className="font-bold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.businessCategory || 'Hardware & Construction Supplies'}</p>
                  </div>

                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-emerald-100 dark:border-slate-800">
                    <p className="text-[10px] text-slate-400 font-medium">Shop Address</p>
                    <p className="font-bold text-slate-800 dark:text-slate-100 mt-0.5">{profileData.shopAddress || profileData.address}</p>
                  </div>

                  <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-emerald-100 dark:border-slate-800">
                    <p className="text-[10px] text-slate-400 font-medium">Business Registration / PAN</p>
                    <p className="font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">{profileData.businessRegistrationNumber || 'PAN-30819283'}</p>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
