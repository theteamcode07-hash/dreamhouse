import React from 'react';
import { LayoutGrid, Ruler, FolderKanban, MessageSquare, ShoppingCart, Users, Store, HelpCircle, LogOut, X, Sun, Moon } from 'lucide-react';
import { useTheme } from '../lib/theme';

const alert = (msg: string) => {
  try {
    window.alert(msg);
  } catch (e) {
    console.warn("Alert blocked in sandbox:", msg);
  }
};

interface UserSidebarProps {
  onNavigateToTab: (tab: string) => void;
  onLogout: () => void;
  setMobileMenuOpen: (open: boolean) => void;
  mobileMenuOpen: boolean;
  cartCount: number;
  setAssistantOpen: (open: boolean) => void;
}

export default function UserSidebar({ 
  onNavigateToTab, onLogout, setMobileMenuOpen, mobileMenuOpen, cartCount, setAssistantOpen 
}: UserSidebarProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <nav className={`fixed left-0 top-0 h-full w-[280px] bg-[#1a2b3c] text-white shadow-md flex flex-col py-6 z-30 transition-transform duration-300 md:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} overflow-y-auto no-scrollbar`}>
      <div className="px-6 mb-8 flex justify-between items-center">
        <div>
          <h2 className="text-lg font-bold font-sans text-[#eff4ff]">Project Workspace</h2>
          <p className="text-xs text-[#8192a7] mt-0.5 font-sans">Modern Villa Revamp</p>
        </div>
        <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(false)}>
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-1.5 px-3">
        <button 
          onClick={() => { onNavigateToTab('dashboard'); setMobileMenuOpen(false); }}
          className="flex items-center gap-4 text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white py-3 px-4 rounded-r transition-all text-sm font-semibold w-full text-left"
        >
          <LayoutGrid className="w-5 h-5" />
          Dashboard
        </button>

        <button 
          onClick={() => { onNavigateToTab('shop'); setMobileMenuOpen(false); }}
          className="flex items-center gap-4 text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white py-3 px-4 transition-all text-sm font-semibold w-full text-left"
        >
          <ShoppingCart className="w-5 h-5" />
          Materials Shop
        </button>

        <button 
          onClick={() => { onNavigateToTab('shopkeepers'); setMobileMenuOpen(false); }}
          className="flex items-center gap-4 text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white py-3 px-4 transition-all text-sm font-semibold w-full text-left"
        >
          <Store className="w-5 h-5" />
          Shopkeepers
        </button>

        <button 
          onClick={() => { onNavigateToTab('experts'); setMobileMenuOpen(false); }}
          className="flex items-center gap-4 bg-[#f8f9ff] text-[#041627] border-l-4 border-[#fd8b00] py-3 px-4 rounded-r translate-x-1 transition-transform text-sm font-semibold w-full text-left"
        >
          <Users className="w-5 h-5 text-[#fd8b00]" />
          Experts
        </button>
      </div>

      <div className="mt-6 flex flex-col gap-1 border-t border-[#8192a7]/20 pt-4 px-3">
        <button 
          onClick={toggleTheme}
          className="flex items-center justify-between text-[#8192a7] hover:bg-[#1a2b3c]/80 hover:text-white py-2.5 px-4 transition-all text-sm font-semibold w-full text-left rounded cursor-pointer"
        >
          <div className="flex items-center gap-4">
            {theme === 'dark' ? (
              <Moon className="w-5 h-5 text-amber-300" />
            ) : (
              <Sun className="w-5 h-5 text-amber-400" />
            )}
            <span>{theme === 'dark' ? 'Dark Theme' : 'Light Theme'}</span>
          </div>
          <span className="text-[10px] uppercase font-bold bg-[#041627] px-2 py-0.5 rounded text-slate-300">
            {theme === 'dark' ? 'ON' : 'OFF'}
          </span>
        </button>

        <button 
          onClick={onLogout}
          className="flex items-center gap-4 text-red-300 hover:bg-[#1a2b3c]/80 py-2.5 px-4 transition-all text-sm font-semibold w-full text-left rounded cursor-pointer"
        >
          <LogOut className="w-5 h-5" />
          Sign Out Workspace
        </button>
      </div>
    </nav>
  );
}
