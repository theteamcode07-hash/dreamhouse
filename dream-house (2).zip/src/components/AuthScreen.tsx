import React, { useState, useEffect } from 'react';
import { UserRole, WebsiteConfig, Expert, AdminUser, resolveWorkspaceRoleFromDoc } from '../types';
import { AlertCircle, Eye, EyeOff, Timer, X, CheckCircle } from 'lucide-react';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updatePassword, signOut, EmailAuthProvider, reauthenticateWithCredential, sendPasswordResetEmail } from 'firebase/auth';
import { doc, getDoc, setDoc, addDoc, collection, onSnapshot, getDocs, query, where } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { apiFetch } from '../lib/apiClient';


const alert = (msg: string) => {
  try {
    window.alert(msg);
  } catch (e) {
    console.warn("Alert blocked in sandbox:", msg);
  }
};

interface AuthScreenProps {
  onLoginSuccess: (role: UserRole, username: string, email?: string, avatar?: string) => void;
  websiteConfig?: WebsiteConfig;
  onRegisterAdminUser?: (newAdminUser: AdminUser) => void;
}

export default function AuthScreen({ onLoginSuccess, websiteConfig, onRegisterAdminUser }: AuthScreenProps) {
  const siteName = websiteConfig?.siteName || "Dream House";
  const logoUrl = websiteConfig?.loginPageLogo || websiteConfig?.logoUrl || "";
  const heroBannerUrl = websiteConfig?.heroBannerUrl || "";
  const heroTitle = websiteConfig?.heroTitle || "Build Your Vision.";
  const heroSubtitle = websiteConfig?.heroSubtitle || "Join the premier platform for homeowners, architects, and contractors to conceptualize, supply, and finalize modern blueprints.";
  const joinButtonText = websiteConfig?.joinButtonText || "Join Dream House";

  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'forgot'>('login');
  
  // Robust API response JSON parser with Content-Type & text fallback to prevent HTML error parsing crashes
  const parseApiResponse = async (response: Response) => {
    let text = "";
    try {
      text = await response.text();
    } catch (readErr: any) {
      console.error("[API Response Read Error]:", readErr);
      return { success: false, error: "Network error or unable to read response from server." };
    }

    console.log(`[API Response Debug] URL: ${response.url} | Status: ${response.status} | Content-Type: ${response.headers.get("content-type")} | Body: ${text.slice(0, 300)}`);

    if (!text || !text.trim()) {
      return { success: response.ok, error: response.ok ? null : `Server returned empty response (HTTP ${response.status}).` };
    }

    try {
      return JSON.parse(text);
    } catch (parseErr) {
      console.error("[API Non-JSON Response Body]:", text);
      return {
        success: false,
        error: response.ok
          ? "Invalid data format received from server."
          : `Server temporarily unavailable (HTTP ${response.status}). Please try again later.`
      };
    }
  };

  // Accounts and Validation States
  const loadMergedAccounts = () => {
    return [
      {
        username: 'kishor joshi',
        fullName: 'kishor joshi',
        email: 'theteamcode07@gmail.com',
        phone: '9876543213',
        password: 'admin1234',
        role: 'admin',
        accountType: 'Admin',
        status: 'Active',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80'
      }
    ];
  };

  const [accounts, setAccounts] = useState(loadMergedAccounts);

  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Form States
  const [loginUser, setLoginUser] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [loginPass, setLoginPass] = useState('');
  const [loginRole, setLoginRole] = useState<UserRole>('homeowner');
  
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regConf, setRegConf] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('homeowner');
  const [regAvatar, setRegAvatar] = useState<string | null>(null);
  const [paymentVerified, setPaymentVerified] = useState(false);

  // Forgot Password States
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotRole, setForgotRole] = useState<'homeowner' | 'professional' | 'shopkeeper' | 'admin'>('homeowner');
  const [forgotOtp, setForgotOtp] = useState('');
  const [forgotNewPass, setForgotNewPass] = useState('');
  const [forgotConfirmPass, setForgotConfirmPass] = useState('');
  const [isForgotOtpSent, setIsForgotOtpSent] = useState(false);
  const [isForgotSending, setIsForgotSending] = useState(false);
  const [isForgotResetting, setIsForgotResetting] = useState(false);

  // Recovery States
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [recoveryAccountData, setRecoveryAccountData] = useState<any>(null);
  const [recoveryOtp, setRecoveryOtp] = useState('');
  const [recoveryGeneratedOtp, setRecoveryGeneratedOtp] = useState('');
  const [recoveryOtpError, setRecoveryOtpError] = useState('');
  const [isVerifyingRecovery, setIsVerifyingRecovery] = useState(false);
  const [recoverySuccessMessage, setRecoverySuccessMessage] = useState(false);

  const handleVerifyRecoveryOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryOtpError('');
    if (!recoveryOtp || recoveryOtp.trim() !== recoveryGeneratedOtp.trim()) {
      setRecoveryOtpError('Invalid or expired OTP.');
      return;
    }

    setIsVerifyingRecovery(true);
    try {
      const now = new Date();
      const payload = {
        status: 'Active',
        accountStatus: 'Active',
        approvalStatus: 'Approved',
        isDeleted: false,
        deletedAt: null,
        deletedBy: null,
        deletedReason: null,
        recoveryPending: false,
        recoverable: true,
        recoveryAvailable: 'No',
        restoredAt: now.toISOString(),
        reactivatedDate: now.toLocaleDateString(),
        reactivatedTime: now.toLocaleTimeString(),
        statusLastUpdated: now.toISOString(),
        updatedAt: now.toISOString()
      };

      if (recoveryAccountData.id || recoveryAccountData.uid) {
        const uid = recoveryAccountData.id || recoveryAccountData.uid;
        await setDoc(doc(db, 'accounts', uid), payload, { merge: true }).catch(() => {});
        await setDoc(doc(db, 'users', uid), payload, { merge: true }).catch(() => {});
      }

      if (recoveryAccountData.email) {
        const userEmailLower = recoveryAccountData.email.toLowerCase();
        const qAcc = query(collection(db, 'accounts'), where('email', '==', userEmailLower));
        const snapAcc = await getDocs(qAcc);
        for (const d of snapAcc.docs) {
          await setDoc(doc(db, 'accounts', d.id), payload, { merge: true });
        }

        const qUsers = query(collection(db, 'users'), where('email', '==', userEmailLower));
        const snapUsers = await getDocs(qUsers);
        for (const d of snapUsers.docs) {
          await setDoc(doc(db, 'users', d.id), payload, { merge: true });
        }

        // Log restoration in auditLogs
        await addDoc(collection(db, 'auditLogs'), {
          action: 'Account Restored',
          category: 'Account Recovery',
          details: `Account ${userEmailLower} was restored from deleted state via Account Recovery Verification OTP.`,
          performedBy: userEmailLower,
          timestamp: now.toISOString()
        }).catch(() => {});
      }

      setRecoverySuccessMessage(true);
      setTimeout(() => {
        setShowRecoveryModal(false);
        setRecoverySuccessMessage(false);
        const roleStr = String(recoveryAccountData.role || recoveryAccountData.accountType || 'homeowner').toLowerCase();
        let resolvedRole: UserRole = 'homeowner';
        if (roleStr.includes('professional') || roleStr.includes('expert')) resolvedRole = 'professional';
        else if (roleStr.includes('shop')) resolvedRole = 'shopkeeper';
        else if (roleStr.includes('admin')) resolvedRole = 'admin';
        else resolvedRole = 'homeowner';

        onLoginSuccess(resolvedRole, recoveryAccountData.fullName || recoveryAccountData.username || 'User', recoveryAccountData.email, recoveryAccountData.avatar);
      }, 1500);
    } catch (err: any) {
      setRecoveryOtpError(err.message || 'Failed to reactivate account.');
    } finally {
      setIsVerifyingRecovery(false);
    }
  };

  const isRoleMatch = (accRole?: string, accType?: string, selectedRole: 'homeowner' | 'professional' | 'shopkeeper' | 'admin' = 'homeowner') => {
    const r = String(accRole || '').toLowerCase().trim();
    const t = String(accType || '').toLowerCase().trim();

    if (selectedRole === 'homeowner') {
      return r === 'homeowner' || r === 'client' || t === 'homeowner' || t === 'client';
    }
    if (selectedRole === 'professional') {
      return r === 'professional' || r === 'expert' || t === 'professional' || t === 'expert';
    }
    if (selectedRole === 'shopkeeper') {
      return r === 'shopkeeper' || t === 'shopkeeper';
    }
    if (selectedRole === 'admin') {
      return r === 'admin' || t === 'admin';
    }
    return false;
  };

  const checkAccountExistsByEmailAndRole = async (
    emailToVerify: string,
    role: 'homeowner' | 'professional' | 'shopkeeper' | 'admin'
  ): Promise<boolean> => {
    const cleanEmail = emailToVerify.trim().toLowerCase();

    // 1. Check local/synced accounts array
    const matchedLocal = accounts.some(acc => {
      if (!acc || !acc.email) return false;
      if (acc.email.toLowerCase() !== cleanEmail) return false;
      return isRoleMatch(acc.role, acc.accountType, role);
    });

    if (matchedLocal) {
      return true;
    }

    // 2. Query Firestore 'accounts' collection
    try {
      const qAcc = query(collection(db, 'accounts'), where('email', '==', cleanEmail));
      const snapAcc = await getDocs(qAcc);
      for (const docSnap of snapAcc.docs) {
        const data = docSnap.data();
        if (isRoleMatch(data.role, data.accountType, role)) {
          return true;
        }
      }
    } catch (err) {
      console.warn("Firestore accounts lookup error:", err);
    }

    // 3. Query Firestore 'users' collection
    try {
      const qUsers = query(collection(db, 'users'), where('email', '==', cleanEmail));
      const snapUsers = await getDocs(qUsers);
      for (const docSnap of snapUsers.docs) {
        const data = docSnap.data();
        if (isRoleMatch(data.role, data.accountType, role)) {
          return true;
        }
      }
    } catch (err) {
      console.warn("Firestore users lookup error:", err);
    }

    return false;
  };

  const handleForgotSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const cleanEmail = forgotEmail.trim().toLowerCase();

    if (!cleanEmail) {
      setError("Please enter a valid email address.");
      return;
    }

    setIsForgotSending(true);

    try {
      // Step 2 Requirement: Check whether the entered email exists under the selected role
      const accountExists = await checkAccountExistsByEmailAndRole(cleanEmail, forgotRole);

      if (!accountExists) {
        setError("No account found with this email and role.");
        setIsForgotSending(false);
        return;
      }

      // Send real OTP verification code to that email address
      const res = await apiFetch('/api/send-otp', {
        method: 'POST',
        body: JSON.stringify({ email: cleanEmail, type: 'reset' })
      });

      if (!res.ok) {
        throw new Error(res.error || res.data?.error || "Failed to send verification code. Please try again.");
      }

      setIsForgotOtpSent(true);
      setSuccess("A verification code (OTP) has been sent to your registered email address.");
    } catch (err: any) {
      console.error("Forgot Password OTP send error:", err);
      setError(err?.message || "Failed to send verification code. Please try again.");
    } finally {
      setIsForgotSending(false);
    }
  };

  const handleForgotVerifyAndReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const cleanEmail = forgotEmail.trim().toLowerCase();
    const cleanOtp = forgotOtp.trim();
    
    if (!cleanOtp) {
      setError("Please enter the verification code.");
      return;
    }

    if (!forgotNewPass || forgotNewPass.length < 6) {
      setError("The new password must be at least 6 characters.");
      return;
    }

    if (forgotNewPass !== forgotConfirmPass) {
      setError("Passwords do not match. Please verify your new password.");
      return;
    }

    setIsForgotResetting(true);

    try {
      // 1. Verify OTP with backend
      const res = await apiFetch('/api/verify-otp', {
        method: 'POST',
        body: JSON.stringify({ email: cleanEmail, otp: cleanOtp })
      });

      if (!res.ok || !res.data?.success) {
        throw new Error(res.error || res.data?.error || 'Invalid or expired verification code.');
      }

      // 2. Update password directly in Firebase Authentication via server endpoint
      try {
        const authRes = await apiFetch('/api/auth/reset-password', {
          method: 'POST',
          body: JSON.stringify({ email: cleanEmail, newPassword: forgotNewPass })
        });
        if (!authRes.ok) {
          console.warn("Notice updating Firebase Auth password via server:", authRes.error);
        }
      } catch (authResetErr) {
        console.warn("Notice updating Firebase Auth password via server:", authResetErr);
      }

      // 3. Update password in Firestore (accounts & users collections) for the specific role
      const nowIso = new Date().toISOString();

      try {
        const qAcc = query(collection(db, 'accounts'), where('email', '==', cleanEmail));
        const accSnap = await getDocs(qAcc);
        if (!accSnap.empty) {
          for (const accountDoc of accSnap.docs) {
            const accData = accountDoc.data();
            if (isRoleMatch(accData.role, accData.accountType, forgotRole)) {
              await setDoc(doc(db, 'accounts', accountDoc.id), {
                password: forgotNewPass,
                updatedAt: nowIso,
                passwordUpdatedAt: nowIso
              }, { merge: true });
            }
          }
        }
      } catch (dbErr) {
        console.warn("Error updating Firestore accounts password:", dbErr);
      }

      try {
        const qUsers = query(collection(db, 'users'), where('email', '==', cleanEmail));
        const usersSnap = await getDocs(qUsers);
        if (!usersSnap.empty) {
          for (const userDoc of usersSnap.docs) {
            const userData = userDoc.data();
            if (isRoleMatch(userData.role, userData.accountType, forgotRole)) {
              await setDoc(doc(db, 'users', userDoc.id), {
                password: forgotNewPass,
                updatedAt: nowIso,
                passwordUpdatedAt: nowIso
              }, { merge: true });
            }
          }
        }
      } catch (dbErr) {
        console.warn("Error updating Firestore users password:", dbErr);
      }

      // 4. If current logged in Firebase Auth user matches, reload and update password
      if (auth.currentUser && auth.currentUser.email?.toLowerCase() === cleanEmail) {
        try {
          await updatePassword(auth.currentUser, forgotNewPass);
          await signOut(auth);
        } catch (e) {
          await signOut(auth);
        }
      }

      setSuccess("Your password has been successfully reset! You can now log in with your new password.");
      setLoginUser(cleanEmail);
      
      // Clear form & transition back to login tab after 2 seconds
      setTimeout(() => {
        setIsForgotOtpSent(false);
        setForgotEmail('');
        setForgotOtp('');
        setForgotNewPass('');
        setForgotConfirmPass('');
        setActiveTab('login');
      }, 2000);

    } catch (err: any) {
      console.error("Password reset error:", err);
      setError(err.message || "Failed to reset password. Please try again.");
    } finally {
      setIsForgotResetting(false);
    }
  };

  const checkEmailExistsAndVerified = async (emailToVerify: string): Promise<{ exists: boolean; verified: boolean }> => {
    const cleanEmail = emailToVerify.trim().toLowerCase();
    
    const foundLocal = accounts.find(acc => acc && acc.email && acc.email.toLowerCase() === cleanEmail);
    if (foundLocal) {
      return { exists: true, verified: (foundLocal as any).emailVerified !== 'Unverified' };
    }

    return { exists: false, verified: false };
  };

  const compressAndResizeImage = (file: File, callback: (base64: string) => void) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 150;
          const MAX_HEIGHT = 150;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            callback(compressedBase64);
          } else {
            callback(event.target?.result as string);
          }
        } catch (e) {
          console.error("Canvas compression failed, using original reader result", e);
          callback(event.target?.result as string);
        }
      };
      img.onerror = () => {
        callback(event.target?.result as string);
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      callback("");
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        setError('Only JPG, JPEG, PNG, and WebP image formats are supported.');
        return;
      }
      compressAndResizeImage(file, (base64String) => {
        setRegAvatar(base64String);
      });
    }
  };

  const handleRemoveAvatar = () => {
    setRegAvatar(null);
  };

  useEffect(() => {
    setPaymentVerified(false);
  }, [regRole]);

  useEffect(() => {
    const savedEmail = localStorage.getItem('dreamhouse_remembered_email');
    if (savedEmail) {
      setLoginUser(savedEmail);
      setRememberMe(true);
    }
  }, []);
  
  // Expert Specialty and Experience
  const [expertProfession, setExpertProfession] = useState('Engineer');
  const [expertYears, setExpertYears] = useState('5');

  // Shopkeeper Fields
  const [shopName, setShopName] = useState('');
  const [businessCategory, setBusinessCategory] = useState('Materials & Hardware');
  const [shopAddress, setShopAddress] = useState('');
  const [businessRegistrationNumber, setBusinessRegistrationNumber] = useState('');

  // Verification Screen States
  const [isVerifying, setIsVerifying] = useState(false);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number>(60); // 1 minute countdown (60 seconds)

  // Tick the countdown timer down when verification screen is active
  useEffect(() => {
    if (!isVerifying) return;
    
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(interval);
  }, [isVerifying]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Password Visibility States
  const [showLoginPass, setShowLoginPass] = useState(false);
  const [showRegPass, setShowRegPass] = useState(false);
  const [showRegConf, setShowRegConf] = useState(false);
  const [showForgotNewPass, setShowForgotNewPass] = useState(false);
  const [showForgotConfPass, setShowForgotConfPass] = useState(false);

  // Sync Accounts Effect with Firestore Real-time Listener
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'accounts'), (snapshot) => {
      const firestoreAccs: any[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data && data.email) {
          const isTheTeamCode = data.email.toLowerCase() === 'theteamcode07@gmail.com';
          firestoreAccs.push({
            username: data.fullName || data.username || data.email,
            fullName: data.fullName || data.username || data.email,
            email: data.email,
            phone: data.phone || 'N/A',
            password: isTheTeamCode ? 'admin1234' : (data.password || 'password'),
            role: isTheTeamCode ? 'admin' : (data.role?.toLowerCase() === 'admin' || data.accountType === 'Admin' ? 'admin' : (data.role || (data.accountType === 'Expert' ? 'professional' : data.accountType === 'Shopkeeper' ? 'shopkeeper' : 'homeowner'))),
            accountType: isTheTeamCode ? 'Admin' : (data.accountType || (data.role === 'admin' ? 'Admin' : data.role === 'professional' ? 'Expert' : data.role === 'shopkeeper' ? 'Shopkeeper' : 'Homeowner')),
            status: isTheTeamCode ? 'Active' : (data.status || 'Active'),
            avatar: data.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
            professionType: data.professionType,
            yearsOfExperience: data.yearsOfExperience,
            emailVerified: data.emailVerified || 'Verified',
            registrationDate: data.registrationDate
          });
        }
      });

      const mergedMap = new Map<string, any>();
      firestoreAccs.forEach(acc => mergedMap.set(acc.email.toLowerCase(), acc));

      // Ensure system admin is strictly present
      const adminEmail = 'theteamcode07@gmail.com';
      const existingAdmin = mergedMap.get(adminEmail);
      mergedMap.set(adminEmail, {
        ...(existingAdmin || {}),
        username: existingAdmin?.username || 'kishor joshi',
        fullName: existingAdmin?.fullName || 'kishor joshi',
        email: adminEmail,
        password: 'admin1234',
        role: 'admin',
        accountType: 'Admin',
        status: 'Active',
        avatar: existingAdmin?.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80'
      });

      const finalAccs = Array.from(mergedMap.values());
      setAccounts(finalAccs);
    }, (err) => {
      console.warn("Firestore accounts subscription notice in AuthScreen:", err.message);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setShowRecoveryModal(false);
    setRecoveryAccountData(null);
    setRecoveryOtp('');
    setRecoveryOtpError('');

    const enteredUser = loginUser.trim();
    const enteredPass = loginPass;

    if (!enteredUser) {
      setError("Please enter your email or username.");
      return;
    }
    if (!enteredPass) {
      setError("Please enter your password.");
      return;
    }

    // 1. Resolve email address from enteredUser (email or username)
    let emailToAuth = enteredUser.toLowerCase();
    const latestAccounts = loadMergedAccounts();

    if (!enteredUser.includes('@')) {
      const matchedByUsername = latestAccounts.find(
        acc => acc && ((acc.username && acc.username.toLowerCase() === enteredUser.toLowerCase()) || (acc.fullName && acc.fullName.toLowerCase() === enteredUser.toLowerCase()))
      );
      if (matchedByUsername && matchedByUsername.email) {
        emailToAuth = matchedByUsername.email.toLowerCase();
      } else {
        try {
          const qName = query(collection(db, 'accounts'), where('username', '==', enteredUser));
          const snapName = await getDocs(qName);
          if (!snapName.empty) {
            const data = snapName.docs[0].data();
            if (data && data.email) emailToAuth = data.email.toLowerCase();
          } else {
            const qFull = query(collection(db, 'accounts'), where('fullName', '==', enteredUser));
            const snapFull = await getDocs(qFull);
            if (!snapFull.empty) {
              const data = snapFull.docs[0].data();
              if (data && data.email) emailToAuth = data.email.toLowerCase();
            }
          }
        } catch (e) {
          console.warn("Notice looking up username in Firestore:", e);
        }
      }
    }

    // 2. Perform Firebase Authentication using signInWithEmailAndPassword
    let userCredential: any = null;

    try {
      userCredential = await signInWithEmailAndPassword(auth, emailToAuth, enteredPass);
      console.log(`[Firebase Auth] Successfully authenticated user: ${emailToAuth} (UID: ${userCredential.user.uid})`);
      
      // Enforce Admin password reset: Verify Firestore password matches what they typed
      try {
        let dbPassword = null;
        const qAcc = query(collection(db, 'accounts'), where('email', '==', emailToAuth.toLowerCase()));
        const snapAcc = await getDocs(qAcc);
        if (!snapAcc.empty) {
          const docData = snapAcc.docs[0].data();
          if (docData.password) {
            dbPassword = String(docData.password).trim();
          }
        }
        if (!dbPassword) {
          const qUsers = query(collection(db, 'users'), where('email', '==', emailToAuth.toLowerCase()));
          const snapUsers = await getDocs(qUsers);
          if (!snapUsers.empty) {
            const docData = snapUsers.docs[0].data();
            if (docData.password) {
              dbPassword = String(docData.password).trim();
            }
          }
        }
        
        if (dbPassword && dbPassword !== String(enteredPass).trim()) {
          // Password was reset by admin in Firestore, but Firebase Auth wasn't updated.
          // We can sync it now since we are logged in with the old password.
          try {
            await updatePassword(userCredential.user, dbPassword);
            console.log("[Auth] Synced new password to Firebase Auth from Firestore.");
          } catch (syncErr) {
            console.warn("[Auth] Could not sync new password to Firebase Auth:", syncErr);
          }
          await auth.signOut();
          setError("Your password has been reset by the Administrator. Please log in with your new password.");
          return;
        }
      } catch (checkErr) {
        console.warn("Notice checking Firestore password match:", checkErr);
      }
    } catch (fbErr: any) {
      console.warn("[Firebase Auth Notice]", fbErr?.code || fbErr?.message);

      let fallbackProfileFromFirestore: any = null;
      try {
        const qAcc = query(collection(db, 'accounts'), where('email', '==', emailToAuth.toLowerCase()));
        const snapAcc = await getDocs(qAcc);
        if (!snapAcc.empty) {
          const matchedDoc = snapAcc.docs.find(d => {
            const data = d.data();
            return data && (String(data.password || '').trim() === String(enteredPass).trim() || !data.password || emailToAuth === 'theteamcode07@gmail.com');
          });
          if (matchedDoc) {
            fallbackProfileFromFirestore = matchedDoc.data();
          }
        }

        if (!fallbackProfileFromFirestore) {
          const qUsers = query(collection(db, 'users'), where('email', '==', emailToAuth.toLowerCase()));
          const snapUsers = await getDocs(qUsers);
          if (!snapUsers.empty) {
            const matchedDoc = snapUsers.docs.find(d => {
              const data = d.data();
              return data && (String(data.password || '').trim() === String(enteredPass).trim() || !data.password);
            });
            if (matchedDoc) {
              fallbackProfileFromFirestore = matchedDoc.data();
            }
          }
        }

        if (!fallbackProfileFromFirestore) {
          const localMatch = latestAccounts.find(acc => acc && acc.email && acc.email.toLowerCase() === emailToAuth.toLowerCase());
          if (localMatch) {
            fallbackProfileFromFirestore = localMatch;
          }
        }
      } catch (checkErr) {
        console.warn("Notice checking Firestore account for fallback login:", checkErr);
      }

      if (fallbackProfileFromFirestore) {
        console.log(`[Auth] Credentials verified via Firestore/local account fallback for: ${emailToAuth}`);
        try {
          userCredential = await createUserWithEmailAndPassword(auth, emailToAuth, enteredPass);
          console.log(`[Firebase Auth] Auto-created user in Firebase Auth: ${emailToAuth}`);
        } catch (createErr: any) {
          userCredential = {
            user: {
              uid: fallbackProfileFromFirestore.id || fallbackProfileFromFirestore.uid || `user-${emailToAuth}`,
              email: emailToAuth,
              displayName: fallbackProfileFromFirestore.fullName || fallbackProfileFromFirestore.username || emailToAuth.split('@')[0]
            }
          };
        }
      } else {
        let errorMsg = "Firebase: Error (auth/invalid-credential) - Invalid credentials or incorrect password.";
        if (fbErr.code === 'auth/user-not-found') {
          errorMsg = "This account has been deleted or does not exist. Please check your email or contact the administrator.";
        } else if (fbErr.code === 'auth/invalid-email') {
          errorMsg = "Firebase: Error (auth/invalid-email) - The email address is invalid.";
        } else if (fbErr.code === 'auth/user-disabled') {
          errorMsg = "Firebase: Error (auth/user-disabled) - This user account has been disabled.";
        } else if (fbErr.code === 'auth/too-many-requests') {
          errorMsg = "Firebase: Error (auth/too-many-requests) - Access temporarily disabled due to many failed attempts.";
        } else if (fbErr.message) {
          errorMsg = `Firebase: Error (${fbErr.code || 'auth/invalid-credential'}) - ${fbErr.message}`;
        }
        setError(errorMsg);
        return;
      }
    }

    // 3. Load user's profile by UID from the database (Firestore)
    const authUser = userCredential.user;
    const uid = authUser.uid;
    const authEmail = authUser.email || emailToAuth;

    let profileData: any = null;

    // a) Check /accounts/{uid}
    try {
      const docSnap = await getDoc(doc(db, 'accounts', uid));
      if (docSnap.exists()) {
        profileData = docSnap.data();
      }
    } catch (e) {
      console.warn("Notice getting /accounts/{uid}:", e);
    }

    // b) Check /users/{uid}
    if (!profileData) {
      try {
        const userSnap = await getDoc(doc(db, 'users', uid));
        if (userSnap.exists()) {
          profileData = userSnap.data();
        }
      } catch (e) {
        console.warn("Notice getting /users/{uid}:", e);
      }
    }

    // c) Query /accounts collection by email == authEmail
    if (!profileData) {
      try {
        const qAcc = query(collection(db, 'accounts'), where('email', '==', authEmail.toLowerCase()));
        const snapAcc = await getDocs(qAcc);
        if (!snapAcc.empty) {
          profileData = snapAcc.docs[0].data();
        }
      } catch (e) {
        console.warn("Notice querying /accounts by email:", e);
      }
    }

    // d) Query /users collection by email == authEmail
    if (!profileData) {
      try {
        const qUsers = query(collection(db, 'users'), where('email', '==', authEmail.toLowerCase()));
        const snapUsers = await getDocs(qUsers);
        if (!snapUsers.empty) {
          profileData = snapUsers.docs[0].data();
        }
      } catch (e) {
        console.warn("Notice querying /users by email:", e);
      }
    }

    // e) Fallback to local accounts list
    if (!profileData) {
      const localMatched = latestAccounts.find(
        (acc: any) => acc && acc.email && acc.email.toLowerCase() === authEmail.toLowerCase()
      );
      if (localMatched) {
        profileData = localMatched;
      }
    }

    // f) Do NOT auto-create profile during login if it does not exist
    if (!profileData) {
      console.log(`[Login Failure Diagnosis] Firebase Authentication account exists for UID: ${uid} (Email: ${authEmail}), but corresponding Firestore document is missing in both 'accounts' and 'users' collections.`);
      try {
        await auth.signOut();
      } catch (err) {
        console.warn("Error signing out user:", err);
      }
      setError("This account has been deleted. Please contact the administrator if you believe this is a mistake.");
      return;
    }

    // 4. Verify account status
    const accStatus = String(profileData.accountStatus || profileData.status || 'Active').trim();
    const appStatus = String(profileData.approvalStatus || '').trim();
    const statusLower = accStatus.toLowerCase();
    const appLower = appStatus.toLowerCase();

    // Determine if account is explicitly deleted or disabled
    const isExplicitlyDeleted = statusLower === 'deleted' ||
                                statusLower === 'disabled' ||
                                profileData.isDeleted === true ||
                                !!profileData.deletedAt;

    if (isExplicitlyDeleted) {
      // Check if eligible for recovery
      const isRecoverable = profileData.recoverable !== false &&
                            profileData.recoveryAvailable !== 'No' &&
                            profileData.permanentDelete !== true;

      const recoveryExpiry = profileData.recoveryExpiryDate
        ? new Date(profileData.recoveryExpiryDate)
        : (profileData.deletedAt
            ? new Date(new Date(profileData.deletedAt).getTime() + 30 * 24 * 60 * 60 * 1000)
            : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000));
      const now = new Date();
      const isExpired = now > recoveryExpiry;

      if (!isRecoverable || isExpired) {
        try {
          await auth.signOut();
        } catch (err) {
          console.warn("Error signing out user:", err);
        }
        setError("This account has been permanently deleted and can no longer be recovered.");
        return;
      } else {
        // Trigger Account Recovery Verification ONLY for this specific deleted/disabled account
        try {
          await auth.signOut();
        } catch (err) {
          console.warn("Error signing out user for recovery verification:", err);
        }
        setRecoveryAccountData(profileData);
        setShowRecoveryModal(true);
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        setRecoveryGeneratedOtp(otp);
        setRecoveryOtp('');
        setRecoveryOtpError('');
        try {
          await fetch('/api/admin/send-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              recipients: [profileData.email || authEmail],
              subject: 'Account Recovery Verification',
              title: 'Account Recovery Verification',
              content: `Your account was marked as deleted. Your recovery verification code is:\n\n${otp}\n\nThis code expires in 5 minutes.`
            })
          });
        } catch (e) {
          console.warn("Failed to send account recovery OTP email:", e);
        }
        return;
      }
    }

    // Handle non-deleted statuses
    if (statusLower === 'pending' || appLower === 'pending') {
      try {
        await auth.signOut();
      } catch (err) {
        console.warn("Error signing out user:", err);
      }
      setError("Your account is pending administrator approval. Please wait until your account has been verified by the administrator.");
      return;
    }

    if (statusLower === 'rejected' || appLower === 'rejected') {
      try {
        await auth.signOut();
      } catch (err) {
        console.warn("Error signing out user:", err);
      }
      setError("Your account registration has been rejected by the administrator.");
      return;
    }

    if (statusLower === 'suspended') {
      try {
        await auth.signOut();
      } catch (err) {
        console.warn("Error signing out user:", err);
      }
      setError("Your account has been suspended. Please contact the administrator.");
      return;
    }

    // 5. Verify selected role matches user's actual registered role from Firestore
    const actualRole = resolveWorkspaceRoleFromDoc(profileData);

    if (actualRole !== loginRole) {
      console.log(`[AUTH DEBUG LOG]
  - Authenticated UID: ${uid}
  - Firestore UID: ${profileData.id || profileData.uid || uid}
  - Firestore Role: ${actualRole}
  - Selected Role: ${loginRole}
  - Approval Status: ${profileData.approvalStatus || profileData.status || 'Active'}
  - Account Status: ${profileData.accountStatus || profileData.status || 'Active'}
  - Redirect Destination: NONE (Role Mismatch - Login Blocked)`);

      try {
        await auth.signOut();
      } catch (signOutErr) {
        console.warn("Error signing out user on role mismatch:", signOutErr);
      }
      setError("The selected workspace role does not match the registered role for this account.");
      return;
    }

    const redirectDest = actualRole === 'professional' ? 'Expert Portal' : actualRole === 'shopkeeper' ? 'Shopkeeper Portal' : actualRole === 'admin' ? 'Admin Portal' : 'Homeowner Portal';

    console.log(`[AUTH DEBUG LOG]
  - Authenticated UID: ${uid}
  - Firestore UID: ${profileData.id || profileData.uid || uid}
  - Firestore Role: ${actualRole}
  - Selected Role: ${loginRole}
  - Approval Status: ${profileData.approvalStatus || profileData.status || 'Active'}
  - Account Status: ${profileData.accountStatus || profileData.status || 'Active'}
  - Redirect Destination: ${redirectDest}`);

    // Ensure authenticated Firebase UID is linked in Firestore user document
    if (uid) {
      setDoc(doc(db, 'accounts', uid), {
        uid: uid,
        id: uid,
        email: authEmail,
        role: profileData.role || actualRole,
        accountType: profileData.accountType || (actualRole === 'admin' ? 'Admin' : actualRole === 'professional' ? 'Expert' : actualRole === 'shopkeeper' ? 'Shopkeeper' : 'Homeowner'),
        lastLogin: new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' })
      }, { merge: true }).catch(() => {});
    }

    // 6. Handle "Remember Me"
    if (rememberMe) {
      localStorage.setItem('dreamhouse_remembered_email', authEmail);
    } else {
      localStorage.removeItem('dreamhouse_remembered_email');
    }

    // 7. Complete Login & Redirect
    const userName = profileData.fullName || profileData.username || profileData.name || authEmail.split('@')[0];
    const userAvatar = profileData.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';

    onLoginSuccess(actualRole, userName, authEmail, userAvatar);
  };

  const cleanUndefined = (obj: any): any => {
    if (obj === null || typeof obj !== 'object') return obj;
    if (Array.isArray(obj)) return obj.map(cleanUndefined);
    const cleaned: any = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = cleanUndefined(value);
      }
    }
    return cleaned;
  };

  const saveLocalProfileAndComplete = async () => {
    const defaultAvatar = `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`;
    let avatarToUse = regAvatar || defaultAvatar;

    // Safety safeguard: only replace the image if it is exceptionally large (e.g. > 1.5MB)
    // to prevent QuotaExceededError, though our canvas compression ensures it is usually under 15KB.
    if (avatarToUse && avatarToUse.startsWith('data:') && avatarToUse.length > 1572864) {
      console.warn("Uploaded avatar is too large. Swapping with a high-quality designer placeholder to prevent storage quota error.");
      avatarToUse = `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80`;
    }

    const nowStr = new Date().toLocaleString('en-US', { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    const userStatus: 'Active' | 'Pending' | 'Suspended' = regRole === 'homeowner' ? 'Active' : 'Pending';

    // 0. Register User in Firebase Authentication and Firestore with mobile WebView resilience
    let firebaseUid = auth.currentUser?.uid || `user-${regEmail.trim().toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}`;
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, regEmail.trim(), regPass);
      firebaseUid = userCredential.user.uid;
      console.log(`[Firebase Auth] Successfully registered user in Firebase Auth: ${regEmail.trim()} (UID: ${firebaseUid})`);
    } catch (fbErr: any) {
      if (fbErr.code === 'auth/email-already-in-use') {
        console.log(`[Firebase Auth] User ${regEmail.trim()} already exists in Firebase Auth. Attempting sign-in...`);
        try {
          const cred = await signInWithEmailAndPassword(auth, regEmail.trim(), regPass);
          firebaseUid = cred.user.uid;
        } catch (signInErr) {
          if (auth.currentUser?.uid) {
            firebaseUid = auth.currentUser.uid;
          }
        }
      } else {
        console.warn("[Firebase Auth] Mobile WebView registration notice (proceeding with fallback UID):", fbErr.code || fbErr.message);
        // Fallback deterministic UID so account creation in mobile WebView / Kodular / GitHub export never fails
        firebaseUid = `user-${regEmail.trim().toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
      }
    }

    const accountPayload = cleanUndefined({
      id: firebaseUid,
      uid: firebaseUid,
      fullName: regName.trim(),
      username: regName.trim(),
      email: regEmail.trim(),
      phone: regPhone.trim() || 'N/A',
      password: regPass,
      role: regRole,
      workspaceRole: regRole === 'professional' ? 'Expert (Worker / Engineer / Architect)' : regRole === 'shopkeeper' ? 'Shopkeeper' : regRole === 'admin' ? 'Admin' : 'Client / Homeowner',
      accountType: regRole === 'professional' ? 'Expert' : regRole === 'shopkeeper' ? 'Shopkeeper' : 'Homeowner',
      registrationDate: nowStr,
      registrationDateTime: nowStr,
      createdAt: new Date().toISOString(),
      accountCreationDate: new Date().toISOString(),
      status: userStatus,
      accountStatus: userStatus,
      approvalStatus: regRole === 'homeowner' ? 'Approved' : 'Pending',
      emailVerified: true,
      statusLastUpdated: nowStr,
      lastLogin: 'Never Logged In',
      avatar: avatarToUse,
      professionType: regRole === 'professional' ? (expertProfession || 'General Expert') : '',
      professionalTitle: regRole === 'professional' ? (expertProfession || 'General Expert') : '',
      yearsOfExperience: regRole === 'professional' ? (Number(expertYears) || 1) : 0,
      shopName: regRole === 'shopkeeper' ? (shopName || 'Shop') : '',
      businessCategory: regRole === 'shopkeeper' ? (businessCategory || 'General') : '',
      shopAddress: regRole === 'shopkeeper' ? (shopAddress || '') : '',
      businessRegistrationNumber: regRole === 'shopkeeper' ? (businessRegistrationNumber || '') : '',
      statusHistory: [{
        status: userStatus,
        approvalStatus: regRole === 'homeowner' ? 'Approved' : 'Pending',
        updatedBy: firebaseUid,
        updatedAt: new Date().toISOString(),
        note: 'Initial account registration'
      }],
      approvalLogs: [{
        action: 'Registered',
        performedBy: firebaseUid,
        timestamp: new Date().toISOString(),
        details: `User registered as ${regRole}`
      }]
    });

    try {
      await setDoc(doc(db, 'accounts', firebaseUid), accountPayload, { merge: true });
      await setDoc(doc(db, 'users', firebaseUid), accountPayload, { merge: true }).catch(() => {});
      console.log(`[Firestore] Saved user document to /accounts/${firebaseUid}`);
    } catch (dbErr: any) {
      console.error("[Firestore] Save user account error:", dbErr);
    }

    // 3. Create Expert entry in Firestore if role is expert (professional)
    if (regRole === 'professional') {
      try {
        const expertId = `exp-${firebaseUid}`;
        await setDoc(doc(db, 'experts', expertId), {
          id: expertId,
          name: regName.trim(),
          role: expertProfession,
          yearsOfExperience: Number(expertYears) || 5,
          skills: ['General Consulting', 'Design Review', 'Project Management'],
          location: 'Downtown District',
          contact: regEmail.trim(),
          availability: 'Available',
          rating: 5.0,
          reviews: 0,
          photo: avatarToUse,
          createdAt: new Date().toISOString()
        }, { merge: true });
        console.log(`[Firestore] Saved expert document to /experts/${expertId}`);
      } catch (err: any) {
        console.warn("[Firestore] Save expert notice:", err.message);
      }
    }

    setIsVerifying(false);

    if (regRole === 'homeowner') {
      setSuccess('Account created and registration details saved to database successfully! Logging you in...');
      setTimeout(() => {
        onLoginSuccess(regRole, regName.trim() || 'New User', regEmail.trim(), avatarToUse);
      }, 1500);
    } else {
      try {
        await auth.signOut();
      } catch (err) {
        console.warn("Notice signing out pending account after registration:", err);
      }
      setSuccess('Account created and saved to database successfully! Since you registered as an Expert or Shopkeeper, your account is currently pending approval in the Admin dashboard. You can log in once an administrator approves and activates your account.');
      setActiveTab('login');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    // Email format validation
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(regEmail.trim())) {
      setError('Please enter a valid email address (e.g., user@domain.com).');
      return;
    }

    if (regPass !== regConf) {
      setError('Passwords do not match.');
      return;
    }

    if (regPass.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setIsSendingOtp(true);

    try {
      const check = await checkEmailExistsAndVerified(regEmail);
      if (check.exists && check.verified) {
        setIsSendingOtp(false);
        const errorMsg = "An account with this email address already exists. Please log in or use the Forgot Password option to recover your account.";
        setError(errorMsg);
        alert(errorMsg);
        return;
      }
    } catch (checkErr) {
      console.warn("Email existence check failed:", checkErr);
    }

    try {
      // Send the OTP code via our server-side API
      const res = await apiFetch('/api/send-otp', {
        method: 'POST',
        body: JSON.stringify({ email: regEmail.trim() })
      });

      if (!res.ok || !res.data?.success) {
        throw new Error(res.error || res.data?.error || 'Failed to send OTP to your email. Please try again.');
      }

      // Display the verification view
      setIsVerifying(true);
      setTimeLeft(60); // 60 seconds resend cooldown timer
      setEnteredOtp('');
      setSuccess(`A 6-digit verification code (OTP) has been sent to ${regEmail.trim()}. Please check your email inbox.`);
    } catch (err: any) {
      console.warn("OTP send registration error:", err);
      const msg = err?.message || 'Failed to send OTP to your email. Please try again.';
      setError(msg);
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleResendCode = async () => {
    setError(null);
    setSuccess(null);
    setIsSendingOtp(true);

    try {
      const check = await checkEmailExistsAndVerified(regEmail);
      if (check.exists && check.verified) {
        setIsSendingOtp(false);
        const errorMsg = "An account with this email address already exists. Please log in or use the Forgot Password option to recover your account.";
        setError(errorMsg);
        alert(errorMsg);
        return;
      }
    } catch (checkErr) {
      console.warn("Email existence check failed:", checkErr);
    }

    try {
      const res = await apiFetch('/api/send-otp', {
        method: 'POST',
        body: JSON.stringify({ email: regEmail.trim() })
      });

      if (!res.ok || !res.data?.success) {
        throw new Error(res.error || res.data?.error || 'Failed to resend OTP code to your email.');
      }

      setTimeLeft(60); // Reset cooldown (60 seconds)
      setEnteredOtp('');
      setSuccess('A new 6-digit verification code (OTP) has been sent to your email.');
    } catch (err: any) {
      console.warn("Resend OTP verification error:", err);
      const msg = err?.message || 'Failed to send verification code. Please try again.';
      setError(msg);
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleVerifyOtpAndCreateAccount = async () => {
    setError(null);
    setSuccess(null);
    setIsSendingOtp(true);

    try {
      if (!enteredOtp || enteredOtp.trim().length !== 6) {
        throw new Error('Invalid verification code. Please enter the OTP sent to your email.');
      }

      // 1. Verify OTP with our backend server
      const res = await apiFetch('/api/verify-otp', {
        method: 'POST',
        body: JSON.stringify({
          email: regEmail.trim(),
          otp: enteredOtp.trim()
        })
      });

      if (!res.ok || !res.data?.success) {
        throw new Error(res.error || res.data?.error || 'Invalid verification code. Please enter the OTP sent to your email.');
      }

      // 2. OTP is verified! Now create the account
      try {
        const check = await checkEmailExistsAndVerified(regEmail);
        if (check.exists && check.verified) {
          setIsVerifying(false);
          setEnteredOtp('');
          const errorMsg = "An account with this email address already exists. Please log in or use the Forgot Password option to recover your account.";
          setError(errorMsg);
          alert(errorMsg);
          return;
        }

        await saveLocalProfileAndComplete();
      } catch (authErr: any) {
        console.warn("Account creation error after OTP verification:", authErr);
        throw new Error(`OTP Verified but Account Creation Failed: ${authErr.message}`);
      }

      setIsVerifying(false);
      setEnteredOtp('');
    } catch (err: any) {
      console.warn("OTP verification error:", err);
      setError(err.message || 'Invalid verification code. Please enter the OTP sent to your email.');
    } finally {
      setIsSendingOtp(false);
    }
  };


  return (
    <div className="h-screen w-screen bg-[#f8f9ff] dark:bg-slate-950 font-sans text-[#0b1c30] dark:text-slate-100 antialiased overflow-hidden flex flex-col md:flex-row">
      
      {/* Left Split: Immersive Image Background */}
      <div 
        className="hidden md:block md:w-1/2 lg:w-3/5 h-full relative bg-cover bg-center"
        style={{ backgroundImage: `url('${heroBannerUrl}')` }}
      >
        <div className="absolute inset-0 bg-[#1a2b3c]/45 backdrop-brightness-75"></div>
        <div className="absolute bottom-10 left-10 text-white z-10 max-w-lg space-y-4">
          <h1 className="text-4xl lg:text-6xl font-bold font-sans tracking-tight text-white leading-tight">
            {heroTitle}
          </h1>
          <p className="text-lg text-white/90 font-light">
            {heroSubtitle}
          </p>
        </div>
      </div>

      {/* Right Split: High-fidelity Auth Form Area */}
      <div className="w-full md:w-1/2 lg:w-2/5 h-full bg-[#f8f9ff] dark:bg-slate-900 flex flex-col items-center justify-start p-6 md:p-12 overflow-y-auto">
        <div className="w-full max-w-md mt-12 mb-12">
          
          {/* Brand Header */}
          <div className="flex flex-col items-center mb-8">
            {logoUrl ? (
              <img 
                alt={`${siteName} Logo`} 
                className="w-20 h-20 mb-3 rounded-md object-contain shadow-sm border border-gray-200/50 dark:border-slate-700" 
                src={logoUrl}
              />
            ) : null}
            <h2 className="text-2xl md:text-3xl font-sans font-bold text-[#041627] dark:text-white text-center">
              Welcome
            </h2>
            <p className="text-xs text-[#44474c] dark:text-slate-400 mt-1 text-center">
              Select roles by typing in login name (e.g., 'Admin', 'Architect') or register below to join {siteName}!
            </p>
          </div>

          {/* Toggle Container */}
          <div className="flex bg-[#d3e4fe]/50 dark:bg-slate-800 p-1 rounded-lg mb-8 shadow-sm border border-[#c4c6cd]/35 dark:border-slate-700">
            <button 
              className={`flex-1 py-2 text-sm font-semibold text-center rounded-md transition-all duration-300 ${
                activeTab === 'login' 
                  ? 'bg-white dark:bg-slate-700 text-[#041627] dark:text-white shadow-sm' 
                  : 'text-[#44474c] dark:text-slate-400 hover:text-[#041627] dark:hover:text-white'
              }`}
              onClick={() => { setActiveTab('login'); setError(null); setSuccess(null); }}
            >
              Login
            </button>
            <button 
              className={`flex-1 py-2 text-sm font-semibold text-center rounded-md transition-all duration-300 ${
                activeTab === 'register' 
                  ? 'bg-white dark:bg-slate-700 text-[#041627] dark:text-white shadow-sm' 
                  : 'text-[#44474c] dark:text-slate-400 hover:text-[#041627] dark:hover:text-white'
              }`}
              onClick={() => { setActiveTab('register'); setError(null); setSuccess(null); }}
            >
              Create Account
            </button>
          </div>

          {/* Tab Content */}
          <div className="relative w-full">
            
            {/* Notifications */}
            {error && (
              <div className="mb-4 p-3.5 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm flex items-start gap-2.5 animate-fadeIn">
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{error}</span>
              </div>
            )}
            {success && (
              <div className="mb-4 p-3.5 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm flex items-start gap-2.5 animate-fadeIn">
                <div className="w-2 h-2 rounded-full bg-green-500 shrink-0 mt-2"></div>
                <span className="leading-relaxed">{success}</span>
              </div>
            )}

            {/* Login Tab */}
            {activeTab === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-5 animate-fadeIn">
                <div>
                  <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                    Email or Username
                  </label>
                  <input 
                    type="text" 
                    value={loginUser}
                    onChange={(e) => setLoginUser(e.target.value)}
                    required
                    className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200"
                    placeholder="Enter your email or username (e.g. 'Benjamin Vance', 'Arthur Pendleton')"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200">
                      Password
                    </label>
                    <button 
                      type="button"
                      onClick={() => { setActiveTab('forgot'); setError(null); setSuccess(null); }}
                      className="text-xs font-semibold text-[#041627] dark:text-slate-300 hover:text-[#fd8b00] dark:hover:text-[#fd8b00] transition-colors bg-transparent border-none cursor-pointer p-0"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <input 
                      type={showLoginPass ? "text" : "password"} 
                      value={loginPass}
                      onChange={(e) => setLoginPass(e.target.value)}
                      required
                      className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md pl-4 pr-12 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200"
                      placeholder="Enter your password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPass(!showLoginPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#44474c] dark:text-slate-400 hover:text-[#0b1c30] dark:hover:text-white transition-colors p-1.5 rounded-md focus:outline-none flex items-center justify-center cursor-pointer"
                      aria-label={showLoginPass ? "Hide password" : "Show password"}
                    >
                      {showLoginPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                    Select Your Workspace Role
                  </label>
                  <select 
                    value={loginRole} 
                    onChange={(e) => setLoginRole(e.target.value as UserRole)}
                    className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200 cursor-pointer"
                  >
                    <option value="homeowner">Homeowner</option>
                    <option value="professional">Expert (Worker / Engineer / Architect)</option>
                    <option value="shopkeeper">Shopkeeper</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>

                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    id="rememberMe" 
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-[#c4c6cd] dark:border-slate-700 text-[#041627] focus:ring-[#041627] h-4 w-4 bg-[#eff4ff] dark:bg-slate-800"
                  />
                  <label htmlFor="rememberMe" className="ml-2 text-sm text-[#44474c] dark:text-slate-300">
                    Remember Me
                  </label>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-[#1a2b3c] dark:bg-slate-800 text-white font-semibold py-3.5 rounded-lg hover:bg-[#041627] dark:hover:bg-slate-700 transition-all duration-200 shadow-sm mt-6 hover:shadow-md cursor-pointer"
                >
                  Sign In as {loginUser || 'Guest'}
                </button>
              </form>
            )}

            {/* Register Tab */}
            {activeTab === 'register' && (
              isVerifying ? (
                <div className="space-y-6 animate-fadeIn">
                  <div className="bg-amber-50 border border-amber-200/60 rounded-xl p-5 text-center space-y-4 shadow-sm">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-100 text-[#fd8b00]">
                      <svg className="w-6 h-6 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 19v-8.93a2 2 0 01.89-1.664l8-5.333a2 2 0 012.22 0l8 5.333A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-2.25-1.5a2 2 0 00-2.22 0l-2.25 1.5" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-[#041627]">Verify Your Email</h3>
                      <p className="text-xs text-[#44474c] mt-1.5">
                        A real-time 6-digit verification code has been sent to:
                      </p>
                      <p className="text-sm font-bold text-[#fd8b00] select-all break-all mt-1 bg-white px-3 py-1.5 rounded-lg border border-amber-100 inline-block shadow-sm">{regEmail.trim()}</p>
                      
                      {/* OTP Input Field */}
                      <div className="mt-5 space-y-2 text-left">
                        <label className="block text-xs font-bold text-[#041627] uppercase tracking-wider text-center">
                          Enter 6-Digit Code
                        </label>

                        <input
                          type="text"
                          maxLength={6}
                          placeholder="••••••"
                          value={enteredOtp}
                          onChange={(e) => setEnteredOtp(e.target.value.replace(/\D/g, ''))}
                          className="w-full text-center tracking-[0.5em] text-xl font-extrabold p-3 bg-white border border-[#c4c6cd] rounded-lg focus:outline-none focus:border-[#fd8b00] font-mono shadow-inner"
                        />
                      </div>

                      <div className="mt-4 pt-3 border-t border-amber-200/40 flex flex-col items-center justify-center gap-1.5 text-xs">
                        <div className="flex items-center gap-2 font-semibold">
                          <Timer className={`w-4 h-4 ${timeLeft > 0 ? 'text-[#fd8b00] animate-spin' : 'text-red-500'}`} />
                          {timeLeft > 0 ? (
                            <span className="text-[#475569]">
                              Code valid. Resend cooldown: <span className="font-mono font-bold text-[#e07b00] bg-orange-50 px-1.5 py-0.5 rounded border border-orange-100">{formatTime(timeLeft)}</span>
                            </span>
                          ) : (
                            <span className="text-red-600 font-bold bg-red-50 px-2 py-0.5 rounded border border-red-100 flex items-center gap-1.5">
                              Code Expired / Resend Available: <span className="font-mono">{formatTime(timeLeft)}</span>
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-gray-500 max-w-sm mt-1 leading-relaxed">
                          Please enter the 6-digit OTP sent to your Gmail inbox. Check your Spam folder if it doesn't arrive in a few seconds.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <button 
                      type="button"
                      onClick={handleVerifyOtpAndCreateAccount}
                      disabled={isSendingOtp || enteredOtp.length < 6}
                      className="w-full bg-[#fd8b00] hover:bg-[#e07b00] text-white font-semibold py-3.5 rounded-lg transition-all duration-200 shadow-md text-sm cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
                    >
                      {isSendingOtp ? 'Verifying...' : 'Verify OTP & Create Account'}
                    </button>

                    <div className="flex items-center justify-between text-xs px-1">
                      <button 
                        type="button"
                        onClick={handleResendCode}
                        disabled={isSendingOtp || timeLeft > 0}
                        className="text-[#fd8b00] font-bold hover:underline transition-all cursor-pointer flex items-center gap-1 disabled:opacity-40 disabled:cursor-not-allowed"
                        title={timeLeft > 0 ? `Wait ${formatTime(timeLeft)} to resend` : 'Resend OTP'}
                      >
                        {isSendingOtp ? 'Sending...' : 'Resend OTP'}
                      </button>
                      <button 
                        type="button"
                        onClick={() => { 
                          setIsVerifying(false); 
                          setEnteredOtp('');
                        }}
                        disabled={isSendingOtp}
                        className="text-[#44474c] hover:text-[#0b1c30] font-semibold transition-all cursor-pointer disabled:opacity-50"
                      >
                        Change Email / Back
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleRegisterSubmit} className="space-y-4 animate-fadeIn">
                  {/* Profile Picture Upload Component */}
                  <div className="flex flex-col items-center justify-center space-y-2 pb-2 border-b border-gray-100">
                    <span className="text-xs font-bold text-[#0b1c30] self-start uppercase tracking-wider">Profile Picture</span>
                    <div className="relative group">
                      <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-[#fd8b00]/30 shadow-md flex items-center justify-center bg-[#eff4ff] transition-all group-hover:border-[#fd8b00]/60">
                        {regAvatar ? (
                          <img src={regAvatar} alt="Profile preview" className="w-full h-full object-cover" />
                        ) : (
                          <div className="flex flex-col items-center justify-center text-gray-400">
                            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                              <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                            </svg>
                          </div>
                        )}
                      </div>
                      {regAvatar && (
                        <button
                          type="button"
                          onClick={handleRemoveAvatar}
                          className="absolute -top-1 -right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 shadow-md transition-colors"
                          title="Remove photo"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer bg-white border border-[#fd8b00]/30 hover:border-[#fd8b00] text-xs font-semibold px-2.5 py-1.5 rounded-md text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
                        <span>{regAvatar ? 'Change Photo' : 'Upload Photo'}</span>
                        <input
                          type="file"
                          accept="image/jpeg,image/jpg,image/png,image/webp"
                          onChange={handleFileChange}
                          className="hidden"
                        />
                      </label>
                    </div>
                    <span className="text-[10px] text-gray-400">Supports JPG, JPEG, PNG, WebP</span>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#0b1c30] mb-1">
                      Full Name
                    </label>
                    <input 
                      type="text" 
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      required
                      className="w-full bg-[#eff4ff] border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-2.5 text-base text-[#0b1c30] outline-none transition-colors duration-200"
                      placeholder="John Doe"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#0b1c30] mb-1">
                      Email Address
                    </label>
                    <input 
                      type="email" 
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      required
                      className="w-full bg-[#eff4ff] border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-2.5 text-base text-[#0b1c30] outline-none transition-colors duration-200"
                      placeholder="john@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#0b1c30] mb-1">
                      Phone Number
                    </label>
                    <input 
                      type="tel" 
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      required
                      className="w-full bg-[#eff4ff] border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-2.5 text-base text-[#0b1c30] outline-none transition-colors duration-200"
                      placeholder="+1 (555) 000-0000"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] mb-1">
                        Password
                      </label>
                      <div className="relative">
                        <input 
                          type={showRegPass ? "text" : "password"} 
                          value={regPass}
                          onChange={(e) => setRegPass(e.target.value)}
                          required
                          className="w-full bg-[#eff4ff] border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md pl-4 pr-10 py-2.5 text-sm text-[#0b1c30] outline-none transition-colors duration-200"
                          placeholder="••••••••"
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegPass(!showRegPass)}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-[#44474c] hover:text-[#0b1c30] transition-colors p-1 rounded-md focus:outline-none flex items-center justify-center cursor-pointer"
                          aria-label={showRegPass ? "Hide password" : "Show password"}
                        >
                          {showRegPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] mb-1">
                        Confirm
                      </label>
                      <div className="relative">
                        <input 
                          type={showRegConf ? "text" : "password"} 
                          value={regConf}
                          onChange={(e) => setRegConf(e.target.value)}
                          required
                          className="w-full bg-[#eff4ff] border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md pl-4 pr-10 py-2.5 text-sm text-[#0b1c30] outline-none transition-colors duration-200"
                          placeholder="••••••••"
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegConf(!showRegConf)}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-[#44474c] hover:text-[#0b1c30] transition-colors p-1 rounded-md focus:outline-none flex items-center justify-center cursor-pointer"
                          aria-label={showRegConf ? "Hide password" : "Show password"}
                        >
                          {showRegConf ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#0b1c30] mb-1">
                      Select Your Workspace Role
                    </label>
                    <select 
                      value={regRole} 
                      onChange={(e) => setRegRole(e.target.value as UserRole)}
                      className="w-full bg-[#eff4ff] border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-2.5 text-base text-[#0b1c30] outline-none transition-colors duration-200"
                    >
                      <option value="homeowner">Homeowner / Client</option>
                      <option value="professional">Architect / Contractor / Professional</option>
                      <option value="shopkeeper">Supplier / Shopkeeper</option>
                    </select>
                  </div>

                  {regRole === 'professional' && (
                    <div className="space-y-4 animate-fadeIn bg-amber-50/50 p-3.5 rounded-lg border border-amber-200/50">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-[#0b1c30] uppercase tracking-wide mb-1">
                            Profession Type
                          </label>
                          <select
                            value={expertProfession}
                            onChange={(e) => setExpertProfession(e.target.value)}
                            className="w-full bg-white border border-[#c4c6cd] rounded-md px-3 py-2 text-sm text-[#0b1c30] outline-none"
                          >
                            <option value="Engineer">Engineer</option>
                            <option value="Architect">Architect</option>
                            <option value="Interior Designer">Interior Designer</option>
                            <option value="Plumber">Plumber</option>
                            <option value="Laborer">Laborer</option>
                            <option value="Electrician">Electrician</option>
                            <option value="Carpenter">Carpenter</option>
                            <option value="Painter">Painter</option>
                            <option value="Mason">Mason</option>
                            <option value="Welder">Welder</option>
                            <option value="Roofing Specialist">Roofing Specialist</option>
                            <option value="Other Expert">Other Expert</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-[#0b1c30] uppercase tracking-wide mb-1">
                            Years of Exp.
                          </label>
                          <input
                            type="number"
                            min="1"
                            max="50"
                            value={expertYears}
                            onChange={(e) => setExpertYears(e.target.value)}
                            required={regRole === 'professional'}
                            className="w-full bg-white border border-[#c4c6cd] rounded-md px-3 py-2 text-sm text-[#0b1c30] outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <button 
                    type="submit"
                    className="w-full text-white font-semibold py-3 rounded-lg transition-all duration-200 shadow-sm mt-4 hover:shadow-md cursor-pointer bg-[#fd8b00] hover:bg-[#e07b00]"
                  >
                    {joinButtonText}
                  </button>
                </form>
              )
            )}

            {/* Forgot Password Tab */}
            {activeTab === 'forgot' && (
              <div className="space-y-5 animate-fadeIn">
                <div className="text-center mb-6">
                  <h3 className="text-lg font-bold text-[#0b1c30] dark:text-white">
                    Password Recovery
                  </h3>
                  <p className="text-xs text-[#44474c] dark:text-slate-400 mt-1">
                    {!isForgotOtpSent 
                      ? "Enter your registered email address to receive a verification code." 
                      : "Enter the verification code sent to your email to reset your password."}
                  </p>
                </div>

                {!isForgotOtpSent ? (
                  <form onSubmit={handleForgotSendOtp} className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                        Email Address
                      </label>
                      <input 
                        type="email" 
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        required
                        className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200"
                        placeholder="your-email@example.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                        Select Your Role
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <button
                          type="button"
                          onClick={() => setForgotRole('homeowner')}
                          className={`py-2.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                            forgotRole === 'homeowner'
                              ? 'bg-[#fd8b00] text-white border-[#fd8b00] shadow-sm'
                              : 'bg-[#eff4ff] dark:bg-slate-800 text-[#0b1c30] dark:text-slate-200 border-transparent hover:border-[#fd8b00]/50'
                          }`}
                        >
                          Client
                        </button>
                        <button
                          type="button"
                          onClick={() => setForgotRole('professional')}
                          className={`py-2.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                            forgotRole === 'professional'
                              ? 'bg-[#fd8b00] text-white border-[#fd8b00] shadow-sm'
                              : 'bg-[#eff4ff] dark:bg-slate-800 text-[#0b1c30] dark:text-slate-200 border-transparent hover:border-[#fd8b00]/50'
                          }`}
                        >
                          Expert
                        </button>
                        <button
                          type="button"
                          onClick={() => setForgotRole('shopkeeper')}
                          className={`py-2.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                            forgotRole === 'shopkeeper'
                              ? 'bg-[#fd8b00] text-white border-[#fd8b00] shadow-sm'
                              : 'bg-[#eff4ff] dark:bg-slate-800 text-[#0b1c30] dark:text-slate-200 border-transparent hover:border-[#fd8b00]/50'
                          }`}
                        >
                          Shopkeeper
                        </button>
                        <button
                          type="button"
                          onClick={() => setForgotRole('admin')}
                          className={`py-2.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                            forgotRole === 'admin'
                              ? 'bg-[#fd8b00] text-white border-[#fd8b00] shadow-sm'
                              : 'bg-[#eff4ff] dark:bg-slate-800 text-[#0b1c30] dark:text-slate-200 border-transparent hover:border-[#fd8b00]/50'
                          }`}
                        >
                          Admin
                        </button>
                      </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={isForgotSending}
                      onClick={() => console.log("Forgot Password button clicked")}
                      className="w-full bg-[#fd8b00] hover:bg-[#e07b00] text-white font-semibold py-3.5 rounded-lg transition-all duration-200 shadow-sm mt-6 hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isForgotSending ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Sending Code...
                        </>
                      ) : (
                        "Send Verification Code"
                      )}
                    </button>

                    <div className="text-center mt-4">
                      <button
                        type="button"
                        onClick={() => { setActiveTab('login'); setError(null); setSuccess(null); }}
                        className="text-xs font-semibold text-[#041627] dark:text-slate-300 hover:text-[#fd8b00] transition-colors"
                      >
                        Back to Login
                      </button>
                    </div>
                  </form>
                ) : (
                  <form onSubmit={handleForgotVerifyAndReset} className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                        Verification Code (OTP)
                      </label>
                      <input 
                        type="text" 
                        value={forgotOtp}
                        onChange={(e) => setForgotOtp(e.target.value)}
                        required
                        className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md px-4 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200 tracking-wider text-center font-mono font-bold"
                        placeholder="123456"
                        maxLength={6}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                        New Password
                      </label>
                      <div className="relative">
                        <input 
                          type={showForgotNewPass ? "text" : "password"} 
                          value={forgotNewPass}
                          onChange={(e) => setForgotNewPass(e.target.value)}
                          required
                          className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md pl-4 pr-12 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200"
                          placeholder="At least 6 characters"
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowForgotNewPass(!showForgotNewPass)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#44474c] dark:text-slate-400 hover:text-[#0b1c30] dark:hover:text-white transition-colors p-1.5 rounded-md focus:outline-none flex items-center justify-center cursor-pointer"
                          aria-label={showForgotNewPass ? "Hide password" : "Show password"}
                        >
                          {showForgotNewPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#0b1c30] dark:text-slate-200 mb-2">
                        Confirm New Password
                      </label>
                      <div className="relative">
                        <input 
                          type={showForgotConfPass ? "text" : "password"} 
                          value={forgotConfirmPass}
                          onChange={(e) => setForgotConfirmPass(e.target.value)}
                          required
                          className="w-full bg-[#eff4ff] dark:bg-slate-800 border-0 border-b-2 border-transparent focus:border-[#fd8b00] rounded-t-md pl-4 pr-12 py-3 text-base text-[#0b1c30] dark:text-slate-100 outline-none transition-colors duration-200"
                          placeholder="Re-enter new password"
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowForgotConfPass(!showForgotConfPass)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#44474c] dark:text-slate-400 hover:text-[#0b1c30] dark:hover:text-white transition-colors p-1.5 rounded-md focus:outline-none flex items-center justify-center cursor-pointer"
                          aria-label={showForgotConfPass ? "Hide password" : "Show password"}
                        >
                          {showForgotConfPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={isForgotResetting}
                      className="w-full bg-[#fd8b00] hover:bg-[#e07b00] text-white font-semibold py-3.5 rounded-lg transition-all duration-200 shadow-sm mt-6 hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isForgotResetting ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Resetting Password...
                        </>
                      ) : (
                        "Reset Password"
                      )}
                    </button>

                    <div className="flex justify-between items-center text-xs mt-4">
                      <button
                        type="button"
                        onClick={() => { setIsForgotOtpSent(false); setError(null); setSuccess(null); }}
                        className="font-semibold text-[#44474c] dark:text-slate-400 hover:text-[#0b1c30] dark:hover:text-white transition-colors"
                      >
                        Change Email
                      </button>
                      <button
                        type="button"
                        onClick={() => { setActiveTab('login'); setError(null); setSuccess(null); }}
                        className="font-semibold text-[#041627] dark:text-slate-300 hover:text-[#fd8b00] transition-colors"
                      >
                        Back to Login
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

          </div>



          {/* Account Recovery Modal */}
          {showRecoveryModal && (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-extrabold text-[#041627]">Account Recovery Verification</h3>
                  <button 
                    onClick={() => setShowRecoveryModal(false)}
                    className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {recoverySuccessMessage ? (
                  <div className="p-4 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-semibold text-center flex flex-col items-center gap-2">
                    <CheckCircle className="w-8 h-8" />
                    Your account has been successfully reactivated! Logging you in...
                  </div>
                ) : (
                  <form onSubmit={handleVerifyRecoveryOtp} className="space-y-4 text-xs">
                    <p className="text-slate-600 font-medium">
                      Your account has been temporarily disabled. We have sent a recovery verification code to your registered email.
                    </p>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Enter Recovery OTP</label>
                      <input 
                        type="text"
                        maxLength={6}
                        value={recoveryOtp}
                        onChange={(e) => setRecoveryOtp(e.target.value)}
                        placeholder="e.g. 482910"
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#fd8b00] font-mono tracking-widest text-center text-sm font-bold"
                        required
                      />
                    </div>
                    {recoveryOtpError && (
                      <div className="p-3 bg-red-50 text-red-600 border border-red-100 rounded-xl font-medium">
                        {recoveryOtpError}
                      </div>
                    )}
                    <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setShowRecoveryModal(false)}
                        className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isVerifyingRecovery}
                        className="px-5 py-2.5 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50"
                      >
                        {isVerifyingRecovery ? 'Verifying...' : 'Reactivate & Login'}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
