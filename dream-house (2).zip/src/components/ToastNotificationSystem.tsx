import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, Info, AlertTriangle, X, ShoppingCart, Bell } from 'lucide-react';
import { ToastNotification } from '../types';

interface ToastItemProps {
  key?: string;
  toast: ToastNotification;
  onClose: (id: string) => void;
  onActionClick?: (toast: ToastNotification) => void;
}

export function ToastItem({ toast, onClose, onActionClick }: ToastItemProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose(toast.id);
    }, 4000); // Auto-dismiss after 4s (3-5s range)
    return () => clearTimeout(timer);
  }, [toast.id, onClose]);

  const getIcon = () => {
    switch (toast.type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />;
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />;
      case 'info':
      default:
        if (toast.orderId) {
          return <ShoppingCart className="w-5 h-5 text-[#fd8b00] shrink-0" />;
        }
        return <Info className="w-5 h-5 text-blue-500 shrink-0" />;
    }
  };

  const getBgColor = () => {
    switch (toast.type) {
      case 'success':
        return 'bg-white border-l-4 border-emerald-500';
      case 'warning':
        return 'bg-white border-l-4 border-amber-500';
      case 'error':
        return 'bg-white border-l-4 border-red-500';
      case 'info':
      default:
        return 'bg-white border-l-4 border-[#fd8b00]';
    }
  };

  return (
    <motion.div
      id={`toast-${toast.id}`}
      layout
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 100, scale: 0.9, transition: { duration: 0.2 } }}
      className={`w-full max-w-sm ${getBgColor()} rounded-r-lg shadow-xl border border-gray-100 p-4 flex gap-3 pointer-events-auto relative overflow-hidden`}
    >
      {/* Background overlay pulse for important alerts */}
      {toast.orderId && (
        <div className="absolute inset-0 bg-orange-50/10 pointer-events-none animate-pulse" />
      )}

      {getIcon()}

      <div className="flex-1 min-w-0 pr-4">
        <div className="flex items-center gap-1.5 mb-1">
          <span className="font-heading text-xs font-bold text-gray-900 leading-tight">
            {toast.title}
          </span>
          {toast.roleScope === 'shopkeeper' && (
            <span className="bg-amber-100 text-amber-900 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider shrink-0">
              Shopkeeper
            </span>
          )}
        </div>
        <p className="text-xs text-gray-600 leading-relaxed break-words">
          {toast.message}
        </p>

        {toast.orderId && onActionClick && (
          <button
            onClick={() => onActionClick(toast)}
            className="mt-2.5 text-[10px] font-bold text-[#fd8b00] hover:text-[#e07b00] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Bell className="w-3 h-3" />
            Go to Fulfillment Screen
          </button>
        )}
      </div>

      <button
        onClick={() => onClose(toast.id)}
        className="text-gray-400 hover:text-gray-600 self-start p-0.5 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
        aria-label="Dismiss toast"
      >
        <X className="w-4 h-4" />
      </button>
    </motion.div>
  );
}

interface ToastContainerProps {
  toasts: ToastNotification[];
  onCloseToast: (id: string) => void;
  onActionClick?: (toast: ToastNotification) => void;
}

export function ToastContainer({ toasts, onCloseToast, onActionClick }: ToastContainerProps) {
  return (
    <div 
      id="toast-notification-container"
      className="fixed top-24 right-6 z-50 flex flex-col gap-3 w-full max-w-sm pointer-events-none"
    >
      <AnimatePresence mode="popLayout">
        {toasts.map((toast) => (
          <ToastItem
            key={toast.id}
            toast={toast}
            onClose={onCloseToast}
            onActionClick={onActionClick}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}
