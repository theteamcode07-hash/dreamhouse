import React, { useRef, useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CategoryScrollNavProps {
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  activeColorClass?: string;
  inactiveColorClass?: string;
  className?: string;
}

export const CategoryScrollNav: React.FC<CategoryScrollNavProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  activeColorClass = 'bg-[#1a2b3c] text-white shadow-sm',
  inactiveColorClass = 'bg-[#f0f4fa] text-[#44474c] hover:bg-[#e2eaf5] hover:text-[#041627] dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700',
  className = '',
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  // Drag-to-scroll state
  const [isMouseDown, setIsMouseDown] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeftPos, setScrollLeftPos] = useState(0);
  const [hasDragged, setHasDragged] = useState(false);

  // Check scroll boundary visibility
  const updateScrollButtons = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const { scrollLeft, scrollWidth, clientWidth } = el;
    const nextLeft = scrollLeft > 2;
    const nextRight = scrollLeft < scrollWidth - clientWidth - 2;
    setCanScrollLeft(prev => prev !== nextLeft ? nextLeft : prev);
    setCanScrollRight(prev => prev !== nextRight ? nextRight : prev);
  }, []);

  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;

    updateScrollButtons();

    const handleScroll = () => {
      updateScrollButtons();
    };

    el.addEventListener('scroll', handleScroll, { passive: true });

    const resizeObserver = new ResizeObserver(() => {
      updateScrollButtons();
    });
    resizeObserver.observe(el);

    return () => {
      el.removeEventListener('scroll', handleScroll);
      resizeObserver.disconnect();
    };
  }, [categories, updateScrollButtons]);

  useEffect(() => {
    updateScrollButtons();
  }, [selectedCategory, updateScrollButtons]);

  // Smooth scroll using arrow buttons
  const handleScrollClick = (direction: 'left' | 'right') => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const scrollAmount = Math.max(el.clientWidth * 0.65, 200);
    el.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  // Convert vertical mouse wheel into horizontal scroll
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    const el = scrollContainerRef.current;
    if (!el) return;

    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      if ((e.deltaY > 0 && canScrollRight) || (e.deltaY < 0 && canScrollLeft)) {
        el.scrollLeft += e.deltaY;
      }
    }
  };

  // Drag to scroll (mouse grab)
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = scrollContainerRef.current;
    if (!el) return;
    // Only drag with left mouse button
    if (e.button !== 0) return;

    setIsMouseDown(true);
    setHasDragged(false);
    setStartX(e.pageX - el.offsetLeft);
    setScrollLeftPos(el.scrollLeft);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isMouseDown) return;
    const el = scrollContainerRef.current;
    if (!el) return;

    e.preventDefault();
    const x = e.pageX - el.offsetLeft;
    const walk = (x - startX) * 1.5;
    if (Math.abs(x - startX) > 5) {
      setHasDragged(true);
    }
    el.scrollLeft = scrollLeftPos - walk;
  };

  const handleMouseUpOrLeave = () => {
    setIsMouseDown(false);
  };

  const handleCategoryClick = (cat: string, e: React.MouseEvent) => {
    if (hasDragged) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    onSelectCategory(cat);
  };

  return (
    <div className={`relative flex items-center min-w-0 w-full group/catnav ${className}`}>
      {/* Left Gradient Overlay */}
      <div 
        className={`absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-white via-white/80 to-transparent dark:from-slate-900 dark:via-slate-900/80 pointer-events-none z-10 transition-opacity duration-300 ${
          canScrollLeft ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Left Arrow Button */}
      <button
        type="button"
        onClick={() => handleScrollClick('left')}
        disabled={!canScrollLeft}
        aria-label="Scroll left"
        className={`absolute left-0 z-20 flex items-center justify-center w-8 h-8 rounded-full bg-white dark:bg-slate-800 text-[#041627] dark:text-slate-100 shadow-md border border-gray-200 dark:border-slate-700 transition-all duration-300 hover:bg-gray-50 dark:hover:bg-slate-700 hover:scale-105 active:scale-95 ${
          canScrollLeft
            ? 'opacity-100 scale-100 pointer-events-auto cursor-pointer'
            : 'opacity-0 scale-90 pointer-events-none'
        }`}
      >
        <ChevronLeft className="w-5 h-5 shrink-0" />
      </button>

      {/* Scrollable Category Row */}
      <div
        ref={scrollContainerRef}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseLeave={handleMouseUpOrLeave}
        className={`flex items-center gap-2 overflow-x-auto py-1 px-8 min-w-0 w-full scrollbar-none no-scrollbar select-none touch-pan-x transition-colors ${
          isMouseDown ? 'cursor-grabbing' : 'cursor-grab'
        }`}
        style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
        }}
      >
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              type="button"
              onClick={(e) => handleCategoryClick(cat, e)}
              aria-selected={isSelected}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 shrink-0 select-none cursor-pointer ${
                isSelected ? activeColorClass : inactiveColorClass
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Right Gradient Overlay */}
      <div 
        className={`absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-white via-white/80 to-transparent dark:from-slate-900 dark:via-slate-900/80 pointer-events-none z-10 transition-opacity duration-300 ${
          canScrollRight ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Right Arrow Button */}
      <button
        type="button"
        onClick={() => handleScrollClick('right')}
        disabled={!canScrollRight}
        aria-label="Scroll right"
        className={`absolute right-0 z-20 flex items-center justify-center w-8 h-8 rounded-full bg-white dark:bg-slate-800 text-[#041627] dark:text-slate-100 shadow-md border border-gray-200 dark:border-slate-700 transition-all duration-300 hover:bg-gray-50 dark:hover:bg-slate-700 hover:scale-105 active:scale-95 ${
          canScrollRight
            ? 'opacity-100 scale-100 pointer-events-auto cursor-pointer'
            : 'opacity-0 scale-90 pointer-events-none'
        }`}
      >
        <ChevronRight className="w-5 h-5 shrink-0" />
      </button>
    </div>
  );
};
