import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, Store, TrendingUp, AlertTriangle, Package, DollarSign, 
  CheckCircle, Plus, ShoppingBag, Truck, RefreshCw, Layers, Tag,
  Upload, X, MapPin, Phone, Shield, List, Sparkles, Clock, Info, User,
  Edit, Trash2, Search, MessageSquare, Menu, Printer, Settings, CreditCard, Megaphone
} from 'lucide-react';
import { Order, InventoryItem, Product } from '../types';
import MessagePortal from './MessagePortal';
import SharedProfileSettings from './SharedProfileSettings';
import ShopkeeperPaymentSettings from './ShopkeeperPaymentSettings';
import AnnouncementsView from './AnnouncementsView';
import { CategoryScrollNav } from './CategoryScrollNav';
import { db, auth } from '../lib/firebase';
import { doc, updateDoc, collection, onSnapshot, setDoc } from 'firebase/firestore';

const DEFAULT_UNITS: string[] = [
  'Piece',
  'Pieces (pcs)',
  'Kg',
  'Kilogram (kg)',
  'Gram (g)',
  'Ton',
  'Tons (ton)',
  'Bag',
  'Bags',
  'Box',
  'Boxes',
  'Bundle',
  'Roll',
  'Sheet',
  'Meter (m)',
  'Feet (ft)',
  'Inch',
  'Square Feet (sq ft)',
  'Square Meter (m²)',
  'Cubic Feet (ft³)',
  'Cubic Meter (m³)',
  'Litre (L)',
  'Millilitre (ml)',
  'Packet',
  'Carton',
  'Set',
  'Pair',
  'Dozen',
  'Truck Load',
  'Tractor Load',
  'Pickup Load',
  'Container'
];
import { subscribeToUserMessages } from '../lib/messaging';
import { optimizeImage } from '../lib/fileUploader';

const alert = (msg: string) => {
  try {
    window.alert(msg);
  } catch (e) {
    console.warn("Alert blocked in sandbox:", msg);
  }
};

interface ShopkeeperDashboardProps {
  username?: string;
  userAvatar?: string;
  userEmail?: string;
  userPhone?: string;
  registrationDate?: string;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  orders: Order[];
  onShipOrder: (id: string) => void;
  onLogout: () => void;
  highlightedOrderId?: string | null;
  onClearHighlight?: () => void;
  onUpdateAvatar?: (newAvatar: string) => void;
  onUpdateProfile?: (updatedData: { fullName?: string; phone?: string; avatar?: string }) => void;
}

export default function ShopkeeperDashboard({
  username = '',
  userAvatar,
  userEmail = '',
  userPhone = '',
  registrationDate = '',
  products,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  orders,
  onShipOrder,
  onLogout,
  highlightedOrderId,
  onClearHighlight,
  onUpdateAvatar,
  onUpdateProfile
}: ShopkeeperDashboardProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [activeTab, setActiveTab] = useState<'orders' | 'inventory' | 'items' | 'messages' | 'profile' | 'payments' | 'announcements'>('orders');
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadAnnouncementsCount, setUnreadAnnouncementsCount] = useState(0);

  // Unread announcements listener
  useEffect(() => {
    const email = (userEmail || auth.currentUser?.email || '').trim().toLowerCase();
    const activeUid = auth.currentUser?.uid || '';

    if (!activeUid || !email) {
      setUnreadAnnouncementsCount(0);
      return;
    }

    let allAnns: any[] = [];
    let readIds = new Set<string>();

    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      allAnns = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      recalc();
    });

    const unsubReads = onSnapshot(collection(db, 'announcement_reads'), (snapshot) => {
      readIds = new Set();
      snapshot.docs.forEach(d => {
        const data = d.data();
        if ((data.userId && data.userId === activeUid) || (data.userEmail && data.userEmail.toLowerCase() === email)) {
          readIds.add(data.announcementId);
        }
      });
      recalc();
    });

    function recalc() {
      const unread = allAnns.filter(item => {
        const target = item.targetAudience || item.targetRole || 'All';
        const isTargeted = 
          target === 'All' ||
          target === 'shopkeeper' ||
          (target === 'individual' && ((item.targetUserEmail || '').toLowerCase() === email || item.targetUserId === activeUid));
        if (!isTargeted) return false;
        if (item.scheduleTime && new Date(item.scheduleTime) > new Date()) return false;
        
        // Only show/count announcements published on or after user account creation date
        if (registrationDate) {
          const itemDate = new Date(item.createdAt || item.scheduleTime || 0);
          const userDate = new Date(registrationDate);
          if (!isNaN(itemDate.getTime()) && !isNaN(userDate.getTime())) {
            if (itemDate < userDate) {
              return false;
            }
          }
        }

        return !readIds.has(item.id);
      }).length;
      setUnreadAnnouncementsCount(unread);
    }

    return () => {
      unsubAnnouncements();
      unsubReads();
    };
  }, [userEmail, registrationDate, auth.currentUser?.uid]);

  useEffect(() => {
    const email = (userEmail || 'shopkeeper@gmail.com').trim();
    if (!email) return;

    const unsub = subscribeToUserMessages(email, (msgs) => {
      const emailLower = email.toLowerCase().trim();
      const count = msgs.filter((m) => {
        const rEmail = (m.recipientEmail || m.recipientId || '').toLowerCase().trim();
        return rEmail === emailLower && !m.read;
      }).length;
      setUnreadCount(count);
    });

    return () => unsub();
  }, [userEmail]);

  const [selectedItemCategory, setSelectedItemCategory] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [selectedOrderForDetail, setSelectedOrderForDetail] = useState<Order | null>(null);

  // Sync details in real-time
  useEffect(() => {
    if (selectedOrderForDetail) {
      const updatedOrder = orders.find(o => o.id === selectedOrderForDetail.id);
      if (updatedOrder) {
        setSelectedOrderForDetail(updatedOrder);
      }
    }
  }, [orders]);

  const handleUpdateOrderStatus = async (orderId: string, newStatus: any, additionalFields: any = {}) => {
    try {
      const orderRef = doc(db, 'orders', orderId);
      await updateDoc(orderRef, {
        status: newStatus,
        updatedAt: new Date().toISOString(),
        ...additionalFields
      });
      // Update local state in selectedOrderForDetail as well so that UI refreshes in real-time
      setSelectedOrderForDetail(prev => prev ? {
        ...prev,
        status: newStatus,
        updatedAt: new Date().toISOString(),
        ...additionalFields
      } : null);
    } catch (err) {
      console.error("Failed to update order status in Firestore:", err);
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const compressAndResizeImage = (file: File, callback: (base64: string) => void) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 150;
          const MAX_HEIGHT = 150;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            callback(compressedBase64);
          } else {
            callback(event.target?.result as string);
          }
        } catch (e) {
          console.error("Canvas compression failed, using original reader result", e);
          callback(event.target?.result as string);
        }
      };
      img.onerror = () => {
        callback(event.target?.result as string);
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      callback("");
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      compressAndResizeImage(file, (base64Url) => {
        if (onUpdateAvatar) {
          onUpdateAvatar(base64Url);
        }
      });
    }
  };

  // Form states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [successPopup, setSuccessPopup] = useState<string | null>(null);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [activeOrderTab, setActiveOrderTab] = useState<'active' | 'delivered' | 'cancelled'>('active');

  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('Bricks');
  const [formBrand, setFormBrand] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formDiscountPrice, setFormDiscountPrice] = useState('');
  const [formQuantity, setFormQuantity] = useState('');
  const [formUnit, setFormUnit] = useState('Piece');
  const [formStockStatus, setFormStockStatus] = useState('In Stock');
  const [formDelivery, setFormDelivery] = useState(true);
  const [formLocation, setFormLocation] = useState('');
  const [formContact, setFormContact] = useState('');
  const [formWarranty, setFormWarranty] = useState('');
  const [formSpecs, setFormSpecs] = useState('');
  const [formTags, setFormTags] = useState('');
  const [formImage, setFormImage] = useState('');

  // Unit of Measure Creatable Select States
  const [firestoreUnits, setFirestoreUnits] = useState<string[]>([]);
  const [unitSearchQuery, setUnitSearchQuery] = useState('');
  const [isUnitDropdownOpen, setIsUnitDropdownOpen] = useState(false);
  const unitDropdownRef = useRef<HTMLDivElement>(null);

  // Real-time listener for Firestore custom units
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'units'), (snapshot) => {
      const unitsList: string[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data && data.name && typeof data.name === 'string') {
          unitsList.push(data.name);
        }
      });
      setFirestoreUnits(unitsList);
    }, (err) => {
      console.warn("Units snapshot error:", err);
    });
    return () => unsub();
  }, []);

  // Close unit dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (unitDropdownRef.current && !unitDropdownRef.current.contains(event.target as Node)) {
        setIsUnitDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Combined available units (Defaults + Firestore Saved + Existing Products)
  const allAvailableUnits = Array.from(new Set([
    ...DEFAULT_UNITS,
    ...firestoreUnits,
    ...(products || []).map(p => p.unit).filter((u): u is string => Boolean(u)),
    ...(products || []).flatMap(p => p.allowedUnits || [])
  ])).filter(Boolean);

  const filteredUnits = allAvailableUnits.filter(unit => 
    unit.toLowerCase().includes(unitSearchQuery.toLowerCase().trim())
  );

  const exactMatchExists = allAvailableUnits.some(
    unit => unit.toLowerCase() === unitSearchQuery.toLowerCase().trim()
  );

  const saveCustomUnit = async (unitName: string) => {
    const trimmed = unitName.trim();
    if (!trimmed) return;
    const docId = `unit_${trimmed.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
    try {
      await setDoc(doc(db, 'units', docId), {
        name: trimmed,
        createdAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.error("Error saving custom unit to Firestore:", err);
    }
  };

  const handleSelectUnit = (unitName: string) => {
    setFormUnit(unitName);
    setUnitSearchQuery('');
    setIsUnitDropdownOpen(false);
  };

  const handleCreateAndSelectUnit = (newUnitName: string) => {
    const trimmed = newUnitName.trim();
    if (!trimmed) return;

    setFormUnit(trimmed);
    setUnitSearchQuery('');
    setIsUnitDropdownOpen(false);
    saveCustomUnit(trimmed);
  };

  const productFileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      try {
        const opt = await optimizeImage(file, 1200, 0.85);
        setFormImage(opt.dataUrl);
      } catch {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormImage(reader.result as string);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const opt = await optimizeImage(file, 1200, 0.85);
        setFormImage(opt.dataUrl);
      } catch {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormImage(reader.result as string);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const resetForm = () => {
    setFormName('');
    setFormCategory('Bricks');
    setFormBrand('');
    setFormDescription('');
    setFormPrice('');
    setFormDiscountPrice('');
    setFormQuantity('');
    setFormUnit('Piece');
    setUnitSearchQuery('');
    setIsUnitDropdownOpen(false);
    setFormStockStatus('In Stock');
    setFormDelivery(true);
    setFormLocation('');
    setFormContact('');
    setFormWarranty('');
    setFormSpecs('');
    setFormTags('');
    setFormImage('');
  };

  const handleOpenEdit = (product: Product) => {
    setEditingProduct(product);
    setFormName(product.name || '');
    setFormCategory(product.category || 'Bricks');
    setFormBrand(product.brand || '');
    setFormDescription(product.description || '');
    setFormPrice(product.price !== undefined ? product.price.toString() : '');
    setFormDiscountPrice(product.originalPrice !== undefined ? product.originalPrice.toString() : '');
    setFormQuantity(product.availableQuantity !== undefined ? product.availableQuantity.toString() : '');
    setFormUnit(product.unit || 'Piece');
    setUnitSearchQuery('');
    setIsUnitDropdownOpen(false);
    setFormStockStatus(product.stockStatus || 'In Stock');
    setFormDelivery(product.deliveryAvailability !== undefined ? product.deliveryAvailability : true);
    setFormLocation(product.location || '');
    setFormContact(product.contactNumber || '');
    setFormWarranty(product.warranty || '');
    setFormSpecs(product.specifications || '');
    setFormTags(product.tags ? product.tags.join(', ') : '');
    setFormImage(product.image || '');
    setIsFormOpen(true);
  };

  const handleOpenAdd = () => {
    setEditingProduct(null);
    resetForm();
    setIsFormOpen(true);
  };

  const handlePublishSubmit = (isDraftValue: boolean) => {
    if (!formName.trim()) return alert('Please enter a product name.');
    if (!formPrice || parseFloat(formPrice) <= 0) return alert('Please enter a valid price.');
    if (!formQuantity || parseInt(formQuantity) < 0) return alert('Please enter available quantity.');
    if (!formLocation.trim()) return alert('Please enter product warehouse/store location.');
    if (!formContact.trim()) return alert('Please enter a contact number.');

    const selectedUnitName = formUnit.trim() || 'Piece';
    saveCustomUnit(selectedUnitName);

    if (editingProduct) {
      const updatedProduct: Product = {
        ...editingProduct,
        name: formName.trim(),
        category: formCategory,
        brand: formBrand.trim() || 'Generic',
        description: formDescription.trim(),
        price: parseFloat(formPrice),
        originalPrice: formDiscountPrice ? parseFloat(formDiscountPrice) : undefined,
        image: formImage.trim() || '',
        availableQuantity: parseInt(formQuantity),
        unit: selectedUnitName,
        stockStatus: formStockStatus,
        deliveryAvailability: formDelivery,
        location: formLocation.trim(),
        contactNumber: formContact.trim(),
        warranty: formWarranty.trim() || undefined,
        specifications: formSpecs.trim() || undefined,
        tags: formTags ? formTags.split(',').map(t => t.trim()).filter(Boolean) : [],
        isDraft: isDraftValue,
        freeDelivery: formDelivery
      };
      onEditProduct(updatedProduct);
      setSuccessPopup('Item updated successfully.');
    } else {
      const newProduct: Product = {
        id: `prod-custom-${Date.now()}`,
        name: formName.trim(),
        category: formCategory,
        brand: formBrand.trim() || 'Generic',
        description: formDescription.trim(),
        price: parseFloat(formPrice),
        originalPrice: formDiscountPrice ? parseFloat(formDiscountPrice) : undefined,
        image: formImage.trim() || '',
        availableQuantity: parseInt(formQuantity),
        unit: selectedUnitName,
        stockStatus: formStockStatus,
        deliveryAvailability: formDelivery,
        location: formLocation.trim(),
        contactNumber: formContact.trim(),
        warranty: formWarranty.trim() || undefined,
        specifications: formSpecs.trim() || undefined,
        tags: formTags ? formTags.split(',').map(t => t.trim()).filter(Boolean) : [],
        isDraft: isDraftValue,
        freeDelivery: formDelivery,
        seller: {
          id: `seller-${Date.now()}`,
          name: username || 'Demo Shopkeeper',
          shopName: 'ProBuild Materials Inc.',
          avatar: userAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 4.9,
          reviewsCount: 142,
          email: userEmail || 'shopkeeper@gmail.com',
          phone: formContact.trim() || '9876543212',
          location: formLocation.trim() || '102 Industrial Parkway, Building B, Austin, TX',
          bio: 'Premier supplier of contractor-grade construction materials, red clay bricks, certified rebar, and Portland cement. Serving builders for over 12 years.',
          yearsOfExperience: 12
        }
      };
      onAddProduct(newProduct);
      if (isDraftValue) {
        setSuccessPopup('Draft saved successfully.');
      } else {
        setSuccessPopup('Item published successfully.');
      }
    }
    
    setIsFormOpen(false);
    resetForm();
    setEditingProduct(null);
  };

  const handleDeleteConfirm = () => {
    if (deleteTargetId) {
      onDeleteProduct(deleteTargetId);
      setDeleteTargetId(null);
      setSuccessPopup('Item deleted successfully.');
    }
  };

  const fillSampleData = () => {
    setFormName('Premium Rust-Oleum Weathered Wood Accent Paint');
    setFormCategory('Paint');
    setFormBrand('Rust-Oleum');
    setFormDescription('An elite water-based weatherproofing paint that guards against micro-fissures and moisture rot on raw pine paneling and cladding.');
    setFormPrice('54.99');
    setFormDiscountPrice('49.50');
    setFormQuantity('45');
    setFormUnit('Piece');
    setFormStockStatus('In Stock');
    setFormDelivery(true);
    setFormLocation('Warehouse B, Section 4');
    setFormContact('+1 (555) 234-5678');
    setFormWarranty('5-Year Weather Shield Warranty');
    setFormSpecs('Gloss finish, VOC compliant, Dries in 2 hours');
    setFormTags('paint, weatherproof, exterior, premium, finish');
    setFormImage('');
  };

  const isProductInCategory = (pCategory: string, filterCategory: string) => {
    if (filterCategory === 'All') return true;
    const cat1 = pCategory.toLowerCase().trim();
    const cat2 = filterCategory.toLowerCase().trim();
    if (cat1 === cat2) return true;
    if (cat2 === 'bricks' && cat1 === 'brick') return true;
    if (cat2 === 'iron & steel' && (cat1 === 'iron rod' || cat1 === 'metal')) return true;
    return false;
  };

  const itemCategories = [
    'All',
    'Bricks',
    'Iron & Steel',
    'Furniture',
    'House Decoration',
    'Cement',
    'Paint',
    'Electrical',
    'Plumbing',
    'Tiles & Flooring',
    'Doors & Windows',
    'Roofing Materials',
    'Tools & Equipment',
    'Other'
  ];

  const shopkeeperProducts = products.filter(p => {
    if (!p.seller) return true;
    if (userEmail && p.seller.email && p.seller.email.toLowerCase() === userEmail.toLowerCase()) {
      return true;
    }
    if (username && p.seller.name && p.seller.name.toLowerCase() === username.toLowerCase()) {
      return true;
    }
    if (!p.seller.email && !p.seller.name) return true;
    return false;
  });

  const currentUid = auth.currentUser?.uid || '';
  const cleanShopkeeperEmail = (userEmail || auth.currentUser?.email || '').toLowerCase().trim();

  // Filter orders relevant to this shopkeeper
  const shopOrders = React.useMemo(() => {
    if (!cleanShopkeeperEmail && !currentUid) return [];
    return orders.filter(o => {
      const sEmail = (o.shopkeeperEmail || o.sellerEmail || o.seller?.email || '').toLowerCase().trim();
      const sId = o.shopkeeperId || '';
      return (cleanShopkeeperEmail && sEmail === cleanShopkeeperEmail) || (currentUid && sId === currentUid);
    });
  }, [orders, cleanShopkeeperEmail, currentUid]);

  const filteredItems = shopkeeperProducts.filter(p => {
    const matchesCategory = isProductInCategory(p.category, selectedItemCategory);
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (p.brand && p.brand.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          (p.description && p.description.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // Calculate stats
  const totalSales = shopOrders.reduce((acc, o) => acc + (o.amount || o.totalPrice || 0), 0);
  const lowStockCount = inventory.filter(item => item.status === 'Low Stock' || item.status === 'Out of Stock').length;

  const handleRestock = (id: string) => {
    setInventory(inventory.map((item) => {
      if (item.id !== id) return item;
      return {
        ...item,
        qty: item.id === 'inv-3' ? '20 units' : '100 bags',
        status: 'In Stock'
      };
    }));
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] flex h-screen font-sans overflow-hidden relative">
      
      {/* Sidebar Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <nav 
        onClickCapture={() => setSidebarOpen(false)}
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#1a2b3c] text-white flex flex-col p-6 shadow-md transition-transform duration-300 ease-in-out shrink-0 overflow-y-auto no-scrollbar md:translate-x-0 md:relative ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        {/* Mobile Sidebar Close Header */}
        <div className="flex md:hidden justify-end mb-2">
          <button 
            type="button"
            onClick={() => setSidebarOpen(false)} 
            className="p-1.5 hover:bg-[#041627] rounded transition-colors text-[#8192a7] hover:text-white focus:outline-none"
            aria-label="Close navigation sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-8 flex items-center gap-3">
          <Store className="w-8 h-8 text-[#fd8b00]" />
          <div>
            <h2 className="text-sm font-bold tracking-wider uppercase">Supplier hub</h2>
            <p className="text-[10px] text-[#8192a7]">ProBuild Materials Inc.</p>
          </div>
        </div>

        {/* User Profile Card */}
        <div className="mb-6 flex items-center gap-3 bg-[#041627]/30 p-3 rounded-lg border border-[#8192a7]/10 shrink-0">
          <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
            <img 
              src={userAvatar || "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80"} 
              alt={username} 
              className="w-10 h-10 rounded-full object-cover border-2 border-[#fd8b00]/30 shadow-sm transition-transform duration-200 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/45 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <span className="text-[8px] text-white font-bold uppercase tracking-wider text-center">Edit</span>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleAvatarChange} 
              accept="image/*" 
              className="hidden" 
            />
          </div>
          <div className="min-w-0">
            <h3 className="text-xs font-bold text-white truncate">{username}</h3>
            <p className="text-[10px] text-[#8192a7] font-semibold tracking-wide uppercase">Shopkeeper</p>
          </div>
        </div>

        <div className="flex-grow space-y-2">
          <button 
            onClick={() => setActiveTab('orders')}
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'orders' ? 'bg-[#041627] text-white border-l-4 border-[#fd8b00]' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-[#fd8b00]" />
            Material Orders ({shopOrders.length})
          </button>

          <button 
            onClick={() => setActiveTab('items')}
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 transition-colors ${
              activeTab === 'items' ? 'bg-[#041627] text-white border-l-4 border-[#fd8b00]' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <Layers className="w-4 h-4 text-[#fd8b00]" />
            Items
          </button>

          <button 
            onClick={() => setActiveTab('messages')}
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between transition-colors ${
              activeTab === 'messages' ? 'bg-[#041627] text-white border-l-4 border-[#fd8b00]' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <span className="flex items-center gap-3">
              <MessageSquare className="w-4 h-4 text-[#fd8b00]" />
              Messages
            </span>
            {unreadCount > 0 && (
              <span className="bg-[#fd8b00] text-white text-[9px] font-bold rounded-full px-1.5 py-0.5 animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          <button 
            onClick={() => setActiveTab('announcements')}
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between transition-colors ${
              activeTab === 'announcements' ? 'bg-[#041627] text-white border-l-4 border-[#fd8b00]' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <span className="flex items-center gap-3">
              <Megaphone className="w-4 h-4 text-[#fd8b00]" />
              Announcements
            </span>
            {unreadAnnouncementsCount > 0 && (
              <span className="bg-[#fd8b00] text-white text-[9px] font-bold rounded-full px-1.5 py-0.5 animate-pulse">
                {unreadAnnouncementsCount}
              </span>
            )}
          </button>
          
          <button 
            onClick={() => setActiveTab('payments')}
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between transition-colors ${
              activeTab === 'payments' ? 'bg-[#041627] text-white border-l-4 border-[#fd8b00]' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <span className="flex items-center gap-3">
              <CreditCard className="w-4 h-4 text-[#fd8b00]" />
              Payment Methods
            </span>
          </button>

          <button 
            onClick={() => setActiveTab('profile')}
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between transition-colors ${
              activeTab === 'profile' ? 'bg-[#041627] text-white border-l-4 border-[#fd8b00]' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'
            }`}
          >
            <span className="flex items-center gap-3">
              <User className="w-4 h-4 text-[#fd8b00]" />
              Profile
            </span>
          </button>
        </div>

        <div className="pt-6 border-t border-[#8192a7]/20">
          <button 
            onClick={onLogout}
            className="w-full text-left text-red-300 hover:bg-[#1a2b3c]/60 py-2 px-4 rounded font-semibold text-xs flex items-center gap-3"
          >
            Sign Out Workspace
          </button>
        </div>
      </nav>

      {/* Main Container Wrapper */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Mobile Header Bar */}
        <header className="bg-[#1a2b3c] text-white px-6 py-4 flex items-center justify-between md:hidden shadow-md shrink-0">
          <div className="flex items-center gap-3">
            <button 
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="p-1.5 -ml-1.5 hover:bg-[#041627] rounded-lg transition-colors focus:outline-none"
              aria-label="Open navigation sidebar"
            >
              <Menu className="w-6 h-6 text-[#fd8b00]" />
            </button>
            <div className="flex items-center gap-2">
              <Store className="w-5 h-5 text-[#fd8b00]" />
              <span className="font-bold text-sm tracking-wide uppercase">Supplier Hub</span>
            </div>
          </div>
          <div className="text-[10px] bg-[#041627] px-2 py-1 rounded text-[#8192a7] font-semibold font-mono">
            SUPPLIER
          </div>
        </header>

        {/* Main Content Area */}
        <main className={`flex-1 min-w-0 ${activeTab === 'messages' ? 'h-[calc(100vh-70px)] overflow-hidden p-4 flex flex-col' : 'overflow-y-auto p-4 sm:p-6 md:p-10'}`}>
          <div className={`max-w-[1280px] w-full mx-auto ${activeTab === 'messages' ? 'h-full flex flex-col' : 'space-y-8'}`}>
          
          {/* Welcome Banner */}
          {activeTab === 'orders' && (
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm">
              <div>
                <h1 className="text-2xl font-bold text-[#041627]">Dashboard Overview</h1>
                <p className="text-xs text-[#44474c] mt-1">Welcome back, {username}. Here is today's summary for ProBuild Materials Inc.</p>
              </div>
            </div>
          )}

          {/* Metrics Grid */}
          {activeTab === 'orders' && (
            <div className="w-full">
              <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm flex flex-col justify-center min-w-0">
                <p className="text-xs text-[#44474c] font-semibold tracking-wider uppercase">Total Sales</p>
                <p className="text-2xl sm:text-3xl font-bold text-[#041627] mt-1.5">
                  Rs. {totalSales.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          )}

          {/* Lower Grid Panels */}
          {activeTab === 'items' ? (
            <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-[#c4c6cd]/25">
                <div>
                  <h3 className="text-base font-bold text-[#041627]">All Listed Store Products</h3>
                  <p className="text-xs text-[#44474c]">Manage, categorize, and publish new build materials for the client shop</p>
                </div>
                <button 
                  onClick={() => setIsFormOpen(true)}
                  className="bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold px-4 py-2.5 rounded-lg transition-all shadow-sm hover:shadow flex items-center gap-2 cursor-pointer shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  Sell New Item
                </button>
              </div>

              {/* Category tabs */}
              <div className="mb-8">
                <CategoryScrollNav
                  categories={itemCategories}
                  selectedCategory={selectedItemCategory}
                  onSelectCategory={setSelectedItemCategory}
                  activeColorClass="bg-[#fd8b00] text-white shadow-sm"
                  inactiveColorClass="bg-[#eff4ff] text-[#44474c] hover:bg-[#e5eeff] dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                />
              </div>

              {/* Products Grid */}
              {filteredItems.length === 0 ? (
                <div className="text-center py-16 bg-[#f8f9ff] rounded-xl border-2 border-dashed border-[#c4c6cd]/40 text-gray-500">
                  <Package className="w-12 h-12 mx-auto mb-3 text-gray-400 opacity-60 animate-bounce" />
                  <p className="text-sm font-bold text-[#041627]">No products found in this category</p>
                  <p className="text-xs text-[#44474c] mt-1">Click "Sell New Item" to list products under this category.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 animate-in fade-in duration-200">
                  {filteredItems.map((prod) => (
                    <div key={prod.id} className="bg-white rounded-xl border border-[#c4c6cd]/40 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
                      <div className="relative aspect-[4/3] bg-gray-50/50 flex items-center justify-center p-4 border-b border-[#c4c6cd]/10">
                        <img 
                          className="w-full h-full object-contain mix-blend-multiply" 
                          alt={prod.name}
                          src={prod.image}
                          referrerPolicy="no-referrer"
                        />
                        {prod.isDraft ? (
                          <span className="absolute top-3 left-3 bg-gray-500 text-white text-[9px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider shadow-sm">
                            Draft
                          </span>
                        ) : (
                          <span className="absolute top-3 left-3 bg-green-600 text-white text-[9px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider shadow-sm">
                            Active Listing
                          </span>
                        )}
                        {prod.deliveryAvailability && (
                          <span className="absolute top-3 right-3 bg-green-100 text-green-800 text-[9px] font-extrabold px-2 py-0.5 rounded shadow-sm">
                            Free Freight
                          </span>
                        )}
                      </div>

                      <div className="p-5 flex-grow flex flex-col justify-between gap-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono uppercase text-[#44474c] tracking-widest font-bold bg-[#eff4ff] px-2 py-0.5 rounded">
                              {prod.category}
                            </span>
                            {prod.brand && (
                              <span className="text-[10px] text-gray-400 font-bold">
                                Brand: {prod.brand}
                              </span>
                            )}
                          </div>
                          <h3 className="text-sm font-bold text-[#041627] leading-snug line-clamp-2" title={prod.name}>
                            {prod.name}
                          </h3>
                          {prod.description && (
                            <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
                              {prod.description}
                            </p>
                          )}
                        </div>

                        <div className="space-y-3 pt-2 border-t border-[#c4c6cd]/10">
                          <div className="flex justify-between items-center">
                            <div>
                              <span className="text-[10px] text-gray-400 font-bold block">Pricing</span>
                              <div className="flex items-baseline gap-1.5">
                                <span className="text-base font-extrabold text-[#041627]">
                                  Rs. {prod.price.toFixed(2)}
                                </span>
                                {prod.originalPrice && (
                                  <span className="text-xs text-gray-400 line-through">
                                    Rs. {prod.originalPrice.toFixed(2)}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] text-gray-400 font-bold block">Stock Level</span>
                              <span className="text-xs font-bold text-[#041627]">
                                {prod.availableQuantity !== undefined ? `${prod.availableQuantity} ${prod.unit || 'pcs'}` : 'In Stock'}
                              </span>
                            </div>
                          </div>

                          {/* Extra published metadata lines */}
                          {(prod.location || prod.contactNumber || prod.warranty || prod.specifications) && (
                            <div className="text-[10px] bg-gray-50 p-2.5 rounded-lg space-y-1 text-gray-600 font-semibold border border-[#c4c6cd]/15">
                              {prod.location && (
                                <div className="flex items-center gap-1.5">
                                  <MapPin className="w-3 h-3 text-[#fd8b00] shrink-0" />
                                  <span className="truncate">{prod.location}</span>
                                </div>
                              )}
                              {prod.contactNumber && (
                                <div className="flex items-center gap-1.5">
                                  <Phone className="w-3 h-3 text-[#fd8b00] shrink-0" />
                                  <span>{prod.contactNumber}</span>
                                </div>
                              )}
                              {prod.warranty && (
                                <div className="flex items-center gap-1.5">
                                  <Shield className="w-3 h-3 text-[#fd8b00] shrink-0" />
                                  <span className="truncate">{prod.warranty}</span>
                                </div>
                              )}
                              {prod.specifications && (
                                <div className="flex items-center gap-1.5">
                                  <List className="w-3 h-3 text-[#fd8b00] shrink-0" />
                                  <span className="truncate">Specs: {prod.specifications}</span>
                                </div>
                              )}
                            </div>
                          )}
                          
                          {prod.tags && prod.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {prod.tags.map((tag, i) => (
                                <span key={i} className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded font-medium">
                                  #{tag}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="px-5 pb-5 pt-0 flex justify-end gap-2 shrink-0">
                        <button 
                          onClick={() => handleOpenEdit(prod)}
                          className="flex items-center gap-1.5 text-xs font-bold text-gray-700 bg-[#eff4ff] hover:bg-[#e5eeff] border border-gray-100 px-3 py-2 rounded-lg transition-colors cursor-pointer flex-1 justify-center"
                        >
                          <Edit className="w-3.5 h-3.5 text-[#fd8b00]" />
                          Edit Item
                        </button>
                        <button 
                          onClick={() => setDeleteTargetId(prod.id)}
                          className="flex items-center gap-1.5 text-xs font-bold text-red-700 bg-rose-50 hover:bg-rose-100 border border-rose-100 px-3 py-2 rounded-lg transition-colors cursor-pointer flex-1 justify-center"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : activeTab === 'inventory' ? (
            <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-[#c4c6cd]/25">
                <div>
                  <h3 className="text-base font-bold text-[#041627]">Inventory & Stock Management</h3>
                  <p className="text-xs text-[#44474c]">View stock levels, update item quantities, and add products to stock</p>
                </div>
                <button 
                  onClick={handleOpenAdd}
                  className="bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold px-4 py-2.5 rounded-lg transition-all shadow-sm hover:shadow flex items-center gap-2 cursor-pointer shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  Add Item to Stock
                </button>
              </div>

              {/* Category scroll nav menu at top (Same menu as Items tab) */}
              <div className="mb-6">
                <CategoryScrollNav
                  categories={itemCategories}
                  selectedCategory={selectedItemCategory}
                  onSelectCategory={setSelectedItemCategory}
                  activeColorClass="bg-[#fd8b00] text-white shadow-sm"
                  inactiveColorClass="bg-[#eff4ff] text-[#44474c] hover:bg-[#e5eeff] dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                />
              </div>

              {/* Search & Stock Summary */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6 bg-[#f8f9ff] p-3.5 rounded-xl border border-[#c4c6cd]/25">
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text"
                    placeholder="Search stock by name, brand..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 text-xs bg-white rounded-lg border border-[#c4c6cd]/40 focus:outline-none focus:border-[#fd8b00]"
                  />
                </div>
                <div className="flex items-center gap-4 text-xs text-[#44474c] font-semibold">
                  <span>Category Items: <strong className="text-[#041627]">{filteredItems.length}</strong></span>
                </div>
              </div>

              {/* Inventory Table */}
              {filteredItems.length === 0 ? (
                <div className="text-center py-16 bg-[#f8f9ff] rounded-xl border-2 border-dashed border-[#c4c6cd]/40 text-gray-500">
                  <Package className="w-12 h-12 mx-auto mb-3 text-gray-400 opacity-60" />
                  <p className="text-sm font-bold text-[#041627]">No items found in stock</p>
                  <p className="text-xs text-[#44474c] mt-1">Click "Add Item to Stock" to add products to your stock inventory.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-[#c4c6cd]/30 text-[#44474c] uppercase font-bold tracking-wider bg-slate-50">
                        <th className="py-3 px-4 font-semibold">Item & Details</th>
                        <th className="py-3 px-4 font-semibold">Category</th>
                        <th className="py-3 px-4 font-semibold">Price / Unit</th>
                        <th className="py-3 px-4 font-semibold">Stock Quantity</th>
                        <th className="py-3 px-4 font-semibold">Stock Status</th>
                        <th className="py-3 px-4 font-semibold text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#c4c6cd]/20">
                      {filteredItems.map((prod) => {
                        const qty = prod.availableQuantity ?? 0;
                        const isLowStock = qty > 0 && qty <= 10;
                        const isOutOfStock = qty <= 0;
                        const statusText = prod.stockStatus || (isOutOfStock ? 'Out of Stock' : isLowStock ? 'Low Stock' : 'In Stock');

                        return (
                          <tr key={prod.id} className="hover:bg-[#f8f9ff] transition-colors">
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                <img 
                                  src={prod.image} 
                                  alt={prod.name} 
                                  className="w-10 h-10 object-contain rounded bg-white border border-[#c4c6cd]/30 p-1 shrink-0" 
                                  referrerPolicy="no-referrer"
                                />
                                <div>
                                  <p className="font-bold text-[#041627] text-xs leading-snug">{prod.name}</p>
                                  <p className="text-[10px] text-[#44474c]">{prod.brand || 'Generic'} • {prod.location || 'Warehouse Main'}</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-3.5 px-4 font-semibold text-[#44474c]">{prod.category}</td>
                            <td className="py-3.5 px-4 font-bold text-[#041627]">
                              Rs. {prod.price.toFixed(2)} <span className="text-[10px] text-[#44474c] font-normal">/ {prod.unit || 'pc'}</span>
                            </td>
                            <td className="py-3.5 px-4 font-bold text-[#041627]">
                              {qty} {prod.unit || 'Pcs'}
                            </td>
                            <td className="py-3.5 px-4">
                              <span className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                                statusText === 'In Stock'
                                  ? 'bg-green-100 text-green-800'
                                  : statusText === 'Low Stock'
                                    ? 'bg-yellow-100 text-yellow-800'
                                    : 'bg-red-100 text-red-800'
                              }`}>
                                {statusText}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <button 
                                  onClick={() => {
                                    const updated: Product = {
                                      ...prod,
                                      availableQuantity: (prod.availableQuantity || 0) + 50,
                                      stockStatus: 'In Stock'
                                    };
                                    onEditProduct(updated);
                                    setSuccessPopup(`Added +50 stock to ${prod.name}`);
                                  }}
                                  className="bg-[#1a2b3c] hover:bg-[#041627] text-white text-[10px] font-bold px-2.5 py-1.5 rounded transition-all flex items-center gap-1 cursor-pointer"
                                  title="Add +50 to stock"
                                >
                                  <Plus className="w-3 h-3 text-[#fd8b00]" /> +50 Stock
                                </button>
                                <button 
                                  onClick={() => handleOpenEdit(prod)}
                                  className="p-1.5 text-slate-500 hover:text-[#041627] hover:bg-slate-100 rounded transition-colors cursor-pointer"
                                  title="Edit Item Details"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button 
                                  onClick={() => setDeleteTargetId(prod.id)}
                                  className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition-colors cursor-pointer"
                                  title="Delete Item"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : activeTab === 'messages' ? (
            <MessagePortal 
              currentRole="shopkeeper" 
              currentUserEmail={userEmail} 
              currentUserName={username} 
              currentUserAvatar={userAvatar}
            />
          ) : activeTab === 'payments' ? (
            <ShopkeeperPaymentSettings userEmail={userEmail} />
          ) : activeTab === 'announcements' ? (
            <AnnouncementsView 
              userId={auth.currentUser?.uid || 'shopkeeper_user'}
              userEmail={userEmail || 'shopkeeper@gmail.com'}
              userRole="shopkeeper"
              userName={username}
              userCreatedAt={registrationDate}
            />
          ) : activeTab === 'profile' ? (
            <SharedProfileSettings
              roleName="Shopkeeper"
              username={username}
              userEmail={userEmail || auth.currentUser?.email || ''}
              userPhone={userPhone}
              registrationDate={registrationDate}
              userAvatar={userAvatar}
              onSave={(data) => {
                if (onUpdateProfile) onUpdateProfile(data);
                else if (data.avatar && onUpdateAvatar) onUpdateAvatar(data.avatar);
              }}
            />
          ) : (
            <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm">
              <h3 className="text-base font-bold text-[#041627] mb-6">Recent Customer Orders</h3>
              
              {highlightedOrderId && (
                <div className="mb-4 bg-amber-50 border border-amber-200 rounded-lg p-3 flex justify-between items-center text-xs text-amber-800">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-[#fd8b00]" />
                    <span>Showing new order <strong className="font-mono">{highlightedOrderId}</strong> checked out by homeowner.</span>
                  </div>
                  <button 
                    onClick={onClearHighlight}
                    className="text-amber-950 hover:text-black underline font-bold cursor-pointer text-xs"
                  >
                    Dismiss Highlight
                  </button>
                </div>
              )}              <div className="flex gap-4 border-b border-[#c4c6cd]/30 pb-4 mb-5">
                <button 
                  onClick={() => setActiveOrderTab('active')}
                  className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                    activeOrderTab === 'active' 
                      ? 'text-[#fd8b00]' 
                      : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Active Orders ({shopOrders.filter(o => ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(o.status)).length})
                  {activeOrderTab === 'active' && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#fd8b00] rounded" />
                  )}
                </button>
                <button 
                  onClick={() => setActiveOrderTab('delivered')}
                  className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                    activeOrderTab === 'delivered' 
                      ? 'text-green-600' 
                      : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Delivered Orders ({shopOrders.filter(o => o.status === 'Delivered').length})
                  {activeOrderTab === 'delivered' && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-600 rounded" />
                  )}
                </button>
                <button 
                  onClick={() => setActiveOrderTab('cancelled')}
                  className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                    activeOrderTab === 'cancelled' 
                      ? 'text-red-600' 
                      : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Cancelled Orders ({shopOrders.filter(o => o.status === 'Cancelled').length})
                  {activeOrderTab === 'cancelled' && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600 rounded" />
                  )}
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#c4c6cd]/30 text-[#44474c] uppercase font-bold tracking-wider">
                      <th className="pb-3 font-semibold">Order ID</th>
                      <th className="pb-3 font-semibold">Homeowner / Client</th>
                      <th className="pb-3 font-semibold">{activeOrderTab === 'cancelled' ? 'Cancellation Date & Time' : 'Order Date'}</th>
                      <th className="pb-3 font-semibold">Pricing</th>
                      <th className="pb-3 font-semibold">{activeOrderTab === 'cancelled' ? 'Cancellation Reason' : 'Status'}</th>
                      <th className="pb-3 font-semibold text-right">Actions / Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#c4c6cd]/20">
                    {shopOrders
                      .filter((ord) => {
                        if (activeOrderTab === 'active') {
                          return ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(ord.status);
                        } else if (activeOrderTab === 'delivered') {
                          return ord.status === 'Delivered';
                        } else {
                          return ord.status === 'Cancelled';
                        }
                      })
                      .map((ord) => {
                        const isHighlighted = ord.id === highlightedOrderId;
                        return (
                          <tr 
                            key={ord.id} 
                            onClick={() => setSelectedOrderForDetail(ord)}
                            className={`hover:bg-[#f8f9ff] transition-colors cursor-pointer ${isHighlighted ? 'bg-amber-50/70 border-l-2 border-amber-500' : ''}`}
                            title="Click to view full order details"
                          >
                            <td className="py-4 font-mono font-bold text-[#fd8b00] flex items-center gap-1.5">
                              <span className="hover:underline">{ord.id}</span>
                              {isHighlighted && (
                                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-extrabold bg-[#fd8b00] text-white tracking-wider uppercase animate-pulse shrink-0">
                                  NEW
                                </span>
                              )}
                            </td>
                            <td className="py-4 font-bold text-[#041627]">{ord.customer}</td>
                            <td className="py-4 text-[#44474c]">
                              {activeOrderTab === 'cancelled' 
                                ? (ord.cancelledAt ? new Date(ord.cancelledAt).toLocaleString() : ord.date)
                                : ord.date}
                            </td>
                            <td className="py-4 text-[#041627] font-bold">
                              Rs. {ord.amount ? ord.amount.toFixed(2) : '320.00'}
                            </td>
                            <td className="py-4">
                              {ord.status === 'Cancelled' ? (
                                <div className="space-y-1">
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-red-100 text-red-800 border border-red-200 text-[10px] font-bold">
                                    ❌ Order Cancelled
                                  </span>
                                  {ord.cancellationReason && (
                                    <p className="text-[10px] text-red-600 font-semibold">Reason: {ord.cancellationReason}</p>
                                  )}
                                  {ord.cancelledBy && (
                                    <p className="text-[9px] text-slate-400 font-medium">By: {ord.cancelledBy}</p>
                                  )}
                                </div>
                              ) : (
                                <span className={`px-2.5 py-1 rounded-full font-semibold text-[10px] ${
                                  ord.status === 'Processing' 
                                    ? 'bg-yellow-100 text-yellow-800' 
                                    : ord.status === 'Shipped'
                                      ? 'bg-blue-100 text-blue-800'
                                      : 'bg-green-100 text-green-800'
                                }`}>
                                  {ord.status}
                                </span>
                              )}
                            </td>
                            <td className="py-4 text-right">
                              {ord.status === 'Cancelled' ? (
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                                  Locked / Read-Only
                                </span>
                              ) : ord.status === 'Processing' ? (
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onShipOrder(ord.id);
                                    if (isHighlighted && onClearHighlight) {
                                      onClearHighlight();
                                    }
                                  }}
                                  className="bg-[#fd8b00] hover:bg-[#e07b00] text-white font-semibold text-[10px] px-3 py-1.5 rounded transition-all cursor-pointer"
                                >
                                  🚚 Ship Order
                                </button>
                              ) : (
                                <span className="text-[10px] text-green-600 font-semibold flex items-center justify-end gap-1">
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  Active Transit
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                     {shopOrders.filter((ord) => {
                       if (activeOrderTab === 'active') {
                         return ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(ord.status);
                       } else if (activeOrderTab === 'delivered') {
                         return ord.status === 'Delivered';
                       } else {
                         return ord.status === 'Cancelled';
                       }
                     }).length === 0 && (
                      <tr>
                        <td colSpan={6} className="text-center py-8 text-[#8192a7] font-semibold text-xs">
                          No {activeOrderTab} orders found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      </main>

      {/* Sell Item Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-[#041627]/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-[#c4c6cd]/50 shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
            
            {/* Header */}
            <div className="p-6 border-b border-[#c4c6cd]/30 flex justify-between items-center bg-[#f8f9ff] rounded-t-2xl shrink-0">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-5 h-5 text-[#fd8b00]" />
                <div>
                  <h3 className="text-base font-bold text-[#041627]">{editingProduct ? 'Edit Heavy-Freight Material' : 'Publish Heavy-Freight Material'}</h3>
                  <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">{editingProduct ? 'Modify the product listing across the B2B marketplace' : 'List a new product across the B2B marketplace'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  type="button"
                  onClick={fillSampleData}
                  className="text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold px-3 py-1.5 rounded-lg border border-amber-200 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Fill Sample Data
                </button>
                <button 
                  type="button"
                  onClick={() => { setIsFormOpen(false); resetForm(); }}
                  className="text-gray-400 hover:text-gray-600 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Form Content - Scrollable */}
            <div className="p-6 overflow-y-auto space-y-6">
              
              {/* Row: Name and Category */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Product Name *</label>
                  <input 
                    type="text"
                    placeholder="e.g. Standard M15 Red Concrete Clay Bricks"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Category *</label>
                  <select 
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors bg-white font-medium"
                  >
                    {[
                      'Bricks',
                      'Iron & Steel',
                      'Furniture',
                      'House Decoration',
                      'Cement',
                      'Paint',
                      'Electrical',
                      'Plumbing',
                      'Tiles & Flooring',
                      'Doors & Windows',
                      'Roofing Materials',
                      'Tools & Equipment',
                      'Other'
                    ].map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row: Brand and Unit */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Brand Name</label>
                  <input 
                    type="text"
                    placeholder="e.g. UltraTech, Tata Steel, BuildPro"
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                
                {/* Searchable, Editable Creatable Combo Box for Unit of Measure */}
                <div className="relative" ref={unitDropdownRef}>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Unit of Measure *</label>
                  <div className="relative">
                    <input 
                      type="text"
                      placeholder="Search or type unit (e.g. Piece, Kg, Box...)"
                      value={isUnitDropdownOpen ? unitSearchQuery : formUnit}
                      onChange={(e) => {
                        setUnitSearchQuery(e.target.value);
                        setFormUnit(e.target.value);
                        if (!isUnitDropdownOpen) setIsUnitDropdownOpen(true);
                      }}
                      onFocus={() => {
                        setUnitSearchQuery(formUnit);
                        setIsUnitDropdownOpen(true);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const query = unitSearchQuery.trim() || formUnit.trim();
                          if (query) {
                            if (filteredUnits.length > 0 && exactMatchExists) {
                              const matched = filteredUnits.find(u => u.toLowerCase() === query.toLowerCase()) || filteredUnits[0];
                              handleSelectUnit(matched);
                            } else {
                              handleCreateAndSelectUnit(query);
                            }
                          }
                        } else if (e.key === 'Escape') {
                          setIsUnitDropdownOpen(false);
                        }
                      }}
                      className="w-full text-xs p-3 pr-10 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors bg-white font-medium"
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-slate-400">
                      {formUnit && !isUnitDropdownOpen && (
                        <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold">
                          Selected
                        </span>
                      )}
                      <button 
                        type="button" 
                        onClick={() => {
                          if (!isUnitDropdownOpen) {
                            setUnitSearchQuery(formUnit);
                          }
                          setIsUnitDropdownOpen(!isUnitDropdownOpen);
                        }}
                        className="p-1 hover:text-slate-600 focus:outline-none cursor-pointer"
                        title="Search / Browse units"
                      >
                        <Search className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Dropdown Options Popover */}
                  {isUnitDropdownOpen && (
                    <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-60 overflow-y-auto py-1 text-xs divide-y divide-slate-100 animate-fadeIn">
                      {/* Create New Custom Unit Option */}
                      {unitSearchQuery.trim() && !exactMatchExists && (
                        <button
                          type="button"
                          onClick={() => handleCreateAndSelectUnit(unitSearchQuery)}
                          className="w-full text-left px-3 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold flex items-center gap-2 transition-colors border-b border-amber-200/60 cursor-pointer"
                        >
                          <Plus className="w-4 h-4 text-[#fd8b00] shrink-0" />
                          <span>Create & Save unit: <strong className="text-[#fd8b00]">"{unitSearchQuery.trim()}"</strong></span>
                        </button>
                      )}

                      {/* Filtered Units List */}
                      <div className="py-1">
                        {filteredUnits.length > 0 ? (
                          filteredUnits.map((u) => {
                            const isSelected = formUnit.toLowerCase() === u.toLowerCase();
                            return (
                              <button
                                key={u}
                                type="button"
                                onClick={() => handleSelectUnit(u)}
                                className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-100 transition-colors cursor-pointer ${
                                  isSelected ? 'bg-amber-50 text-[#fd8b00] font-bold' : 'text-slate-700 font-medium'
                                }`}
                              >
                                <span>{u}</span>
                                {isSelected && <CheckCircle className="w-3.5 h-3.5 text-[#fd8b00]" />}
                              </button>
                            );
                          })
                        ) : (
                          !unitSearchQuery.trim() && (
                            <div className="px-3 py-3 text-center text-slate-400 italic text-[11px]">
                              Type to search or add a custom unit
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Image upload widget: Supports Drag & Drop, File input, or Text URL input */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-[#041627]">Product Image *</label>
                
                <div 
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => productFileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                    dragActive 
                      ? 'border-[#fd8b00] bg-orange-50/50' 
                      : formImage 
                        ? 'border-green-300 bg-green-50/10' 
                        : 'border-gray-300 hover:border-[#fd8b00] bg-gray-50/50'
                  }`}
                >
                  <input 
                    ref={productFileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  {formImage ? (
                    <div className="space-y-2">
                      <div className="w-24 h-24 mx-auto relative group">
                        <img src={formImage} alt="Uploaded preview" className="w-full h-full object-contain rounded-lg border border-gray-200" referrerPolicy="no-referrer" />
                        <button 
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setFormImage(''); }}
                          className="absolute -top-1.5 -right-1.5 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 shadow-md transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                      <p className="text-[10px] text-green-600 font-semibold">✓ Image selected successfully</p>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-1" />
                      <p className="text-xs font-bold text-gray-700">Drag & drop your product image here, or <span className="text-[#fd8b00]">browse files</span></p>
                      <p className="text-[10px] text-gray-500">Supports PNG, JPG, JPEG (Max 5MB)</p>
                    </div>
                  )}
                </div>

                <div>
                  <span className="text-[10px] text-gray-400 font-semibold block mb-1">OR ENTER DIRECT IMAGE URL</span>
                  <input 
                    type="text"
                    placeholder="https://example.com/image.jpg"
                    value={formImage}
                    onChange={(e) => setFormImage(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
              </div>

              {/* Row: Price, Discount Price, Quantity, Stock Status */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Price (Rs.) *</label>
                  <input 
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="120.00"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Original Price (Rs.)</label>
                  <input 
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="Discount price fallback"
                    value={formDiscountPrice}
                    onChange={(e) => setFormDiscountPrice(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Qty Available *</label>
                  <input 
                    type="number"
                    min="0"
                    placeholder="350"
                    value={formQuantity}
                    onChange={(e) => setFormQuantity(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Stock Status *</label>
                  <select 
                    value={formStockStatus}
                    onChange={(e) => setFormStockStatus(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors bg-white font-medium"
                  >
                    {['In Stock', 'Low Stock', 'Out of Stock'].map(st => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row: Location & Contact */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Storage Location *</label>
                  <input 
                    type="text"
                    placeholder="e.g. Warehouse A, Bay 4, Rack 2"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Contact Phone Number *</label>
                  <input 
                    type="text"
                    placeholder="e.g. +1 (555) 019-2834"
                    value={formContact}
                    onChange={(e) => setFormContact(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
              </div>

              {/* Row: Warranty, Specifications, Tags */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Warranty Period (Optional)</label>
                  <input 
                    type="text"
                    placeholder="e.g. 5-Year Limited Manufacturer Warranty"
                    value={formWarranty}
                    onChange={(e) => setFormWarranty(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">Tags (Comma-separated)</label>
                  <input 
                    type="text"
                    placeholder="e.g. red, clay, brick, fireproof"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors"
                  />
                </div>
              </div>

              {/* Specifications textarea */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Product Specifications (Optional)</label>
                <textarea 
                  placeholder="e.g. Compressive strength: 15N/mm², Water absorption: <12%, Size: 230mm x 110mm x 75mm"
                  value={formSpecs}
                  onChange={(e) => setFormSpecs(e.target.value)}
                  rows={2}
                  className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors resize-none"
                />
              </div>

              {/* Description textarea */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Product Description</label>
                <textarea 
                  placeholder="Enter comprehensive material description, batch notes, transport parameters..."
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  rows={3}
                  className="w-full text-xs p-3 rounded-lg border border-[#c4c6cd]/60 focus:outline-none focus:border-[#fd8b00] transition-colors resize-none"
                />
              </div>

              {/* Delivery Toggle */}
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200">
                <div className="flex items-center gap-2">
                  <Truck className="w-5 h-5 text-[#fd8b00]" />
                  <div>
                    <p className="text-xs font-bold text-[#041627]">Delivery Availability</p>
                    <p className="text-[10px] text-gray-500 font-medium">Toggle if you support shipping/freight delivery for this item.</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => setFormDelivery(!formDelivery)}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                    formDelivery ? 'bg-[#fd8b00]' : 'bg-gray-300'
                  }`}
                >
                  <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    formDelivery ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>

            </div>

            {/* Footer */}
            <div className="p-6 border-t border-[#c4c6cd]/30 flex justify-end gap-3 bg-gray-50 rounded-b-2xl shrink-0">
              <button 
                type="button"
                onClick={() => { setIsFormOpen(false); resetForm(); }}
                className="px-5 py-2.5 rounded-lg text-xs font-bold text-gray-700 hover:bg-gray-100 border border-gray-300 bg-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              {(!editingProduct || editingProduct.isDraft) && (
                <button 
                  type="button"
                  onClick={() => handlePublishSubmit(true)}
                  className="px-5 py-2.5 rounded-lg text-xs font-bold text-gray-700 hover:bg-gray-100 border border-gray-300 bg-white transition-colors cursor-pointer"
                >
                  Save Draft
                </button>
              )}
              <button 
                type="button"
                onClick={() => handlePublishSubmit(false)}
                className="px-6 py-2.5 rounded-lg text-xs font-bold text-white bg-[#fd8b00] hover:bg-[#e07b00] shadow-md hover:shadow-lg transition-all cursor-pointer"
              >
                {editingProduct ? 'Save Changes' : 'Publish Listing'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Success Popup */}
      {successPopup && (
        <div className="fixed inset-0 bg-[#041627]/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-2xl border border-green-200 p-6 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-[#041627]">Operation Successful</h3>
            <p className="text-xs text-gray-600 mt-2 font-medium">{successPopup}</p>
            <button 
              onClick={() => setSuccessPopup(null)}
              className="mt-5 w-full bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-bold py-2.5 rounded-lg transition-colors cursor-pointer shadow-sm"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* Order Details Modal */}
      {selectedOrderForDetail && (
        <div className="fixed inset-0 bg-[#041627]/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fadeIn">
          <div 
            className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col max-h-[90vh] animate-scaleUp text-[#0b1c30]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className={`${selectedOrderForDetail.status === 'Cancelled' ? 'bg-red-950 border-b border-red-900' : 'bg-[#1a2b3c]'} text-white p-5 flex justify-between items-center shrink-0`}>
              <div className="flex items-center gap-3">
                <div className={`p-2 ${selectedOrderForDetail.status === 'Cancelled' ? 'bg-red-600' : 'bg-[#fd8b00]'} rounded-xl text-white`}>
                  {selectedOrderForDetail.status === 'Cancelled' ? <AlertTriangle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold tracking-tight">Order {selectedOrderForDetail.id}</h3>
                    <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full text-white uppercase tracking-wider ${selectedOrderForDetail.status === 'Cancelled' ? 'bg-red-600' : 'bg-[#fd8b00]'}`}>
                      {selectedOrderForDetail.status}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium">Placed on {selectedOrderForDetail.date}</p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedOrderForDetail(null)}
                className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Body - Hidden scrollbar cross-browser */}
            <div 
              className="p-4 sm:p-6 overflow-y-auto overflow-x-hidden flex-1 space-y-6 text-[#0b1c30] no-scrollbar scrollbar-none [ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
              style={{
                msOverflowStyle: 'none',
                scrollbarWidth: 'none',
              }}
            >
              
              {selectedOrderForDetail.status === 'Cancelled' && (
                <div className="bg-red-50 border border-red-100 rounded-2xl p-6 flex items-start gap-4 shadow-sm animate-in fade-in zoom-in-95 duration-200">
                  <div className="p-3 bg-red-600 text-white rounded-full shrink-0 shadow-md">
                    <Trash2 className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-base font-extrabold text-red-900 tracking-tight">Order Cancelled</h3>
                    <p className="text-xs text-red-800 font-bold">This order has been cancelled. Fulfillment operations have stopped.</p>
                    {selectedOrderForDetail.cancellationReason && (
                      <p className="text-xs text-red-700 bg-red-100/50 p-2.5 rounded-xl border border-red-200 mt-2 font-semibold">
                        Reason: {selectedOrderForDetail.cancellationReason}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* STATUS TRACKING PROGRESS TIMELINE */}
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-[#fd8b00]" /> Real-Time Fulfillment Tracking
                </h4>

                {selectedOrderForDetail.status === 'Cancelled' ? (
                  <div className="relative pt-2 pb-6">
                    {/* Progress Bar Line */}
                    <div className="absolute top-[26px] left-[15%] right-[15%] h-1 bg-slate-200 -z-0">
                      <div className="h-full bg-red-500 w-full transition-all duration-500" />
                    </div>

                    {/* Timeline Nodes */}
                    <div className="flex justify-between relative z-10">
                      {[
                        { label: 'Order Placed', desc: 'Awaiting vendor', completed: true },
                        { label: 'Order Confirmed', desc: 'Logistics set', completed: true },
                        { label: 'Order Cancelled', desc: 'Fulfillment stopped', completed: false, isCancelNode: true }
                      ].map((step, idx) => {
                        return (
                          <div key={idx} className="flex flex-col items-center w-[30%] text-center">
                            <div 
                              className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all ${
                                step.isCancelNode 
                                  ? 'bg-red-500 border-red-500 text-white ring-4 ring-red-100' 
                                  : 'bg-emerald-500 border-emerald-500 text-white'
                              }`}
                            >
                              {step.isCancelNode ? <X className="w-5 h-5 font-bold" /> : <CheckCircle className="w-5 h-5" />}
                            </div>
                            <span className={`text-[11px] font-bold mt-2 ${step.isCancelNode ? 'text-red-600' : 'text-emerald-600'}`}>
                              {step.label}
                            </span>
                            <span className="text-[9px] text-slate-400 mt-0.5 leading-tight font-medium">
                              {step.desc}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="relative pt-2 pb-6">
                    {/* Progress Bar Line */}
                    <div className="absolute top-[26px] left-[10%] right-[10%] h-1 bg-slate-200 -z-0">
                      <div 
                        className="h-full bg-emerald-500 transition-all duration-500"
                        style={{
                          width: `${
                            selectedOrderForDetail.status === 'Pending' ? '0%' :
                            selectedOrderForDetail.status === 'Confirmed' ? '25%' :
                            selectedOrderForDetail.status === 'Processing' ? '50%' :
                            selectedOrderForDetail.status === 'Shipped' ? '75%' :
                            selectedOrderForDetail.status === 'Delivered' ? '100%' : '0%'
                          }`
                        }}
                      />
                    </div>

                    {/* Timeline Nodes */}
                    <div className="flex justify-between relative z-10">
                      {[
                        { label: 'Pending', desc: 'Awaiting vendor' },
                        { label: 'Confirmed', desc: 'Order verified' },
                        { label: 'Processing', desc: 'Preparing logistics' },
                        { label: 'Shipped', desc: 'In heavy transit' },
                        { label: 'Delivered', desc: 'Arrived at jobsite' }
                      ].map((step, idx) => {
                        const statusWeights: Record<string, number> = { 'Pending': 1, 'Confirmed': 2, 'Processing': 3, 'Shipped': 4, 'Delivered': 5 };
                        const currentWeight = statusWeights[selectedOrderForDetail.status] || 1;
                        const stepWeight = idx + 1;
                        const isCompleted = currentWeight >= stepWeight;
                        const isActive = currentWeight === stepWeight;

                        return (
                          <div key={idx} className="flex flex-col items-center w-[18%] text-center">
                            <div 
                              className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all ${
                                isCompleted ? 'bg-emerald-500 border-emerald-500 text-white' : 
                                'bg-white border-slate-200 text-slate-400'
                              } ${isActive ? 'ring-4 ring-emerald-100' : ''}`}
                            >
                              {isCompleted ? <CheckCircle className="w-5 h-5" /> : <span className="text-xs font-bold">{idx + 1}</span>}
                            </div>
                            <span className={`text-[11px] font-bold mt-2 ${isCompleted ? 'text-[#041627]' : 'text-slate-400'}`}>
                              {step.label}
                            </span>
                            <span className="text-[9px] text-slate-400 mt-0.5 leading-tight font-medium">
                              {step.desc}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* TWO COLUMN GRID: LEFT COLUMN (ORDER INFO, CUSTOMER INFO, NOTES), RIGHT COLUMN (PRODUCTS & BILLING) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Left Part: Info Cards (7 cols) */}
                <div className="lg:col-span-7 space-y-6">
                  
                  {/* Order & Payment Information */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-1.5">
                      <Info className="w-4 h-4 text-[#fd8b00]" /> Order Metadata
                    </h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Order ID:</span>
                          <span className="font-mono font-bold text-slate-700">{selectedOrderForDetail.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Order Date:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.date}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Last Updated:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.updatedAt ? new Date(selectedOrderForDetail.updatedAt).toLocaleDateString() : selectedOrderForDetail.date}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Fulfillment Status:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.status}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Payment Status:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.paymentStatus || 'Paid'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Payment Method:</span>
                          <span className="font-bold text-slate-700">{selectedOrderForDetail.paymentMethod || 'Online Credit Card'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Tracking Number:</span>
                          <span className="font-mono font-bold text-slate-700">{selectedOrderForDetail.paymentId || ("TRK-" + selectedOrderForDetail.id.replace('#', '') + "-772")}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-semibold">Est. Delivery Date:</span>
                          <span className="font-bold text-slate-700">3 Days after confirmation</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Customer Information Card */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-1.5">
                      <User className="w-4 h-4 text-[#fd8b00]" /> Customer Information
                    </h4>

                    <div className="flex items-center gap-4">
                      <img 
                        src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80" 
                        alt="Customer profile" 
                        className="w-12 h-12 rounded-full border border-slate-200 shadow-sm"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h5 className="text-sm font-bold text-slate-800">{selectedOrderForDetail.clientName || selectedOrderForDetail.customer}</h5>
                        <p className="text-xs text-slate-400 font-medium">@{selectedOrderForDetail.customer}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2">
                      <div>
                        <span className="text-slate-400 font-semibold block">Email Address:</span>
                        <span className="font-bold text-slate-700">{selectedOrderForDetail.clientEmail || selectedOrderForDetail.customerEmail || (selectedOrderForDetail.customer + "@gmail.com")}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 font-semibold block">Phone Number:</span>
                        <span className="font-bold text-slate-700">{selectedOrderForDetail.customerPhone || "+977-9851-012345"}</span>
                      </div>
                      <div className="sm:col-span-2">
                        <span className="text-slate-400 font-semibold block">Delivery Address:</span>
                        <span className="font-bold text-slate-700">{selectedOrderForDetail.shippingAddress || "Kathmandu Metropolitan, Nepal"}</span>
                      </div>
                    </div>
                  </div>

                  {/* Payment Details Card */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 text-xs">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-emerald-500" /> Secure Payment Ledger
                    </h4>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">Transaction ID:</span>
                      <span className="font-mono font-bold text-slate-700">{selectedOrderForDetail.transactionId || ("TXN-" + selectedOrderForDetail.id.replace('#', '') + "-8891")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">Payment Date:</span>
                      <span className="font-bold text-slate-700">{selectedOrderForDetail.paymentTime || selectedOrderForDetail.date}</span>
                    </div>
                    {selectedOrderForDetail.status === 'Cancelled' && (
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-semibold">Refund Status:</span>
                        <span className="font-extrabold text-red-600 uppercase tracking-wide bg-red-50 px-2 py-0.5 rounded border border-red-100 text-[10px]">
                          {selectedOrderForDetail.refundStatus || 'Refund Initiated'}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Order Notes Card */}
                  <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-1.5">
                      <MessageSquare className="w-4 h-4 text-[#fd8b00]" /> Order & Delivery Notes
                    </h4>
                    <div className="space-y-3 text-xs">
                      <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl">
                        <span className="font-bold text-slate-600 block mb-1">Customer Note:</span>
                        <p className="text-slate-500 italic">"Please drop off materials near the concrete mixer on the north side of the jobsite."</p>
                      </div>
                      <div className="bg-amber-50/50 border border-amber-100 p-3 rounded-xl">
                        <span className="font-bold text-amber-800 block mb-1">Seller Response:</span>
                        <p className="text-amber-700 font-medium">"Assigned heavy-duty carrier for prompt delivery. Verified load balance before dispatch."</p>
                      </div>
                    </div>
                  </div>

                  {/* QR PAYMENT VERIFICATION CONTROL */}
                  {selectedOrderForDetail.paymentStatus === 'Pending Verification' && (
                    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-3">
                      <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1.5">
                        <DollarSign className="w-4 h-4 text-amber-600" /> QR Payment Verification Required
                      </h4>
                      <p className="text-[11px] text-amber-700 font-medium leading-relaxed">
                        The client has completed payment of <strong className="text-amber-900">Rs. {selectedOrderForDetail.totalPrice?.toFixed(2)}</strong> via <strong className="text-amber-900">{selectedOrderForDetail.paymentMethod}</strong>. Please check your {selectedOrderForDetail.paymentMethod} wallet or merchant statement to verify the funds.
                      </p>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const orderRef = doc(db, 'orders', selectedOrderForDetail.id);
                            await updateDoc(orderRef, {
                              paymentStatus: 'Paid',
                              updatedAt: new Date().toISOString()
                            });
                            setSelectedOrderForDetail(prev => prev ? { ...prev, paymentStatus: 'Paid', updatedAt: new Date().toISOString() } : null);
                          } catch (err) {
                            console.error("Failed to verify payment:", err);
                          }
                        }}
                        className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer active:scale-95 flex items-center justify-center gap-1.5"
                      >
                        ✓ Confirm & Approve QR Transfer
                      </button>
                    </div>
                  )}

                  {/* MERCHANT INTERACTIVE STATUS CONTROLS */}
                  {selectedOrderForDetail.status !== 'Cancelled' && selectedOrderForDetail.status !== 'Delivered' && (
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-5 space-y-3">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Settings className="w-4 h-4 text-[#fd8b00]" /> Merchant Fulfillment Actions
                      </h4>
                      <p className="text-[10px] text-slate-400 font-medium leading-relaxed">Update the delivery progression state for this order. Homeowners will receive real-time notifications on their tracking dashboards instantly.</p>
                      <div className="flex flex-wrap gap-2.5 pt-1">
                        {selectedOrderForDetail.status === 'Pending' && (
                          <button
                            onClick={() => handleUpdateOrderStatus(selectedOrderForDetail.id, 'Confirmed')}
                            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer active:scale-95"
                          >
                            ✓ Confirm Order
                          </button>
                        )}
                        {(selectedOrderForDetail.status === 'Pending' || selectedOrderForDetail.status === 'Confirmed') && (
                          <button
                            onClick={() => handleUpdateOrderStatus(selectedOrderForDetail.id, 'Processing')}
                            className="px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer active:scale-95"
                          >
                            ⚙️ Start Processing
                          </button>
                        )}
                        {(selectedOrderForDetail.status === 'Processing' || selectedOrderForDetail.status === 'Confirmed' || selectedOrderForDetail.status === 'Pending') && (
                          <button
                            onClick={() => handleUpdateOrderStatus(selectedOrderForDetail.id, 'Shipped')}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer active:scale-95"
                          >
                            🚚 Ship Order
                          </button>
                        )}
                        {selectedOrderForDetail.status === 'Shipped' && (
                          <button
                            onClick={() => handleUpdateOrderStatus(selectedOrderForDetail.id, 'Delivered')}
                            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer active:scale-95"
                          >
                            ✅ Mark as Delivered
                          </button>
                        )}
                        
                        <button
                          onClick={() => {
                            const reason = window.prompt("Please specify cancellation reason:");
                            if (reason !== null) {
                              handleUpdateOrderStatus(selectedOrderForDetail.id, 'Cancelled', {
                                cancelledAt: new Date().toISOString(),
                                cancelledBy: 'Seller',
                                cancellationReason: reason || "Vendor cancelled the order."
                              });
                            }
                          }}
                          className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer active:scale-95 ml-auto"
                        >
                          ❌ Cancel Order
                        </button>
                      </div>
                    </div>
                  )}

                </div>

                {/* Right Part: Products & Invoice Slip (5 cols) */}
                <div className="lg:col-span-5 space-y-6">
                  
                  {/* PDF-LIKE INVOICE LAYOUT CONTAINER (FOR DOWNLOAD/PRINTING) */}
                  <div id="print-invoice-area-shop" className="bg-white border border-slate-200 rounded-2xl p-5 space-y-5 shadow-sm">
                    
                    {/* Invoice Branding Header */}
                    <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                      <div>
                        <h2 className="text-base font-black tracking-tight text-[#041627]">
                          PROBUILD MATERIALS
                        </h2>
                        <p className="text-[9px] text-[#fd8b00] font-bold uppercase tracking-wider mt-0.5">Heavy Logistics Invoice</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] font-extrabold text-[#041627] uppercase tracking-wide">Invoice Slip</p>
                        <p className="text-[10px] text-slate-500 font-mono mt-0.5">Ref: {selectedOrderForDetail.id}</p>
                      </div>
                    </div>

                    {/* Addresses Stack */}
                    <div className="text-xs space-y-3 pb-4 border-b border-slate-100">
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Bill To</span>
                        <p className="font-bold text-[#041627] mt-0.5">{selectedOrderForDetail.clientName || selectedOrderForDetail.customer}</p>
                        <p className="text-slate-500 font-medium">{selectedOrderForDetail.clientEmail || (selectedOrderForDetail.customer + "@gmail.com")}</p>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Ship To (Jobsite)</span>
                        <p className="font-semibold text-slate-800 mt-0.5 leading-relaxed">
                          {selectedOrderForDetail.shippingAddress || 'Jobsite #12 - Kathmandu Metropolitan, Nepal'}
                        </p>
                      </div>
                    </div>

                    {/* Itemized Materials Table */}
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-400 font-bold uppercase text-[9px] tracking-wider">
                            <th className="pb-2 w-10">Preview</th>
                            <th className="pb-2">Material Description</th>
                            <th className="pb-2 text-center">Qty</th>
                            <th className="pb-2 text-right">Unit Price</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 text-[#0b1c30] font-medium">
                          {selectedOrderForDetail.items && selectedOrderForDetail.items.length > 0 ? (
                            selectedOrderForDetail.items.map((item: any, idx: number) => (
                              <tr key={idx} className="hover:bg-slate-50/30">
                                <td className="py-2.5 pr-2">
                                  <img 
                                    src={item.productImage || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&auto=format&fit=crop&q=80'} 
                                    alt={item.productName} 
                                    className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                                    referrerPolicy="no-referrer"
                                  />
                                </td>
                                <td className="py-2.5 font-bold text-slate-800">
                                  {item.productName}
                                  <p className="text-[9px] text-slate-400 font-medium mt-0.5">Category: Building Supplies</p>
                                </td>
                                <td className="py-2.5 text-center font-bold text-slate-900">{item.quantity}</td>
                                <td className="py-2.5 text-right font-mono text-slate-500">Rs. {(item.unitPrice ?? 0).toFixed(2)}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td className="py-2.5 pr-2">
                                <img 
                                  src={selectedOrderForDetail.productImage || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&auto=format&fit=crop&q=80'} 
                                  alt={selectedOrderForDetail.productName} 
                                  className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                                  referrerPolicy="no-referrer"
                                />
                              </td>
                              <td className="py-2.5 font-bold text-slate-800">
                                {selectedOrderForDetail.productName}
                                <p className="text-[9px] text-slate-400 font-medium mt-0.5">Single Item Supply</p>
                              </td>
                              <td className="py-2.5 text-center font-bold text-slate-900">{selectedOrderForDetail.quantity}</td>
                              <td className="py-2.5 text-right font-mono text-slate-500">Rs. {(selectedOrderForDetail.unitPrice ?? 0).toFixed(2)}</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    {/* Calculations Row */}
                    <div className="pt-4 border-t border-slate-100 flex justify-end text-xs">
                      <div className="w-full space-y-2">
                        <div className="flex justify-between text-slate-500 font-medium">
                          <span>Subtotal:</span>
                          <span className="font-mono text-slate-800">
                            Rs. {((selectedOrderForDetail.amount ?? selectedOrderForDetail.totalPrice ?? 0) - (selectedOrderForDetail.freight ?? 45.00)).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between text-slate-500 font-medium">
                          <span>Flat Heavy Freight:</span>
                          <span className="font-mono text-slate-800">
                            Rs. {(selectedOrderForDetail.freight ?? 45.00).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between text-slate-500 font-medium">
                          <span>VAT Taxes (13%):</span>
                          <span className="font-mono text-emerald-600 font-bold">Inclusive</span>
                        </div>
                        <div className="flex justify-between pt-2 border-t border-slate-100 text-sm font-extrabold text-[#041627]">
                          <span>Grand Total:</span>
                          <span className="font-mono font-black text-[#fd8b00]">
                            Rs. {(selectedOrderForDetail.totalPrice ?? selectedOrderForDetail.amount ?? 0).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Ledger Footer */}
                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 text-[9px] text-slate-500 leading-relaxed font-medium">
                      This document serves as an electronic payment ledger receipt for contractors and project managers. Trade settlements are verified directly with the vendor.
                    </div>
                  </div>

                </div>

              </div>
            </div>

            {/* Modal Bottom Actions Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 shrink-0 flex flex-col xs:flex-row justify-between gap-3 w-full">
              {/* Left Side Info */}
              <div className="flex items-center text-[10px] text-slate-400 font-medium">
                <Shield className="w-3.5 h-3.5 text-emerald-500 mr-1.5" /> Secure end-to-end cloud ledger integration.
              </div>

              {/* Right Side Buttons */}
              <div className="flex gap-2.5 justify-end">
                <button 
                  onClick={() => {
                    const printContents = document.getElementById("print-invoice-area-shop")?.innerHTML;
                    if (printContents) {
                      const printWindow = window.open('', '', 'height=600,width=800');
                      if (printWindow) {
                        printWindow.document.write('<html><head><title>Print Invoice</title>');
                        printWindow.document.write('<style>body{font-family:sans-serif;padding:40px;} table{width:100%;border-collapse:collapse;} th,td{border-bottom:1px solid #ddd;padding:10px;text-align:left;} img{display:none;} .text-right{text-align:right;} .font-bold{font-weight:bold;} .flex{display:flex;justify-content:space-between;} .grid{display:grid;grid-template-cols:1fr 1fr 1fr;gap:20px;} .space-y-6 > * + * {margin-top:24px;} .pb-6{padding-bottom:24px;border-bottom:1px solid #eee;} .pt-6{padding-top:24px;border-top:1px solid #eee;} .border-t{border-top:1px solid #eee;} .font-black{font-weight:900;} .bg-slate-50{background-color:#f8fafc;padding:15px;border-radius:10px;}</style>');
                        printWindow.document.write('</head><body>');
                        printWindow.document.write(printContents);
                        printWindow.document.write('</body></html>');
                        printWindow.document.close();
                        printWindow.focus();
                        setTimeout(() => {
                          printWindow.print();
                          printWindow.close();
                        }, 500);
                      }
                    }
                  }}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Invoice</span>
                </button>

                <button 
                  onClick={() => setSelectedOrderForDetail(null)}
                  className="px-5 py-2 bg-slate-800 hover:bg-black text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Close Detail
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Delete Confirmation Popup */}
      {deleteTargetId && (
        <div className="fixed inset-0 bg-[#041627]/50 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-2xl border border-red-200 p-6 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="w-12 h-12 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-[#041627]">Delete Product Listing</h3>
            <p className="text-xs text-gray-600 mt-2 font-medium">Are you sure you want to delete this item?</p>
            <div className="mt-6 flex gap-3">
              <button 
                onClick={() => setDeleteTargetId(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold py-2.5 rounded-lg transition-colors cursor-pointer border border-gray-200 shadow-sm"
              >
                Cancel
              </button>
              <button 
                onClick={handleDeleteConfirm}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white text-xs font-bold py-2.5 rounded-lg transition-colors cursor-pointer shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      </div>
    </div>
  );
}
