import React, { useState, useEffect, useRef } from 'react';
import { 
   MessageSquare, Send, Search, Plus, X, User, Bell, MessageCircle, AlertCircle, Check, CheckCheck
} from 'lucide-react';
import { subscribeToUserMessages, sendChatMessage, markConversationAsRead, ChatMessage } from '../lib/messaging';
import { subscribeToPresence } from '../lib/presence';
import UserProfileModal from './UserProfileModal';

type Message = ChatMessage;

interface MessagePortalProps {
  currentRole: 'homeowner' | 'professional' | 'shopkeeper' | 'admin';
  currentUserEmail: string;
  currentUserName: string;
  currentUserAvatar?: string;
  initialContactEmail?: string | null;
  onClearInitialContactEmail?: () => void;
  presenceMap?: Record<string, boolean>;
}

export default function MessagePortal({ 
  currentRole, 
  currentUserEmail, 
  currentUserName, 
  currentUserAvatar,
  initialContactEmail,
  onClearInitialContactEmail,
  presenceMap: presenceMapProp
}: MessagePortalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [contacts, setContacts] = useState<any[]>([]);
  const [presenceMapState, setPresenceMapState] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [newMessageText, setNewMessageText] = useState('');
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [contactSearchQuery, setContactSearchQuery] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [temporaryActiveConversation, setTemporaryActiveConversation] = useState<any | null>(null);
  const [selectedProfileUserEmail, setSelectedProfileUserEmail] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Presence listener
  useEffect(() => {
    if (presenceMapProp) {
      setPresenceMapState(presenceMapProp);
      return;
    }
    const unsubPresence = subscribeToPresence((pMap) => {
      setPresenceMapState(pMap);
    });
    return () => unsubPresence();
  }, [presenceMapProp]);

  // Load contacts from local storage and fallback/merge
  useEffect(() => {
    const mergeWithLocalAndDemo = (loadedUsers: any[]) => {
        const merged = [...loadedUsers];

        // 1. Merge localStorage accounts (dreamhouse_accounts)
        try {
          const localRaw = localStorage.getItem('dreamhouse_accounts');
          if (localRaw) {
            const localAccounts = JSON.parse(localRaw);
            if (Array.isArray(localAccounts)) {
              localAccounts.forEach((acc: any) => {
                if (acc && acc.email) {
                  const emailLower = acc.email.toLowerCase();
                  const exists = merged.some(u => u.email.toLowerCase() === emailLower);
                  if (!exists) {
                    const uName = acc.username || acc.fullName?.toLowerCase().replace(/\s+/g, '') || acc.email.split('@')[0];
                    merged.push({
                      fullName: acc.fullName || acc.username || 'User',
                      username: uName,
                      email: acc.email,
                      role: acc.role || 'homeowner',
                      avatar: acc.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
                      phone: acc.phone || 'N/A',
                      status: acc.status || 'Active',
                      professionType: acc.professionType || undefined,
                      yearsOfExperience: acc.yearsOfExperience || undefined
                    });
                  }
                }
              });
            }
          }
        } catch (e) {
          console.warn("Failed to merge dreamhouse_accounts:", e);
        }

        // 2. Merge localStorage admin users (dreamhouse_admin_users)
        try {
          const adminRaw = localStorage.getItem('dreamhouse_admin_users');
          if (adminRaw) {
            const localAdminUsers = JSON.parse(adminRaw);
            if (Array.isArray(localAdminUsers)) {
              localAdminUsers.forEach((adminUser: any) => {
                if (adminUser && adminUser.email) {
                  const emailLower = adminUser.email.toLowerCase();
                  const existingIdx = merged.findIndex(u => u.email.toLowerCase() === emailLower);
                  const mappedRole = adminUser.accountType === 'Expert' ? 'professional' : adminUser.accountType === 'Shopkeeper' ? 'shopkeeper' : adminUser.accountType === 'Admin' ? 'admin' : 'homeowner';
                  const uName = adminUser.username || adminUser.fullName?.toLowerCase().replace(/\s+/g, '') || adminUser.email.split('@')[0];
                  
                  const mappedUser = {
                    fullName: adminUser.fullName || 'User',
                    username: uName,
                    email: adminUser.email,
                    role: mappedRole,
                    avatar: adminUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
                    phone: adminUser.phone || 'N/A',
                    status: adminUser.status || 'Active',
                    professionType: adminUser.professionType || undefined,
                    yearsOfExperience: adminUser.yearsOfExperience || undefined
                  };

                  if (existingIdx >= 0) {
                    merged[existingIdx] = { ...mappedUser, ...merged[existingIdx] };
                  } else {
                    merged.push(mappedUser);
                  }
                }
              });
            }
          }
        } catch (e) {
          console.warn("Failed to merge dreamhouse_admin_users:", e);
        }

        // 4. Merge dreamhouse_experts from localStorage
        try {
          const expertsRaw = localStorage.getItem('dreamhouse_experts');
          if (expertsRaw) {
            const localExperts = JSON.parse(expertsRaw);
            if (Array.isArray(localExperts)) {
              localExperts.forEach((exp: any) => {
                if (exp && exp.contact) {
                  const emailLower = exp.contact.toLowerCase();
                  const exists = merged.some(u => u.email.toLowerCase() === emailLower);
                  if (!exists && emailLower !== currentUserEmail.toLowerCase()) {
                    const uName = exp.name?.toLowerCase().replace(/\s+/g, '') || emailLower.split('@')[0];
                    merged.push({
                      fullName: exp.name || 'Expert',
                      username: uName,
                      email: exp.contact,
                      role: 'professional',
                      avatar: exp.photo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
                      phone: 'N/A',
                      status: exp.availability === 'Available' ? 'Active' : 'Offline',
                      professionType: exp.role || undefined,
                      yearsOfExperience: exp.yearsOfExperience || undefined
                    });
                  }
                }
              });
            }
          }
        } catch (e) {
          console.warn("Failed to merge dreamhouse_experts:", e);
        }

        // Ensure System Admin is always present as a contact
        const adminEmail = 'admin@dreamhouse.com';
        if (!merged.some(u => u.email.toLowerCase() === adminEmail.toLowerCase()) && adminEmail.toLowerCase() !== currentUserEmail.toLowerCase()) {
          merged.push({
            fullName: 'System Admin',
            username: 'admin',
            email: adminEmail,
            role: 'admin',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
            phone: 'N/A',
            status: 'Active'
          });
        }

        return merged.filter(c => c.email.toLowerCase() !== currentUserEmail.toLowerCase());
      };

    const setupUsersListener = () => {
      const merged = mergeWithLocalAndDemo([]);
      setContacts(merged);
    };

    setupUsersListener();

    window.addEventListener('dreamhouse_sync_users', setupUsersListener);

    return () => {
      window.removeEventListener('dreamhouse_sync_users', setupUsersListener);
    };
  }, [currentUserEmail]);

  // Programmatically trigger a conversation select when initialContactEmail is set
  useEffect(() => {
    if (initialContactEmail) {
      // Look for the expert in the contacts, but also support lookup if contacts list is still empty or loading
      let contact = contacts.find(c => c.email.toLowerCase() === initialContactEmail.toLowerCase());
      
      if (!contact) {
        // Check dreamhouse_experts fallback
        try {
          const raw = localStorage.getItem('dreamhouse_experts');
          if (raw) {
            const list = JSON.parse(raw);
            if (Array.isArray(list)) {
              const found = list.find((e: any) => e.contact?.toLowerCase() === initialContactEmail.toLowerCase());
              if (found) {
                contact = {
                  fullName: found.name,
                  username: found.name.toLowerCase().replace(/\s+/g, ''),
                  email: found.contact,
                  role: 'professional',
                  avatar: found.photo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
                  phone: 'N/A',
                  status: found.availability === 'Available' ? 'Active' : 'Offline',
                  professionType: found.role
                };
              }
            }
          }
        } catch (e) {
          console.warn("Error fallback reading dreamhouse_experts:", e);
        }
      }

      if (contact) {
        // Generate a consistent conversation ID by sorting emails
        const emails = [currentUserEmail.toLowerCase(), contact.email.toLowerCase()].sort();
        const generatedId = `${emails[0]}_${emails[1]}`;

        // Ensure this contact is registered in our contacts state so it's always recognized
        const contactObj = contact;
        setContacts(prev => {
          if (!prev.some(c => c.email.toLowerCase() === contactObj.email.toLowerCase())) {
            return [...prev, contactObj];
          }
          return prev;
        });

        const tempConv = {
          conversationId: generatedId,
          otherUser: {
            fullName: contact.fullName,
            email: contact.email,
            role: contact.role,
            avatar: contact.avatar,
            username: contact.username || contact.email.split('@')[0],
            professionType: contact.professionType
          },
          latestMessage: {
            id: 'temp',
            conversationId: generatedId,
            senderId: currentUserEmail,
            senderName: currentUserName,
            senderRole: currentRole === 'professional' ? 'expert' : currentRole,
            senderAvatar: currentUserAvatar || '',
            recipientId: contact.email,
            recipientName: contact.fullName,
            recipientRole: contact.role === 'professional' ? 'expert' : contact.role,
            recipientAvatar: contact.avatar,
            text: 'Conversation started',
            timestamp: Date.now(),
            read: true
          }
        };

        setTemporaryActiveConversation(tempConv);
        setSelectedConversationId(generatedId);
        
        if (onClearInitialContactEmail) {
          onClearInitialContactEmail();
        }
      }
    }
  }, [initialContactEmail, contacts, currentUserEmail, currentUserName, currentRole, currentUserAvatar, onClearInitialContactEmail]);

  // Real-time listener for Firestore messages
  useEffect(() => {
    if (!currentUserEmail) return;

    setLoading(true);
    const unsubscribe = subscribeToUserMessages(currentUserEmail, (firestoreMsgs) => {
      setMessages(firestoreMsgs);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUserEmail]);

  // Auto-scroll to bottom of active chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedConversationId]);

  // Mark selected conversation as read in Firestore
  useEffect(() => {
    if (!selectedConversationId || !currentUserEmail) return;
    markConversationAsRead(selectedConversationId, currentUserEmail);
  }, [selectedConversationId, messages, currentUserEmail]);

  const conversationsMap = new Map<string, {
    conversationId: string;
    otherUser: {
      fullName: string;
      email: string;
      role: string;
      avatar: string;
      username?: string;
      professionType?: string;
    };
    latestMessage: Message;
    unreadCount: number;
  }>();

  if (temporaryActiveConversation) {
    conversationsMap.set(temporaryActiveConversation.conversationId, {
      conversationId: temporaryActiveConversation.conversationId,
      otherUser: {
        fullName: temporaryActiveConversation.otherUser.fullName,
        email: temporaryActiveConversation.otherUser.email,
        role: temporaryActiveConversation.otherUser.role,
        avatar: temporaryActiveConversation.otherUser.avatar,
        username: temporaryActiveConversation.otherUser.username,
        professionType: temporaryActiveConversation.otherUser.professionType
      },
      latestMessage: temporaryActiveConversation.latestMessage,
      unreadCount: 0
    });
  }

  messages.forEach(msg => {
    const isSelfSender = msg.senderId.toLowerCase() === currentUserEmail.toLowerCase();
    const otherUserEmail = isSelfSender ? msg.recipientId : msg.senderId;
    
    // Resolve up-to-date user details from contacts registry
    const matchingContact = contacts.find(c => c.email.toLowerCase() === otherUserEmail.toLowerCase());
    
    const otherUserName = matchingContact?.fullName || (isSelfSender ? msg.recipientName : msg.senderName);
    const otherUserRole = matchingContact?.role || (isSelfSender ? msg.recipientRole : msg.senderRole);
    const otherUserAvatar = matchingContact?.avatar || (isSelfSender ? msg.recipientAvatar : msg.senderAvatar);
    const otherUserUsername = matchingContact?.username || otherUserEmail.split('@')[0];
    const otherUserProfessionType = matchingContact?.professionType;

    const existing = conversationsMap.get(msg.conversationId);
    const unread = (!isSelfSender && !msg.read) ? 1 : 0;

    if (!existing || msg.timestamp > existing.latestMessage.timestamp) {
      conversationsMap.set(msg.conversationId, {
        conversationId: msg.conversationId,
        otherUser: {
          fullName: otherUserName,
          email: otherUserEmail,
          role: otherUserRole,
          avatar: otherUserAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          username: otherUserUsername,
          professionType: otherUserProfessionType
        },
        latestMessage: msg,
        unreadCount: (existing?.unreadCount || 0) + unread
      });
    } else {
      conversationsMap.set(msg.conversationId, {
        ...existing,
        unreadCount: existing.unreadCount + unread
      });
    }
  });

  const conversationList = Array.from(conversationsMap.values()).sort(
    (a, b) => b.latestMessage.timestamp - a.latestMessage.timestamp
  );

  // Filter conversation list based on search bar
  const filteredConversations = conversationList.filter(conv => {
    const nameMatch = conv.otherUser.fullName.toLowerCase().includes(searchQuery.toLowerCase());
    const msgMatch = conv.latestMessage.text.toLowerCase().includes(searchQuery.toLowerCase());
    return nameMatch || msgMatch;
  });

  // Filter contact list for new chat modal
  const allowedContacts = contacts.filter(contact => {
    // Admin is always reachable by everyone
    if (contact.role === 'admin') return true;

    // Experts (professional) and Shopkeepers can message homeowner (Client) and admin
    if (currentRole === 'professional' || currentRole === 'shopkeeper') {
      return contact.role === 'homeowner' || contact.role === 'admin';
    }
    // Homeowners (Clients) can message experts (professional), shopkeepers, or other registered users / admins
    return true;
  });

  const filteredContacts = allowedContacts.filter(contact => {
    const searchLower = contactSearchQuery.toLowerCase();
    const matchesSearch = contact.fullName.toLowerCase().includes(searchLower) ||
                          contact.email.toLowerCase().includes(searchLower) ||
                          (contact.username && contact.username.toLowerCase().includes(searchLower));
    return matchesSearch;
  });

  // Send message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newMessageText.trim() || !selectedConversationId) return;

    // Retrieve selected conversation details
    const activeConv = conversationsMap.get(selectedConversationId);
    if (!activeConv) return;

    const messageText = newMessageText.trim();
    setNewMessageText('');

    try {
      const msgPayload: ChatMessage = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        conversationId: selectedConversationId,
        senderId: currentUserEmail,
        senderEmail: currentUserEmail,
        senderName: currentUserName,
        senderRole: currentRole === 'professional' ? 'expert' : currentRole,
        senderAvatar: currentUserAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        recipientId: activeConv.otherUser.email,
        recipientEmail: activeConv.otherUser.email,
        recipientName: activeConv.otherUser.fullName,
        recipientRole: activeConv.otherUser.role === 'professional' ? 'expert' : activeConv.otherUser.role,
        recipientAvatar: activeConv.otherUser.avatar,
        text: messageText,
        timestamp: Date.now(),
        read: false
      };

      await sendChatMessage(msgPayload);
    } catch (e: any) {
      console.warn("Failed to send message to Firestore:", e);
      setErrorMsg("Failed to deliver message: " + (e.message || 'Network error'));
    }
  };

  // Start new conversation from modal
  const handleStartNewConversation = (contact: any) => {
    // Generate a consistent conversation ID by sorting emails
    const emails = [currentUserEmail.toLowerCase(), contact.email.toLowerCase()].sort();
    const generatedId = `${emails[0]}_${emails[1]}`;

    const tempConv = {
      conversationId: generatedId,
      otherUser: {
        fullName: contact.fullName,
        email: contact.email,
        role: contact.role,
        avatar: contact.avatar
      },
      latestMessage: {
        id: 'temp',
        conversationId: generatedId,
        senderId: currentUserEmail,
        senderName: currentUserName,
        senderRole: currentRole === 'professional' ? 'expert' : currentRole,
        senderAvatar: currentUserAvatar || '',
        recipientId: contact.email,
        recipientName: contact.fullName,
        recipientRole: contact.role === 'professional' ? 'expert' : contact.role,
        recipientAvatar: contact.avatar,
        text: 'Conversation started',
        timestamp: Date.now(),
        read: true
      }
    };

    setTemporaryActiveConversation(tempConv);
    setSelectedConversationId(generatedId);
    setIsNewChatModalOpen(false);
    setContactSearchQuery('');
  };

  const getRoleBadgeColor = (role: string) => {
    const formatted = role.toLowerCase();
    if (formatted.includes('homeowner') || formatted.includes('client')) return 'bg-sky-100 text-sky-800 dark:bg-sky-950/40 dark:text-sky-300';
    if (formatted.includes('expert') || formatted.includes('professional') || formatted.includes('architect')) return 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300';
    if (formatted.includes('shopkeeper') || formatted.includes('supplier')) return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300';
    return 'bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-300';
  };

  const getRoleDisplayName = (role: string) => {
    const formatted = role.toLowerCase();
    if (formatted.includes('homeowner')) return 'Client';
    if (formatted.includes('professional') || formatted.includes('expert')) return 'Expert';
    if (formatted.includes('shopkeeper')) return 'Supplier / Shop';
    return role;
  };

  const formatMessageTime = (ms: number) => {
    try {
      const date = new Date(ms);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return '';
    }
  };

  const isUserOnline = (email?: string) => {
    if (!email) return false;
    const lower = email.toLowerCase().trim();
    if (presenceMapState[lower] !== undefined) {
      return presenceMapState[lower];
    }
    const contact = contacts.find(c => c.email.toLowerCase() === lower);
    return contact ? contact.status === 'Active' : false;
  };

  // Active conversation details
  const activeConversation = selectedConversationId ? conversationsMap.get(selectedConversationId) : null;
  const activeChatMessages = messages.filter(m => m.conversationId === selectedConversationId);

  return (
    <div className="w-full h-full min-h-[450px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex shadow-sm animate-in fade-in duration-200">
      
      {/* Sidebar: Conversation List */}
      <div className="w-80 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-slate-50/50 dark:bg-slate-900/50 shrink-0">
        
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2 text-sm uppercase tracking-wider">
              <MessageCircle className="w-4 h-4 text-[#fd8b00]" />
              Direct Messages
            </h3>
            <button 
              onClick={() => setIsNewChatModalOpen(true)}
              className="bg-[#fd8b00] hover:bg-[#e07b00] text-white p-1.5 rounded-lg transition-colors cursor-pointer"
              title="Start New Conversation"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-4 py-2.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:outline-none focus:border-[#fd8b00]"
            />
          </div>
        </div>

        {/* Conversation List Scrollable Area */}
        <div className="flex-grow overflow-y-auto no-scrollbar scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden divide-y divide-slate-100 dark:divide-slate-800/50">
          {filteredConversations.map((conv) => {
            const isActive = selectedConversationId === conv.conversationId;
            const hasUnread = conv.unreadCount > 0;
            const online = isUserOnline(conv.otherUser.email);

            return (
              <button
                key={conv.conversationId}
                onClick={() => setSelectedConversationId(conv.conversationId)}
                className={`w-full text-left p-4 flex gap-3 transition-colors ${
                  isActive ? 'bg-slate-100 dark:bg-slate-800' : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="relative shrink-0">
                  <img 
                    src={conv.otherUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'} 
                    alt={conv.otherUser.fullName} 
                    title={`View ${conv.otherUser.fullName}'s Profile`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedProfileUserEmail(conv.otherUser.email);
                    }}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 cursor-pointer hover:ring-2 hover:ring-[#fd8b00] hover:scale-105 transition-all"
                  />
                  <span className={`absolute bottom-0 right-0 block h-2.5 w-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                    online ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                  }`} />
                </div>
                
                <div className="min-w-0 flex-grow relative">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="text-xs font-bold text-slate-800 dark:text-white truncate">
                      {conv.otherUser.fullName}
                    </span>
                    <span className="text-[9px] text-slate-400 shrink-0 font-mono">
                      {formatMessageTime(conv.latestMessage.timestamp)}
                    </span>
                  </div>

                  <p className={`text-[11px] truncate pr-4 ${hasUnread ? 'font-bold text-[#0b1c30] dark:text-slate-100' : 'text-slate-500'}`}>
                    {conv.latestMessage.text}
                  </p>

                  <div className="flex justify-between items-center mt-1.5">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase tracking-wider ${getRoleBadgeColor(conv.otherUser.role)}`}>
                      {getRoleDisplayName(conv.otherUser.role)}
                    </span>

                    <span className={`text-[9px] font-bold ${online ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`}>
                      {online ? 'Online' : 'Offline'}
                    </span>

                    {hasUnread && (
                      <span className="bg-[#fd8b00] text-white text-[9px] font-bold rounded-full h-4 min-w-4 px-1 flex items-center justify-center animate-pulse">
                        {conv.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}

          {filteredConversations.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs px-4">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="font-semibold">No direct messages yet.</p>
              <p className="text-[10px] mt-0.5">Click the plus icon to start a conversation.</p>
            </div>
          )}
        </div>
      </div>

      {/* Main chat window */}
      <div className="flex-1 flex flex-col bg-white dark:bg-slate-900 relative">
        {activeConversation ? (
          <>
            {/* Conversation Header */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50/30 dark:bg-slate-900/30">
              <div className="flex items-center gap-3">
                <div className="relative shrink-0">
                  <img 
                    src={activeConversation.otherUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'} 
                    alt={activeConversation.otherUser.fullName} 
                    title={`View ${activeConversation.otherUser.fullName}'s Profile`}
                    onClick={() => setSelectedProfileUserEmail(activeConversation.otherUser.email)}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 cursor-pointer hover:ring-2 hover:ring-[#fd8b00] hover:scale-105 transition-all"
                    referrerPolicy="no-referrer"
                  />
                  <span className={`absolute bottom-0 right-0 block h-2.5 w-2.5 rounded-full ring-2 ring-white dark:ring-slate-900 ${
                    isUserOnline(activeConversation.otherUser.email) ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                  }`} />
                </div>
                <div>
                  <h4 
                    onClick={() => setSelectedProfileUserEmail(activeConversation.otherUser.email)}
                    className="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-2 flex-wrap cursor-pointer hover:text-[#fd8b00] transition-colors"
                  >
                    {activeConversation.otherUser.fullName}
                    {activeConversation.otherUser.username && (
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                        @{activeConversation.otherUser.username}
                      </span>
                    )}
                    <span className={`inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      isUserOnline(activeConversation.otherUser.email) ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      <span className={`w-1 h-1 rounded-full ${isUserOnline(activeConversation.otherUser.email) ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                      {isUserOnline(activeConversation.otherUser.email) ? 'Online' : 'Offline'}
                    </span>
                  </h4>
                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase tracking-wider shrink-0 ${getRoleBadgeColor(activeConversation.otherUser.role)}`}>
                      {getRoleDisplayName(activeConversation.otherUser.role)}
                    </span>
                    {activeConversation.otherUser.professionType && (
                      <span className="text-[9px] bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 px-1.5 py-0.5 rounded font-bold border border-amber-100 dark:border-amber-900/30">
                        {activeConversation.otherUser.professionType}
                      </span>
                    )}
                    <span className="text-[10px] text-slate-400">• {activeConversation.otherUser.email}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Error notifications */}
            {errorMsg && (
              <div className="bg-rose-50 dark:bg-rose-950/20 border-b border-rose-200 dark:border-rose-900/50 p-2.5 flex justify-between items-center text-[11px] text-rose-800 dark:text-rose-300">
                <span className="flex items-center gap-1.5 font-semibold">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {errorMsg}
                </span>
                <button onClick={() => setErrorMsg(null)} className="text-rose-950 dark:text-rose-200 font-bold hover:underline">Dismiss</button>
              </div>
            )}

            {/* Message Area */}
            <div className="flex-1 overflow-y-auto no-scrollbar scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden p-4 space-y-4 bg-slate-50/20 dark:bg-slate-950/20">
              {activeChatMessages.map((msg) => {
                const isSelf = msg.senderId.toLowerCase() === currentUserEmail.toLowerCase();
                
                // Dynamically resolve sender profile details from actual database / contacts
                let resolvedSenderName = msg.senderName;
                let resolvedSenderAvatar = msg.senderAvatar;
                let resolvedSenderRole = msg.senderRole;
                
                if (isSelf) {
                  resolvedSenderName = currentUserName;
                  resolvedSenderAvatar = currentUserAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';
                  resolvedSenderRole = currentRole === 'professional' ? 'expert' : currentRole;
                } else {
                  const match = contacts.find(c => c.email.toLowerCase() === msg.senderId.toLowerCase());
                  if (match) {
                    resolvedSenderName = match.fullName;
                    resolvedSenderAvatar = match.avatar;
                    resolvedSenderRole = match.role;
                  }
                }

                return (
                  <div key={msg.id} className={`flex gap-2.5 max-w-[80%] ${isSelf ? 'ml-auto flex-row-reverse' : ''}`}>
                    <img 
                      src={resolvedSenderAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'} 
                      alt={resolvedSenderName} 
                      title={`View ${resolvedSenderName}'s Profile`}
                      onClick={() => setSelectedProfileUserEmail(msg.senderId || msg.senderEmail || '')}
                      className="w-7 h-7 rounded-full object-cover border border-slate-100 dark:border-slate-800 shrink-0 cursor-pointer hover:ring-2 hover:ring-[#fd8b00] hover:scale-110 transition-all"
                      referrerPolicy="no-referrer"
                    />
                    
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300">
                          {resolvedSenderName}
                        </span>
                        <span className={`text-[8px] px-1 py-0.2 rounded font-extrabold uppercase tracking-wide shrink-0 ${getRoleBadgeColor(resolvedSenderRole || '')}`}>
                          {getRoleDisplayName(resolvedSenderRole || '')}
                        </span>
                        <span className="text-[8px] text-slate-400 font-mono">
                          {formatMessageTime(msg.timestamp)}
                        </span>
                        {isSelf && (
                          <span className="inline-flex items-center gap-0.5 text-[8px] font-mono shrink-0 ml-1">
                            {msg.read ? (
                              <span className="text-emerald-500 flex items-center gap-0.5 font-bold" title="Read by recipient">
                                <CheckCheck className="w-3 h-3 text-emerald-500" /> Read
                              </span>
                            ) : (
                              <span className="text-sky-400 flex items-center gap-0.5 font-medium" title="Delivered to server">
                                <Check className="w-3 h-3 text-sky-400" /> Sent
                              </span>
                            )}
                          </span>
                        )}
                      </div>

                      <div className={`p-3 rounded-2xl text-xs leading-relaxed break-all ${
                        isSelf 
                          ? 'bg-[#1a2b3c] text-white rounded-tr-none' 
                          : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-tl-none shadow-sm'
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input Box */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-200 dark:border-slate-800 flex gap-3 items-end">
              <textarea 
                rows={1}
                placeholder="Type your message here..."
                value={newMessageText}
                onChange={(e) => setNewMessageText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                className="flex-1 text-xs px-4 py-3 bg-[#f8f9ff] dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:outline-none focus:border-[#fd8b00] resize-none overflow-y-auto max-h-28"
              />
              <button 
                type="submit"
                disabled={!newMessageText.trim()}
                className="bg-[#fd8b00] hover:bg-[#e07b00] disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white px-5 py-3 rounded-xl transition-all cursor-pointer flex items-center justify-center font-bold text-xs gap-1.5 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                Send
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-10 text-center text-slate-400 select-none">
            <div className="w-16 h-16 bg-[#ffdcc3] text-[#fd8b00] rounded-full flex items-center justify-center mb-4 shadow-sm animate-pulse">
              <MessageSquare className="w-8 h-8" />
            </div>
            <h4 className="text-base font-bold text-slate-700 dark:text-white">Workspace Messenger</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm">Select a homeowner or supplier chat from the sidebar, or click the plus button to open a direct message channel.</p>
          </div>
        )}
      </div>

      {/* Direct Contact Picker Modal */}
      {isNewChatModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl max-w-md w-full max-h-[80vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-900/50">
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-white">Start a Direct Message</h4>
                <p className="text-[10px] text-slate-400 mt-0.5">Select a verified connection to start chatting</p>
              </div>
              <button 
                onClick={() => { setIsNewChatModalOpen(false); setContactSearchQuery(''); }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal search bar */}
            <div className="p-3 border-b border-slate-100 dark:border-slate-800/40">
              <input 
                type="text" 
                placeholder="Search name, email, or username..."
                value={contactSearchQuery}
                onChange={(e) => setContactSearchQuery(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-[#f8f9ff] dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white focus:outline-none"
              />
            </div>

            {/* Modal Contact List */}
            <div className="flex-1 overflow-y-auto no-scrollbar scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden divide-y divide-slate-100 dark:divide-slate-800/40">
              {filteredContacts.map((contact) => {
                const online = isUserOnline(contact.email);
                return (
                  <button
                    key={contact.email}
                    onClick={() => handleStartNewConversation(contact)}
                    className="w-full text-left p-3.5 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <div className="relative shrink-0">
                      <img 
                        src={contact.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'} 
                        alt={contact.fullName} 
                        title={`View ${contact.fullName}'s Profile`}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedProfileUserEmail(contact.email);
                        }}
                        className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 cursor-pointer hover:ring-2 hover:ring-[#fd8b00] hover:scale-105 transition-all"
                        referrerPolicy="no-referrer"
                      />
                      <span className={`absolute bottom-0 right-0 block h-2 w-2 rounded-full ring-1 ring-white dark:ring-slate-900 ${
                        online ? 'bg-emerald-500' : 'bg-slate-400'
                      }`} />
                    </div>
                    <div className="min-w-0 flex-grow">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h5 className="text-xs font-bold text-slate-800 dark:text-white truncate">
                          {contact.fullName}
                        </h5>
                        <span className="text-[10px] text-slate-400 font-mono">
                          @{contact.username}
                        </span>
                        <span className={`text-[8px] px-1 py-0.2 rounded font-semibold ${online ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30' : 'text-slate-400 bg-slate-50 dark:bg-slate-900'}`}>
                          {online ? 'Online' : 'Offline'}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 mt-0.5">
                        <p className="text-[10px] text-slate-400 truncate flex-1">{contact.email}</p>
                        {contact.professionType && (
                          <span className="text-[9px] bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 px-1.5 py-0.2 rounded font-medium border border-amber-100 dark:border-amber-900/30">
                            {contact.professionType}
                          </span>
                        )}
                      </div>
                    </div>
                    <span className={`text-[8px] px-1.5 py-0.5 rounded font-extrabold uppercase tracking-wider shrink-0 ${getRoleBadgeColor(contact.role)}`}>
                      {getRoleDisplayName(contact.role)}
                    </span>
                  </button>
                );
              })}

              {filteredContacts.length === 0 && (
                <div className="text-center py-12 text-slate-400 text-xs px-4">
                  <User className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="font-semibold">No contacts found.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* User Profile Modal */}
      {selectedProfileUserEmail && (
        <UserProfileModal
          userEmailOrId={selectedProfileUserEmail}
          onClose={() => setSelectedProfileUserEmail(null)}
          presenceMap={presenceMapState}
          onSendMessage={(email) => {
            const contact = contacts.find(c => c.email.toLowerCase() === email.toLowerCase());
            if (contact) {
              handleStartNewConversation(contact);
            }
          }}
        />
      )}

    </div>
  );
}
