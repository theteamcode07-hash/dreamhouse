import React, { useState, useRef } from 'react';
import { User, Mail, Phone, MapPin, Edit2, Camera, Trash2, X, Filter, Plus } from 'lucide-react';
import { optimizeImage } from '../lib/fileUploader';

interface ProjectPhoto {
  id: string;
  url: string;
  title: string;
  category: string;
}

interface ProfileData {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
}

export default function ProfessionalProfile({
  username,
  userEmail,
  userAvatar,
  onUpdateAvatar,
  onUpdateProfile,
}: {
  username: string;
  userEmail: string;
  userAvatar?: string;
  onUpdateAvatar?: (newAvatar: string) => void;
  onUpdateProfile?: (updatedData: { fullName?: string; phone?: string; avatar?: string }) => void;
}) {
  const [profile, setProfile] = useState<ProfileData>({
    fullName: username,
    email: userEmail,
    phone: '9876543210',
    location: 'Kathmandu, Nepal',
    bio: 'Experienced architect specializing in modern residential designs and sustainable construction practices.',
  });

  const [isEditing, setIsEditing] = useState(false);
  const [projectPhotos, setProjectPhotos] = useState<ProjectPhoto[]>([
    { id: '1', url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400&auto=format&fit=crop&q=80', title: 'Modern Villa', category: 'Residential' },
    { id: '2', url: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=400&auto=format&fit=crop&q=80', title: 'Office Complex', category: 'Commercial' },
  ]);

  const [filter, setFilter] = useState('All');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const handleSaveProfile = () => {
    setIsEditing(false);
    if (onUpdateProfile) {
      onUpdateProfile({
        fullName: profile.fullName.trim(),
        phone: profile.phone.trim(),
        avatar: userAvatar
      });
    }
  };

  const handleAddPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const opt = await optimizeImage(file, 1600, 0.85);
        const newPhoto: ProjectPhoto = {
          id: Date.now().toString(),
          url: opt.dataUrl,
          title: 'New Project',
          category: 'General',
        };
        setProjectPhotos([...projectPhotos, newPhoto]);
      } catch {
        const reader = new FileReader();
        reader.onload = (event) => {
          const newPhoto: ProjectPhoto = {
            id: Date.now().toString(),
            url: event.target?.result as string,
            title: 'New Project',
            category: 'General',
          };
          setProjectPhotos([...projectPhotos, newPhoto]);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleRemovePhoto = (id: string) => {
    setProjectPhotos(projectPhotos.filter(p => p.id !== id));
  };

  const filteredPhotos = filter === 'All' ? projectPhotos : projectPhotos.filter(p => p.category === filter);

  return (
    <div className="space-y-8 bg-white p-6 rounded-xl border border-[#c4c6cd]/40 shadow-sm">
      {/* Profile Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="relative group">
            <img
              src={userAvatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80"}
              alt={profile.fullName}
              className="w-24 h-24 rounded-full object-cover border-4 border-[#fd8b00]/20"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 bg-[#fd8b00] text-white p-2 rounded-full hover:bg-[#e07b00]"
            >
              <Camera className="w-4 h-4" />
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={async (e) => {
                const file = e.target.files?.[0];
                if (file && onUpdateAvatar) {
                  try {
                    const opt = await optimizeImage(file, 512, 0.85);
                    onUpdateAvatar(opt.dataUrl);
                  } catch {
                    const reader = new FileReader();
                    reader.onload = (ev) => onUpdateAvatar(ev.target?.result as string);
                    reader.readAsDataURL(file);
                  }
                }
            }}/>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#041627]">{profile.fullName}</h2>
            <p className="text-sm text-[#44474c] font-medium">Expert Architect</p>
          </div>
        </div>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="flex items-center gap-2 px-4 py-2 bg-[#f8f9ff] text-[#041627] rounded-lg border border-[#c4c6cd]/40 font-semibold text-xs hover:bg-slate-100"
        >
          <Edit2 className="w-4 h-4" />
          {isEditing ? 'Cancel' : 'Edit Profile'}
        </button>
      </div>

      {/* Profile Details */}
      {isEditing ? (
        <div className="grid grid-cols-2 gap-4">
          <input className="p-2 border rounded" value={profile.fullName} onChange={e => setProfile({...profile, fullName: e.target.value})} placeholder="Full Name" />
          <input className="p-2 border rounded" value={profile.email} disabled placeholder="Email" />
          <input className="p-2 border rounded" value={profile.phone} onChange={e => setProfile({...profile, phone: e.target.value})} placeholder="Phone" />
          <input className="p-2 border rounded" value={profile.location} onChange={e => setProfile({...profile, location: e.target.value})} placeholder="Location" />
          <textarea className="col-span-2 p-2 border rounded" value={profile.bio} onChange={e => setProfile({...profile, bio: e.target.value})} placeholder="Bio" />
          <button onClick={handleSaveProfile} className="col-span-2 bg-[#fd8b00] text-white py-2 rounded font-bold">Save Changes</button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-6 text-sm">
          <div className="flex items-center gap-3"><Mail className="w-4 h-4 text-[#fd8b00]" /> {profile.email}</div>
          <div className="flex items-center gap-3"><Phone className="w-4 h-4 text-[#fd8b00]" /> {profile.phone}</div>
          <div className="flex items-center gap-3"><MapPin className="w-4 h-4 text-[#fd8b00]" /> {profile.location}</div>
          <p className="col-span-2 text-[#44474c] leading-relaxed">{profile.bio}</p>
        </div>
      )}

      {/* Project Photos */}
      <div className="border-t pt-8">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold text-[#041627]">Project Work Photos</h3>
          <div className="flex gap-4">
            <select className="text-xs p-2 border rounded" value={filter} onChange={e => setFilter(e.target.value)}>
              <option>All</option>
              <option>Residential</option>
              <option>Commercial</option>
            </select>
            <button 
              onClick={() => photoInputRef.current?.click()}
              className="flex items-center gap-2 bg-[#fd8b00] text-white px-4 py-2 rounded font-bold text-xs"
            >
              <Plus className="w-4 h-4" /> Add Photo
            </button>
            <input type="file" ref={photoInputRef} className="hidden" accept="image/*" onChange={handleAddPhoto} />
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-6">
          {filteredPhotos.map(photo => (
            <div key={photo.id} className="relative group border rounded-lg overflow-hidden">
              <img src={photo.url} alt={photo.title} className="w-full h-48 object-cover" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button onClick={() => handleRemovePhoto(photo.id)} className="bg-white p-2 rounded-full text-red-600"><Trash2 className="w-4 h-4" /></button>
              </div>
              <p className="p-2 text-xs font-semibold">{photo.title}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
