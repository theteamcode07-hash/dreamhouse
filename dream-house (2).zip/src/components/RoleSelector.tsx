import React from 'react';
import { Home, Store, Shield, ArrowLeft, Ruler } from 'lucide-react';
import { UserRole, WebsiteConfig } from '../types';

interface RoleSelectorProps {
  onSelectRole: (role: UserRole) => void;
  onBackToAuth: () => void;
  websiteConfig?: WebsiteConfig;
}

export default function RoleSelector({ onSelectRole, onBackToAuth, websiteConfig }: RoleSelectorProps) {
  const logoUrl = websiteConfig?.loginPageLogo || websiteConfig?.logoUrl || "";
  const siteName = websiteConfig?.siteName || "Dream House";
  const roleSelectorTitle = websiteConfig?.roleSelectorTitle || "Select Your Role";
  const roleSelectorSubtitle = websiteConfig?.roleSelectorSubtitle || "Choose how you want to interact with the Dream House platform to access the tools and features tailored to your needs.";

  const roles = [
    {
      id: 'homeowner' as UserRole,
      title: 'User Login',
      description: 'Homeowners and clients looking to manage projects, view designs, and track progress.',
      icon: <Home className="w-9 h-9 text-[#041627] dark:text-slate-200 transition-all duration-300 group-hover:scale-110 group-hover:text-[#fd8b00]" />
    },
    {
      id: 'professional' as UserRole,
      title: 'Professionals',
      description: 'Workers, Engineers, and Architects accessing blueprints, site plans, and team communication.',
      icon: <Ruler className="w-9 h-9 text-[#041627] dark:text-slate-200 transition-all duration-300 group-hover:scale-110 group-hover:text-[#fd8b00]" />
    },
    {
      id: 'shopkeeper' as UserRole,
      title: 'Shopkeeper',
      description: 'Suppliers and vendors managing inventory, fulfilling orders, and tracking shipments.',
      icon: <Store className="w-9 h-9 text-[#041627] dark:text-slate-200 transition-all duration-300 group-hover:scale-110 group-hover:text-[#fd8b00]" />
    },
    {
      id: 'admin' as UserRole,
      title: 'Admin',
      description: 'System administrators managing user access, platform settings, and overarching security.',
      icon: <Shield className="w-9 h-9 text-[#041627] dark:text-slate-200 transition-all duration-300 group-hover:scale-110 group-hover:text-[#fd8b00]" />
    }
  ];

  return (
    <div className="min-h-screen bg-[#f8f9ff] dark:bg-slate-950 text-[#0b1c30] dark:text-slate-100 flex flex-col font-sans">
      {/* Header */}
      <header className="w-full px-6 md:px-10 h-20 max-w-[1280px] mx-auto flex items-center justify-between">
        <div className="flex items-center gap-4">
          {logoUrl ? (
            <img 
              alt={`${siteName} Logo`} 
              className="h-10 w-10 object-contain rounded-md" 
              src={logoUrl}
            />
          ) : null}
          <span className="text-xl md:text-2xl font-bold font-sans text-[#041627] dark:text-white">{siteName}</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow flex flex-col items-center justify-center px-6 md:px-10 py-12 max-w-[1280px] mx-auto w-full">
        <div className="text-center mb-12 max-w-2xl">
          <h1 className="text-3xl md:text-5xl font-sans font-bold text-[#041627] dark:text-white mb-4">
            {roleSelectorTitle}
          </h1>
          <p className="text-base md:text-lg text-[#44474c] dark:text-slate-300 leading-relaxed">
            {roleSelectorSubtitle}
          </p>
        </div>

        {/* Roles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-5xl">
          {roles.map((role) => (
            <button
              key={role.id}
              onClick={() => onSelectRole(role.id)}
              className="group role-card bg-white dark:bg-slate-900 rounded-xl border border-[#c4c6cd] dark:border-slate-800 p-8 flex flex-col items-center text-center cursor-pointer shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-[#041627] dark:hover:border-[#fd8b00] active:translate-y-0"
              id={`role-${role.id}`}
            >
              <div className="h-16 w-16 rounded-full bg-[#eff4ff] dark:bg-slate-850 flex items-center justify-center mb-6 transition-colors group-hover:bg-[#e5eeff] dark:group-hover:bg-slate-800">
                {role.icon}
              </div>
              <h2 className="text-xl font-bold font-sans text-[#041627] dark:text-white mb-3">
                {role.title}
              </h2>
              <p className="text-sm text-[#44474c] dark:text-slate-300 leading-relaxed">
                {role.description}
              </p>
            </button>
          ))}
        </div>

        {/* Return Button */}
        <div className="mt-16 text-center">
          <button
            onClick={onBackToAuth}
            className="text-sm font-semibold text-[#44474c] dark:text-slate-300 hover:text-[#041627] dark:hover:text-white transition-colors flex items-center justify-center gap-2 group"
          >
            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
            Return to Login & Register
          </button>
        </div>
      </main>
    </div>
  );
}
