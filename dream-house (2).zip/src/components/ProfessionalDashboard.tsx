import React, { useState, useEffect } from 'react';
import { 
  Menu, X, ArrowLeft, Ruler, Calendar, Award, TrendingUp, CheckCircle, 
  MapPin, MessageSquare, Plus, CheckCircle2, ChevronRight, LogOut, User, Star, Megaphone 
} from 'lucide-react';
import { LeadOpportunity, ScheduleEvent } from '../types';
import MessagePortal from './MessagePortal';
import SharedProfileSettings from './SharedProfileSettings';
import ExpertReviewsView from './ExpertReviewsView';
import AnnouncementsView from './AnnouncementsView';
import { db, auth } from '../lib/firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import { subscribeToUserMessages } from '../lib/messaging';

interface ProfessionalDashboardProps {
  username?: string;
  userAvatar?: string;
  userEmail?: string;
  userPhone?: string;
  registrationDate?: string;
  onLogout: () => void;
  onUpdateAvatar?: (newAvatar: string) => void;
  onUpdateProfile?: (updatedData: { fullName?: string; phone?: string; avatar?: string }) => void;
}

export default function ProfessionalDashboard({ 
  username = '', 
  userAvatar, 
  userEmail = '',
  userPhone = '',
  registrationDate = '',
  onLogout, 
  onUpdateAvatar,
  onUpdateProfile
}: ProfessionalDashboardProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [opportunities, setOpportunities] = useState<LeadOpportunity[]>([]);
  const [events, setEvents] = useState<ScheduleEvent[]>([]);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [activeSubView, setActiveSubView] = useState<'dashboard' | 'messages' | 'profile' | 'reviews' | 'announcements'>('dashboard');
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadAnnouncementsCount, setUnreadAnnouncementsCount] = useState(0);

  // Unread announcements listener
  useEffect(() => {
    const email = (userEmail || auth.currentUser?.email || '').trim().toLowerCase();
    const activeUid = auth.currentUser?.uid || '';

    if (!activeUid || !email) {
      setUnreadAnnouncementsCount(0);
      return;
    }

    let allAnns: any[] = [];
    let readIds = new Set<string>();

    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      allAnns = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      recalc();
    });

    const unsubReads = onSnapshot(collection(db, 'announcement_reads'), (snapshot) => {
      readIds = new Set();
      snapshot.docs.forEach(d => {
        const data = d.data();
        if ((data.userId && data.userId === activeUid) || (data.userEmail && data.userEmail.toLowerCase() === email)) {
          readIds.add(data.announcementId);
        }
      });
      recalc();
    });

    function recalc() {
      const unread = allAnns.filter(item => {
        const target = item.targetAudience || item.targetRole || 'All';
        const isTargeted = 
          target === 'All' ||
          target === 'professional' ||
          (target === 'individual' && ((item.targetUserEmail || '').toLowerCase() === email || item.targetUserId === activeUid));
        if (!isTargeted) return false;
        if (item.scheduleTime && new Date(item.scheduleTime) > new Date()) return false;
        
        // Only show/count announcements published on or after user account creation date
        if (registrationDate) {
          const itemDate = new Date(item.createdAt || item.scheduleTime || 0);
          const userDate = new Date(registrationDate);
          if (!isNaN(itemDate.getTime()) && !isNaN(userDate.getTime())) {
            if (itemDate < userDate) {
              return false;
            }
          }
        }

        return !readIds.has(item.id);
      }).length;
      setUnreadAnnouncementsCount(unread);
    }

    return () => {
      unsubAnnouncements();
      unsubReads();
    };
  }, [userEmail, registrationDate, auth.currentUser?.uid]);

  useEffect(() => {
    const email = (userEmail || 'expert@gmail.com').trim();
    if (!email) return;

    const unsub = subscribeToUserMessages(email, (msgs) => {
      const emailLower = email.toLowerCase().trim();
      const count = msgs.filter((m) => {
        const rEmail = (m.recipientEmail || m.recipientId || '').toLowerCase().trim();
        return rEmail === emailLower && !m.read;
      }).length;
      setUnreadCount(count);
    });

    return () => unsub();
  }, [userEmail]);

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const compressAndResizeImage = (file: File, callback: (base64: string) => void) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 150;
          const MAX_HEIGHT = 150;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            callback(compressedBase64);
          } else {
            callback(event.target?.result as string);
          }
        } catch (e) {
          console.error("Canvas compression failed, using original reader result", e);
          callback(event.target?.result as string);
        }
      };
      img.onerror = () => {
        callback(event.target?.result as string);
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      callback("");
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      compressAndResizeImage(file, (base64Url) => {
        if (onUpdateAvatar) {
          onUpdateAvatar(base64Url);
        }
      });
    }
  };

  const [projects, setProjects] = useState([
    { id: 'p-1', name: 'Villa Nova Residence', phase: 'Design Phase 2', status: 'In Progress', date: 'Oct 24, 2023' },
    { id: 'p-2', name: 'Apex Commercial Plaza', phase: 'Framing Audit', status: 'Awaiting Materials', date: 'Oct 28, 2023' },
    { id: 'p-3', name: 'Riverside Cabin Extension', phase: 'Foundation Poured', status: 'Verified Compliant', date: 'Nov 02, 2023' }
  ]);

  const handleAcceptLead = (id: string, title: string) => {
    setOpportunities(opportunities.filter(o => o.id !== id));
    setSuccessMsg(`Success! You have claimed the lead for "${title}". A direct customer draft channel has been established.`);
  };

  const handleCancelEvent = (id: string) => {
    setEvents(events.filter(e => e.id !== id));
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] flex h-screen font-sans overflow-hidden relative">
      
      {/* Sidebar Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <nav 
        onClickCapture={() => setSidebarOpen(false)}
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#1a2b3c] text-white flex flex-col p-6 shadow-md transition-transform duration-300 ease-in-out shrink-0 overflow-y-auto no-scrollbar md:translate-x-0 md:relative ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        {/* Mobile Sidebar Close Header */}
        <div className="flex md:hidden justify-end mb-2">
          <button 
            type="button"
            onClick={() => setSidebarOpen(false)} 
            className="p-1.5 hover:bg-[#041627] rounded transition-colors text-[#8192a7] hover:text-white focus:outline-none"
            aria-label="Close navigation sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-8 flex items-center gap-3">
          <Ruler className="w-8 h-8 text-[#fd8b00]" />
          <div>
            <h2 className="text-sm font-bold tracking-wider uppercase">Pro Console</h2>
            <p className="text-[10px] text-[#8192a7]">Architect & Engineer suite</p>
          </div>
        </div>

        {/* User Profile Card */}
        <div className="mb-6 flex items-center gap-3 bg-[#041627]/30 p-3 rounded-lg border border-[#8192a7]/10 shrink-0">
          <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
            <img 
              src={userAvatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80"} 
              alt={username} 
              className="w-10 h-10 rounded-full object-cover border-2 border-[#fd8b00]/30 shadow-sm transition-transform duration-200 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/45 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <span className="text-[8px] text-white font-bold uppercase tracking-wider text-center">Edit</span>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleAvatarChange} 
              accept="image/*" 
              className="hidden" 
            />
          </div>
          <div className="min-w-0">
            <h3 className="text-xs font-bold text-white truncate">{username}</h3>
            <p className="text-[10px] text-[#8192a7] font-semibold tracking-wide uppercase">Expert / Pro</p>
          </div>
        </div>

        <div className="flex-grow space-y-2">
          <button 
            onClick={() => setActiveSubView('dashboard')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 ${activeSubView === 'dashboard' ? 'bg-[#041627] text-white' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'}`}
          >
            <Award className="w-4 h-4 text-[#fd8b00]" />
            Ongoing Projects Table
          </button>

          <button 
            onClick={() => setActiveSubView('profile')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 ${activeSubView === 'profile' ? 'bg-[#041627] text-white' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'}`}
          >
            <User className="w-4 h-4 text-[#fd8b00]" />
            Profile
          </button>

          <button 
            onClick={() => setActiveSubView('reviews')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center gap-3 ${activeSubView === 'reviews' ? 'bg-[#041627] text-white' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'}`}
          >
            <Star className="w-4 h-4 text-[#fd8b00]" />
            Ratings & Reviews
          </button>

          <button 
            onClick={() => setActiveSubView('messages')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between ${activeSubView === 'messages' ? 'bg-[#041627] text-white' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'}`}
          >
            <span className="flex items-center gap-3">
              <MessageSquare className="w-4 h-4 text-[#fd8b00]" />
              Messages
            </span>
            {unreadCount > 0 && (
              <span className="bg-[#fd8b00] text-white text-[9px] font-bold rounded-full px-1.5 py-0.5 animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          <button 
            onClick={() => setActiveSubView('announcements')} 
            className={`w-full text-left py-2.5 px-4 rounded font-semibold text-xs flex items-center justify-between ${activeSubView === 'announcements' ? 'bg-[#041627] text-white' : 'text-[#8192a7] hover:bg-[#1a2b3c]/60'}`}
          >
            <span className="flex items-center gap-3">
              <Megaphone className="w-4 h-4 text-[#fd8b00]" />
              Announcements
            </span>
            {unreadAnnouncementsCount > 0 && (
              <span className="bg-[#fd8b00] text-white text-[9px] font-bold rounded-full px-1.5 py-0.5 animate-pulse">
                {unreadAnnouncementsCount}
              </span>
            )}
          </button>
        </div>

        <div className="pt-6 border-t border-[#8192a7]/20">
          <button 
            onClick={onLogout}
            className="w-full text-left text-red-300 hover:bg-[#1a2b3c]/60 py-2 px-4 rounded font-semibold text-xs flex items-center gap-3"
          >
            <LogOut className="w-4 h-4" />
            Sign Out Workspace
          </button>
        </div>
      </nav>

      {/* Main Container Wrapper */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Mobile Header Bar */}
        <header className="bg-[#1a2b3c] text-white px-6 py-4 flex items-center justify-between md:hidden shadow-md shrink-0">
          <div className="flex items-center gap-3">
            <button 
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="p-1.5 -ml-1.5 hover:bg-[#041627] rounded-lg transition-colors focus:outline-none"
              aria-label="Open navigation sidebar"
            >
              <Menu className="w-6 h-6 text-[#fd8b00]" />
            </button>
            <div className="flex items-center gap-2">
              <Ruler className="w-5 h-5 text-[#fd8b00]" />
              <span className="font-bold text-sm tracking-wide uppercase">Pro Console</span>
            </div>
          </div>
          <div className="text-[10px] bg-[#041627] px-2 py-1 rounded text-[#8192a7] font-semibold font-mono">
            EXPERT
          </div>
        </header>

        {/* Main Content Area */}
        <main className={`flex-1 min-w-0 ${activeSubView === 'messages' ? 'h-[calc(100vh-70px)] overflow-hidden p-4 flex flex-col' : 'overflow-y-auto p-4 sm:p-6 md:p-10'}`}>
          <div className={`max-w-[1280px] w-full mx-auto ${activeSubView === 'messages' ? 'h-full flex flex-col' : 'space-y-8'}`}>
          
           {activeSubView === 'dashboard' ? (
            <>
              {/* Top Welcome Banner */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-r from-white to-[#eff4ff] p-6 rounded-xl border border-[#c4c6cd]/40">
                <div>
                  <h1 className="text-2xl font-bold text-[#041627]">Welcome back, {username}</h1>
                  <p className="text-xs text-[#44474c] mt-1">Reviewing modern villa Revit blueprints and matching client drafting proposals.</p>
                </div>
              </div>

              {/* Success messages */}
              {successMsg && (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-xs text-green-800 flex justify-between items-center animate-fadeIn">
                  <span>{successMsg}</span>
                  <button onClick={() => setSuccessMsg(null)} className="font-bold underline hover:no-underline">Dismiss</button>
                </div>
              )}

              {/* Metrics Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-5 shadow-sm">
                  <p className="text-xs font-semibold text-[#44474c]">Ongoing Projects</p>
                  <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-2">
                    <span className="text-2xl sm:text-3xl font-bold text-[#041627] whitespace-nowrap shrink-0">3 Active</span>
                    <div className="h-2 w-24 bg-gray-100 rounded-full overflow-hidden shrink-0">
                      <div className="h-full bg-[#fd8b00]" style={{ width: '75%' }}></div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-5 shadow-sm">
                  <p className="text-xs font-semibold text-[#44474c]">Active Leads Queue</p>
                  <p className="text-2xl sm:text-3xl font-bold text-[#041627] mt-1 whitespace-nowrap shrink-0">{opportunities.length} Leads</p>
                </div>

                <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-5 shadow-sm">
                  <p className="text-xs font-semibold text-[#44474c]">Total Earnings</p>
                  <div className="flex flex-wrap items-baseline gap-2 mt-1">
                    <span className="text-2xl sm:text-3xl font-bold text-[#041627] whitespace-nowrap shrink-0">Rs. 42,500</span>
                  </div>
                </div>
              </div>

              {/* Lower Grid: Projects table, Schedule, and Opportunities */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Current Active Projects Table */}
                <div className="lg:col-span-2 bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm">
                  <h3 className="text-base font-bold text-[#041627] mb-6">Current Drafting Projects</h3>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-[#c4c6cd]/30 text-[#44474c] uppercase font-bold tracking-wider">
                          <th className="pb-3 font-semibold">Project Residence</th>
                          <th className="pb-3 font-semibold">Workspace Phase</th>
                          <th className="pb-3 font-semibold">Status Rating</th>
                          <th className="pb-3 font-semibold">Next Milestone</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#c4c6cd]/20">
                        {projects.map((proj) => (
                          <tr key={proj.id} className="hover:bg-[#f8f9ff]">
                            <td className="py-4 font-bold text-[#041627]">{proj.name}</td>
                            <td className="py-4 text-[#44474c]">{proj.phase}</td>
                            <td className="py-4">
                              <span className={`px-2.5 py-1 rounded-full font-semibold text-[10px] ${
                                proj.status.includes('Awaiting') 
                                  ? 'bg-yellow-100 text-yellow-800' 
                                  : 'bg-green-100 text-green-800'
                              }`}>
                                {proj.status}
                              </span>
                            </td>
                            <td className="py-4 text-[#44474c]/80 font-mono">{proj.date}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Split right column: Upcoming inspection events, and opportunities */}
                <div className="space-y-6">
                  
                  {/* Upcoming Schedule */}
                  <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm">
                    <h3 className="text-sm font-bold text-[#041627] mb-4 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#fd8b00]" />
                      Upcoming Site Audits
                    </h3>

                    <div className="space-y-3">
                      {events.map((evt) => (
                        <div key={evt.id} className="flex gap-4 items-center p-3 bg-[#f8f9ff] rounded border border-[#c4c6cd]/20 text-xs">
                          <div className="bg-[#1a2b3c] text-white p-3.5 rounded-lg flex flex-col items-center justify-center font-bold">
                            <span className="text-base leading-none">{evt.date}</span>
                            <span className="text-[9px] uppercase mt-0.5 tracking-wider">Oct</span>
                          </div>
                          
                          <div className="flex-1">
                            <h4 className="font-bold text-[#041627]">{evt.title}</h4>
                            <p className="text-[10px] text-[#44474c] mt-0.5">{evt.time}</p>
                            <p className="text-[10px] text-[#44474c]/80 font-semibold mt-0.5">Location: {evt.location}</p>
                          </div>

                          <button 
                            onClick={() => handleCancelEvent(evt.id)}
                            className="text-xs text-red-500 hover:underline"
                          >
                            Cancel
                          </button>
                        </div>
                      ))}

                      {events.length === 0 && (
                        <p className="text-xs text-[#44474c] text-center py-4">No remaining site events scheduled today.</p>
                      )}
                    </div>
                  </div>

                  {/* Opportunities queue list */}
                  <div className="bg-white rounded-xl border border-[#c4c6cd]/40 p-6 shadow-sm">
                    <h3 className="text-sm font-bold text-[#041627] mb-4 flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-[#fd8b00]" />
                      New Opportunities
                    </h3>

                    <div className="space-y-3">
                      {opportunities.map((opp) => (
                        <div key={opp.id} className="p-3 bg-[#eff4ff] rounded-lg border border-[#c4c6cd]/20 text-xs">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-bold text-[#041627]">{opp.title}</h4>
                              <p className="text-[10px] text-[#44474c] mt-0.5 flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {opp.location}
                              </p>
                            </div>
                            {opp.status && (
                              <span className="bg-[#ffdcc3] text-[#6e3900] text-[9px] font-bold px-1.5 py-0.5 rounded">
                                {opp.status}
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-[#44474c]/80 mt-2">{opp.contact}</p>

                          <button 
                            onClick={() => handleAcceptLead(opp.id, opp.title)}
                            className="mt-3 w-full py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white rounded font-semibold text-[10px] text-center transition-colors cursor-pointer"
                          >
                            Claim Design Opportunity
                          </button>
                        </div>
                      ))}

                      {opportunities.length === 0 && (
                        <p className="text-xs text-[#44474c] text-center py-4">All available matching opportunities claimed.</p>
                      )}
                    </div>
                  </div>

                </div>

              </div>
            </>
          ) : activeSubView === 'profile' ? (
            <SharedProfileSettings
              roleName="Expert / Pro"
              username={username}
              userEmail={userEmail || auth.currentUser?.email || ''}
              userPhone={userPhone}
              registrationDate={registrationDate}
              userAvatar={userAvatar}
              onSave={(data) => {
                if (onUpdateProfile) onUpdateProfile(data);
                else if (data.avatar && onUpdateAvatar) onUpdateAvatar(data.avatar);
              }}
            />
          ) : activeSubView === 'reviews' ? (
            <ExpertReviewsView userEmail={userEmail} />
          ) : activeSubView === 'announcements' ? (
            <AnnouncementsView 
              userId={auth.currentUser?.uid || 'expert_user'}
              userEmail={userEmail || 'expert@gmail.com'}
              userRole="professional"
              userName={username}
              userCreatedAt={registrationDate}
            />
          ) : (
            <MessagePortal 
              currentRole="professional" 
              currentUserEmail={userEmail} 
              currentUserName={username} 
              currentUserAvatar={userAvatar}
            />
          )}
        </div>
      </main>

      </div>
    </div>
  );
}
