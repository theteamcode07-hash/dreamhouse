import React from 'react';

export function OnlineBadge({
  isOnline,
  email,
  presenceMap,
  sizeClass = "w-3.5 h-3.5",
  className = ""
}: {
  isOnline?: boolean;
  email?: string;
  presenceMap?: Record<string, boolean>;
  sizeClass?: string;
  className?: string;
}) {
  const online = isOnline !== undefined 
    ? isOnline 
    : (email && presenceMap ? !!presenceMap[email.toLowerCase().trim()] : false);

  if (!online) return null;
  return (
    <span
      className={`absolute ${sizeClass} bg-emerald-500 border-2 border-white dark:border-slate-800 rounded-full shadow-sm ring-2 ring-emerald-400/40 animate-pulse ${className}`}
      title="Online now"
    />
  );
}

export function UserAvatar({
  src,
  alt = "User",
  isOnline = false,
  email,
  presenceMap,
  sizeClass = "w-10 h-10",
  className = "",
  roundedClass = "rounded-full"
}: {
  src?: string;
  alt?: string;
  isOnline?: boolean;
  email?: string;
  presenceMap?: Record<string, boolean>;
  sizeClass?: string;
  className?: string;
  roundedClass?: string;
}) {
  const avatarUrl =
    src ||
    "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80";

  return (
    <div className={`relative inline-block shrink-0 ${className}`}>
      <img
        src={avatarUrl}
        alt={alt}
        className={`${sizeClass} ${roundedClass} object-cover border border-slate-200 dark:border-slate-700`}
        referrerPolicy="no-referrer"
      />
      <OnlineBadge isOnline={isOnline} email={email} presenceMap={presenceMap} />
    </div>
  );
}

export default OnlineBadge;
