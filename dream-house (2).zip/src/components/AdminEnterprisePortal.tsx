import React, { useState, useEffect } from 'react';
import { 
  Globe, Edit, Save, Upload, Plus, Trash2, Eye, EyeOff, Search, Filter, 
  ChevronLeft, ChevronRight, FileSpreadsheet, Download, Check, X, ShieldAlert,
  FolderOpen, AlertCircle, ShoppingBag, CreditCard, Star, MessageSquare, 
  Bell, FileText, Activity, Layers, RefreshCw, BarChart2, DollarSign,
  UserCheck, UserX, Trash, Ban, CheckCircle2, ListFilter, Megaphone, Pin,
  AlertTriangle, Send, Paperclip, Clock, Calendar, User, Mail, Repeat, Pencil, Tag, CheckCircle, XCircle
} from 'lucide-react';
import { db, storage } from '../lib/firebase';
import { 
  collection, getDocs, deleteDoc, doc, setDoc, updateDoc, onSnapshot, query, where, addDoc 
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import ImageUploader from './ImageUploader';
import PlatformConfigEditor from './PlatformConfigEditor';

interface AdminEnterprisePortalProps {
  activeTab: 'platform' | 'homepage' | 'categories' | 'products' | 'orders' | 'payments' | 'reviews' | 'messages' | 'notifications' | 'reports' | 'logs';
  adminName?: string;
}

// ----------------------------------------------------
// Core CSV & Excel Export Helper
// ----------------------------------------------------
const exportToCSV = (data: any[], filename: string) => {
  if (data.length === 0) return;
  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(item => 
    Object.values(item)
      .map(val => {
        const str = typeof val === 'object' ? JSON.stringify(val) : String(val);
        return `"${str.replace(/"/g, '""')}"`;
      })
      .join(',')
  );
  const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join("\n");
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export default function AdminEnterprisePortal({ activeTab, adminName = 'Super Admin' }: AdminEnterprisePortalProps) {
  // ----------------------------------------------------
  // States & Real-time Listeners
  // ----------------------------------------------------
  const [platformConfig, setPlatformConfig] = useState<any>({
    websiteName: 'Dream House',
    websiteLogo: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=100',
    websiteFavicon: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=32',
    heroBackground: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200',
    heroHeading: 'Design & Build Your Ultimate Dream House',
    heroDescription: 'Connect with certified structural engineers, top architects, builders, and elite material sellers all in one robust B2B platform.',
    heroButtonText: 'Explore Experts',
    heroButtonLink: '/directory',
    aboutSection: 'Dream House is a premium ecosystem transforming how residential and commercial development happens.',
    aboutImages: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600'
    ],
    homepageBanners: [
      { title: 'Architectural Excellence', image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800' }
    ],
    galleryImages: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=600'
    ],
    contactPhone: '+1 (555) 019-2834',
    contactEmail: 'support@dreamhouse.com',
    contactAddress: '100 Architectural Way, Design District, NY 10001',
    footerContent: '© 2026 Dream House Enterprise Platform. All rights reserved.',
    socialFacebook: 'https://facebook.com/dreamhouse',
    socialInstagram: 'https://instagram.com/dreamhouse',
    socialLinkedin: 'https://linkedin.com/company/dreamhouse',
    socialYoutube: 'https://youtube.com/dreamhouse',
    seoTitle: 'Dream House | Build & Shop Construction Marketplace',
    seoDescription: 'Enterprise portal connecting premium clients to architects, contractors, and building material suppliers.',
    seoKeywords: 'construction, architect, engineer, interior design, materials B2B',
        maintenanceMode: false
  });

  // Debounce ref and helper for live real-time auto-saving to Firestore
  const saveTimeoutRef = React.useRef<any>(null);
  const updatePlatformConfigAndSync = (newConfig: any) => {
    setPlatformConfig(newConfig);
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(async () => {
      try {
        const fullyMapped = {
          ...newConfig,
          // Guarantee legacy fields map for real-time live synchronization on other screens
          siteName: newConfig.websiteName || 'Dream House',
          logoUrl: newConfig.websiteLogo || '',
          heroBannerUrl: newConfig.heroBackground || '',
          heroTitle: newConfig.heroHeading || '',
          heroSubtitle: newConfig.heroDescription || '',
          joinButtonText: newConfig.heroButtonText || 'Join Dream House'
        };
        await setDoc(doc(db, 'website_config', 'main'), fullyMapped);
      } catch (err) {
        console.error("Error auto-saving website_config:", err);
      }
    }, 400);
  };

  const [homepageContent, setHomepageContent] = useState<any>({
    sections: [
      { id: 'hero', title: 'Main Hero Section', visible: true, order: 1, description: 'Prominent header layout with primary CTA.' },
      { id: 'categories', title: 'Service Categories Grid', visible: true, order: 2, description: 'Direct links to architects, contractors, and materials.' },
      { id: 'featured_experts', title: 'Top Ranked Professionals', visible: true, order: 3, description: 'Showcases high rating experts dynamically.' },
      { id: 'banners', title: 'Promotional Mid-Banners', visible: true, order: 4, description: 'Graphic banners highlighting platform offers.' },
      { id: 'gallery', title: 'Completed Project Showcase', visible: true, order: 5, description: 'Visual inspiration board for prospective homeowners.' }
    ]
  });

  const [categories, setCategories] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [adminLogs, setAdminLogs] = useState<any[]>([]);
  
  // Announcements & Email Notification states
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [announcementReads, setAnnouncementReads] = useState<any[]>([]);
  const [allAccounts, setAllAccounts] = useState<any[]>([]);
  
  // Form states
  const [notifCategory, setNotifCategory] = useState<'General' | 'System Update' | 'Maintenance' | 'Promotion' | 'Urgent Notice'>('General');
  const [selectedIndividualUser, setSelectedIndividualUser] = useState<string>('');
  const [notifChannel, setNotifChannel] = useState<'Announcement' | 'Email' | 'Both'>('Announcement');
  const [notifPriority, setNotifPriority] = useState<'Normal' | 'Important' | 'Urgent'>('Normal');
  const [isPinned, setIsPinned] = useState<boolean>(false);
  const [scheduleTime, setScheduleTime] = useState<string>('');
  const [notifTimeZone, setNotifTimeZone] = useState<string>('Local (NPT)');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [isDispatching, setIsDispatching] = useState<boolean>(false);

  // Edit modal state
  const [editingAnnouncement, setEditingAnnouncement] = useState<any | null>(null);

  // Search & Filter states for Admin list
  const [adminSearchQuery, setAdminSearchQuery] = useState('');
  const [adminRoleFilter, setAdminRoleFilter] = useState('All');
  const [adminPriorityFilter, setAdminPriorityFilter] = useState('All');
  const [adminCategoryFilter, setAdminCategoryFilter] = useState('All');

  // Feedback Notification banner
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Log audit helper
  const logAdminAction = async (actionText: string, moduleName: string) => {
    const logId = `log_${Date.now()}`;
    const dateObj = new Date();
    try {
      await setDoc(doc(db, 'admin_logs', logId), {
        id: logId,
        adminName,
        action: actionText,
        module: moduleName,
        date: dateObj.toLocaleDateString(),
        time: dateObj.toLocaleTimeString(),
        ipAddress: '192.168.1.105'
      });
    } catch (e) {
      console.error("Error creating audit log:", e);
    }
  };

  // ----------------------------------------------------
  // Mount real-time Firebase listeners
  // ----------------------------------------------------
  useEffect(() => {
    // 1. Platform configuration listener
    const unsubPlatform = onSnapshot(doc(db, 'website_config', 'main'), (snapshot) => {
      if (snapshot.exists()) {
        setPlatformConfig(snapshot.data());
      } else {
        // Seed default config to Firestore
        setDoc(doc(db, 'website_config', 'main'), platformConfig).catch(console.error);
      }
    });

    // 2. Homepage content layout listener
    const unsubHomepage = onSnapshot(doc(db, 'homepage_content', 'main'), (snapshot) => {
      if (snapshot.exists()) {
        setHomepageContent(snapshot.data());
      } else {
        setDoc(doc(db, 'homepage_content', 'main'), homepageContent).catch(console.error);
      }
    });

    // 3. Categories listener
    const unsubCategories = onSnapshot(collection(db, 'categories'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      // Sort by sortOrder
      list.sort((a: any, b: any) => (a.sortOrder || 0) - (b.sortOrder || 0));
      setCategories(list);
    });

    // 4. Products list listener
    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setProducts(list);
    });

    // 5. Orders listener
    const unsubOrders = onSnapshot(collection(db, 'orders'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setOrders(list);
    });

    // 6. Reviews listener
    const unsubReviews = onSnapshot(collection(db, 'reviews'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setReviews(list);
    });

    // 7. Messages listener
    const unsubMessages = onSnapshot(collection(db, 'messages'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setMessages(list);
    });

    // 8. Notifications history listener
    const unsubNotifications = onSnapshot(collection(db, 'notifications'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setNotifications(list);
    });

    // 9. Admin auditing logs listener
    const unsubLogs = onSnapshot(collection(db, 'admin_logs'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      // Newest logs first
      list.sort((a: any, b: any) => b.id.localeCompare(a.id));
      setAdminLogs(list);
    });

    // 10. Announcements listener
    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      list.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      setAnnouncements(list);
    });

    // 11. Announcement Reads listener
    const unsubReads = onSnapshot(collection(db, 'announcement_reads'), (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setAnnouncementReads(list);
    });

    // 12. Accounts listener
    const unsubAccounts = onSnapshot(collection(db, 'accounts'), (snapshot) => {
      const list = snapshot.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter((a: any) => !a.isDeleted && a.status !== 'Deleted' && a.accountStatus !== 'Deleted');
      setAllAccounts(list);
    });

    return () => {
      unsubPlatform();
      unsubHomepage();
      unsubCategories();
      unsubProducts();
      unsubOrders();
      unsubReviews();
      unsubMessages();
      unsubNotifications();
      unsubLogs();
      unsubAnnouncements();
      unsubReads();
      unsubAccounts();
    };
  }, []);

  const executeAutoDispatch = async (ann: any) => {
    try {
      await updateDoc(doc(db, 'announcements', ann.id), { status: 'Sending' });

      let targetEmails: string[] = [];
      const aud = ann.targetAudience || ann.targetRole || 'All';
      if (aud === 'individual') {
        const found = allAccounts.find(a => a.id === ann.targetUserId || a.email === ann.targetUserEmail);
        if (found && found.email) targetEmails.push(found.email);
        else if (ann.targetUserEmail) targetEmails.push(ann.targetUserEmail);
      } else if (aud === 'homeowner') {
        targetEmails = allAccounts.filter(a => a.accountType === 'Homeowner' && a.email).map(a => a.email);
      } else if (aud === 'professional') {
        targetEmails = allAccounts.filter(a => a.accountType === 'Expert' && a.email).map(a => a.email);
      } else if (aud === 'shopkeeper') {
        targetEmails = allAccounts.filter(a => a.accountType === 'Shopkeeper' && a.email).map(a => a.email);
      } else {
        targetEmails = allAccounts.filter(a => a.email).map(a => a.email);
      }
      targetEmails = Array.from(new Set(targetEmails.map(e => e.trim().toLowerCase()).filter(Boolean)));

      let emailDelivered: string[] = [];
      let emailFailed: { email: string; error: string }[] = [];
      let emailStatus: 'sent' | 'failed' | 'n/a' = 'n/a';

      if (ann.deliveryChannel === 'Email' || ann.deliveryChannel === 'Both') {
        if (targetEmails.length > 0) {
          try {
            const resp = await fetch('/api/admin/send-email', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                recipients: targetEmails,
                subject: ann.title,
                title: ann.title,
                content: ann.content || ann.body,
                category: ann.category
              })
            });
            const result = await resp.json();
            if (result.success) {
              emailDelivered = result.delivered || [];
              emailFailed = result.failed || [];
              emailStatus = emailFailed.length > 0 ? 'failed' : 'sent';
            } else {
              emailStatus = 'failed';
              emailFailed = targetEmails.map(e => ({ email: e, error: result.error || 'Server dispatch error' }));
            }
          } catch (err: any) {
            emailStatus = 'failed';
            emailFailed = targetEmails.map(e => ({ email: e, error: err.message || 'Network dispatch error' }));
          }
        }
      }

      const nowStr = new Date();
      const sentDateStr = nowStr.toLocaleDateString();
      const sentTimeStr = nowStr.toLocaleTimeString();

      const updatedPayload = {
        ...ann,
        status: 'Sent',
        sentDate: sentDateStr,
        sentTime: sentTimeStr,
        actualSentDate: sentDateStr,
        actualSentTime: sentTimeStr,
        emailStatus,
        recipientCount: targetEmails.length,
        deliveredEmails: emailDelivered,
        failedEmails: emailFailed,
        emailError: emailFailed.length > 0 ? emailFailed[0].error : ''
      };

      await setDoc(doc(db, 'announcements', ann.id), updatedPayload);
      await setDoc(doc(db, 'notifications', ann.id), updatedPayload);
      await logAdminAction(`Automatically dispatched scheduled announcement: "${ann.title}"`, 'Notification Management');
    } catch (err) {
      console.error("Auto dispatch error:", err);
      await updateDoc(doc(db, 'announcements', ann.id), { status: 'Failed' }).catch(() => {});
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      announcements.forEach(ann => {
        if (ann.status === 'Scheduled' && ann.scheduleTime) {
          const sched = new Date(ann.scheduleTime);
          if (!isNaN(sched.getTime()) && sched <= now) {
            executeAutoDispatch(ann);
          }
        }
      });
    }, 10000);
    return () => clearInterval(timer);
  }, [announcements, allAccounts]);

  // ----------------------------------------------------
  // Local variables for searching, filters, sorting & pagination
  // ----------------------------------------------------
  const [searchTerm, setSearchTerm] = useState('');
  const [filterOption, setFilterOption] = useState('All');
  const [sortOption, setSortOption] = useState('Newest');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Selected row checkboxes for bulk operations
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  // Reset pagination & selections on tab change
  useEffect(() => {
    setSearchTerm('');
    setFilterOption('All');
    setSortOption('Newest');
    setCurrentPage(1);
    setSelectedItems([]);
  }, [activeTab]);

  const handleSelectRow = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAll = (ids: string[]) => {
    if (selectedItems.length === ids.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(ids);
    }
  };

  // ----------------------------------------------------
  // Module 1: Platform Management Submit Handler
  // ----------------------------------------------------
  const handleSavePlatformConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'website_config', 'main'), platformConfig);
      await logAdminAction('Updated global website configuration settings', 'Platform Management');
      showToast('Website platform settings saved successfully!');
    } catch (err: any) {
      showToast(err.message || 'Error updating platform settings', 'error');
    }
  };


  // ----------------------------------------------------
  // Module 2: Homepage Content Manager Handlers
  // ----------------------------------------------------
  const handleToggleSectionVisibility = async (sectionId: string) => {
    const updatedSections = homepageContent.sections.map((sec: any) => {
      if (sec.id === sectionId) {
        return { ...sec, visible: !sec.visible };
      }
      return sec;
    });
    try {
      await setDoc(doc(db, 'homepage_content', 'main'), { sections: updatedSections });
      await logAdminAction(`Toggled section ${sectionId} visibility`, 'Homepage Content');
      showToast(`Section visibility toggled successfully!`);
    } catch (err: any) {
      showToast(err.message || 'Error toggling section', 'error');
    }
  };

  const handleOrderSection = async (index: number, direction: 'up' | 'down') => {
    const updated = [...homepageContent.sections];
    if (direction === 'up' && index > 0) {
      const temp = updated[index];
      updated[index] = updated[index - 1];
      updated[index - 1] = temp;
    } else if (direction === 'down' && index < updated.length - 1) {
      const temp = updated[index];
      updated[index] = updated[index + 1];
      updated[index + 1] = temp;
    }
    // Re-assign logical orders
    const sorted = updated.map((sec, idx) => ({ ...sec, order: idx + 1 }));
    try {
      await setDoc(doc(db, 'homepage_content', 'main'), { sections: sorted });
      await logAdminAction('Reordered homepage content sections block layout', 'Homepage Content');
      showToast('Section layout order updated successfully!');
    } catch (err: any) {
      showToast(err.message || 'Error ordering sections', 'error');
    }
  };

  // ----------------------------------------------------
  // Module 3: Category Management Handlers
  // ----------------------------------------------------
  const [newCatName, setNewCatName] = useState('');
  const [newCatCode, setNewCatCode] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('Layers');
  const [editingCategory, setEditingCategory] = useState<any | null>(null);

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim() || !newCatCode.trim()) return;
    const catId = `cat_${Date.now()}`;
    const payload = {
      id: catId,
      name: newCatName.trim(),
      code: newCatCode.trim().toLowerCase(),
      icon: newCatIcon,
      sortOrder: categories.length + 1,
      enabled: true
    };
    try {
      await setDoc(doc(db, 'categories', catId), payload);
      await logAdminAction(`Created product category: ${newCatName}`, 'Category Management');
      setNewCatName('');
      setNewCatCode('');
      setNewCatIcon('Layers');
      showToast(`Category "${newCatName}" created successfully!`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleUpdateCategory = async (cat: any) => {
    try {
      await setDoc(doc(db, 'categories', cat.id), cat, { merge: true });
      await logAdminAction(`Updated category attributes for: ${cat.name}`, 'Category Management');
      setEditingCategory(null);
      showToast(`Category updated successfully!`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDeleteCategory = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete the category: "${name}"?`)) return;
    try {
      await deleteDoc(doc(db, 'categories', id));
      await logAdminAction(`Deleted product category: ${name}`, 'Category Management');
      showToast(`Category "${name}" deleted successfully.`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // ----------------------------------------------------
  // Module 4: Product Management Handlers
  // ----------------------------------------------------
  const handleUpdateProductStatus = async (productId: string, status: string) => {
    try {
      await updateDoc(doc(db, 'products', productId), { status });
      await logAdminAction(`Changed product ${productId} status to ${status}`, 'Product Management');
      showToast(`Product status updated to ${status}`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleToggleProductFeature = async (productId: string, featured: boolean) => {
    try {
      await updateDoc(doc(db, 'products', productId), { featured });
      await logAdminAction(`Toggled product ${productId} featured to ${featured}`, 'Product Management');
      showToast(featured ? `Product marked as Featured` : `Product removed from Featured`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleUpdateProductStockPrice = async (productId: string, price: number, stock: number) => {
    try {
      await updateDoc(doc(db, 'products', productId), { price, stock });
      await logAdminAction(`Updated price (Rs. ${price}) and stock (${stock}) for product ${productId}`, 'Product Management');
      showToast(`Product inventory details saved successfully.`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDeleteProduct = async (productId: string, name: string) => {
    if (!window.confirm(`Are you sure you want to permanently delete: "${name}"?`)) return;
    try {
      await deleteDoc(doc(db, 'products', productId));
      await logAdminAction(`Deleted product listing: ${name}`, 'Product Management');
      showToast(`Product deleted successfully.`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // ----------------------------------------------------
  // Module 5 & 6: Order & Payment Management Handlers
  // ----------------------------------------------------
  const [viewingInvoiceOrder, setViewingInvoiceOrder] = useState<any | null>(null);
  const [orderFilterTab, setOrderFilterTab] = useState<'active' | 'delivered' | 'cancelled'>('active');

  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      const currentOrder = orders.find(o => o.id === orderId);
      if (currentOrder && currentOrder.status === 'Cancelled') {
        showToast("Cannot modify a cancelled order directly. Please restore it first.", 'error');
        return;
      }
      await updateDoc(doc(db, 'orders', orderId), { status });
      await logAdminAction(`Updated order ${orderId} status to ${status}`, 'Order Management');
      showToast(`Order status updated to ${status}`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleRestoreOrder = async (orderId: string) => {
    if (!window.confirm(`Are you sure you want to explicitly restore cancelled order ${orderId} back to Active/Pending status?`)) return;
    try {
      await updateDoc(doc(db, 'orders', orderId), { 
        status: 'Pending',
        restoredAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      await logAdminAction(`Explicitly restored cancelled order ${orderId} to Pending`, 'Order Management');
      showToast(`Order ${orderId} restored to Pending status successfully!`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!window.confirm(`Are you sure you want to permanently delete order ${orderId}?`)) return;
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      await logAdminAction(`Deleted order record: ${orderId}`, 'Order Management');
      showToast('Order record removed.');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // ----------------------------------------------------
  // Module 7: Review Management Handlers
  // ----------------------------------------------------
  const handleToggleReviewHide = async (reviewId: string, currentHidden: boolean) => {
    try {
      await updateDoc(doc(db, 'reviews', reviewId), { hidden: !currentHidden });
      await logAdminAction(`Toggled review ${reviewId} visibility`, 'Review Management');
      showToast(currentHidden ? `Review is now visible` : `Review is now hidden from public`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDeleteReview = async (reviewId: string) => {
    if (!window.confirm('Are you sure you want to permanently delete this customer review?')) return;
    try {
      await deleteDoc(doc(db, 'reviews', reviewId));
      await logAdminAction(`Deleted review document ID: ${reviewId}`, 'Review Management');
      showToast('Review removed permanently.');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // ----------------------------------------------------
  // Module 8: Message Management Handlers
  // ----------------------------------------------------
  const handleDeleteMessage = async (messageId: string) => {
    if (!window.confirm('Delete this user message permanently?')) return;
    try {
      await deleteDoc(doc(db, 'messages', messageId));
      await logAdminAction(`Deleted direct message log ID: ${messageId}`, 'Message Management');
      showToast('Message deleted.');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleBlockUser = async (userEmail: string) => {
    if (!window.confirm(`Are you sure you want to suspend/block the user with email: ${userEmail}?`)) return;
    try {
      // Find user account and update status
      const qAcc = query(collection(db, 'accounts'), where('email', '==', userEmail.toLowerCase()));
      const snap = await getDocs(qAcc);
      if (snap.empty) {
        showToast('User account not found in system databases.', 'error');
        return;
      }
      for (const d of snap.docs) {
        await updateDoc(doc(db, 'accounts', d.id), { status: 'Suspended' });
      }
      await logAdminAction(`Suspended user account: ${userEmail}`, 'Message Management');
      showToast(`User ${userEmail} is now Suspended.`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // ----------------------------------------------------
  // Module 9: Notification Management Handlers
  // ----------------------------------------------------
  const [notifTitle, setNotifTitle] = useState('');
  const [notifBody, setNotifBody] = useState('');
  const [notifRole, setNotifRole] = useState<'All' | 'homeowner' | 'professional' | 'shopkeeper' | 'individual'>('All');

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifBody.trim()) {
      showToast('Please provide both an alert title and message body.', 'error');
      return;
    }

    setIsDispatching(true);
    const notifId = `ann_${Date.now()}`;

    // Target emails selection
    let targetEmails: string[] = [];
    let selectedUserEmail = '';
    let selectedUserId = '';

    if (notifRole === 'individual') {
      const found = allAccounts.find(a => a.id === selectedIndividualUser || a.email === selectedIndividualUser);
      if (found) {
        selectedUserEmail = found.email || '';
        selectedUserId = found.id || '';
        if (selectedUserEmail) targetEmails.push(selectedUserEmail);
      } else if (selectedIndividualUser && selectedIndividualUser.includes('@')) {
        selectedUserEmail = selectedIndividualUser;
        targetEmails.push(selectedIndividualUser);
      }
    } else if (notifRole === 'homeowner') {
      targetEmails = allAccounts.filter(a => a.accountType === 'Homeowner' && a.email).map(a => a.email);
    } else if (notifRole === 'professional') {
      targetEmails = allAccounts.filter(a => a.accountType === 'Expert' && a.email).map(a => a.email);
    } else if (notifRole === 'shopkeeper') {
      targetEmails = allAccounts.filter(a => a.accountType === 'Shopkeeper' && a.email).map(a => a.email);
    } else {
      targetEmails = allAccounts.filter(a => a.email).map(a => a.email);
    }

    targetEmails = Array.from(new Set(targetEmails.map(e => e.trim().toLowerCase()).filter(Boolean)));

    const isFutureSchedule = scheduleTime && new Date(scheduleTime) > new Date();
    const status = isFutureSchedule ? 'Scheduled' : 'Sent';

    let emailDelivered: string[] = [];
    let emailFailed: { email: string; error: string }[] = [];
    let emailStatus: 'sent' | 'failed' | 'n/a' = 'n/a';
    let sentDateStr = '';
    let sentTimeStr = '';

    // Dispatch email if delivery channel includes Email and sending immediately
    if (!isFutureSchedule && (notifChannel === 'Email' || notifChannel === 'Both')) {
      if (targetEmails.length === 0) {
        showToast('No registered user emails found for the selected distribution group.', 'error');
        setIsDispatching(false);
        return;
      }
      try {
        const resp = await fetch('/api/admin/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            recipients: targetEmails,
            subject: notifTitle.trim(),
            title: notifTitle.trim(),
            content: notifBody.trim(),
            category: notifCategory
          })
        });
        const result = await resp.json();
        if (result.success) {
          emailDelivered = result.delivered || [];
          emailFailed = result.failed || [];
          emailStatus = emailFailed.length > 0 ? 'failed' : 'sent';
        } else {
          emailStatus = 'failed';
          emailFailed = targetEmails.map(e => ({ email: e, error: result.error || 'Server dispatch error' }));
        }
      } catch (err: any) {
        console.error("Email API failed:", err);
        emailStatus = 'failed';
        emailFailed = targetEmails.map(e => ({ email: e, error: err.message || 'Network dispatch error' }));
      }
    }

    if (!isFutureSchedule) {
      const now = new Date();
      sentDateStr = now.toLocaleDateString();
      sentTimeStr = now.toLocaleTimeString();
    }

    const payload = {
      id: notifId,
      title: notifTitle.trim(),
      content: notifBody.trim(),
      body: notifBody.trim(),
      category: notifCategory,
      targetAudience: notifRole,
      targetRole: notifRole,
      targetUserEmail: selectedUserEmail,
      targetUserId: selectedUserId,
      deliveryChannel: notifChannel,
      type: notifChannel,
      priority: notifPriority,
      isPinned: Boolean(isPinned),
      scheduleTime: scheduleTime || '',
      timeZone: notifTimeZone,
      status,
      attachmentUrl: attachmentUrl || '',
      createdAt: new Date().toISOString(),
      timestamp: new Date().toLocaleString(),
      createdByName: adminName || 'Super Admin',
      sentDate: sentDateStr,
      sentTime: sentTimeStr,
      actualSentDate: sentDateStr,
      actualSentTime: sentTimeStr,
      emailStatus,
      recipientCount: targetEmails.length,
      deliveredEmails: emailDelivered,
      failedEmails: emailFailed,
      emailError: emailFailed.length > 0 ? emailFailed[0].error : ''
    };

    try {
      await setDoc(doc(db, 'announcements', notifId), payload);
      if (!isFutureSchedule) {
        await setDoc(doc(db, 'notifications', notifId), payload);
        await logAdminAction(`Dispatched ${notifChannel} announcement: "${notifTitle}"`, 'Notification Management');
      } else {
        await logAdminAction(`Scheduled announcement for ${new Date(scheduleTime).toLocaleString()}: "${notifTitle}"`, 'Notification Management');
      }

      // Reset form fields
      setNotifTitle('');
      setNotifBody('');
      setScheduleTime('');
      setAttachmentUrl('');
      setIsPinned(false);
      setSelectedIndividualUser('');

      if (isFutureSchedule) {
        showToast(`Announcement successfully scheduled for ${new Date(scheduleTime).toLocaleString()} (${notifTimeZone})!`);
      } else if (emailStatus === 'failed') {
        showToast(`Announcement created, but email delivery encountered issues (${emailFailed.length} failed).`, 'error');
      } else {
        showToast(`Announcement dispatched successfully via ${notifChannel}!`);
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsDispatching(false);
    }
  };

  const handleCancelAnnouncement = async (id: string, title: string) => {
    if (!window.confirm(`Cancel scheduled announcement "${title}"?`)) return;
    try {
      await updateDoc(doc(db, 'announcements', id), { status: 'Cancelled' });
      await logAdminAction(`Cancelled scheduled announcement: "${title}"`, 'Notification Management');
      showToast('Scheduled announcement cancelled.');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleEditAnnouncement = (ann: any) => {
    setEditingAnnouncement({ ...ann });
  };

  const handleSaveEditAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnnouncement) return;
    try {
      const payload = {
        title: editingAnnouncement.title,
        content: editingAnnouncement.content,
        body: editingAnnouncement.content,
        category: editingAnnouncement.category,
        priority: editingAnnouncement.priority,
        targetAudience: editingAnnouncement.targetAudience,
        targetRole: editingAnnouncement.targetAudience,
        isPinned: Boolean(editingAnnouncement.isPinned),
        scheduleTime: editingAnnouncement.scheduleTime || '',
        attachmentUrl: editingAnnouncement.attachmentUrl || ''
      };
      await updateDoc(doc(db, 'announcements', editingAnnouncement.id), payload);
      await updateDoc(doc(db, 'notifications', editingAnnouncement.id), payload).catch(() => {});
      
      await logAdminAction(`Edited announcement: "${editingAnnouncement.title}"`, 'Notification Management');
      setEditingAnnouncement(null);
      showToast('Announcement updated successfully!');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDeleteAnnouncement = async (id: string, title: string) => {
    if (!window.confirm(`Permanently delete announcement "${title}"?`)) return;
    try {
      await deleteDoc(doc(db, 'announcements', id));
      await deleteDoc(doc(db, 'notifications', id)).catch(() => {});
      await logAdminAction(`Deleted announcement: "${title}"`, 'Notification Management');
      showToast('Announcement deleted successfully!');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleTogglePin = async (id: string, currentPin: boolean) => {
    try {
      await updateDoc(doc(db, 'announcements', id), { isPinned: !currentPin });
      showToast(!currentPin ? 'Announcement pinned to top!' : 'Announcement unpinned.');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleRetryFailedEmails = async (ann: any) => {
    if (!ann.failedEmails || ann.failedEmails.length === 0) return;
    const failedList: string[] = ann.failedEmails.map((f: any) => f.email);
    showToast(`Retrying email delivery for ${failedList.length} recipient(s)...`, 'success');

    try {
      const resp = await fetch('/api/admin/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipients: failedList,
          subject: ann.title,
          title: ann.title,
          content: ann.content || ann.body,
          category: ann.category
        })
      });
      const result = await resp.json();
      if (result.success) {
        const newlyDelivered = result.delivered || [];
        const stillFailed = result.failed || [];

        const updatedDelivered = Array.from(new Set([...(ann.deliveredEmails || []), ...newlyDelivered]));
        const updatedStatus = stillFailed.length === 0 ? 'sent' : 'failed';

        await updateDoc(doc(db, 'announcements', ann.id), {
          deliveredEmails: updatedDelivered,
          failedEmails: stillFailed,
          emailStatus: updatedStatus,
          emailError: stillFailed.length > 0 ? stillFailed[0].error : ''
        });

        if (stillFailed.length === 0) {
          showToast(`All failed emails retried and delivered successfully!`);
        } else {
          showToast(`Retry complete: ${newlyDelivered.length} delivered, ${stillFailed.length} still failing.`, 'error');
        }
      } else {
        showToast(`Email retry failed: ${result.error || 'Server error'}`, 'error');
      }
    } catch (err: any) {
      showToast(`Retry network error: ${err.message}`, 'error');
    }
  };

  // ----------------------------------------------------
  // Bulk Operations Dispatcher
  // ----------------------------------------------------
  const handleBulkDelete = async (colName: string) => {
    if (selectedItems.length === 0) return;
    if (!window.confirm(`Permanently delete all ${selectedItems.length} selected items?`)) return;
    try {
      for (const id of selectedItems) {
        await deleteDoc(doc(db, colName, id));
      }
      await logAdminAction(`Bulk deleted ${selectedItems.length} records from ${colName}`, 'Enterprise Portal');
      setSelectedItems([]);
      showToast(`Bulk delete complete!`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleBulkUpdateStatus = async (colName: string, statusVal: string) => {
    if (selectedItems.length === 0) return;
    try {
      for (const id of selectedItems) {
        await updateDoc(doc(db, colName, id), { status: statusVal });
      }
      await logAdminAction(`Bulk updated status to ${statusVal} for ${selectedItems.length} records in ${colName}`, 'Enterprise Portal');
      setSelectedItems([]);
      showToast(`Bulk status update complete!`);
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // ----------------------------------------------------
  // Render Dynamic Content based on activeTab
  // ----------------------------------------------------
  return (
    <div className="bg-white rounded-xl border border-[#c4c6cd]/40 shadow-sm p-6 space-y-8 relative overflow-hidden">
      
      {/* Toast Feedback */}
      {toast && (
        <div className={`fixed top-6 right-6 z-50 flex items-center gap-2.5 px-5 py-3 rounded-xl shadow-xl border text-sm font-bold transition-all duration-300 animate-slide-in ${
          toast.type === 'success' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          <CheckCircle2 className={`w-5 h-5 ${toast.type === 'success' ? 'text-emerald-600' : 'text-rose-600'}`} />
          {toast.message}
        </div>
      )}

      {/* VIEW INVOICE MODAL (Overlay) */}
      {viewingInvoiceOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-8 border border-slate-200 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button 
              onClick={() => setViewingInvoiceOrder(null)}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5 text-slate-500" />
            </button>

            <div className="space-y-6 printable-invoice">

              <div className="flex justify-between items-start border-b border-slate-100 pb-6">
                <div>
                  <h3 className="font-black text-slate-900 text-2xl">ORDER INVOICE</h3>
                  <p className="text-sm text-slate-500">#{viewingInvoiceOrder?.id?.slice(-8).toUpperCase()}</p>
                </div>
                <div className="text-right">
                   <p className="text-sm text-slate-500">Date</p>
                   <p className="font-bold text-slate-800">{new Date(viewingInvoiceOrder?.createdAt || Date.now()).toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="py-4">
                 <p className="text-xs text-slate-500 uppercase tracking-wider font-bold mb-2">Customer Details</p>
                 <p className="font-bold text-slate-800">{viewingInvoiceOrder?.customerName}</p>
                 <p className="text-slate-600">{viewingInvoiceOrder?.customerEmail}</p>
                 {viewingInvoiceOrder?.shippingAddress && (
                   <p className="text-slate-600 max-w-xs">{viewingInvoiceOrder.shippingAddress}</p>
                 )}
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500">
                    <tr>
                      <th className="p-3 font-bold">Item</th>
                      <th className="p-3 font-bold text-right">Price</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {viewingInvoiceOrder?.items?.map((item: any, i: number) => (
                      <tr key={i}>
                        <td className="p-3 text-slate-800 font-medium">{item.name} <span className="text-slate-400">x{item.quantity}</span></td>
                        <td className="p-3 text-right text-slate-800 font-bold">Rs. {(item.price * item.quantity).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end pt-4 border-t border-slate-100">
                <div className="text-right">
                  <p className="text-sm text-slate-500 mb-1">Total Amount</p>
                  <p className="text-3xl font-black text-[#fd8b00]">Rs. {Number(viewingInvoiceOrder?.totalAmount || 0).toLocaleString()}</p>
                </div>
              </div>
              
              <div className="flex justify-end gap-3 pt-6">
                <button 
                  onClick={() => window.print()}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
                >
                  Print / Save PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================
          TAB 1: PLATFORM MANAGEMENT
          ==================================================== */}
      {activeTab === 'platform' && (
        <PlatformConfigEditor 
          platformConfig={platformConfig}
          updatePlatformConfigAndSync={updatePlatformConfigAndSync}
          showToast={showToast}
        />
      )}

      {/* ====================================================
          TAB 2: HOMEPAGE CONTENT MANAGER
          ==================================================== */}
      {activeTab === 'homepage' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-black text-[#041627] tracking-tight">Homepage Layout Block Manager</h2>
            <p className="text-xs text-[#8192a7]">Reorder, restructure, or toggle live visibility on primary frontpage grid modules.</p>
          </div>

          <div className="border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Sort Order</th>
                  <th className="p-4">Homepage Section</th>
                  <th className="p-4">Functional Purpose</th>
                  <th className="p-4">Visibility Status</th>
                  <th className="p-4 text-center">Move / Order</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {homepageContent.sections.map((sec: any, index: number) => (
                  <tr key={sec.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-mono font-bold text-[#fd8b00]">#{sec.order}</td>
                    <td className="p-4 font-extrabold text-slate-900">{sec.title}</td>
                    <td className="p-4 text-slate-500 max-w-sm">{sec.description}</td>
                    <td className="p-4">
                      <button 
                        onClick={() => handleToggleSectionVisibility(sec.id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border transition-all ${
                          sec.visible 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                            : 'bg-slate-100 text-slate-500 border-slate-200'
                        }`}
                      >
                        {sec.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        {sec.visible ? 'Live visible' : 'Hidden section'}
                      </button>
                    </td>
                    <td className="p-4 text-center">
                      <div className="inline-flex gap-1.5">
                        <button 
                          disabled={index === 0}
                          onClick={() => handleOrderSection(index, 'up')}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded disabled:opacity-40"
                        >
                          ▲
                        </button>
                        <button 
                          disabled={index === homepageContent.sections.length - 1}
                          onClick={() => handleOrderSection(index, 'down')}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded disabled:opacity-40"
                        >
                          ▼
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 3: CATEGORY MANAGEMENT
          ==================================================== */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight">Product Category Directory</h2>
              <p className="text-xs text-[#8192a7]">Structure global material categories, assign custom icons, and change platform sort weights.</p>
            </div>
            <button 
              onClick={() => exportToCSV(categories, 'B2B_Categories')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Export CSV
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Create / Edit Form */}
            <form onSubmit={handleCreateCategory} className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 text-xs space-y-4 h-fit">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {editingCategory ? 'Modify Category' : 'Create New B2B Category'}
              </h3>

              <div>
                <label className="block font-semibold text-[#041627] mb-1">Display Name</label>
                <input 
                  type="text" 
                  value={editingCategory ? editingCategory.name : newCatName}
                  onChange={e => editingCategory 
                    ? setEditingCategory({ ...editingCategory, name: e.target.value }) 
                    : setNewCatName(e.target.value)
                  }
                  placeholder="e.g. Structural Timber"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-[#041627] mb-1">Category Code / URL Slug</label>
                <input 
                  type="text" 
                  value={editingCategory ? editingCategory.code : newCatCode}
                  onChange={e => editingCategory 
                    ? setEditingCategory({ ...editingCategory, code: e.target.value }) 
                    : setNewCatCode(e.target.value)
                  }
                  placeholder="e.g. structural-timber"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-[#041627] mb-1">Lucide Symbol Icon</label>
                <select 
                  value={editingCategory ? editingCategory.icon : newCatIcon}
                  onChange={e => editingCategory 
                    ? setEditingCategory({ ...editingCategory, icon: e.target.value }) 
                    : setNewCatIcon(e.target.value)
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                >
                  <option value="Layers">Layers</option>
                  <option value="ShoppingBag">ShoppingBag</option>
                  <option value="Globe">Globe</option>
                  <option value="Star">Star</option>
                  <option value="Award">Award</option>
                </select>
              </div>

              {editingCategory ? (
                <div className="flex gap-2">
                  <button 
                    type="button" 
                    onClick={() => handleUpdateCategory(editingCategory)}
                    className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl"
                  >
                    Save Changes
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setEditingCategory(null)}
                    className="flex-1 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button 
                  type="submit" 
                  className="w-full py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold rounded-xl"
                >
                  Create Category
                </button>
              )}
            </form>

            {/* List Table */}
            <div className="lg:col-span-2 border border-slate-100 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-400 font-bold">
                  <tr>
                    <th className="p-3">Weight</th>
                    <th className="p-3">Name</th>
                    <th className="p-3">Slug</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                  {categories.map((cat: any) => (
                    <tr key={cat.id} className="hover:bg-slate-50/50">
                      <td className="p-3 text-[#fd8b00] font-bold font-mono">#{cat.sortOrder}</td>
                      <td className="p-3 font-bold text-slate-900 flex items-center gap-1.5">
                        <span className="p-1 bg-[#f8f9ff] text-[#fd8b00] rounded">
                          <Layers className="w-3.5 h-3.5" />
                        </span>
                        {cat.name}
                      </td>
                      <td className="p-3 font-mono text-slate-500">{cat.code}</td>
                      <td className="p-3">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          cat.enabled ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                        }`}>
                          {cat.enabled ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td className="p-3 text-right space-x-1.5">
                        <button 
                          onClick={() => setEditingCategory(cat)}
                          className="p-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-600"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => handleDeleteCategory(cat.id, cat.name)}
                          className="p-1 bg-rose-50 hover:bg-rose-100 rounded text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {categories.length === 0 && (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-400">No categories created yet. Use the sidebar form to register categories.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 4: PRODUCT MANAGEMENT
          ==================================================== */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight">B2B Material Supplier Inventory</h2>
              <p className="text-xs text-[#8192a7]">Moderate active product listings, inspect stock levels, authorize price modifications, and feature premium materials.</p>
            </div>
            
            <div className="flex items-center gap-2">
              <button 
                onClick={() => exportToCSV(products, 'Marketplace_Products')}
                className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Export CSV
              </button>
              {selectedItems.length > 0 && (
                <div className="inline-flex gap-1.5">
                  <button 
                    onClick={() => handleBulkUpdateStatus('products', 'Approved')}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl"
                  >
                    Bulk Approve
                  </button>
                  <button 
                    onClick={() => handleBulkDelete('products')}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl"
                  >
                    Bulk Delete
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Search, Filter, & Sort Bar */}
          <div className="flex flex-wrap items-center gap-3.5 bg-slate-50/50 p-4 rounded-2xl border border-slate-100 text-xs">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search products by name, category, or manufacturer..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 bg-white"
              />
            </div>

            <select 
              value={filterOption} 
              onChange={e => setFilterOption(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 font-medium"
            >
              <option value="All">All Statuses</option>
              <option value="Approved">Approved Only</option>
              <option value="Pending">Pending Validation</option>
              <option value="Rejected">Rejected</option>
              <option value="Hidden">Hidden</option>
            </select>

            <select 
              value={sortOption} 
              onChange={e => setSortOption(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 font-medium"
            >
              <option value="Newest">Newest Listed</option>
              <option value="PriceHigh">Price: High to Low</option>
              <option value="PriceLow">Price: Low to High</option>
              <option value="StockLow">Stock: Low Alerts</option>
            </select>
          </div>

          {/* Product Data List Grid */}
          <div className="border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold border-b border-slate-100">
                <tr>
                  <th className="p-4 w-12 text-center">
                    <input 
                      type="checkbox" 
                      onChange={() => handleSelectAll(products.map(p => p.id))}
                      checked={selectedItems.length === products.length && products.length > 0}
                    />
                  </th>
                  <th className="p-4">Material / Product Details</th>
                  <th className="p-4">B2B Category</th>
                  <th className="p-4">B2B Trade Price</th>
                  <th className="p-4">Current Stock</th>
                  <th className="p-4">Approval Status</th>
                  <th className="p-4 text-right">Moderator Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {products
                  .filter(p => {
                    const matchesSearch = p.name?.toLowerCase().includes(searchTerm.toLowerCase()) || p.category?.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesFilter = filterOption === 'All' || p.status === filterOption;
                    return matchesSearch && matchesFilter;
                  })
                  .map((product: any) => (
                    <tr key={product.id} className="hover:bg-slate-50/50">
                      <td className="p-4 text-center">
                        <input 
                          type="checkbox" 
                          checked={selectedItems.includes(product.id)}
                          onChange={() => handleSelectRow(product.id)}
                        />
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <img src={product.image || "https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?w=150"} alt={product.name} className="w-10 h-10 object-cover rounded-lg border shrink-0" />
                          <div className="min-w-0">
                            <p className="font-extrabold text-slate-900 truncate">{product.name}</p>
                            <p className="text-[10px] text-slate-400">Seller: {product.seller?.fullName || product.sellerEmail || 'Vendor Pool'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 font-semibold text-slate-500 capitalize">{product.category}</td>
                      <td className="p-4">
                        <input 
                          type="number" 
                          value={product.price}
                          onChange={e => handleUpdateProductStockPrice(product.id, parseFloat(e.target.value) || 0, product.stock || 0)}
                          className="w-20 px-2 py-1 rounded border text-slate-800 font-bold"
                        />
                      </td>
                      <td className="p-4">
                        <input 
                          type="number" 
                          value={product.stock || 0}
                          onChange={e => handleUpdateProductStockPrice(product.id, product.price, parseInt(e.target.value) || 0)}
                          className="w-16 px-2 py-1 rounded border text-slate-800 font-mono"
                        />
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border ${
                          product.status === 'Approved' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                          product.status === 'Pending' ? 'bg-amber-50 text-amber-800 border-amber-200 animate-pulse' :
                          'bg-rose-50 text-rose-800 border-rose-200'
                        }`}>
                          {product.status || 'Pending'}
                        </span>
                      </td>
                      <td className="p-4 text-right space-x-1.5">
                        <button 
                          onClick={() => handleUpdateProductStatus(product.id, product.status === 'Approved' ? 'Hidden' : 'Approved')}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-600"
                          title={product.status === 'Approved' ? 'Deactivate Listing' : 'Approve & Publish'}
                        >
                          {product.status === 'Approved' ? <EyeOff className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5 text-emerald-600" />}
                        </button>
                        <button 
                          onClick={() => handleToggleProductFeature(product.id, !product.featured)}
                          className={`p-1.5 rounded border transition-colors ${
                            product.featured ? 'bg-amber-50 text-amber-600 border-amber-200' : 'bg-slate-100 text-slate-400 border-transparent'
                          }`}
                          title="Feature Product"
                        >
                          <Star className="w-3.5 h-3.5 fill-current" />
                        </button>
                        <button 
                          onClick={() => handleDeleteProduct(product.id, product.name)}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 rounded text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                {products.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">No product inventory found in database.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 5: ORDER MANAGEMENT
          ==================================================== */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight">Customer Sales Orders</h2>
              <p className="text-xs text-[#8192a7]">Verify customer purchases, package deliveries, generate official enterprise tax invoice, and download CSV audit trails.</p>
            </div>

            <button 
              onClick={() => exportToCSV(orders, 'Customer_Orders')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Export Orders
            </button>
          </div>

          {/* Order sub-tabs */}
          <div className="flex gap-4 border-b border-slate-200 pb-3 mb-5">
            <button 
              onClick={() => setOrderFilterTab('active')}
              className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                orderFilterTab === 'active' 
                  ? 'text-[#fd8b00]' 
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              Active Orders ({orders.filter(o => ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(o.status)).length})
              {orderFilterTab === 'active' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#fd8b00] rounded" />
              )}
            </button>
            <button 
              onClick={() => setOrderFilterTab('delivered')}
              className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                orderFilterTab === 'delivered' 
                  ? 'text-green-600' 
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              Delivered Orders ({orders.filter(o => o.status === 'Delivered').length})
              {orderFilterTab === 'delivered' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-600 rounded" />
              )}
            </button>
            <button 
              onClick={() => setOrderFilterTab('cancelled')}
              className={`pb-2 px-4 text-xs font-extrabold transition-all relative cursor-pointer ${
                orderFilterTab === 'cancelled' 
                  ? 'text-red-600' 
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              Cancelled Orders ({orders.filter(o => o.status === 'Cancelled').length})
              {orderFilterTab === 'cancelled' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600 rounded" />
              )}
            </button>
          </div>

          {/* Order table */}
          <div className="border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Order ID</th>
                  <th className="p-4">Customer Name</th>
                  <th className="p-4">{orderFilterTab === 'cancelled' ? 'Cancellation Date & Time' : 'Date Authorized'}</th>
                  <th className="p-4">Total Amount</th>
                  <th className="p-4">{orderFilterTab === 'cancelled' ? 'Cancellation Details' : 'Fulfillment Status'}</th>
                  <th className="p-4 text-right">Fulfillment / Invoice Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {orders
                  .filter((order: any) => {
                    if (orderFilterTab === 'active') {
                      return ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(order.status);
                    } else if (orderFilterTab === 'delivered') {
                      return order.status === 'Delivered';
                    } else {
                      return order.status === 'Cancelled';
                    }
                  })
                  .map((order: any) => (
                    <tr key={order.id} className="hover:bg-slate-50/50">
                      <td className="p-4 font-mono font-bold text-slate-900">{order.id}</td>
                      <td className="p-4 font-extrabold text-slate-800">{order.customer || 'Guest Client'}</td>
                      <td className="p-4 text-slate-500">
                        {orderFilterTab === 'cancelled' 
                          ? (order.cancelledAt ? new Date(order.cancelledAt).toLocaleString() : order.date) 
                          : (order.date || 'Authorized')}
                      </td>
                      <td className="p-4 font-bold text-slate-900">Rs. {order.amount}</td>
                      <td className="p-4">
                        {order.status === 'Cancelled' ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-red-100 text-red-800 border border-red-200 text-[10px] font-bold">
                              ❌ Cancelled
                            </span>
                            {order.cancellationReason && (
                              <p className="text-[10px] text-red-600 font-semibold">Reason: {order.cancellationReason}</p>
                            )}
                            {order.cancelledBy && (
                              <p className="text-[9px] text-slate-400 font-semibold">By: {order.cancelledBy}</p>
                            )}
                          </div>
                        ) : (
                          <select 
                            value={order.status}
                            disabled={order.status === 'Cancelled'}
                            onChange={e => handleUpdateOrderStatus(order.id, e.target.value)}
                            className={`px-3 py-1 rounded-full font-bold border text-[10px] ${
                              order.status === 'Delivered' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                              'bg-amber-50 text-amber-800 border-amber-200'
                            }`}
                          >
                            <option value="Pending">Pending</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Packed">Packed</option>
                            <option value="Shipping">Shipping</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Refunded">Refunded</option>
                          </select>
                        )}
                      </td>
                      <td className="p-4 text-right space-x-1.5">
                        <button 
                          onClick={() => setViewingInvoiceOrder(order)}
                          className="px-3 py-1.5 bg-slate-900 text-white hover:bg-slate-800 rounded-lg text-[10px] font-extrabold uppercase tracking-wider flex inline-flex items-center gap-1"
                        >
                          <FileText className="w-3.5 h-3.5" /> Invoice
                        </button>
                        {order.status === 'Cancelled' && (
                          <button 
                            onClick={() => handleRestoreOrder(order.id)}
                            className="px-3 py-1.5 bg-[#fd8b00]/15 text-[#fd8b00] hover:bg-[#fd8b00] hover:text-white border border-[#fd8b00]/30 rounded-lg text-[10px] font-extrabold transition-colors cursor-pointer inline-flex items-center gap-1"
                            title="Restore this cancelled order back to active status"
                          >
                            🔄 Restore
                          </button>
                        )}
                        <button 
                          onClick={() => handleDeleteOrder(order.id)}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 rounded text-rose-600 inline-flex align-middle"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                {orders.filter((order: any) => {
                  if (orderFilterTab === 'active') {
                    return ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipping', 'Shipped', 'Out for Delivery'].includes(order.status);
                  } else if (orderFilterTab === 'delivered') {
                    return order.status === 'Delivered';
                  } else {
                    return order.status === 'Cancelled';
                  }
                }).length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">No {orderFilterTab} orders recorded.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 6: PAYMENT MANAGEMENT
          ==================================================== */}
      {activeTab === 'payments' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-black text-[#041627] tracking-tight">Payment Ledger & Trade Revenue</h2>
            <p className="text-xs text-[#8192a7]">Verify direct B2B transaction receipts, refunds, payment settlements, and audit reports.</p>
          </div>

          {/* Revenue metrics row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-50 border p-5 rounded-2xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Gross Trade volume</span>
              <p className="text-2xl font-black text-slate-900 mt-1">Rs. {orders.reduce((acc, curr) => acc + (parseFloat(curr.amount) || 0), 0).toFixed(2)}</p>
            </div>
            <div className="bg-slate-50 border p-5 rounded-2xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Transactions Completed</span>
              <p className="text-2xl font-black text-slate-900 mt-1">{orders.filter(o => o.status === 'Delivered').length}</p>
            </div>
            <div className="bg-slate-50 border p-5 rounded-2xl">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Processing pipeline</span>
              <p className="text-2xl font-black text-slate-900 mt-1">{orders.filter(o => o.status !== 'Delivered' && o.status !== 'Cancelled').length}</p>
            </div>
            <div className="bg-[#fd8b00]/5 border border-[#fd8b00]/20 p-5 rounded-2xl">
              <span className="text-[10px] uppercase font-bold text-[#fd8b00] tracking-wider">Net Platform Earnings</span>
              <p className="text-2xl font-black text-slate-900 mt-1">Rs. {(orders.reduce((acc, curr) => acc + (parseFloat(curr.amount) || 0), 0) * 0.05).toFixed(2)}</p>
            </div>
          </div>

          <div className="border border-slate-100 rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Reference ID</th>
                  <th className="p-4">Customer Account</th>
                  <th className="p-4">Transaction Date</th>
                  <th className="p-4">Trade Value</th>
                  <th className="p-4">Payment Method</th>
                  <th className="p-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {orders.map((order: any) => (
                  <tr key={order.id} className="hover:bg-slate-50/50">
                    <td className="p-4 font-mono font-bold text-slate-500">#{order.id?.substring(0, 8)}...</td>
                    <td className="p-4 font-extrabold text-slate-900">{order.customer || 'Platform client'}</td>
                    <td className="p-4 text-slate-400">{order.date || 'Authorized'}</td>
                    <td className="p-4 font-black text-slate-950">Rs. {order.amount}</td>
                    <td className="p-4">Online Gateway Card</td>
                    <td className="p-4">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        order.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                        order.status === 'Delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {order.status === 'Cancelled' ? 'Refunded' : order.status === 'Delivered' ? 'Settled' : 'Captured'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 7: REVIEW MODERATION
          ==================================================== */}
      {activeTab === 'reviews' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight">Public Reviews Moderation</h2>
              <p className="text-xs text-[#8192a7]">Moderate contractor, design, and supplier ratings. Delete spam, hide sensitive feedback, and inspect flagged reports.</p>
            </div>
            
            <button 
              onClick={() => exportToCSV(reviews, 'Public_Reviews')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Export Reviews
            </button>
          </div>

          <div className="border border-slate-100 rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Product / Expert</th>
                  <th className="p-4">Reviewer</th>
                  <th className="p-4">Rating</th>
                  <th className="p-4">Feedback Message</th>
                  <th className="p-4">Moderation Flag</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {reviews.map((rev: any) => (
                  <tr key={rev.id} className="hover:bg-slate-50/50">
                    <td className="p-4 font-bold text-slate-900">{rev.productName || 'B2B Client Review'}</td>
                    <td className="p-4">
                      <p className="font-bold">{rev.reviewerName}</p>
                      <p className="text-[10px] text-slate-400">{rev.reviewerEmail}</p>
                    </td>
                    <td className="p-4 text-amber-500 font-bold flex items-center gap-0.5">
                      <Star className="w-3.5 h-3.5 fill-current" /> {rev.rating || 5}
                    </td>
                    <td className="p-4 text-slate-500 max-w-sm italic">"{rev.comment}"</td>
                    <td className="p-4">
                      {rev.reported ? (
                        <span className="bg-red-100 text-red-800 text-[9px] font-bold px-2 py-0.5 rounded border border-red-300 flex items-center gap-1 w-fit">
                          <AlertCircle className="w-3 h-3 text-red-600" /> Flagged Spam
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px]">Normal</span>
                      )}
                    </td>
                    <td className="p-4 text-right space-x-1.5">
                      <button 
                        onClick={() => handleToggleReviewHide(rev.id, rev.hidden)}
                        className={`px-2.5 py-1 rounded text-[10px] font-bold border transition-colors ${
                          rev.hidden ? 'bg-amber-100 text-amber-800 border-amber-300' : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        {rev.hidden ? 'Show Review' : 'Hide Review'}
                      </button>
                      <button 
                        onClick={() => handleDeleteReview(rev.id)}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 rounded text-rose-600 inline-flex align-middle"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {reviews.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">No public reviews written yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 8: MESSAGE MANAGEMENT
          ==================================================== */}
      {activeTab === 'messages' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-black text-[#041627] tracking-tight">Direct Conversation Audits</h2>
            <p className="text-xs text-[#8192a7]">Verify network communication safety, resolve platform chat disputes, delete messages, or suspend accounts.</p>
          </div>

          <div className="border border-slate-100 rounded-2xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Sender ID / Name</th>
                  <th className="p-4">Recipient Name</th>
                  <th className="p-4">Message Body Log</th>
                  <th className="p-4">Timestamp</th>
                  <th className="p-4 text-right">Auditor Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {messages.map((msg: any) => (
                  <tr key={msg.id} className="hover:bg-slate-50/50">
                    <td className="p-4">
                      <p className="font-extrabold text-slate-900">{msg.senderName || 'Anonymous User'}</p>
                      <p className="font-mono text-[9px] text-slate-400">ID: {msg.senderId}</p>
                    </td>
                    <td className="p-4 font-bold text-slate-700">{msg.recipientName || 'Workspace Expert'}</td>
                    <td className="p-4 text-slate-500 italic max-w-sm">"{msg.body}"</td>
                    <td className="p-4 text-slate-400 font-mono">{msg.timestamp || 'Just now'}</td>
                    <td className="p-4 text-right space-x-1.5">
                      <button 
                        onClick={() => handleBlockUser(msg.senderEmail || msg.senderId)}
                        className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-bold rounded border border-rose-200"
                        title="Suspend Sender Account"
                      >
                        Suspend User
                      </button>
                      <button 
                        onClick={() => handleDeleteMessage(msg.id)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-600 inline-flex align-middle"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {messages.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400">No communication logs recorded in database.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 9: ANNOUNCEMENT & NOTIFICATION MANAGEMENT
          ==================================================== */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-[#fd8b00]" />
                Announcement & Notification Management
              </h2>
              <p className="text-xs text-[#8192a7] mt-0.5">
                Create and schedule broadcast announcements, dispatch real-time portal banners, and manage targeted email notifications across all user roles.
              </p>
            </div>
          </div>

          {/* Key Metrics Overview Bar */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                <Megaphone className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Notices</p>
                <p className="text-xl font-black text-slate-900">{announcements.length}</p>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Reads</p>
                <p className="text-xl font-black text-slate-900">{announcementReads.length}</p>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">User Accounts</p>
                <p className="text-xl font-black text-slate-900">{allAccounts.length}</p>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Email Delivery Failures</p>
                <p className="text-xl font-black text-slate-900">
                  {announcements.reduce((acc, curr) => acc + (curr.failedEmails?.length || 0), 0)}
                </p>
              </div>
            </div>
          </div>

          {/* Full Width Top Section: Create New Announcement */}
          <form onSubmit={handleSendNotification} className="w-full bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm text-xs space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Send className="w-4 h-4 text-[#fd8b00]" />
                Create New Announcement
              </h3>
              <span className="text-[10px] text-slate-400 font-semibold bg-slate-50 px-2.5 py-1 rounded-md border border-slate-100">Firebase Live Sync</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="lg:col-span-2">
                <label className="block font-bold mb-1 text-slate-700">Announcement Title <span className="text-red-500">*</span></label>
                <input 
                  type="text" 
                  value={notifTitle}
                  onChange={e => setNotifTitle(e.target.value)}
                  placeholder="e.g. Scheduled System Maintenance Notice"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:col-span-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-slate-700">Category</label>
                  <select 
                    value={notifCategory}
                    onChange={e => setNotifCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                  >
                    <option value="General">General</option>
                    <option value="System Update">System Update</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Promotion">Promotion</option>
                    <option value="Urgent Notice">Urgent Notice</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700">Priority Level</label>
                  <select 
                    value={notifPriority}
                    onChange={e => setNotifPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                  >
                    <option value="Normal">Normal</option>
                    <option value="Important">Important</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700">Target Distribution Group</label>
                  <select 
                    value={notifRole}
                    onChange={e => setNotifRole(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                  >
                    <option value="All">All Users (Broadcast)</option>
                    <option value="homeowner">Clients / Homeowners Only</option>
                    <option value="professional">Experts / Professionals Only</option>
                    <option value="shopkeeper">Shopkeepers Only</option>
                    <option value="individual">Selected Individual User</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700">Delivery Channel</label>
                  <select 
                    value={notifChannel}
                    onChange={e => setNotifChannel(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                  >
                    <option value="Announcement">Announcement (Dashboard Banner Only)</option>
                    <option value="Email">Email Notification Only</option>
                    <option value="Both">Both (Dashboard Banner & Email Notification)</option>
                  </select>
                </div>
              </div>

              {/* Individual user selection dropdown */}
              {notifRole === 'individual' && (
                <div className="lg:col-span-2">
                  <label className="block font-bold mb-1 text-slate-700">Select Specific User</label>
                  <select 
                    value={selectedIndividualUser}
                    onChange={e => setSelectedIndividualUser(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                    required
                  >
                    <option value="">-- Choose User --</option>
                    {allAccounts.filter(acc => acc.accountType !== 'Admin' && acc.role !== 'admin' && acc.email !== 'theteamcode07@gmail.com').map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.fullName || acc.email} ({acc.accountType || 'User'}) - {acc.email}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="lg:col-span-2">
                <label className="block font-bold mb-1 text-slate-700">Announcement Content / Message Body <span className="text-red-500">*</span></label>
                <textarea 
                  rows={3}
                  value={notifBody}
                  onChange={e => setNotifBody(e.target.value)}
                  placeholder="Type full announcement details or email body..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30"
                  required
                />
              </div>

              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                <div>
                  <label className="block font-bold mb-1 text-slate-700">Schedule Date & Time (Optional)</label>
                  <input 
                    type="datetime-local"
                    value={scheduleTime}
                    onChange={e => setScheduleTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-800 font-medium text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-slate-700">Time Zone</label>
                  <select 
                    value={notifTimeZone}
                    onChange={e => setNotifTimeZone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800 text-xs"
                  >
                    <option value="Local (NPT)">Local Time (NPT)</option>
                    <option value="UTC">UTC (Coordinated Universal Time)</option>
                    <option value="EST">EST (Eastern Standard Time)</option>
                    <option value="PST">PST (Pacific Standard Time)</option>
                    <option value="GMT">GMT (Greenwich Mean Time)</option>
                  </select>
                </div>
              </div>

              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                <div>
                  <label className="block font-bold mb-1 text-slate-700">Attachment Upload / Link (Optional)</label>
                  <input 
                    type="url"
                    value={attachmentUrl}
                    onChange={e => setAttachmentUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-800 font-medium text-xs"
                  />
                </div>

                <div className="flex items-center gap-2 pt-5">
                  <input 
                    type="checkbox"
                    id="pinCheckbox"
                    checked={isPinned}
                    onChange={e => setIsPinned(e.target.checked)}
                    className="w-4 h-4 text-[#fd8b00] rounded focus:ring-[#fd8b00]"
                  />
                  <label htmlFor="pinCheckbox" className="font-bold text-slate-700 cursor-pointer flex items-center gap-1.5 text-xs">
                    <Pin className="w-3.5 h-3.5 text-[#fd8b00]" /> Pin Announcement to top
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button 
                type="submit" 
                disabled={isDispatching}
                className="w-full sm:w-auto px-8 py-3 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold rounded-xl shadow-md uppercase tracking-wider text-xs transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isDispatching ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Dispatching Announcement...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" /> Send Announcement
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Full Width Bottom Section: Announcement List & Delivery Logs */}
          <div className="w-full bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden flex flex-col">
            
            {/* Table Header & Search/Filters */}
            <div className="p-6 bg-slate-50/70 border-b border-slate-100 flex flex-col gap-5">
              {/* Heading & Subtitle */}
              <div>
                <h3 className="text-base font-black text-slate-800 flex items-center gap-2">
                  <Megaphone className="w-5 h-5 text-[#fd8b00]" />
                  Announcement List & Delivery Logs
                </h3>
                <p className="text-xs text-slate-500 mt-1 font-medium">
                  View sent status, reader counts, email logs, and manage pinned items.
                </p>
              </div>

              {/* Controls Row: Search Bar (~48% width) + Filters */}
              <div className="flex flex-col md:flex-row gap-3 items-center justify-between w-full">
                {/* Search Bar */}
                <div className="relative w-full md:w-[48%] flex-shrink-0">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text"
                    value={adminSearchQuery}
                    onChange={e => setAdminSearchQuery(e.target.value)}
                    placeholder="Search by title or body..."
                    className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm transition-all"
                  />
                </div>

                {/* Filters Group */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full md:w-auto md:flex-1 items-center">
                  <select 
                    value={adminCategoryFilter}
                    onChange={e => setAdminCategoryFilter(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm cursor-pointer transition-all"
                  >
                    <option value="All">All Categories</option>
                    <option value="General">General</option>
                    <option value="System Update">System Update</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Promotion">Promotion</option>
                    <option value="Urgent Notice">Urgent Notice</option>
                  </select>

                  <select 
                    value={adminRoleFilter}
                    onChange={e => setAdminRoleFilter(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm cursor-pointer transition-all"
                  >
                    <option value="All">All Audiences</option>
                    <option value="homeowner">Homeowners</option>
                    <option value="professional">Experts</option>
                    <option value="shopkeeper">Shopkeepers</option>
                    <option value="individual">Individual</option>
                  </select>

                  <select 
                    value={adminPriorityFilter}
                    onChange={e => setAdminPriorityFilter(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/30 shadow-sm cursor-pointer transition-all"
                  >
                    <option value="All">All Priorities</option>
                    <option value="Normal">Normal</option>
                    <option value="Important">Important</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>
            </div>

              {/* Table Body */}
              <div className="overflow-x-auto flex-1">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-400 font-bold border-b border-slate-100">
                    <tr>
                      <th className="p-3">Channel / Priority</th>
                      <th className="p-3">Target Audience</th>
                      <th className="p-3">Title & Content</th>
                      <th className="p-3">Delivery & Reads</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                    {announcements
                      .filter(ann => {
                        if (adminSearchQuery.trim()) {
                          const q = adminSearchQuery.toLowerCase();
                          const m1 = ann.title?.toLowerCase().includes(q);
                          const m2 = ann.content?.toLowerCase().includes(q) || ann.body?.toLowerCase().includes(q);
                          if (!m1 && !m2) return false;
                        }
                        if (adminRoleFilter !== 'All' && ann.targetAudience !== adminRoleFilter && ann.targetRole !== adminRoleFilter) return false;
                        if (adminPriorityFilter !== 'All' && ann.priority !== adminPriorityFilter) return false;
                        return true;
                      })
                      .map((ann: any) => {
                        const readsCount = announcementReads.filter(r => r.announcementId === ann.id).length;
                        const hasFailed = ann.failedEmails && ann.failedEmails.length > 0;

                        return (
                          <tr key={ann.id} className="hover:bg-slate-50/50">
                            <td className="p-3 space-y-1">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-extrabold uppercase tracking-wider ${
                                ann.deliveryChannel === 'Email' ? 'bg-slate-900 text-white' :
                                ann.deliveryChannel === 'Both' ? 'bg-purple-100 text-purple-800' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {ann.deliveryChannel || ann.type || 'Announcement'}
                              </span>

                              <div>
                                {ann.priority === 'Urgent' ? (
                                  <span className="text-[9px] font-black text-red-600 bg-red-50 px-1.5 py-0.5 rounded border border-red-200">Urgent</span>
                                ) : ann.priority === 'Important' ? (
                                  <span className="text-[9px] font-black text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">Important</span>
                                ) : (
                                  <span className="text-[9px] font-bold text-slate-500">Normal</span>
                                )}
                              </div>
                            </td>

                            <td className="p-3 capitalize font-semibold text-slate-600">
                              {ann.targetAudience || ann.targetRole || 'All'}
                              {ann.targetUserEmail && (
                                <p className="text-[9px] font-mono text-slate-400 truncate max-w-[120px]">{ann.targetUserEmail}</p>
                              )}
                            </td>

                            <td className="p-3">
                              <div className="flex items-center gap-1.5">
                                {ann.isPinned && <Pin className="w-3 h-3 text-[#fd8b00] fill-[#fd8b00] shrink-0" />}
                                <p className="font-extrabold text-slate-900">{ann.title}</p>
                              </div>
                              <p className="text-[10px] text-slate-400 mt-0.5 max-w-xs truncate">{ann.content || ann.body}</p>
                              <span className="text-[9px] text-slate-400 font-mono block mt-0.5">
                                {ann.createdAt ? new Date(ann.createdAt).toLocaleString() : ann.timestamp}
                              </span>
                            </td>

                            <td className="p-3 space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                                  {readsCount} Reads
                                </span>
                                {ann.recipientCount > 0 && (
                                  <span className="text-[10px] text-slate-500">
                                    / {ann.recipientCount} Recipients
                                  </span>
                                )}
                              </div>

                              {ann.deliveryChannel !== 'Announcement' && (
                                <div className="text-[10px]">
                                  {hasFailed ? (
                                    <span className="text-red-600 font-bold flex items-center gap-1">
                                      <XCircle className="w-3 h-3 text-red-500" />
                                      {ann.failedEmails.length} Email Failed
                                    </span>
                                  ) : ann.emailStatus === 'sent' ? (
                                    <span className="text-emerald-600 font-bold flex items-center gap-1">
                                      <CheckCircle className="w-3 h-3 text-emerald-500" />
                                      Email Sent
                                    </span>
                                  ) : null}
                                </div>
                              )}
                            </td>

                            <td className="p-3 text-right space-x-1.5 whitespace-nowrap">
                              {hasFailed && (
                                <button 
                                  onClick={() => handleRetryFailedEmails(ann)}
                                  className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 text-[10px] font-bold rounded border border-amber-200 inline-flex items-center gap-1"
                                  title="Retry failed email dispatches"
                                >
                                  <Repeat className="w-3 h-3" /> Retry Email
                                </button>
                              )}

                              <button 
                                onClick={() => handleTogglePin(ann.id, Boolean(ann.isPinned))}
                                className={`p-1.5 rounded transition-colors ${ann.isPinned ? 'bg-orange-100 text-orange-800' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                                title={ann.isPinned ? "Unpin Announcement" : "Pin Announcement"}
                              >
                                <Pin className="w-3.5 h-3.5" />
                              </button>

                              <button 
                                onClick={() => handleEditAnnouncement(ann)}
                                className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 inline-flex align-middle"
                                title="Edit Announcement"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>

                              <button 
                                onClick={() => handleDeleteAnnouncement(ann.id, ann.title)}
                                className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded inline-flex align-middle border border-rose-200"
                                title="Delete Announcement"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}

                    {announcements.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400">
                          No announcements created yet. Use the form above to create your first broadcast announcement.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      {/* Edit Announcement Modal */}
      {editingAnnouncement && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleSaveEditAnnouncement} className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl p-6 space-y-4 text-xs">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                <Pencil className="w-4 h-4 text-[#fd8b00]" /> Edit Announcement
              </h3>
              <button 
                type="button"
                onClick={() => setEditingAnnouncement(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="block font-bold mb-1 text-slate-700">Title</label>
              <input 
                type="text"
                value={editingAnnouncement.title || ''}
                onChange={e => setEditingAnnouncement({ ...editingAnnouncement, title: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 font-medium text-slate-800"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold mb-1 text-slate-700">Category</label>
                <select 
                  value={editingAnnouncement.category || 'General'}
                  onChange={e => setEditingAnnouncement({ ...editingAnnouncement, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                >
                  <option value="General">General</option>
                  <option value="System Update">System Update</option>
                  <option value="Maintenance">Maintenance</option>
                  <option value="Promotion">Promotion</option>
                  <option value="Urgent Notice">Urgent Notice</option>
                </select>
              </div>

              <div>
                <label className="block font-bold mb-1 text-slate-700">Priority</label>
                <select 
                  value={editingAnnouncement.priority || 'Normal'}
                  onChange={e => setEditingAnnouncement({ ...editingAnnouncement, priority: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium text-slate-800"
                >
                  <option value="Normal">Normal</option>
                  <option value="Important">Important</option>
                  <option value="Urgent">Urgent</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold mb-1 text-slate-700">Content / Message Body</label>
              <textarea 
                rows={4}
                value={editingAnnouncement.content || editingAnnouncement.body || ''}
                onChange={e => setEditingAnnouncement({ ...editingAnnouncement, content: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/50 font-medium text-slate-800"
                required
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input 
                type="checkbox"
                id="editPinCheckbox"
                checked={Boolean(editingAnnouncement.isPinned)}
                onChange={e => setEditingAnnouncement({ ...editingAnnouncement, isPinned: e.target.checked })}
                className="w-4 h-4 text-[#fd8b00] rounded focus:ring-[#fd8b00]"
              />
              <label htmlFor="editPinCheckbox" className="font-bold text-slate-700 cursor-pointer">
                Pinned Notice
              </label>
            </div>

            <div className="pt-3 flex justify-end gap-2.5 border-t border-slate-100">
              <button 
                type="button"
                onClick={() => setEditingAnnouncement(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-colors"
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="px-5 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white font-bold rounded-xl shadow-md transition-colors"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}


      {/* ====================================================
          TAB 10: ENTERPRISE ANALYTICS & REPORTS
          ==================================================== */}
      {activeTab === 'reports' && (
        <div className="space-y-8">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight">Enterprise Analytic Reporting</h2>
              <p className="text-xs text-[#8192a7]">Verify marketplace sales velocity, customer acquisition rates, and download spreadsheets.</p>
            </div>
            
            <button 
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all uppercase tracking-wider"
            >
              <FileText className="w-4 h-4 text-[#fd8b00]" /> Print PDF Report
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
            
            {/* Sales Summary */}
            <div className="border border-slate-100 p-5 rounded-2xl bg-slate-50/50 space-y-4">
              <h3 className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-[#fd8b00]" /> Sales & Category Distribution
              </h3>

              <div className="space-y-2.5 text-slate-700">
                <div className="flex justify-between border-b pb-2">
                  <span>Gross trade volume (Rs.):</span>
                  <span className="font-bold text-slate-900">Rs. {orders.reduce((acc, curr) => acc + (parseFloat(curr.amount) || 0), 0).toFixed(2)}</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span>Authorized customer receipts:</span>
                  <span className="font-bold text-slate-900">{orders.length} orders</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span>Average ticket value:</span>
                  <span className="font-bold text-slate-900">
                    Rs. {(orders.reduce((acc, curr) => acc + (parseFloat(curr.amount) || 0), 0) / (orders.length || 1)).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Active product listings:</span>
                  <span className="font-bold text-[#fd8b00]">{products.length} materials</span>
                </div>
              </div>
            </div>

            {/* Marketplace Status */}
            <div className="border border-slate-100 p-5 rounded-2xl bg-slate-50/50 space-y-4">
              <h3 className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-emerald-500" /> Platform Demographics
              </h3>

              <div className="space-y-2.5 text-slate-700">
                <div className="flex justify-between border-b pb-2">
                  <span>Registered Trade Categories:</span>
                  <span className="font-bold text-slate-900">{categories.length} segments</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span>B2B Reviews Written:</span>
                  <span className="font-bold text-slate-900">{reviews.length} total reviews</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span>Reported / Flagged Posts:</span>
                  <span className="font-bold text-rose-600">{reviews.filter(r => r.reported).length} reviews</span>
                </div>
                <div className="flex justify-between">
                  <span>System Audit Trails:</span>
                  <span className="font-bold text-slate-900">{adminLogs.length} action logs</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}


      {/* ====================================================
          TAB 11: ACTIVITY LOGS
          ==================================================== */}
      {activeTab === 'logs' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-black text-[#041627] tracking-tight">System Security Audit Trail</h2>
              <p className="text-xs text-[#8192a7]">Historical chronicle of administrator actions, website content changes, user approvals, and IP security checks.</p>
            </div>

            <button 
              onClick={() => exportToCSV(adminLogs, 'Admin_Security_Logs')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-200"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Export Logs
            </button>
          </div>

          {/* Table */}
          <div className="border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold">
                <tr>
                  <th className="p-4">Admin Name</th>
                  <th className="p-4">Action Description</th>
                  <th className="p-4">Enterprise Module</th>
                  <th className="p-4">Date Dispatched</th>
                  <th className="p-4">Time</th>
                  <th className="p-4">Security IP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {adminLogs.map((log: any) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="p-4 font-extrabold text-slate-900">{log.adminName || 'Super Admin'}</td>
                    <td className="p-4 text-slate-600 font-semibold">{log.action}</td>
                    <td className="p-4">
                      <span className="bg-slate-100 text-slate-800 font-bold px-2.5 py-0.5 rounded text-[10px] uppercase tracking-wider border border-slate-200">
                        {log.module}
                      </span>
                    </td>
                    <td className="p-4 text-slate-400 font-mono">{log.date}</td>
                    <td className="p-4 text-slate-400 font-mono">{log.time}</td>
                    <td className="p-4 text-slate-400 font-mono">{log.ipAddress || '127.0.0.1'}</td>
                  </tr>
                ))}
                {adminLogs.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">No action logs written to Firestore yet. Actions will populate dynamically as configurations are modified.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
