import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingCart, Trash2, ArrowLeft, ArrowRight, Minus, Plus, Tag, 
  MapPin, Calendar, Heart, ShieldCheck, Bookmark, RefreshCw, Sparkles, CheckCircle2, Info
} from 'lucide-react';
import { CartItem, Product } from '../types';

interface ShoppingCartPageProps {
  cartItems: CartItem[];
  savedItems?: CartItem[];
  products: Product[];
  onUpdateQty: (id: string, qty: number, unit?: string) => void;
  onRemoveFromCart: (id: string) => void;
  onClearCart: () => void;
  onSaveForLater: (item: CartItem) => void;
  onMoveToCart: (item: CartItem) => void;
  onRemoveSavedItem: (id: string) => void;
  onProceedToCheckout: () => void;
  onBackToShop: () => void;
  userAddress?: string;
  onChangeAddress?: (newAddress: string) => void;
}

const COMMON_UNITS = [
  'Pieces (pcs)',
  'Kilograms (kg)',
  'Grams (g)',
  'Tons (ton)',
  'Liters (L)',
  'Milliliters (mL)',
  'Meters (m)',
  'Feet (ft)',
  'Square Feet (sq ft)',
  'Cubic Feet (cu ft)',
  'Bags',
  'Boxes',
  'Bundles',
  'Rolls',
  'Sheets',
  'Packs',
  'Sets',
  'Custom Unit'
];

export default function ShoppingCartPage({
  cartItems,
  savedItems = [],
  products,
  onUpdateQty,
  onRemoveFromCart,
  onClearCart,
  onSaveForLater,
  onMoveToCart,
  onRemoveSavedItem,
  onProceedToCheckout,
  onBackToShop,
  userAddress = 'Jobsite #12 - Kathmandu Metropolitan, Nepal',
  onChangeAddress
}: ShoppingCartPageProps) {
  // Manual quantity and validation states
  const [typedQty, setTypedQty] = useState<Record<string, string>>({});
  const [valErrors, setValErrors] = useState<Record<string, string>>({});

  const isDecimalUnit = (unit: string) => {
    const u = unit.toLowerCase();
    return u.includes('kg') || u.includes('kilogram') || u.includes('g') || u.includes('gram') || u.includes('ton') || 
           u.includes('l') || u.includes('liter') || u.includes('ml') || u.includes('milliliter') ||
           u.includes('m') || u.includes('meter') || u.includes('ft') || u.includes('feet') || 
           u.includes('sq') || u.includes('square') || u.includes('cu') || u.includes('cubic');
  };

  const getAllowedUnitsForItem = (item: CartItem) => {
    const matched = products.find(p => p.id === item.id);
    const units = matched?.allowedUnits || item.allowedUnits;
    if (units && units.length > 0) {
      return units;
    }
    const defaultUnit = matched?.unit || item.unit || 'Piece';
    const defaultList = [defaultUnit];
    COMMON_UNITS.forEach(u => {
      const cleanU = u.split(' ')[0].toLowerCase();
      if (!defaultList.some(dl => dl.toLowerCase().includes(cleanU) || cleanU.includes(dl.toLowerCase()))) {
        defaultList.push(u);
      }
    });
    return defaultList;
  };

  // Selected item for product detail modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Calculations
  const totalItemCount = cartItems.length;
  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.qty, 0);
  
  // Freight / Shipping Calculation
  // Shipping is $45 flat rate for heavy freight delivery if cart has items
  const shippingFee = cartItems.length === 0 ? 0 : 45.00;
  
  // Tax calculation (13% VAT)
  const estimatedTax = subtotal * 0.13;
  
  // Discount is 0 since coupons are removed
  const discount = 0;

  const serviceCharge = cartItems.length > 0 ? 15.00 : 0;
  const grandTotal = Math.max(0, subtotal + shippingFee + estimatedTax + serviceCharge);

  // Group all cart items by shop name to calculate global totals for each shop in the cart
  const allShopsGrouped = cartItems.reduce((acc, item) => {
    const sName = item.seller?.shopName || 'ProBuild Materials Inc.';
    if (!acc[sName]) {
      acc[sName] = [];
    }
    acc[sName].push(item);
    return acc;
  }, {} as Record<string, typeof cartItems>);

  const allShopsTotals = Object.entries(allShopsGrouped).map(([sName, sItems]) => {
    const sSubtotal = sItems.reduce((acc, item) => acc + item.price * item.qty, 0);
    const sShippingFee = 45.00;
    const sTax = sSubtotal * 0.13;
    const sServiceCharge = 15.00;
    const sDiscount = 0;
    const sGrandTotal = Math.max(0, sSubtotal + sShippingFee + sTax - sDiscount + sServiceCharge);
    return {
      shopName: sName,
      grandTotal: sGrandTotal
    };
  });

  const overallGrandTotal = allShopsTotals.reduce((sum, item) => sum + item.grandTotal, 0);

  // Update quantity handler with validation
  const handleQuantityChange = (item: CartItem, newQty: number, selectedUnit?: string) => {
    const matchedProduct = products.find(p => p.id === item.id);
    const unit = selectedUnit || item.unit || 'Piece';
    const maxStock = matchedProduct?.unitStocks?.[unit] ?? matchedProduct?.availableQuantity ?? 100;

    if (newQty <= 0) {
      onRemoveFromCart(item.id);
      return;
    }
    if (newQty > maxStock) {
      alert(`Requested quantity exceeds available stock (${maxStock} units remaining)`);
      onUpdateQty(item.id, maxStock, unit);
      setTypedQty(prev => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
      return;
    }
    onUpdateQty(item.id, newQty, unit);
    setTypedQty(prev => {
      const next = { ...prev };
      delete next[item.id];
      return next;
    });
  };

  const handleQtyInput = (item: CartItem, rawVal: string, targetUnit?: string) => {
    const unit = targetUnit || item.unit || 'Piece';
    setTypedQty(prev => ({ ...prev, [item.id]: rawVal }));

    if (rawVal.trim() === '') {
      setValErrors(prev => ({ ...prev, [item.id]: 'Quantity cannot be empty' }));
      return;
    }

    const parsed = parseFloat(rawVal);
    if (isNaN(parsed)) {
      setValErrors(prev => ({ ...prev, [item.id]: 'Please enter a valid number' }));
      return;
    }

    if (parsed <= 0) {
      setValErrors(prev => ({ ...prev, [item.id]: 'Quantity must be greater than 0' }));
      return;
    }

    const matchedProduct = products.find(p => p.id === item.id);
    const maxStock = matchedProduct?.unitStocks?.[unit] ?? matchedProduct?.availableQuantity ?? 100;
    if (parsed > maxStock) {
      setValErrors(prev => ({ ...prev, [item.id]: `Quantity exceeds stock (${maxStock} max)` }));
      return;
    }

    const allowedDecimal = isDecimalUnit(unit);
    if (!allowedDecimal && !Number.isInteger(parsed)) {
      setValErrors(prev => ({ ...prev, [item.id]: 'Whole numbers only for this unit' }));
      return;
    }

    // All checks passed! Clear error and trigger parent callback
    setValErrors(prev => {
      const next = { ...prev };
      delete next[item.id];
      return next;
    });
    onUpdateQty(item.id, parsed, unit);
  };

  const handleQtyBlur = (item: CartItem) => {
    if (valErrors[item.id] || !typedQty[item.id] || typedQty[item.id].trim() === '') {
      setTypedQty(prev => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
      setValErrors(prev => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
    }
  };

  // Open detail modal helper
  const handleViewProductDetail = (itemId: string) => {
    const matched = products.find(p => p.id === itemId);
    if (matched) {
      setSelectedProduct(matched);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16 font-sans">
      {/* Top Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <button 
            onClick={onBackToShop}
            className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors bg-slate-100 hover:bg-slate-200 px-4 py-2.5 rounded-xl cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Materials Shop</span>
          </button>
          
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-[#fd8b00]" />
            <h1 className="text-xl font-bold text-slate-900">Project Shopping Cart</h1>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-bold text-slate-400">STATUS</span>
            <span className="bg-amber-100 text-amber-800 text-xs font-black px-3 py-1 rounded-full border border-amber-200 uppercase tracking-wider">
              Shopping
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <AnimatePresence mode="popLayout">
          {cartItems.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-12 text-center shadow-md border border-slate-200 max-w-2xl mx-auto mt-12"
            >
              <div className="w-24 h-24 bg-amber-50 rounded-full flex items-center justify-center mx-auto mb-6 border border-amber-100">
                <ShoppingCart className="w-12 h-12 text-[#fd8b00]" />
              </div>
              <h2 className="text-2xl font-black text-slate-950 font-sans">Your Cart is Empty</h2>
              <p className="text-slate-500 mt-2 text-sm max-w-md mx-auto">
                No materials selected yet. Explore our premier catalog of sand, steel, cement, and brick products to stock your jobsite.
              </p>
              <div className="mt-8">
                <button
                  onClick={onBackToShop}
                  className="bg-[#fd8b00] hover:bg-[#e07b00] text-white font-extrabold px-8 py-4 rounded-xl shadow-lg transition-transform hover:scale-105 active:scale-95 cursor-pointer inline-flex items-center gap-2.5 text-sm"
                >
                  <span>Start Shopping Catalog</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ) : (
            <div className="max-w-5xl mx-auto space-y-8 w-full">
              
              {/* Header operations */}
              <div className="flex flex-col bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-bold text-slate-800">
                    {totalItemCount} {totalItemCount === 1 ? 'Item' : 'Items'} in Cart from {Object.keys(cartItems.reduce((acc, item) => {
                      const sName = item.seller?.shopName || 'ProBuild Materials Inc.';
                      acc[sName] = true;
                      return acc;
                    }, {} as Record<string, boolean>)).length} Shops
                  </span>
                  <button 
                    onClick={onClearCart}
                    className="text-xs font-bold text-red-600 hover:text-red-700 hover:bg-red-50 px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear Entire Cart</span>
                  </button>
                </div>
                
                {cartItems.length > 0 && (
                  <div className="pt-2.5 border-t border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-2">Total Quantities Summary</p>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 text-xs text-slate-600">
                      {cartItems.map((item) => (
                        <li key={item.id} className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#fd8b00]" />
                          <span className="font-semibold text-slate-700 truncate max-w-[150px]">{item.name}</span>
                          <span className="text-slate-400">–</span>
                          <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[10px]">
                            {item.qty} {item.unit || 'Piece'}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Grouped Shop Sections */}
              {Object.entries(
                cartItems.reduce((acc, item) => {
                  const shopName = item.seller?.shopName || 'ProBuild Materials Inc.';
                  if (!acc[shopName]) {
                    acc[shopName] = [];
                  }
                  acc[shopName].push(item);
                  return acc;
                }, {} as Record<string, typeof cartItems>)
              ).map(([shopName, shopItems]) => {
                const firstItem = shopItems[0];
                // Extracted shop information or robust fallbacks
                const seller = firstItem?.seller || {
                  name: 'Arthur Pendleton',
                  shopName: shopName,
                  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
                  rating: 4.8,
                  phone: '+977-1-4412345'
                };

                // Shop-specific calculations
                const shopSubtotal = shopItems.reduce((acc, item) => acc + item.price * item.qty, 0);
                const shopShippingFee: number = 45.00;
                const shopTax = shopSubtotal * 0.13;
                const shopServiceCharge = 15.00;
                const shopDiscount = 0;
                const shopGrandTotal = Math.max(0, shopSubtotal + shopShippingFee + shopTax - shopDiscount + shopServiceCharge);

                return (
                  <div key={shopName} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
                    
                    {/* Shop Header & Info */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-100 bg-slate-50/50 -mx-6 -mt-6 p-6 rounded-t-2xl">
                      <div className="flex items-center gap-3">
                        <img 
                          src={seller.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'} 
                          alt={seller.name} 
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-full border border-slate-200 object-cover shrink-0"
                        />
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-base font-black text-slate-900 flex items-center gap-1.5">
                              <span className="text-lg">🏪</span>
                              {seller.shopName || shopName}
                            </span>
                            <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-100 flex items-center gap-1">
                              <span className="w-1 h-1 rounded-full bg-emerald-500" /> Verified Merchant
                            </span>
                          </div>
                          <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                            <span>Seller: <strong className="font-semibold text-slate-700">{seller.name || 'Arthur Pendleton'}</strong></span>
                            <span className="flex items-center gap-1">
                              <span className="text-amber-500">★</span>
                              <strong className="font-semibold text-slate-700">{seller.rating || 4.8}</strong>
                            </span>
                            <span>Contact: <strong className="font-semibold text-slate-700">{seller.phone || '+977-1-4412345'}</strong></span>
                          </div>
                        </div>
                      </div>
                      <div className="bg-amber-50 border border-amber-100 px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 shrink-0 text-amber-800">
                        <Calendar className="w-3.5 h-3.5" />
                        <span className="text-xs font-bold">Est. Delivery: 2-3 Days</span>
                      </div>
                    </div>

                    {/* Responsive Two-Column Grid inside each Shop section */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                      
                      {/* Left portion: Shop items list (takes 2 of 3 columns) */}
                      <div className="lg:col-span-2 space-y-4">
                        {shopItems.map((item) => {
                          const matchedProduct = products.find(p => p.id === item.id);
                          const currentUnit = item.unit || 'Piece';
                          const stockCount = matchedProduct?.unitStocks?.[currentUnit] ?? matchedProduct?.availableQuantity ?? 100;
                          const isOutOfStock = stockCount <= 0;

                          return (
                            <motion.div
                              key={item.id}
                              layoutId={`cart-item-${item.id}`}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, x: -100 }}
                              transition={{ duration: 0.2 }}
                              className="bg-white rounded-2xl border border-slate-100 p-4 shadow-xs hover:border-slate-200 transition-all flex flex-col sm:flex-row gap-4"
                            >
                              {/* Product Image */}
                              <div 
                                onClick={() => handleViewProductDetail(item.id)}
                                className="w-full sm:w-20 h-20 bg-slate-50 rounded-xl overflow-hidden shrink-0 border border-slate-100 cursor-pointer group relative"
                              >
                                <img 
                                  src={item.image} 
                                  alt={item.name} 
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                                />
                                <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                  <span className="bg-white/95 text-slate-800 text-[10px] font-black px-1.5 py-0.5 rounded shadow-xs">View</span>
                                </div>
                              </div>

                              {/* Product Meta */}
                              <div className="flex-1 flex flex-col justify-between">
                                <div>
                                  <div className="flex justify-between items-start gap-2">
                                    <div>
                                      <span className="text-[9px] font-black text-[#fd8b00] uppercase tracking-wider bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                                        {item.category}
                                      </span>
                                      <h3 
                                        onClick={() => handleViewProductDetail(item.id)}
                                        className="text-sm font-black text-slate-900 mt-1 hover:text-[#fd8b00] transition-colors cursor-pointer"
                                      >
                                        {item.name}
                                      </h3>
                                    </div>
                                    <div className="text-right">
                                      <span className="text-sm font-black text-slate-950 block">
                                        Rs. {(item.price * item.qty).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                      </span>
                                      <span className="text-[10px] text-slate-400 mt-0.5 block">
                                        Rs. {item.price.toFixed(2)} / {currentUnit}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="flex flex-wrap items-center gap-2.5 mt-2">
                                    <span className={`inline-flex items-center text-[10px] font-bold ${
                                      isOutOfStock ? 'text-red-600 bg-red-50' : stockCount < 10 ? 'text-amber-600 bg-amber-50' : 'text-emerald-700 bg-emerald-50'
                                    } px-2 py-0.5 rounded border ${
                                      isOutOfStock ? 'border-red-100' : stockCount < 10 ? 'border-amber-100' : 'border-emerald-100'
                                    }`}>
                                      {isOutOfStock ? 'Out of Stock' : `${stockCount} ${currentUnit} available`}
                                    </span>
                                  </div>
                                </div>

                                {/* Controls (Qty / Unit / Save / Remove) */}
                                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 mt-3">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="text-[11px] font-bold text-slate-400">Qty:</span>
                                    <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg overflow-hidden h-8">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const currentVal = parseFloat(typedQty[item.id] !== undefined ? typedQty[item.id] : item.qty.toString());
                                          const step = isDecimalUnit(currentUnit) ? 0.5 : 1;
                                          const newVal = Math.max(0, currentVal - step);
                                          handleQuantityChange(item, newVal, currentUnit);
                                        }}
                                        className="px-2 text-slate-500 hover:bg-slate-200 transition-colors h-full flex items-center justify-center cursor-pointer"
                                      >
                                        <Minus className="w-3 h-3" />
                                      </button>
                                      <input
                                        type="text"
                                        value={typedQty[item.id] !== undefined ? typedQty[item.id] : item.qty}
                                        onFocus={(e) => e.target.select()}
                                        onClick={(e) => (e.target as HTMLInputElement).select()}
                                        onChange={(e) => handleQtyInput(item, e.target.value, currentUnit)}
                                        onBlur={() => handleQtyBlur(item)}
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter' || e.key === 'Escape') {
                                            (e.target as HTMLInputElement).blur();
                                          }
                                        }}
                                        className="w-12 text-center font-bold text-xs bg-transparent border-none text-slate-800 focus:outline-none focus:ring-0 cursor-text"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const currentVal = parseFloat(typedQty[item.id] !== undefined ? typedQty[item.id] : item.qty.toString());
                                          const step = isDecimalUnit(currentUnit) ? 0.5 : 1;
                                          const newVal = currentVal + step;
                                          handleQuantityChange(item, newVal, currentUnit);
                                        }}
                                        className="px-2 text-slate-500 hover:bg-slate-200 transition-colors h-full flex items-center justify-center cursor-pointer"
                                      >
                                        <Plus className="w-3 h-3" />
                                      </button>
                                    </div>

                                    <span className="text-[11px] font-bold text-slate-400 ml-1">Unit:</span>
                                    <select
                                      value={currentUnit}
                                      onChange={(e) => {
                                        const nextUnit = e.target.value;
                                        const maxStockNew = matchedProduct?.unitStocks?.[nextUnit] ?? matchedProduct?.availableQuantity ?? 100;
                                        const currentQty = item.qty;
                                        const adjustedQty = currentQty > maxStockNew ? maxStockNew : currentQty;
                                        onUpdateQty(item.id, adjustedQty, nextUnit);
                                        setTypedQty(prev => {
                                          const next = { ...prev };
                                          delete next[item.id];
                                          return next;
                                        });
                                        setValErrors(prev => {
                                          const next = { ...prev };
                                          delete next[item.id];
                                          return next;
                                        });
                                      }}
                                      className="h-8 text-[11px] px-2 rounded-lg border border-slate-200 bg-slate-50 font-bold text-slate-700 cursor-pointer"
                                    >
                                      {getAllowedUnitsForItem(item).map((un) => (
                                        <option key={un} value={un}>{un}</option>
                                      ))}
                                    </select>
                                  </div>

                                  <div className="flex items-center gap-1.5">
                                    <button
                                      onClick={() => onSaveForLater(item)}
                                      className="text-[11px] text-slate-400 hover:text-slate-800 hover:bg-slate-50 px-2 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                                    >
                                      <Bookmark className="w-3 h-3" />
                                      <span>Save</span>
                                    </button>
                                    <button
                                      onClick={() => onRemoveFromCart(item.id)}
                                      className="text-[11px] text-red-500 hover:text-red-700 hover:bg-red-50 p-1 rounded-lg cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                                {valErrors[item.id] && (
                                  <p className="text-[10px] font-bold text-red-500 mt-1">
                                    ⚠️ {valErrors[item.id]}
                                  </p>
                                )}
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>

                      {/* Right portion: Shop-Specific Billing Summary & Order Calculation */}
                      <div className="lg:sticky lg:top-28 space-y-4">
                        <div className="border border-slate-200/80 bg-slate-50/70 p-5 rounded-2xl space-y-3.5 shadow-xs">
                          <h3 className="text-xs font-black text-slate-500 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200/50 pb-2 mb-2">
                            <Info className="w-4 h-4 text-[#fd8b00]" />
                            <span>Order Calculation</span>
                          </h3>

                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between items-center text-slate-500 font-medium">
                              <span className="text-left">Subtotal ({shopItems.length} {shopItems.length === 1 ? 'item' : 'items'})</span>
                              <span className="font-bold text-slate-800 text-right whitespace-nowrap">Rs. {shopSubtotal.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center text-slate-500 font-medium">
                              <span className="text-left">Freight Transport Delivery</span>
                              <span className="font-bold text-slate-800 text-right whitespace-nowrap">
                                {shopShippingFee === 0 ? <span className="text-emerald-600 font-extrabold">FREE</span> : `Rs. ${shopShippingFee.toFixed(2)}`}
                              </span>
                            </div>
                            <div className="flex justify-between items-center text-slate-500 font-medium">
                              <span className="text-left">Estimated Tax (13% VAT)</span>
                              <span className="font-bold text-slate-800 text-right whitespace-nowrap">Rs. {shopTax.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center text-slate-500 font-medium">
                              <span className="text-left">Unloading Service Charge</span>
                              <span className="font-bold text-slate-800 text-right whitespace-nowrap">Rs. {shopServiceCharge.toFixed(2)}</span>
                            </div>
                          </div>

                          {/* Divider separating list from totals */}
                          <div className="border-t border-slate-200/80 my-3.5" />

                          {allShopsTotals.length > 1 ? (
                            <div className="space-y-4 pt-1">
                              {/* List of multiple shops */}
                              <div className="space-y-2.5">
                                <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block text-left">
                                  Total per Shop
                                </span>
                                <div className="space-y-2">
                                  {allShopsTotals.map((shopTotal) => (
                                    <div 
                                      key={shopTotal.shopName} 
                                      className="flex items-center justify-between gap-2 w-full text-xs"
                                    >
                                      <span 
                                        className={`truncate font-semibold select-all text-left ${
                                          shopTotal.shopName === shopName 
                                            ? 'text-slate-900 font-black' 
                                            : 'text-slate-500'
                                        }`} 
                                        style={{ maxWidth: '55%' }}
                                        title={shopTotal.shopName}
                                      >
                                        {shopTotal.shopName}
                                        {shopTotal.shopName === shopName && (
                                          <span className="text-[9px] text-[#fd8b00] ml-1 font-bold">(current)</span>
                                        )}
                                      </span>
                                      <div className="flex-1 border-b border-dotted border-slate-300 min-w-[12px] h-3 mx-1 self-center" />
                                      <span 
                                        className={`font-extrabold whitespace-nowrap text-right ${
                                          shopTotal.shopName === shopName 
                                            ? 'text-slate-900 font-black' 
                                            : 'text-slate-700'
                                        }`}
                                      >
                                        Rs. {shopTotal.grandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Divider above Grand Total */}
                              <div className="border-t border-slate-200/80 my-2 pt-2" />

                              {/* Overall Grand Total */}
                              <div className="flex items-center justify-between gap-4 w-full">
                                <span className="text-xs font-black text-slate-900 uppercase tracking-wider text-left">
                                  Grand Total
                                </span>
                                <div className="flex-1 border-b border-dashed border-slate-400 min-w-[12px] h-3 mx-1 self-center" />
                                <span className="text-xl font-black text-[#fd8b00] whitespace-nowrap text-right">
                                  Rs. {overallGrandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div>
                          ) : (
                            /* Only single shop in cart */
                            <div className="space-y-1.5 pt-1">
                              <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block text-left">
                                Total for Shop
                              </span>
                              <div className="flex items-center justify-between gap-4 w-full pt-1">
                                <span 
                                  className="text-sm font-semibold text-slate-700 truncate text-left" 
                                  style={{ maxWidth: '55%' }}
                                  title={shopName}
                                >
                                  {shopName}
                                </span>
                                <div className="flex-1 border-b border-dashed border-slate-300 min-w-[12px] h-3 mx-1 self-center" />
                                <span className="text-xl font-black text-[#fd8b00] whitespace-nowrap text-right">
                                  Rs. {shopGrandTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div>
                          )}

                          <div className="pt-4">
                            <button
                              onClick={() => {
                                localStorage.setItem('dreamhouse_checkout_shop', shopName);
                                onProceedToCheckout();
                              }}
                              className="w-full bg-[#fd8b00] hover:bg-[#e07b00] text-white text-xs font-black px-6 py-3.5 rounded-xl shadow-sm hover:shadow hover:scale-[1.01] active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                            >
                              <span>Proceed to Payment</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>

                  </div>
                );
              })}

              {/* Save for Later Section */}
              {savedItems.length > 0 && (
                <div className="bg-slate-100/50 rounded-2xl border border-slate-200 p-6">
                  <h3 className="text-base font-black text-slate-900 mb-4 flex items-center gap-2">
                    <Bookmark className="w-5 h-5 text-[#fd8b00]" />
                    <span>Saved For Later ({savedItems.length})</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedItems.map((sItem) => (
                      <div key={sItem.id} className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs flex gap-3.5">
                        <img 
                          src={sItem.image} 
                          alt={sItem.name} 
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 object-cover rounded-lg border border-slate-100 shrink-0" 
                        />
                        <div className="flex-1 min-w-0 flex flex-col justify-between">
                          <div>
                            <h4 className="text-xs font-bold text-slate-900 truncate">{sItem.name}</h4>
                            <p className="text-xs font-extrabold text-[#fd8b00] mt-1">Rs. {sItem.price.toFixed(2)}</p>
                          </div>
                          <div className="flex items-center gap-3 mt-2 pt-2 border-t border-slate-100">
                            <button
                              onClick={() => onMoveToCart(sItem)}
                              className="text-[11px] font-black text-slate-800 hover:text-[#fd8b00] cursor-pointer flex items-center gap-1"
                            >
                              <ShoppingCart className="w-3 h-3" />
                              <span>Move to Cart</span>
                            </button>
                            <button
                              onClick={() => onRemoveSavedItem(sItem.id)}
                              className="text-[11px] font-medium text-red-500 hover:text-red-700 cursor-pointer"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Secure Badge */}
              <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
                <ShieldCheck className="w-4 h-4 text-slate-400" />
                <span>256-Bit SSL Encrypted Connections Only</span>
              </div>

            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl relative">
            <button 
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 rounded-full p-2 cursor-pointer transition-colors"
            >
              <ArrowLeft className="w-4 h-4 rotate-90" />
            </button>
            <div className="h-48 w-full bg-slate-100 rounded-2xl overflow-hidden mt-4">
              <img src={selectedProduct.image} alt={selectedProduct.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
            </div>
            <div className="mt-4 space-y-3">
              <span className="bg-amber-100 text-[#fd8b00] text-xs font-extrabold px-2.5 py-0.5 rounded-full uppercase border border-amber-200">
                {selectedProduct.category}
              </span>
              <h3 className="text-xl font-black text-slate-950 font-sans">{selectedProduct.name}</h3>
              <p className="text-2xl font-black text-[#fd8b00]">Rs. {selectedProduct.price.toFixed(2)}</p>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {selectedProduct.description || "Premium contractor-grade raw building materials selected specifically for durability and load-bearing performance."}
              </p>
              <div className="border-t border-slate-100 pt-3 space-y-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-400">Available Stock:</span>
                  <span className="text-slate-800">{selectedProduct.availableQuantity ?? 100} units</span>
                </div>
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-400">Merchant Seller:</span>
                  <span className="text-slate-800">{selectedProduct.seller?.shopName || "ProBuild Materials Inc."}</span>
                </div>
              </div>
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedProduct(null)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-black px-6 py-3 rounded-xl cursor-pointer"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
