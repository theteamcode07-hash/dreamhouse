import React, { useState } from 'react';
import { 
  X, Star, CheckCircle2, MessageSquare, Truck, ShieldCheck, 
  MapPin, Phone, ShoppingBag, Plus, Sparkles, Building2, ChevronRight, Store 
} from 'lucide-react';
import { Product, SellerInfo } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  getSellerForProduct: (prod: Product) => SellerInfo;
  onOpenChat: (seller: SellerInfo) => void;
  onOpenSellerProfile: (seller: SellerInfo) => void;
}

const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart,
  getSellerForProduct,
  onOpenChat,
  onOpenSellerProfile
}) => {
  if (!isOpen || !product) return null;

  const seller = getSellerForProduct(product);

  const allowedUnits = product.allowedUnits && product.allowedUnits.length > 0
    ? product.allowedUnits
    : [product.unit || 'Piece'];

  const [selectedUnit, setSelectedUnit] = useState<string>(product.unit || allowedUnits[0]);

  // Dynamically resolve price and stock based on selected unit
  const activePrice = product.unitPrices && product.unitPrices[selectedUnit] !== undefined
    ? product.unitPrices[selectedUnit]
    : product.price;

  const activeStock = product.unitStocks && product.unitStocks[selectedUnit] !== undefined
    ? product.unitStocks[selectedUnit]
    : product.availableQuantity;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Modal Content */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl border border-slate-100 shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-slate-100 shrink-0 bg-slate-50/50">
          <div>
            <span className="text-[10px] font-black text-amber-600 uppercase tracking-wider">Product Master Details</span>
            <h2 className="text-sm font-black text-slate-800 uppercase tracking-tight truncate max-w-sm">
              {product.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-200/60 rounded-xl text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
            title="Close details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Left: Image Panel */}
            <div className="flex flex-col gap-4">
              <div className="relative aspect-square rounded-2xl bg-slate-50 border border-slate-200/60 p-6 flex items-center justify-center overflow-hidden">
                <img
                  src={product.image || 'https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?w=150'}
                  alt={product.name}
                  className="w-full h-full object-contain mix-blend-multiply"
                  referrerPolicy="no-referrer"
                />
                
                {product.isBestSeller && (
                  <span className="absolute top-3 left-3 bg-[#fd8b00] text-white text-[9px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider shadow-sm">
                    Best Seller
                  </span>
                )}
                {product.freeDelivery && (
                  <span className="absolute top-3 right-3 bg-emerald-500 text-white text-[9px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider shadow-sm">
                    Free Freight
                  </span>
                )}
              </div>

              {/* Delivery info & Warranty */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-2.5 text-xs text-slate-600 font-semibold bg-slate-50 border border-slate-100 p-3 rounded-xl">
                  <Truck className="w-4 h-4 text-emerald-600" />
                  <div>
                    <span className="block font-bold text-slate-800">Prompt Material Delivery</span>
                    <span className="text-[10px] text-slate-400 font-medium">Available for local dispatch</span>
                  </div>
                </div>

                {product.warranty && (
                  <div className="flex items-center gap-2.5 text-xs text-slate-600 font-semibold bg-slate-50 border border-slate-100 p-3 rounded-xl">
                    <ShieldCheck className="w-4 h-4 text-[#fd8b00]" />
                    <div>
                      <span className="block font-bold text-slate-800">Quality Assured</span>
                      <span className="text-[10px] text-slate-400 font-medium">{product.warranty} Warranty</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Technical Details & Purchase */}
            <div className="space-y-4">
              
              {/* Category, Brand, Rating Row */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  <span>{product.category} {product.brand ? `• ${product.brand}` : ''}</span>
                  <div className="flex items-center gap-0.5 text-amber-500">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    <span className="text-slate-800 font-bold">{seller.rating?.toFixed(1) || '4.8'}</span>
                  </div>
                </div>
                <h1 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                  {product.name}
                </h1>
              </div>

              {/* Price block */}
              <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-4 flex justify-between items-center">
                <div className="space-y-1">
                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Contractor Price</span>
                  <div className="flex items-baseline gap-1.5 flex-wrap">
                    <span className="text-xl font-black text-[#fd8b00]">
                      Rs. {activePrice.toLocaleString('en-US')}
                    </span>
                    {product.originalPrice && product.originalPrice > activePrice && (
                      <span className="text-xs text-slate-400 line-through font-semibold">
                        Rs. {product.originalPrice.toLocaleString('en-US')}
                      </span>
                    )}
                  </div>
                </div>

                {/* Unit Selector */}
                <div className="space-y-1 text-right">
                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Unit Selection</span>
                  {allowedUnits.length > 1 ? (
                    <select
                      value={selectedUnit}
                      onChange={(e) => setSelectedUnit(e.target.value)}
                      className="text-xs font-black text-amber-700 bg-white border border-amber-200 rounded-lg px-2.5 py-1.5 outline-none cursor-pointer shadow-xs"
                    >
                      {allowedUnits.map((u) => (
                        <option key={u} value={u}>
                          / {u}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className="text-xs font-black text-amber-700 bg-amber-100 border border-amber-200/50 rounded-lg px-3 py-1.5 inline-block">
                      / {selectedUnit}
                    </span>
                  )}
                </div>
              </div>

              {/* Stock Status Badge */}
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-400">Inventory Status:</span>
                {(() => {
                  if (activeStock !== undefined) {
                    if (activeStock > 0) {
                      return (
                        <span className="text-emerald-700 font-extrabold flex items-center gap-1.5 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-full">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                          <span>{activeStock} {selectedUnit} available in stock</span>
                        </span>
                      );
                    } else {
                      return (
                        <span className="text-rose-700 font-extrabold flex items-center gap-1.5 bg-rose-50 border border-rose-100 px-2.5 py-1 rounded-full">
                          <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                          <span>Sold out / Out of Stock</span>
                        </span>
                      );
                    }
                  }
                  return (
                    <span className="text-emerald-700 font-extrabold flex items-center gap-1.5 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-full">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span>Available</span>
                    </span>
                  );
                })()}
              </div>

              {/* Product specifications or specifications details block */}
              {(product.specifications || product.description) && (
                <div className="space-y-2 border-t border-slate-100 pt-3">
                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Specifications & Info</span>
                  {product.description && (
                    <p className="text-xs text-slate-600 leading-relaxed font-medium">
                      {product.description}
                    </p>
                  )}
                  {product.specifications && (
                    <div className="text-xs bg-slate-50 border border-slate-100 rounded-xl p-3 text-slate-700 leading-normal font-semibold font-mono whitespace-pre-line">
                      {product.specifications}
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>

          {/* Bottom: Comprehensive Merchant Information Card */}
          <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-4 space-y-3.5">
            <div className="flex justify-between items-start gap-4">
              <div className="flex gap-3 items-center">
                <div className="relative shrink-0">
                  <img
                    src={seller.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                    alt={seller.shopName || seller.name}
                    className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-md"
                    referrerPolicy="no-referrer"
                  />
                  {seller.isVerified && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 bg-white rounded-full absolute -bottom-0.5 -right-0.5" />
                  )}
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900 flex items-center gap-1">
                    <span>{seller.shopName || seller.name}</span>
                    <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[8px] font-extrabold px-1.5 py-0.2 rounded uppercase">Verified</span>
                  </h4>
                  <p className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                    <span className="text-amber-500 font-bold">★ {seller.rating?.toFixed(1) || '4.9'}</span>
                    <span>({seller.reviewsCount || 48} review history)</span>
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenChat(seller);
                  }}
                  className="p-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-600 hover:text-slate-900 transition-all cursor-pointer shadow-xs"
                  title="Chat directly with shopkeeper"
                >
                  <MessageSquare className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenSellerProfile(seller);
                  }}
                  className="px-3 py-2 bg-[#fd8b00] hover:bg-[#e07b00] text-white text-[10px] font-black rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1"
                >
                  <span>Visit Shop</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Seller extra contact & location info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] font-semibold text-slate-500 border-t border-slate-200/55 pt-3">
              {seller.location && (
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{seller.location}</span>
                </div>
              )}
              {seller.phone && (
                <div className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Call support: {seller.phone}</span>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Modal Footer with Interactive Purchase Action */}
        <div className="px-6 py-4 border-t border-slate-100 shrink-0 flex items-center justify-between gap-4 bg-slate-50/50">
          <div className="flex flex-col">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider">Subtotal Preview</span>
            <span className="text-base font-black text-slate-900">
              Rs. {activePrice.toLocaleString('en-US')} <span className="text-[11px] font-bold text-slate-400">/ {selectedUnit}</span>
            </span>
          </div>

          <button
            type="button"
            onClick={() => {
              onAddToCart({
                ...product,
                unit: selectedUnit,
                price: activePrice,
                availableQuantity: activeStock
              });
              onClose();
            }}
            disabled={activeStock !== undefined && activeStock <= 0}
            className={`px-6 py-3 font-black text-xs rounded-xl transition-all active:scale-95 flex items-center justify-center gap-2 shadow-md cursor-pointer ${
              activeStock !== undefined && activeStock <= 0
                ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed shadow-none'
                : 'bg-slate-950 hover:bg-[#fd8b00] hover:text-white text-white'
            }`}
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>{activeStock !== undefined && activeStock <= 0 ? 'SOLD OUT' : 'ADD TO ACTIVE CART'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

export default ProductDetailModal;
