/**
 * Dream House Robust API Client
 * Provides cross-platform, HTTPS-enforced, mobile-friendly API communication with detailed logging,
 * automatic URL resolution (handling Cloud Run, GitHub Pages, Android WebView/Kodular, and Mobile Safari),
 * and human-readable network error messages.
 */

// Resolved fallback backend production URL for external deployments (GitHub Pages, Kodular, WebViews)
const FALLBACK_PRODUCTION_API_URL = "https://ais-dev-37tid3dmfyagb7or5qawct-321954895058.asia-southeast1.run.app";

/**
 * Resolves full API URL with HTTPS enforcement and cross-platform origin safety.
 */
export function getApiBaseUrl(): string {
  // 1. Explicit env variable override if provided
  const envBaseUrl = (import.meta as any).env?.VITE_API_BASE_URL;
  if (envBaseUrl && typeof envBaseUrl === 'string' && envBaseUrl.trim()) {
    let url = envBaseUrl.trim().replace(/\/+$/, '');
    if (url.startsWith('http://') && !url.includes('localhost') && !url.includes('127.0.0.1')) {
      url = url.replace('http://', 'https://');
    }
    return url;
  }

  // 2. Browser window origin context
  if (typeof window !== 'undefined' && window.location) {
    const { origin, hostname, protocol } = window.location;

    // A. File protocol (e.g., Android WebView / Kodular offline asset) or null origin
    if (protocol === 'file:' || origin === 'null' || !origin) {
      return FALLBACK_PRODUCTION_API_URL;
    }

    // B. Hosted on GitHub Pages or custom external static hosting without backend
    if (hostname.endsWith('.github.io') || hostname.includes('github.app') || hostname.includes('kodular')) {
      return FALLBACK_PRODUCTION_API_URL;
    }

    // C. Running on Cloud Run container or standard origin
    let currentOrigin = origin.replace(/\/+$/, '');
    
    // Replace HTTP with HTTPS for non-localhost remote origins
    if (currentOrigin.startsWith('http://') && !hostname.includes('localhost') && !hostname.includes('127.0.0.1')) {
      currentOrigin = currentOrigin.replace('http://', 'https://');
    }

    return currentOrigin;
  }

  return FALLBACK_PRODUCTION_API_URL;
}

/**
 * Builds complete HTTPS endpoint URL from path
 */
export function getApiUrl(endpoint: string): string {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const baseUrl = getApiBaseUrl();

  // If baseUrl is current origin (empty or relative ok in same host), use full URL to prevent WebView ambiguity
  if (baseUrl.startsWith('http://') || baseUrl.startsWith('https://')) {
    return `${baseUrl}${cleanEndpoint}`;
  }
  return cleanEndpoint;
}

export interface ApiFetchOptions extends RequestInit {
  timeoutMs?: number;
}

export interface ApiResponse<T = any> {
  ok: boolean;
  status: number;
  data: T;
  headers: Record<string, string>;
  error?: string | null;
}

/**
 * Executes a network fetch call with full diagnostic logging, JSON/HTML verification, and mobile network recovery.
 */
export async function apiFetch<T = any>(
  endpoint: string,
  options: ApiFetchOptions = {}
): Promise<ApiResponse<T>> {
  const { timeoutMs = 20000, ...fetchInit } = options;
  const fullUrl = getApiUrl(endpoint);
  const method = (fetchInit.method || 'GET').toUpperCase();

  // Ensure default JSON headers if sending a body
  const headers = new Headers(fetchInit.headers || {});
  if (fetchInit.body && typeof fetchInit.body === 'string' && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  headers.set('Accept', 'application/json');

  const headersObject: Record<string, string> = {};
  headers.forEach((val, key) => {
    headersObject[key] = val;
  });

  // Log Request (Requirement #2, #9)
  console.log(`[API Client Request] ${method} ${fullUrl}`, {
    url: fullUrl,
    method,
    headers: headersObject,
    body: fetchInit.body ? String(fetchInit.body).slice(0, 500) : null
  });

  // Check client connectivity prior to fetch (Requirement #10)
  if (typeof navigator !== 'undefined' && navigator && navigator.onLine === false) {
    const errorMsg = "Internet connection lost. Please check your network connection and try again.";
    console.error(`[API Client Offline Error] ${method} ${fullUrl}:`, errorMsg);
    return {
      ok: false,
      status: 0,
      data: { success: false, error: errorMsg } as any,
      headers: {},
      error: errorMsg
    };
  }

  // Setup timeout controller
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(fullUrl, {
      ...fetchInit,
      headers,
      signal: controller.signal
    });

    clearTimeout(timer);

    const resHeadersObject: Record<string, string> = {};
    response.headers.forEach((val, key) => {
      resHeadersObject[key] = val;
    });

    const contentType = response.headers.get('content-type') || '';
    const rawText = await response.text();

    // Log Response (Requirement #2, #9)
    console.log(`[API Client Response] ${method} ${fullUrl} - Status: ${response.status}`, {
      status: response.status,
      contentType,
      headers: resHeadersObject,
      bodyPreview: rawText.slice(0, 500)
    });

    // Verify Content-Type is application/json (Requirement #8)
    if (contentType.includes('application/json')) {
      try {
        const parsedJson = JSON.parse(rawText);
        
        if (!response.ok && !parsedJson.error) {
          parsedJson.error = `Server returned status ${response.status}. Please try again later.`;
        }

        return {
          ok: response.ok,
          status: response.status,
          data: parsedJson,
          headers: resHeadersObject,
          error: parsedJson.error || null
        };
      } catch (jsonErr) {
        console.error(`[API Client JSON Parse Error] ${method} ${fullUrl}:`, rawText);
        const parseMsg = `Invalid data format received from server (HTTP ${response.status}). Please try again.`;
        return {
          ok: false,
          status: response.status,
          data: { success: false, error: parseMsg } as any,
          headers: resHeadersObject,
          error: parseMsg
        };
      }
    } else {
      // Non-JSON response (e.g., HTML error page, 404, or 502 Bad Gateway) (Requirement #7, #8)
      console.warn(`[API Client Non-JSON Warning] Expected application/json but received ${contentType} from ${fullUrl}`);
      let userFriendlyError = `API not reachable or server unavailable (HTTP ${response.status}). Please try again later.`;
      
      if (response.status === 404) {
        userFriendlyError = `API endpoint not found on server (HTTP 404). Please verify your connection.`;
      } else if (response.status >= 500) {
        userFriendlyError = `Server temporarily unavailable (HTTP ${response.status}). Please try again shortly.`;
      }

      return {
        ok: false,
        status: response.status,
        data: { success: false, error: userFriendlyError } as any,
        headers: resHeadersObject,
        error: userFriendlyError
      };
    }

  } catch (netErr: any) {
    clearTimeout(timer);
    
    // Detailed Network Error Handling (Requirement #10)
    console.error(`[API Client Network Failure] ${method} ${fullUrl}:`, netErr);

    let friendlyMessage = "Server unavailable or API not reachable. Please check your internet connection.";

    if (netErr.name === 'AbortError') {
      friendlyMessage = "Request timed out while connecting to server. Please check your internet connection and try again.";
    } else if (typeof navigator !== 'undefined' && navigator && navigator.onLine === false) {
      friendlyMessage = "Internet connection lost. Please verify your Wi-Fi or mobile data.";
    } else if (endpoint.includes('otp') || endpoint.includes('email')) {
      friendlyMessage = "Email service unavailable or server not reachable. Please check your connection and try again.";
    } else {
      friendlyMessage = "API not reachable. Please check your internet connection and try again.";
    }

    return {
      ok: false,
      status: 0,
      data: { success: false, error: friendlyMessage } as any,
      headers: {},
      error: friendlyMessage
    };
  }
}
