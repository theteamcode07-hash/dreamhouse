import { doc, setDoc, onSnapshot, collection } from 'firebase/firestore';
import { db } from './firebase';

export interface UserPresence {
  email: string;
  name?: string;
  status: 'online' | 'offline';
  lastSeen: number;
}

/**
 * Updates the current user's presence state in Firestore.
 */
export async function updateUserPresence(
  email: string,
  name: string = '',
  status: 'online' | 'offline' = 'online'
) {
  if (!email) return;
  const normalizedEmail = email.toLowerCase().trim();
  try {
    const presenceRef = doc(db, 'presence', normalizedEmail);
    await setDoc(
      presenceRef,
      {
        email: normalizedEmail,
        name,
        status,
        lastSeen: Date.now()
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('[Presence] Failed to update presence:', err);
  }
}

/**
 * Starts a real-time heartbeat that keeps the user marked as 'online' in Firestore.
 * Automatically handles page unload, tab hide/show, and interval updates.
 */
export function startPresenceHeartbeat(email: string, name: string) {
  if (!email) return () => {};

  const normalizedEmail = email.toLowerCase().trim();

  // Initial online state write
  updateUserPresence(normalizedEmail, name, 'online');

  // Heartbeat interval every 25 seconds
  const intervalId = setInterval(() => {
    updateUserPresence(normalizedEmail, name, 'online');
  }, 25000);

  // Unload event handlers
  const handleUnload = () => {
    updateUserPresence(normalizedEmail, name, 'offline');
  };

  const handleVisibilityChange = () => {
    if (document.visibilityState === 'hidden') {
      updateUserPresence(normalizedEmail, name, 'offline');
    } else {
      updateUserPresence(normalizedEmail, name, 'online');
    }
  };

  window.addEventListener('beforeunload', handleUnload);
  window.addEventListener('pagehide', handleUnload);
  document.addEventListener('visibilitychange', handleVisibilityChange);

  // Return cleanup function
  return () => {
    clearInterval(intervalId);
    window.removeEventListener('beforeunload', handleUnload);
    window.removeEventListener('pagehide', handleUnload);
    document.removeEventListener('visibilitychange', handleVisibilityChange);
    updateUserPresence(normalizedEmail, name, 'offline');
  };
}

/**
 * Subscribes in real time to all user presence records in Firestore.
 * Evaluates online vs offline based on status and heartbeat timestamp (< 90s).
 */
export function subscribeToPresence(
  callback: (presenceMap: Record<string, boolean>) => void
) {
  try {
    const presenceRef = collection(db, 'presence');
    const unsubscribe = onSnapshot(
      presenceRef,
      (snapshot) => {
        const presenceMap: Record<string, boolean> = {};
        const now = Date.now();

        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as UserPresence;
          if (data && data.email) {
            const emailLower = data.email.toLowerCase().trim();
            const isOnline =
              data.status === 'online' && now - (data.lastSeen || 0) < 90000;
            presenceMap[emailLower] = isOnline;
          }
        });

        callback(presenceMap);
      },
      (error) => {
        console.warn('[Presence] Real-time listener error:', error);
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('[Presence] Could not set up snapshot listener:', err);
    return () => {};
  }
}
