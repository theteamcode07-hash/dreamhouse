import { doc, setDoc, onSnapshot, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from './firebase';

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderEmail: string;
  senderName: string;
  senderRole: string;
  senderAvatar: string;
  recipientId: string;
  recipientEmail: string;
  recipientName: string;
  recipientRole: string;
  recipientAvatar: string;
  text: string;
  imageUrl?: string;
  timestamp: number;
  read: boolean;
}

/**
 * Computes a standardized, deterministic conversation ID for any two emails.
 */
export function getConversationId(emailA: string, emailB: string): string {
  const e1 = (emailA || '').toLowerCase().trim();
  const e2 = (emailB || '').toLowerCase().trim();
  const sorted = [e1, e2].sort();
  return `${sorted[0]}_${sorted[1]}`;
}

/**
 * Sends a chat message to Firestore in real-time.
 */
export async function sendChatMessage(msg: ChatMessage): Promise<void> {
  if (!msg.id) {
    msg.id = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }

  // Ensure lowercased emails
  msg.senderEmail = (msg.senderEmail || msg.senderId || '').toLowerCase().trim();
  msg.recipientEmail = (msg.recipientEmail || msg.recipientId || '').toLowerCase().trim();
  msg.senderId = msg.senderEmail;
  msg.recipientId = msg.recipientEmail;

  if (!msg.conversationId) {
    msg.conversationId = getConversationId(msg.senderEmail, msg.recipientEmail);
  }

  try {
    // Write directly to Firestore messages collection
    const msgRef = doc(db, 'messages', msg.id);
    await setDoc(msgRef, msg, { merge: true });

    // Also sync to local storage cache for instant local optimistic display
    try {
      const saved = localStorage.getItem('dreamhouse_messages');
      const list: ChatMessage[] = saved ? JSON.parse(saved) : [];
      const existingIdx = list.findIndex((m) => m.id === msg.id);
      if (existingIdx >= 0) {
        list[existingIdx] = msg;
      } else {
        list.push(msg);
      }
      localStorage.setItem('dreamhouse_messages', JSON.stringify(list));
      window.dispatchEvent(new Event('dreamhouse_sync_messages'));
    } catch (e) {
      console.warn('Notice updating local messages cache:', e);
    }
  } catch (err) {
    console.error('[Messaging] Failed to send message to Firestore:', err);
    throw err;
  }
}

/**
 * Subscribes to all real-time chat messages in Firestore relevant to currentUserEmail.
 */
export function subscribeToUserMessages(
  currentUserEmail: string,
  callback: (messages: ChatMessage[]) => void
) {
  if (!currentUserEmail) {
    callback([]);
    return () => {};
  }

  const userEmailLower = currentUserEmail.toLowerCase().trim();

  try {
    const messagesRef = collection(db, 'messages');
    
    // Subscribe to messages collection and strictly filter for current user
    const unsubscribe = onSnapshot(
      messagesRef,
      (snapshot) => {
        const firestoreMessages: ChatMessage[] = [];

        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as ChatMessage;
          if (data) {
            const sEmail = (data.senderEmail || data.senderId || '').toLowerCase().trim();
            const rEmail = (data.recipientEmail || data.recipientId || '').toLowerCase().trim();

            if (sEmail === userEmailLower || rEmail === userEmailLower) {
              firestoreMessages.push({
                ...data,
                id: docSnap.id || data.id,
                senderEmail: sEmail,
                recipientEmail: rEmail,
                conversationId: data.conversationId || getConversationId(sEmail, rEmail)
              });
            }
          }
        });

        // Also merge with user-isolated local messages cache
        let mergedMessages = [...firestoreMessages];
        try {
          const localSaved = localStorage.getItem('dreamhouse_messages');
          if (localSaved) {
            const localList: ChatMessage[] = JSON.parse(localSaved);
            if (Array.isArray(localList)) {
              localList.forEach((localMsg) => {
                if (!localMsg) return;
                const localSender = (localMsg.senderEmail || localMsg.senderId || '').toLowerCase().trim();
                const localRecipient = (localMsg.recipientEmail || localMsg.recipientId || '').toLowerCase().trim();
                
                if (localSender === userEmailLower || localRecipient === userEmailLower) {
                  if (!mergedMessages.some((m) => m.id === localMsg.id)) {
                    mergedMessages.push(localMsg);
                  }
                }
              });
            }
          }
        } catch (e) {
          console.warn('Notice parsing local messages cache:', e);
        }

        // Sort chronologically (oldest first, newest last)
        mergedMessages.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

        callback(mergedMessages);
      },
      (error) => {
        console.warn('[Messaging] Real-time message snapshot notice:', error);
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('[Messaging] Failed to create message listener:', err);
    return () => {};
  }
}

/**
 * Marks all unread messages in a conversation sent to currentUserEmail as read in Firestore.
 */
export async function markConversationAsRead(
  conversationId: string,
  currentUserEmail: string
) {
  if (!conversationId || !currentUserEmail) return;

  const userEmailLower = currentUserEmail.toLowerCase().trim();

  try {
    const q = query(
      collection(db, 'messages'),
      where('conversationId', '==', conversationId),
      where('read', '==', false)
    );
    const snapshot = await getDocs(q);

    const updatePromises: Promise<void>[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data() as ChatMessage;
      if (
        data.recipientEmail?.toLowerCase() === userEmailLower ||
        data.recipientId?.toLowerCase() === userEmailLower
      ) {
        updatePromises.push(
          setDoc(doc(db, 'messages', docSnap.id), { read: true }, { merge: true })
        );
      }
    });

    if (updatePromises.length > 0) {
      await Promise.all(updatePromises);
    }
  } catch (err) {
    console.warn('[Messaging] Notice marking conversation as read:', err);
  }
}
