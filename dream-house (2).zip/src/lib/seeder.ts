import { collection, getDocs, doc, setDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from './firebase';

export async function seedFirestoreIfNeeded() {
  try {
    // 1. Seed accounts
    const accountsRef = collection(db, 'accounts');
    const accountsSnap = await getDocs(accountsRef);
    if (accountsSnap.empty) {
      console.log('[Seeder] Seeding default accounts...');
      const demoUsers = [
        {
          id: 'demo-admin-theteamcode07',
          fullName: 'kishor joshi',
          email: 'theteamcode07@gmail.com',
          phone: '9876543213',
          password: 'admin1234',
          role: 'admin',
          accountType: 'Admin',
          registrationDate: 'Jul 24, 2026',
          status: 'Active',
          statusLastUpdated: 'Jul 24, 2026',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
          emailVerified: 'Verified'
        },
        {
          id: 'demo-expert-jenkins',
          fullName: 'Sarah Jenkins',
          email: 'sarah.jenkins@designstudio.com',
          phone: '+1 (555) 482-9922',
          password: 'expert1234',
          role: 'professional',
          accountType: 'Expert',
          registrationDate: 'Jul 24, 2026',
          status: 'Active',
          statusLastUpdated: 'Jul 24, 2026',
          avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
          professionType: 'Architect & Interior Specialist',
          yearsOfExperience: 9,
          emailVerified: 'Verified'
        },
        {
          id: 'demo-shopkeeper-probuild',
          fullName: 'Demo Shopkeeper',
          email: 'shopkeeper@gmail.com',
          phone: '+1 (555) 987-6543',
          password: 'shopkeeper1234',
          role: 'shopkeeper',
          accountType: 'Shopkeeper',
          registrationDate: 'Jul 24, 2026',
          status: 'Active',
          statusLastUpdated: 'Jul 24, 2026',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          emailVerified: 'Verified'
        }
      ];

      for (const u of demoUsers) {
        await setDoc(doc(db, 'accounts', u.id), u, { merge: true });
      }
    }

    // 2. Seed experts collection
    const expertsRef = collection(db, 'experts');
    const expertsSnap = await getDocs(expertsRef);
    if (expertsSnap.empty) {
      console.log('[Seeder] Seeding default experts...');
      const defaultExperts = [
        {
          id: 'exp-top-1',
          name: 'David Chen',
          profession: 'Structural Engineer',
          yearsOfExperience: 12,
          rating: 4.9,
          reviewsCount: 86,
          completedProjects: 54,
          location: 'Austin, TX',
          tagline: 'Specializing in heavy structural analysis, foundation design, and seismic retrofitting.',
          skills: ['Structural Analysis', 'Concrete Engineering', 'FEA Modeling', 'Seismic Design', 'Building Code Review'],
          certifications: ['PE Certified Structural Engineer', 'LEED AP BD+C', 'NSPE Fellow'],
          photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?w=1000&auto=format&fit=crop&q=80',
          contact: 'david.chen@structural.com',
          phone: '+1 (555) 392-1100',
          availability: 'Available',
          bio: 'Over 12 years of experience leading complex structural engineering projects for high-end residential estates and commercial developments. Passionate about structural integrity, code compliance, and innovative material efficiency.'
        },
        {
          id: 'exp-top-2',
          name: 'Sarah Jenkins',
          profession: 'Architect & Interior Specialist',
          yearsOfExperience: 9,
          rating: 5.0,
          reviewsCount: 112,
          completedProjects: 68,
          location: 'Los Angeles, CA',
          tagline: 'Creating modern luxury interior spaces, custom spatial layouts, and architectural blueprints.',
          skills: ['3D Spatial Rendering', 'Bespoke Lighting', 'Interior Drafting', 'Material Curation', 'Sustainable Finishes'],
          certifications: ['NCIDQ Certified Designer', 'AIA Associate Member', 'ASID Professional'],
          photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1000&auto=format&fit=crop&q=80',
          contact: 'sarah.jenkins@designstudio.com',
          phone: '+1 (555) 482-9922',
          availability: 'Available',
          bio: 'Renowned architect and interior planner focusing on open-concept modern floor plans, daylighting optimization, and bespoke material palettes that harmonize form and function.'
        },
        {
          id: 'exp-top-3',
          name: 'Marcus Vance',
          profession: 'Master Electrician',
          yearsOfExperience: 15,
          rating: 4.9,
          reviewsCount: 94,
          completedProjects: 120,
          location: 'Houston, TX',
          tagline: 'Commercial and high-capacity residential electrical wiring, solar integrations, and smart power grids.',
          skills: ['High-Voltage Systems', 'Smart Home Automation', 'Solar Inverters', 'Circuit Load Testing', 'Backup Generators'],
          certifications: ['Master Electrician License #49201', 'OSHA 30 Construction Certified', 'IEC Master Tech'],
          photo: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1000&auto=format&fit=crop&q=80',
          contact: 'marcus.vance@powergrid.com',
          phone: '+1 (555) 883-2041',
          availability: 'Available',
          bio: 'Licensed Master Electrician with 15 years in utility-scale wiring, smart home automation infrastructure, and renewable energy integration. Known for zero-defect compliance and safe execution.'
        },
        {
          id: 'exp-top-4',
          name: 'Elena Rostova',
          profession: 'Senior Landscape Architect',
          yearsOfExperience: 11,
          rating: 4.8,
          reviewsCount: 64,
          completedProjects: 42,
          location: 'Seattle, WA',
          tagline: 'Eco-friendly exterior architectural landscaping, hardscaping, and outdoor living suite designs.',
          skills: ['Hardscape Design', 'Native Ecology Plan', 'Irrigation Engineering', 'Outdoor Living Suites', 'Terracing'],
          certifications: ['Registered Landscape Architect (RLA)', 'CLARB Certified', 'Sustainable Sites Accredited'],
          photo: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1558904541-efa8c196b27d?w=1000&auto=format&fit=crop&q=80',
          contact: 'elena.rostova@ecoscape.com',
          phone: '+1 (555) 912-7833',
          availability: 'Available',
          bio: 'Dedicated landscape architect specializing in sustainable site development, custom stone terracing, native drought-tolerant greenery, and luxury outdoor entertainment amenities.'
        },
        {
          id: 'exp-top-5',
          name: 'Robert Martinez',
          profession: 'Master Plumber & MEP Specialist',
          yearsOfExperience: 14,
          rating: 4.9,
          reviewsCount: 78,
          completedProjects: 95,
          location: 'Dallas, TX',
          tagline: 'Advanced hydronic piping, backflow prevention, and heavy MEP installation for luxury estates.',
          skills: ['Hydronic Heating', 'MEP Coordination', 'Backflow Prevention', 'Water Filtration', 'Gas Line Piping'],
          certifications: ['Master Plumber License #88219', 'MedGas Certified', 'ASSE Backflow Specialist'],
          photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1000&auto=format&fit=crop&q=80',
          contact: 'robert.martinez@mepsolutions.com',
          phone: '+1 (555) 301-4455',
          availability: 'Available',
          bio: 'Master Plumber and MEP system designer. Specializes in luxury residential plumbing rough-ins, radiant floor heating loops, rainwater harvesting, and high-volume gas supply manifolds.'
        }
      ];

      for (const exp of defaultExperts) {
        await setDoc(doc(db, 'experts', exp.id), exp, { merge: true });
      }
    }

    // 3. Seed shopkeepers collection
    const shopkeepersRef = collection(db, 'shopkeepers');
    const shopkeepersSnap = await getDocs(shopkeepersRef);
    if (shopkeepersSnap.empty) {
      console.log('[Seeder] Seeding default shopkeepers...');
      const defaultSellers = [
        {
          id: 'seller-1',
          name: 'Demo Shopkeeper',
          shopName: 'ProBuild Materials Inc.',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 4.9,
          reviewsCount: 142,
          productsCount: 18,
          location: '102 Industrial Parkway, Austin, TX',
          description: 'Premier supplier of contractor-grade construction materials, red clay bricks, certified rebar, and Portland cement.',
          email: 'shopkeeper@gmail.com',
          phone: '+1 (555) 987-6543',
          yearsOfExperience: 12,
          categories: ['Bricks', 'Cement', 'Iron Rod', 'Aggregates']
        },
        {
          id: 'seller-2',
          name: 'Marcus Vance',
          shopName: 'Apex Heavy Building Supply',
          avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 4.8,
          reviewsCount: 98,
          productsCount: 24,
          location: '45 Commerce Way, Houston, TX',
          description: 'Authorized distributor for heavy structural steel, Grade 60 rebar, framing lumber, and industrial hardware.',
          email: 'apex.supplies@dreamhouse.com',
          phone: '+1 (800) 555-0192',
          yearsOfExperience: 10,
          categories: ['Steel & Rebar', 'Framing Lumber', 'Safety Gear', 'Fasteners']
        },
        {
          id: 'seller-3',
          name: 'Eleanor Hayes',
          shopName: 'BuildCraft Timber & Masonry',
          avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 5.0,
          reviewsCount: 215,
          productsCount: 32,
          location: '78 Timber Ridge Road, Seattle, WA',
          description: 'Specializing in premium Baltic birch plywood, engineered timber, and architectural masonry products.',
          email: 'buildcraft@dreamhouse.com',
          phone: '+1 (888) 444-2300',
          yearsOfExperience: 15,
          categories: ['Plywood', 'Hardwood Timber', 'Stone Veneer', 'Custom Trim']
        },
        {
          id: 'seller-4',
          name: 'Arthur Pendelton',
          shopName: 'Prime Hardware Depot',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 4.9,
          reviewsCount: 164,
          productsCount: 45,
          location: '302 Distribution Blvd, Dallas, TX',
          description: 'High-grade power tools, electrical fixtures, commercial plumbing hardware, and jobsite fasteners.',
          email: 'prime.depot@dreamhouse.com',
          phone: '+1 (555) 720-1928',
          yearsOfExperience: 14,
          categories: ['Power Tools', 'Plumbing Fixtures', 'Electrical Supplies', 'Safety']
        }
      ];

      for (const seller of defaultSellers) {
        await setDoc(doc(db, 'shopkeepers', seller.id), seller, { merge: true });
      }
    }

    // 4. Seed topExperts collection
    const topExpertsRef = collection(db, 'topExperts');
    const topExpertsSnap = await getDocs(topExpertsRef);
    if (topExpertsSnap.empty) {
      console.log('[Seeder] Seeding default topExperts...');
      const top3Experts = [
        {
          id: 'exp-top-1',
          name: 'David Chen',
          profession: 'Structural Engineer',
          yearsOfExperience: 12,
          rating: 4.9,
          reviewsCount: 86,
          completedProjects: 54,
          location: 'Austin, TX',
          tagline: 'Specializing in heavy structural analysis, foundation design, and seismic retrofitting.',
          skills: ['Structural Analysis', 'Concrete Engineering', 'FEA Modeling', 'Seismic Design', 'Building Code Review'],
          certifications: ['PE Certified Structural Engineer', 'LEED AP BD+C', 'NSPE Fellow'],
          photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?w=1000&auto=format&fit=crop&q=80',
          contact: 'david.chen@structural.com',
          phone: '+1 (555) 392-1100',
          availability: 'Available',
          bio: 'Over 12 years of experience leading complex structural engineering projects for high-end residential estates and commercial developments. Passionate about structural integrity, code compliance, and innovative material efficiency.'
        },
        {
          id: 'exp-top-2',
          name: 'Sarah Jenkins',
          profession: 'Architect & Interior Specialist',
          yearsOfExperience: 9,
          rating: 5.0,
          reviewsCount: 112,
          completedProjects: 68,
          location: 'Los Angeles, CA',
          tagline: 'Creating modern luxury interior spaces, custom spatial layouts, and architectural blueprints.',
          skills: ['3D Spatial Rendering', 'Bespoke Lighting', 'Interior Drafting', 'Material Curation', 'Sustainable Finishes'],
          certifications: ['NCIDQ Certified Designer', 'AIA Associate Member', 'ASID Professional'],
          photo: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1000&auto=format&fit=crop&q=80',
          contact: 'sarah.jenkins@designstudio.com',
          phone: '+1 (555) 482-9922',
          availability: 'Available',
          bio: 'Renowned architect and interior planner focusing on open-concept modern floor plans, daylighting optimization, and bespoke material palettes that harmonize form and function.'
        },
        {
          id: 'exp-top-3',
          name: 'Marcus Vance',
          profession: 'Master Electrician',
          yearsOfExperience: 15,
          rating: 4.9,
          reviewsCount: 94,
          completedProjects: 120,
          location: 'Houston, TX',
          tagline: 'Commercial and high-capacity residential electrical wiring, solar integrations, and smart power grids.',
          skills: ['High-Voltage Systems', 'Smart Home Automation', 'Solar Inverters', 'Circuit Load Testing', 'Backup Generators'],
          certifications: ['Master Electrician License #49201', 'OSHA 30 Construction Certified', 'IEC Master Tech'],
          photo: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&auto=format&fit=crop&q=80',
          coverPhoto: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1000&auto=format&fit=crop&q=80',
          contact: 'marcus.vance@powergrid.com',
          phone: '+1 (555) 883-2041',
          availability: 'Available',
          bio: 'Licensed Master Electrician with 15 years in utility-scale wiring, smart home automation infrastructure, and renewable energy integration. Known for zero-defect compliance and safe execution.'
        }
      ];

      for (const exp of top3Experts) {
        await setDoc(doc(db, 'topExperts', exp.id), exp, { merge: true });
      }
    }

    // 5. Seed topSellers collection
    const topSellersRef = collection(db, 'topSellers');
    const topSellersSnap = await getDocs(topSellersRef);
    if (topSellersSnap.empty) {
      console.log('[Seeder] Seeding default topSellers...');
      const top3Sellers = [
        {
          id: 'seller-1',
          name: 'Demo Shopkeeper',
          shopName: 'ProBuild Materials Inc.',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 4.9,
          reviewsCount: 142,
          productsCount: 18,
          location: '102 Industrial Parkway, Austin, TX',
          description: 'Premier supplier of contractor-grade construction materials, red clay bricks, certified rebar, and Portland cement.',
          email: 'shopkeeper@gmail.com',
          phone: '+1 (555) 987-6543',
          yearsOfExperience: 12,
          categories: ['Bricks', 'Cement', 'Iron Rod', 'Aggregates']
        },
        {
          id: 'seller-2',
          name: 'Marcus Vance',
          shopName: 'Apex Heavy Building Supply',
          avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 4.8,
          reviewsCount: 98,
          productsCount: 24,
          location: '45 Commerce Way, Houston, TX',
          description: 'Authorized distributor for heavy structural steel, Grade 60 rebar, framing lumber, and industrial hardware.',
          email: 'apex.supplies@dreamhouse.com',
          phone: '+1 (800) 555-0192',
          yearsOfExperience: 10,
          categories: ['Steel & Rebar', 'Framing Lumber', 'Safety Gear', 'Fasteners']
        },
        {
          id: 'seller-3',
          name: 'Eleanor Hayes',
          shopName: 'BuildCraft Timber & Masonry',
          avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
          bannerUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1000&auto=format&fit=crop&q=80',
          isVerified: true,
          rating: 5.0,
          reviewsCount: 215,
          productsCount: 32,
          location: '78 Timber Ridge Road, Seattle, WA',
          description: 'Specializing in premium Baltic birch plywood, engineered timber, and architectural masonry products.',
          email: 'buildcraft@dreamhouse.com',
          phone: '+1 (888) 444-2300',
          yearsOfExperience: 15,
          categories: ['Plywood', 'Hardwood Timber', 'Stone Veneer', 'Custom Trim']
        }
      ];

      for (const seller of top3Sellers) {
        await setDoc(doc(db, 'topSellers', seller.id), seller, { merge: true });
      }
    }

    // 6. Seed products and items collection
    const productsRef = collection(db, 'products');
    const productsSnap = await getDocs(productsRef);
    if (productsSnap.empty) {
      console.log('[Seeder] Seeding default products...');
      const defaultProducts = [
        {
          id: 'prod-1',
          name: 'Red Clay Bricks (2000 Pcs)',
          category: 'Bricks',
          price: 480.00,
          originalPrice: 550.00,
          image: 'https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=500&auto=format&fit=crop&q=80',
          isBestSeller: true,
          freeDelivery: true,
          brand: 'ProBrick',
          description: 'Premium red clay solid bricks with extreme load-bearing strength, perfect for heavy structural load-bearing walls and durable home foundations.',
          availableQuantity: 45,
          unit: 'Pack',
          deliveryAvailability: true,
          location: 'Austin, TX',
          contactNumber: '+1 (555) 987-6543',
          warranty: 'Lifetime Structural Warranty',
          specifications: 'Compressive Strength: >15 MPa, Size: 9x4x3 inches, Water Absorption: <8%',
          tags: ['Solid Brick', 'Clay', 'Masonry', 'Structural'],
          stockStatus: 'In Stock',
          seller: {
            id: 'seller-1',
            name: 'Demo Shopkeeper',
            shopName: 'ProBuild Materials Inc.',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            email: 'shopkeeper@gmail.com'
          }
        },
        {
          id: 'prod-2',
          name: 'OPC Portland Cement (Grade 53, 50kg)',
          category: 'Cement',
          price: 9.50,
          originalPrice: 11.00,
          image: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=500&auto=format&fit=crop&q=80',
          isBestSeller: true,
          freeDelivery: false,
          brand: 'UltraCrete',
          description: 'High-strength Grade 53 Ordinary Portland Cement (OPC) ideal for high-capacity RCC structures, heavy columns, slabs, and fast-curing jobs.',
          availableQuantity: 500,
          unit: 'Bag',
          deliveryAvailability: true,
          location: 'Austin, TX',
          contactNumber: '+1 (555) 987-6543',
          warranty: 'Shelf Life: 3 Months',
          specifications: 'Grade: 53 OPC, Standard: ASTM C150, Initial Setting Time: >45 mins',
          tags: ['RCC', 'Cement', 'Concrete', 'OPC 53'],
          stockStatus: 'In Stock',
          seller: {
            id: 'seller-1',
            name: 'Demo Shopkeeper',
            shopName: 'ProBuild Materials Inc.',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            email: 'shopkeeper@gmail.com'
          }
        },
        {
          id: 'prod-3',
          name: 'Structural Steel Rebar (Grade 60, 1 Ton)',
          category: 'Iron Rod',
          price: 920.00,
          originalPrice: 1050.00,
          image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=500&auto=format&fit=crop&q=80',
          isBestSeller: false,
          freeDelivery: true,
          brand: 'TMT Titan',
          description: 'Thermo-Mechanically Treated (TMT) high-tensile steel rebar rods. Perfect for concrete beam reinforcement and foundational safety.',
          availableQuantity: 15,
          unit: 'Ton',
          deliveryAvailability: true,
          location: 'Austin, TX',
          contactNumber: '+1 (555) 987-6543',
          warranty: 'Corrosion Resistant 10 Years',
          specifications: 'Grade: 60 TMT, Size: 12mm diameter, Length: 40 feet standard',
          tags: ['TMT Bar', 'Rebar', 'Steel Rod', 'Foundations'],
          stockStatus: 'In Stock',
          seller: {
            id: 'seller-1',
            name: 'Demo Shopkeeper',
            shopName: 'ProBuild Materials Inc.',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            email: 'shopkeeper@gmail.com'
          }
        }
      ];

      for (const prod of defaultProducts) {
        const itemData = {
          ...prod,
          ownerId: prod.seller.email,
          shopkeeperId: prod.seller.id,
          itemName: prod.name,
          imageUrl: prod.image,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        };
        await setDoc(doc(db, 'products', prod.id), itemData, { merge: true });
        await setDoc(doc(db, 'items', prod.id), itemData, { merge: true });
      }
    }
    console.log('[Seeder] Firestore check & seed completed successfully.');
  } catch (error) {
    console.warn('[Seeder] Optional Firestore seeding warning:', error);
  }
}
