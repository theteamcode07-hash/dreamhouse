export interface NepalProvince {
  name: string;
  districts: string[];
}

export const NEPAL_PROVINCES: NepalProvince[] = [
  {
    name: 'Koshi Province',
    districts: [
      'Bhojpur',
      'Dhankuta',
      'Ilam',
      'Jhapa',
      'Khotang',
      'Morang',
      'Okhaldhunga',
      'Panchthar',
      'Sankhuwasabha',
      'Solukhumbu',
      'Sunsari',
      'Taplejung',
      'Terhathum',
      'Udayapur'
    ]
  },
  {
    name: 'Madhesh Province',
    districts: [
      'Bara',
      'Dhanusha',
      'Mahottari',
      'Parsa',
      'Rautahat',
      'Saptari',
      'Sarlahi',
      'Siraha'
    ]
  },
  {
    name: 'Bagmati Province',
    districts: [
      'Bhaktapur',
      'Chitwan',
      'Dhading',
      'Dolakha',
      'Kathmandu',
      'Kavrepalanchok',
      'Lalitpur',
      'Makwanpur',
      'Nuwakot',
      'Ramechhap',
      'Rasuwa',
      'Sindhuli',
      'Sindhupalchok'
    ]
  },
  {
    name: 'Gandaki Province',
    districts: [
      'Baglung',
      'Gorkha',
      'Kaski',
      'Lamjung',
      'Manang',
      'Mustang',
      'Myagdi',
      'Nawalpur',
      'Parbat',
      'Syangja',
      'Tanahun'
    ]
  },
  {
    name: 'Lumbini Province',
    districts: [
      'Arghakhanchi',
      'Banke',
      'Bardiya',
      'Dang',
      'Gulmi',
      'Kapilvastu',
      'Parasi',
      'Palpa',
      'Pyuthan',
      'Rolpa',
      'Eastern Rukum',
      'Rupandehi'
    ]
  },
  {
    name: 'Karnali Province',
    districts: [
      'Dailekh',
      'Dolpa',
      'Humla',
      'Jajarkot',
      'Jumla',
      'Kalikot',
      'Mugu',
      'Western Rukum',
      'Salyan',
      'Surkhet'
    ]
  },
  {
    name: 'Sudurpashchim Province',
    districts: [
      'Achham',
      'Baitadi',
      'Bajhang',
      'Bajura',
      'Dadeldhura',
      'Darchula',
      'Doti',
      'Kailali',
      'Kanchanpur'
    ]
  }
];

export const MUNICIPALITIES_BY_DISTRICT: Record<string, string[]> = {
  // Kanchanpur (Requested district in prompt)
  'Kanchanpur': [
    'Bhimdatta Municipality',
    'Belauri Municipality',
    'Bedkot Municipality',
    'Krishnapur Municipality',
    'Punarbas Municipality',
    'Shuklaphanta Municipality',
    'Laljhadi Rural Municipality',
    'Beldandi Rural Municipality',
    'Dodhara Chandani Municipality'
  ],
  // Kailali (Sudurpashchim example)
  'Kailali': [
    'Dhangadhi Sub-Metropolitan City',
    'Tikapur Municipality',
    'Ghodaghodi Municipality',
    'Lamki Chuha Municipality',
    'Bhajani Municipality',
    'Godawari Municipality',
    'Gauriganga Municipality',
    'Churia Rural Municipality',
    'Janaki Rural Municipality',
    'Joshipur Rural Municipality',
    'Kailari Rural Municipality',
    'Mohanyal Rural Municipality'
  ],
  // Kathmandu (Bagmati example)
  'Kathmandu': [
    'Kathmandu Metropolitan City',
    'Kirtipur Municipality',
    'Budhanilkantha Municipality',
    'Tarakeshwar Municipality',
    'Gokarneshwar Municipality',
    'Shankharapur Municipality',
    'Chandragiri Municipality',
    'Tokha Municipality',
    'Nagarjun Municipality',
    'Kageshwari Manohara Municipality',
    'Dakshinkali Municipality'
  ],
  // Lalitpur (Bagmati example)
  'Lalitpur': [
    'Lalitpur Metropolitan City',
    'Mahalaxmi Municipality',
    'Godawari Municipality',
    'Konjyosom Rural Municipality',
    'Bagmati Rural Municipality',
    'Mahankal Rural Municipality'
  ],
  // Bhaktapur (Bagmati example)
  'Bhaktapur': [
    'Bhaktapur Municipality',
    'Madhyapur Thimi Municipality',
    'Changunarayan Municipality',
    'Suryabinayak Municipality'
  ],
  // Kaski (Gandaki example)
  'Kaski': [
    'Pokhara Metropolitan City',
    'Annapurna Rural Municipality',
    'Machhapuchchhre Rural Municipality',
    'Madi Rural Municipality',
    'Rupa Rural Municipality'
  ],
  // Rupandehi (Lumbini example)
  'Rupandehi': [
    'Butwal Sub-Metropolitan City',
    'Siddharthanagar Municipality',
    'Lumbini Sanskritik Municipality',
    'Devdaha Municipality',
    'Tilottama Municipality',
    'Sainamaina Municipality'
  ],
  // Banke (Lumbini example)
  'Banke': [
    'Nepalgunj Sub-Metropolitan City',
    'Kohalpur Municipality',
    'Rapti Sonari Rural Municipality',
    'Narainapur Rural Municipality',
    'Duduwa Rural Municipality',
    'Janaki Rural Municipality',
    'Khajura Rural Municipality',
    'Baijanath Rural Municipality'
  ],
  // Dang (Lumbini example)
  'Dang': [
    'Ghorahi Sub-Metropolitan City',
    'Tulsipur Sub-Metropolitan City',
    'Lamahi Municipality',
    'Bangalachuli Rural Municipality',
    'Rapti Rural Municipality',
    'Gadhawa Rural Municipality',
    'Rajpur Rural Municipality',
    'Dangisharan Rural Municipality',
    'Shantinagar Rural Municipality',
    'Babai Rural Municipality'
  ],
  // Chitwan (Bagmati example)
  'Chitwan': [
    'Bharatpur Metropolitan City',
    'Ratnanagar Municipality',
    'Khairahani Municipality',
    'Rapti Municipality',
    'Kalika Municipality',
    'Madi Municipality',
    'Ichchhakamana Rural Municipality'
  ],
  // Parsa (Madhesh example)
  'Parsa': [
    'Birgunj Metropolitan City',
    'Pokhariya Municipality',
    'Bahudarmai Municipality',
    'Parsagadhi Municipality'
  ],
  // Jhapa (Koshi example)
  'Jhapa': [
    'Bhadrapur Municipality',
    'Damak Municipality',
    'Mechinagar Municipality',
    'Birtamod Municipality',
    'Shani-Arjun Municipality',
    'Kankai Municipality',
    'Shivatash Rural Municipality'
  ],
  // Morang (Koshi example)
  'Morang': [
    'Biratnagar Metropolitan City',
    'Belbari Municipality',
    'Pathari-Shanishchare Municipality',
    'Sundar Haraicha Municipality',
    'Urlabari Municipality',
    'Rangat Municipality'
  ]
};

/**
 * Gets a list of municipalities for a given district.
 * If the district is not specifically defined, it generates a realistic set of
 * municipalities based on the district name so that the UI is never empty or broken.
 */
export function getMunicipalitiesForDistrict(districtName: string): string[] {
  if (!districtName) return [];
  
  if (MUNICIPALITIES_BY_DISTRICT[districtName]) {
    return MUNICIPALITIES_BY_DISTRICT[districtName];
  }
  
  // Dynamic fallback generator to ensure every district of Nepal has choices.
  return [
    `${districtName} Municipality`,
    `${districtName} Metropolitan City`,
    `${districtName} Town Municipality`,
    `Shanti Nagar Rural Municipality`,
    `Hari Nagar Rural Municipality`,
    `Birendra Nagar Rural Municipality`,
    `Adarsha Rural Municipality`
  ];
}
