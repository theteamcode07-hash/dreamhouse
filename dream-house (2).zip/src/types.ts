export type UserRole = 'homeowner' | 'professional' | 'shopkeeper' | 'admin';

export function resolveWorkspaceRoleFromDoc(pData: any): UserRole {
  if (!pData) return 'homeowner';

  const email = String(pData.email || '').toLowerCase().trim();
  const rawRole = String(pData.role || '').toLowerCase().trim();
  const rawType = String(pData.accountType || pData.type || '').toLowerCase().trim();
  const rawWsRole = String(pData.workspaceRole || '').toLowerCase().trim();

  // 1. Admin or Super Admin
  if (
    email === 'theteamcode07@gmail.com' ||
    rawRole === 'admin' || rawRole === 'super_admin' || rawRole === 'superadmin' ||
    rawType === 'admin' || rawType === 'super admin' || rawType === 'superadmin' ||
    rawWsRole === 'admin' || rawWsRole.includes('admin')
  ) {
    return 'admin';
  }

  // 2. Expert / Professional / Worker / Engineer / Architect
  if (
    rawRole === 'professional' || rawRole === 'expert' ||
    rawType === 'expert' || rawType === 'professional' ||
    rawWsRole.includes('expert') || rawWsRole.includes('professional') || rawWsRole.includes('worker') || rawWsRole.includes('engineer') || rawWsRole.includes('architect') ||
    rawRole.includes('engineer') || rawRole.includes('architect') || rawRole.includes('worker') ||
    rawType.includes('expert') || rawType.includes('professional')
  ) {
    return 'professional';
  }

  // 3. Shopkeeper / Vendor
  if (
    rawRole === 'shopkeeper' || rawType === 'shopkeeper' ||
    rawWsRole.includes('shopkeeper') || rawWsRole.includes('vendor') || rawWsRole.includes('seller') ||
    rawRole.includes('vendor') || rawRole.includes('shop') ||
    rawType.includes('shopkeeper') || rawType.includes('vendor')
  ) {
    return 'shopkeeper';
  }

  // 4. Client / Homeowner
  return 'homeowner';
}

export interface CartItem {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  qty: number;
  image: string;
  freeDelivery?: boolean;
  seller?: SellerInfo;
  unit?: string;
  allowedUnits?: string[];
  unitPrices?: Record<string, number>;
  unitStocks?: Record<string, number>;
}

export interface SellerInfo {
  id?: string;
  name: string;
  shopName: string;
  avatar: string;
  isVerified?: boolean;
  rating?: number;
  reviewsCount?: number;
  email: string;
  phone?: string;
  location?: string;
  bio?: string;
  yearsOfExperience?: number;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  isBestSeller?: boolean;
  freeDelivery?: boolean;
  isDraft?: boolean;
  brand?: string;
  description?: string;
  availableQuantity?: number;
  unit?: string;
  allowedUnits?: string[];
  unitPrices?: Record<string, number>;
  unitStocks?: Record<string, number>;
  deliveryAvailability?: boolean;
  location?: string;
  contactNumber?: string;
  warranty?: string;
  specifications?: string;
  tags?: string[];
  stockStatus?: string;
  seller?: SellerInfo;
}

export interface CanvasRoom {
  id: string;
  name: string;
  width: number; // in feet
  length: number; // in feet
  x: number; // percentage or pixels
  y: number; // percentage or pixels
  color?: string;
}

export interface ProjectService {
  id: string;
  name: string;
  phase: string;
  status: string;
  dueDate: string;
  icon: string;
}

export interface RecentInspiration {
  id: string;
  title: string;
  author: string;
  image: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage?: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  shopkeeperId?: string;
  shopkeeperName?: string;
  unit?: string;
}

export interface Order {
  id: string;
  customer: string;
  clientId?: string;
  clientName?: string;
  clientEmail?: string;
  productId?: string;
  productName?: string;
  productImage?: string;
  quantity?: number;
  unitPrice?: number;
  totalPrice?: number;
  amount?: number;
  shopkeeperId?: string;
  shopkeeperName?: string;
  shopkeeperEmail?: string;
  sellerEmail?: string;
  seller?: SellerInfo;
  date: string;
  status: 'Pending' | 'Confirmed' | 'Processing' | 'Packed' | 'Shipping' | 'Shipped' | 'Delivered' | 'Cancelled' | 'Refunded';
  paymentStatus?: 'Paid' | 'Pending' | 'Failed' | 'Pending Verification';
  paymentMethod?: string;
  paymentId?: string;
  transactionId?: string;
  paidAmount?: number;
  paymentTime?: string;
  customerPhone?: string;
  customerEmail?: string;
  shippingAddress?: string;
  createdAt?: string;
  updatedAt?: string;
  items?: OrderItem[];
  cancelledAt?: string;
  cancelledBy?: 'Client' | 'Seller' | 'Admin';
  cancellationReason?: string;
  refundStatus?: 'Refund Initiated' | 'Refund Processing' | 'Refunded';
  refundEstimatedTime?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  qty: string | number;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
}

export interface LeadOpportunity {
  id: string;
  title: string;
  location: string;
  status?: string;
  contact: string;
  timeAgo: string;
}

export interface ScheduleEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
}

export interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
  timestamp: number;
  read?: boolean;
  orderId?: string;
  roleScope?: UserRole | 'all';
}

export interface WebsiteConfig {
  siteName: string;
  logoUrl: string;
  heroBannerUrl: string;
  heroTitle: string;
  heroSubtitle: string;
  roleSelectorTitle: string;
  roleSelectorSubtitle: string;
  joinButtonText: string;
  footerTagline?: string;
  copyrightText?: string;
  contactEmail?: string;
  contactPhone?: string;
  officeAddress?: string;
  socialLinks?: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
    twitter?: string;
    youtube?: string;
  };
  loginPageLogo?: string;
  footerLogo?: string;
  splashScreenLogo?: string;
  heroBannerImage?: string;
  websiteFavicon?: string;
}

export type CMSContentType = 
  | 'branding'
  | 'banner'
  | 'homepage_section'
  | 'category'
  | 'expert'
  | 'shopkeeper'
  | 'product'
  | 'service'
  | 'house_plan'
  | 'gallery'
  | 'review'
  | 'faq'
  | 'contact_social'
  | 'navigation'
  | 'button_icon';

export interface CMSItem {
  id: string;
  title: string;
  contentType: CMSContentType;
  category?: string;
  type?: string;
  description?: string;
  imageUrl?: string;
  price?: number;
  originalPrice?: number;
  status: 'Published' | 'Draft';
  isEnabled: boolean; // Active / Disabled
  createdAt: string;
  updatedAt: string;
  authorOrUser?: string;
  roleScope?: string;
  rating?: number;
  reviewsCount?: number;
  skillsOrTags?: string[];
  location?: string;
  contactNumberOrEmail?: string;
  extraData?: Record<string, any>;
}

export interface Expert {
  id: string;
  name: string;
  role: string;
  yearsOfExperience: number;
  skills: string[];
  location: string;
  contact: string;
  availability: 'Available' | 'Busy';
  rating: number;
  reviews: number;
  photo: string;
}

export interface Draft {
  id: string;
  name: string;
  date: string;
  rooms: number;
}

export interface AdminUser {
  id: string;
  uid?: string;
  fullName: string;
  email: string;
  phone: string;
  accountType: 'Homeowner' | 'Expert' | 'Shopkeeper' | 'Admin';
  registrationDate: string;
  registrationDateTime?: string;
  createdAt?: string;
  status: 'Pending' | 'Active' | 'Suspended' | 'Rejected' | 'Deleted' | 'Disabled';
  accountStatus?: 'Pending' | 'Active' | 'Suspended' | 'Rejected' | 'Deleted' | 'Disabled';
  approvalStatus?: 'Pending' | 'Approved' | 'Rejected';
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  statusHistory?: Array<{ status: string; approvalStatus?: string; updatedBy: string; updatedAt: string; note?: string }>;
  approvalLogs?: Array<{ action: string; performedBy: string; timestamp: string; details?: string }>;
  lastUpdatedBy?: string;
  statusLastUpdated?: string;
  lastLogin: string;
  avatar: string;
  professionType?: string;
  professionalTitle?: string;
  yearsOfExperience?: number;
  emailVerified?: 'Verified' | 'Unverified';
  rating?: number;
  reviews?: number;
  skillsOrTags?: string[];
  location?: string;
  address?: string;
  province?: string;
  district?: string;
  municipality?: string;
  bio?: string;
  about?: string;
  certifications?: string;
  shopName?: string;
  businessCategory?: string;
  shopAddress?: string;
  businessRegistrationNumber?: string;
  shopDescription?: string;
  coverPhoto?: string;
  username?: string;
  languages?: string;
  availability?: string;
  lastActive?: string;
  productsCount?: number;
  ordersCount?: number;
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  senderName?: string;
  deliveryChannels?: string[];
  targetAudience?: 'All' | 'homeowner' | 'professional' | 'shopkeeper' | 'individual';
  targetRole?: string;
  targetUserId?: string;
  targetUserEmail?: string;
  createdAt: string;
  updatedAt?: string;
  isPinned?: boolean;
  priority?: 'High' | 'Normal' | 'Urgent';
  actionUrl?: string;
  scheduleTime?: string;
  emailStatus?: 'pending' | 'delivered' | 'failed' | 'partially_failed';
  emailError?: string;
}

export const DEFAULT_WEBSITE_CONFIG: WebsiteConfig = {
  siteName: 'Dream House',
  logoUrl: '',
  heroBannerUrl: '',
  heroTitle: 'Build Your Vision.',
  heroSubtitle: 'Join the premier platform for homeowners, architects, and contractors to conceptualize, supply, and finalize modern blueprints.',
  roleSelectorTitle: 'Select Your Role',
  roleSelectorSubtitle: 'Choose how you want to interact with the Dream House platform to access the tools and features tailored to your needs.',
  joinButtonText: 'Join Dream House',

  loginPageLogo: '',
  footerLogo: '',
  splashScreenLogo: '',
  heroBannerImage: '',
  websiteFavicon: '',
};

