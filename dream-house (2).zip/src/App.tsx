import React, { useState, useEffect, useRef } from 'react';
import { UserRole, CartItem, Order, Product, ToastNotification, WebsiteConfig, AdminUser, DEFAULT_WEBSITE_CONFIG, resolveWorkspaceRoleFromDoc } from './types';
import AuthScreen from './components/AuthScreen';
import RoleSelector from './components/RoleSelector';
import LoadingScreen from './components/LoadingScreen';
import UserDashboard from './components/UserDashboard';
import FloorPlanBuilder from './components/FloorPlanBuilder';
import MaterialShop from './components/MaterialShop';
import AdminDashboard from './components/AdminDashboard';
import ProfessionalDashboard from './components/ProfessionalDashboard';
import ShopkeeperDashboard from './components/ShopkeeperDashboard';
import ShopkeepersView from './components/ShopkeepersView';
import ShoppingCartPage from './components/ShoppingCartPage';
import CheckoutPage from './components/CheckoutPage';
import OrderSuccessPage from './components/OrderSuccessPage';
import { ToastContainer } from './components/ToastNotificationSystem';
import { collection, onSnapshot, doc, getDoc, setDoc, updateDoc, deleteDoc, query, where, getDocs, serverTimestamp, getDocFromServer } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { db, auth, handleFirestoreError, OperationType } from './lib/firebase';
import { Sun, Moon, ArrowLeft } from 'lucide-react';
import { startPresenceHeartbeat, subscribeToPresence } from './lib/presence';

import { useTheme } from './lib/theme';

export default function App() {
  const { theme, toggleTheme } = useTheme();

  const [activeView, setActiveView] = useState<'auth' | 'roles' | 'dashboard' | 'floor_plans' | 'shop' | 'shopkeepers' | 'cart' | 'checkout' | 'order-success'>('auth');
  const [currentRole, setCurrentRole] = useState<UserRole>('homeowner');
  const [username, setUsername] = useState<string>('');
  const [userAvatar, setUserAvatar] = useState<string>('https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80');

  // Multi-role state syncing
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('dreamhouse_cart');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {
        // use empty
      }
    }
    return [];
  });

  const [savedItems, setSavedItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('dreamhouse_saved_items');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {
        // use empty
      }
    }
    return [];
  });

  const [userAddress, setUserAddress] = useState<string>('');
  const [recentCompletedOrder, setRecentCompletedOrder] = useState<Order | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('dreamhouse_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.warn("Could not save cart to localStorage", e);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('dreamhouse_saved_items', JSON.stringify(savedItems));
    } catch (e) {
      console.warn("Could not save savedItems to localStorage", e);
    }
  }, [savedItems]);
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('dreamhouse_orders');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [];
  });

  // Products state syncing
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('dreamhouse_products');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {
        // use default
      }
    }
    return [];
  });

  // Admin users state syncing
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() => {
    const saved = localStorage.getItem('dreamhouse_admin_users');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter((u: any) => 
            u && 
            u.status !== 'Deleted' && 
            u.accountStatus !== 'Deleted' && 
            !u.isDeleted
          );
        }
      } catch (e) {
        // ignore
      }
    }
    return [];
  });

  // Master user email tracker to synchronize profile details
  const [userEmail, setUserEmail] = useState<string>(() => {
    return localStorage.getItem('dreamhouse_current_user_email') || '';
  });

  const [currentUid, setCurrentUid] = useState<string>(() => auth.currentUser?.uid || '');
  const lastUserUidRef = useRef<string | null>(auth.currentUser?.uid || null);

  const [presenceMap, setPresenceMap] = useState<Record<string, boolean>>({});

  // Real-time presence listener across the app
  useEffect(() => {
    const unsub = subscribeToPresence((pMap) => setPresenceMap(pMap));
    return () => unsub();
  }, []);

  // Start heartbeat for logged-in user
  useEffect(() => {
    if (!userEmail) return;
    const cleanupHeartbeat = startPresenceHeartbeat(userEmail, username || 'User');
    return () => cleanupHeartbeat();
  }, [userEmail, username]);

  // Real-time factory reset listener: if admin performs factory reset and deletes user account, sign out immediately
  useEffect(() => {
    if (!currentUid) return;
    const adminEmail = 'theteamcode07@gmail.com';
    if (userEmail.toLowerCase() === adminEmail) return;

    const userDocRef = doc(db, 'accounts', currentUid);
    const unsubFactoryReset = onSnapshot(userDocRef, async (docSnap) => {
      if (!docSnap.exists() && auth.currentUser) {
        console.log("[App] Account deleted via Factory Reset. Terminating session...");
        alert("A system factory reset was performed by the administrator. Your account has been removed. Please log in again.");
        await auth.signOut();
      }
    }, (err) => {
      console.warn("Factory reset watch warning:", err);
    });

    return () => unsubFactoryReset();
  }, [currentUid, userEmail]);

  // Synchronize authenticated Firebase user state and load user profile from Firestore by UID
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (user) {
        if (lastUserUidRef.current !== user.uid) {
          // A different or new user logged in! Clear states and localStorage instantly to prevent carryover
          setCartItems([]);
          setSavedItems([]);
          localStorage.removeItem('dreamhouse_cart');
          localStorage.removeItem('dreamhouse_saved_items');
          lastUserUidRef.current = user.uid;
        }
        setCurrentUid(user.uid);
        try {
          const userDocRef = doc(db, 'accounts', user.uid);
          const docSnap = await getDoc(userDocRef);
          let pData: any = null;
          if (docSnap.exists()) {
            pData = docSnap.data();
          } else if (user.email) {
            const userEmailLower = user.email.toLowerCase();
            const qAcc = query(collection(db, 'accounts'), where('email', '==', userEmailLower));
            const snap = await getDocs(qAcc);
            if (!snap.empty) {
              pData = snap.docs[0].data();
            } else {
              const qUsers = query(collection(db, 'users'), where('email', '==', userEmailLower));
              const snapUsers = await getDocs(qUsers);
              if (!snapUsers.empty) {
                pData = snapUsers.docs[0].data();
              }
            }
          }

          if (pData) {
            const email = pData.email || user.email || '';
            const accStatus = String(pData.accountStatus || pData.status || 'Active').trim().toLowerCase();
            const appStatus = String(pData.approvalStatus || '').trim().toLowerCase();
            const isPending = accStatus === 'pending' || appStatus === 'pending';
            const isRejected = accStatus === 'rejected' || appStatus === 'rejected';
            const isSuspended = accStatus === 'suspended';

            // Strictly check for 'deleted' status and 'recoverable' flag in the Firestore account document
            const isDeleted = accStatus === 'deleted' ||
                              accStatus === 'disabled' ||
                              pData.isDeleted === true ||
                              !!pData.deletedAt;
            const isRecoverable = pData.recoverable !== false &&
                                  pData.recoveryAvailable !== 'No' &&
                                  pData.permanentDelete !== true;

            // Admin accounts ignore deletion/recovery checks UNLESS specifically marked as deleted
            const isAdminRole = email.toLowerCase() === 'theteamcode07@gmail.com' || (pData.role || '').toLowerCase() === 'admin';
            const isAdminNotDeleted = isAdminRole && !isDeleted;

            if ((isPending || isRejected || isSuspended || isDeleted) && !isAdminNotDeleted) {
              console.log(`[App.tsx Auth] User ${email} status check (accStatus: '${accStatus}', isDeleted: ${isDeleted}, isRecoverable: ${isRecoverable}, isAdminNotDeleted: ${isAdminNotDeleted}). Signing out...`);
              await auth.signOut();
              setCurrentUid('');
              setUserEmail('');
              setUsername('');
              setUserAvatar('https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80');
              setCartItems([]);
              setSavedItems([]);
              setRecentCompletedOrder(null);
              localStorage.removeItem('dreamhouse_current_user_email');
              localStorage.removeItem('dreamhouse_cart');
              localStorage.removeItem('dreamhouse_saved_items');
              localStorage.removeItem('dreamhouse_orders');
              localStorage.removeItem('dreamhouse_messages');
              return;
            }

            const fullName = pData.fullName || pData.username || user.displayName || email.split('@')[0];
            const avatar = pData.avatar || user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80';
            const realRole = resolveWorkspaceRoleFromDoc(pData);

            setUserEmail(email);
            setUsername(fullName);
            setUserAvatar(avatar);
            setCurrentRole(realRole);
            localStorage.setItem('dreamhouse_current_user_email', email);
          } else if (user.email) {
            setUserEmail(user.email);
            setUsername(user.displayName || user.email.split('@')[0]);
            setUserAvatar(user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80');
            localStorage.setItem('dreamhouse_current_user_email', user.email);
          }
        } catch (err) {
          console.warn("Error loading profile on auth state change:", err);
        }
      } else {
        // User logged out
        setCurrentUid('');
        setUserEmail('');
        setUsername('');
        setUserAvatar('https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80');
        setCartItems([]);
        setSavedItems([]);
        setRecentCompletedOrder(null);
        sessionStorage.clear();
        localStorage.removeItem('dreamhouse_current_user_email');
        localStorage.removeItem('dreamhouse_cart');
        localStorage.removeItem('dreamhouse_saved_items');
        localStorage.removeItem('dreamhouse_orders');
        localStorage.removeItem('dreamhouse_messages');
        localStorage.removeItem('dreamhouse_2d_projects');
        localStorage.removeItem('dreamhouse_2d_current_plan');
        localStorage.removeItem('dreamhouse_announcement_cache');
        localStorage.removeItem('dreamhouse_unread_announcements_count');
        localStorage.removeItem('dreamhouse_user_session_cache');
      }
    });

    return () => unsub();
  }, []);

  const cartKey = currentUid || auth.currentUser?.uid || userEmail;

  // Helper to sync cart changes to Firebase document
  const syncCartToFirebase = async (items: CartItem[], saved: CartItem[]) => {
    const key = currentUid || auth.currentUser?.uid || userEmail;
    if (!key) return;
    try {
      const cleanItems = JSON.parse(JSON.stringify(items));
      const cleanSaved = JSON.parse(JSON.stringify(saved));
      await setDoc(doc(db, 'carts', key), {
        items: cleanItems,
        saved: cleanSaved,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error syncing cart to Firebase:", error);
    }
  };

  // Real-time Firebase-synchronized Shopping Cart listener
  useEffect(() => {
    const key = currentUid || auth.currentUser?.uid || userEmail;
    if (!key) {
      setCartItems([]);
      setSavedItems([]);
      return;
    }

    const unsub = onSnapshot(doc(db, 'carts', key), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data) {
          const remoteItems = Array.isArray(data.items) ? data.items : [];
          const remoteSaved = Array.isArray(data.saved) ? data.saved : [];

          // Deep comparison prevents infinite render loops
          setCartItems((currentLocalItems) => {
            if (JSON.stringify(currentLocalItems) !== JSON.stringify(remoteItems)) {
              return remoteItems;
            }
            return currentLocalItems;
          });

          setSavedItems((currentLocalSaved) => {
            if (JSON.stringify(currentLocalSaved) !== JSON.stringify(remoteSaved)) {
              return remoteSaved;
            }
            return currentLocalSaved;
          });
        }
      } else {
        // Cart does not exist yet for new user
        setCartItems([]);
        setSavedItems([]);
      }
    });

    return () => unsub();
  }, [currentUid, userEmail]);

  useEffect(() => {
    localStorage.setItem('dreamhouse_admin_users', JSON.stringify(adminUsers));
  }, [adminUsers]);

  // Dynamically synchronize the currently logged-in user's name and avatar in real-time across all views
  useEffect(() => {
    if (!userEmail) return;
    const currentUser = adminUsers.find(u => u.email && u.email.toLowerCase() === userEmail.toLowerCase());
    if (currentUser) {
      if (currentUser.fullName && currentUser.fullName !== username) {
        setUsername(currentUser.fullName);
      }
      if (currentUser.avatar && currentUser.avatar !== userAvatar) {
        setUserAvatar(currentUser.avatar);
      }
    }
  }, [adminUsers, userEmail, username, userAvatar]);

  // Real-time Firestore synchronization for Accounts across all connected devices
  useEffect(() => {
    // Ensure the default admin profile metadata is present without overwriting stored password
    const ensureAdminInFirestore = async () => {
      try {
        const uid = 'demo-admin-theteamcode07';
        const adminDocRef = doc(db, 'accounts', uid);
        const adminDocSnap = await getDoc(adminDocRef);
        if (!adminDocSnap.exists()) {
          await setDoc(adminDocRef, {
            id: uid,
            fullName: 'kishor joshi',
            email: 'theteamcode07@gmail.com',
            phone: '9876543213',
            role: 'admin',
            accountType: 'Admin',
            registrationDate: 'Jul 24, 2026',
            status: 'Active',
            statusLastUpdated: new Date().toLocaleString('en-US'),
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
            emailVerified: 'Verified'
          }, { merge: true });
        }
      } catch (e: any) {
        console.warn("Notice updating admin in Firestore:", e.message);
      }
    };
    ensureAdminInFirestore();

    const unsubscribe = onSnapshot(collection(db, 'accounts'), (snapshot) => {
      if (!snapshot.empty) {
        const firestoreUsers: AdminUser[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (data && (data.email || data.fullName)) {
            // Permanently purge soft-deleted users
            if (data.isDeleted === true || data.status === 'Deleted' || data.accountStatus === 'Deleted') {
              deleteDoc(doc(db, 'accounts', docSnap.id)).catch(() => {});
              deleteDoc(doc(db, 'users', docSnap.id)).catch(() => {});
              if (data.email) {
                const cleanEmail = data.email.trim().toLowerCase();
                fetch('/api/admin/delete-user', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ uid: docSnap.id, email: cleanEmail }),
                }).catch(() => {});
              }
              return;
            }
            firestoreUsers.push({
              id: docSnap.id || data.id || `acc-${Date.now()}`,
              uid: docSnap.id || data.uid || data.id,
              fullName: data.fullName || data.username || data.email || 'User',
              email: data.email || '',
              phone: data.phone || 'N/A',
              accountType: data.accountType || (data.role === 'admin' ? 'Admin' : data.role === 'professional' ? 'Expert' : data.role === 'shopkeeper' ? 'Shopkeeper' : 'Homeowner'),
              registrationDate: data.registrationDate || new Date().toLocaleDateString('en-US'),
              registrationDateTime: data.registrationDateTime || data.createdAt || data.registrationDate || new Date().toLocaleString('en-US'),
              createdAt: data.createdAt || data.registrationDate || new Date().toISOString(),
              status: (data.accountStatus || data.status || 'Pending') as any,
              accountStatus: (data.accountStatus || data.status || 'Pending') as any,
              approvalStatus: (data.approvalStatus || (data.status === 'Active' ? 'Approved' : 'Pending')) as any,
              approvedBy: data.approvedBy,
              approvedAt: data.approvedAt,
              rejectedBy: data.rejectedBy,
              rejectedAt: data.rejectedAt,
              statusHistory: Array.isArray(data.statusHistory) ? data.statusHistory : [],
              approvalLogs: Array.isArray(data.approvalLogs) ? data.approvalLogs : [],
              lastUpdatedBy: data.lastUpdatedBy,
              statusLastUpdated: data.statusLastUpdated || data.registrationDate,
              lastLogin: data.lastLogin || 'Never Logged In',
              avatar: data.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
              professionType: data.professionType || data.professionalTitle || '',
              professionalTitle: data.professionalTitle || data.professionType || '',
              yearsOfExperience: data.yearsOfExperience !== undefined ? Number(data.yearsOfExperience) : undefined,
              emailVerified: data.emailVerified || 'Verified',
              rating: data.rating !== undefined ? Number(data.rating) : 5.0,
              reviews: data.reviews !== undefined ? Number(data.reviews) : (data.reviewsCount !== undefined ? Number(data.reviewsCount) : 0),
              skillsOrTags: Array.isArray(data.skillsOrTags) ? data.skillsOrTags : (Array.isArray(data.skills) ? data.skills : []),
              location: data.location || (data.address ? `${data.address}, ${data.district || ''}` : 'Not specified'),
              address: data.address || '',
              province: data.province || '',
              district: data.district || '',
              municipality: data.municipality || '',
              bio: data.bio || data.about || '',
              about: data.about || data.bio || '',
              certifications: data.certifications || '',
              shopName: data.shopName || '',
              businessCategory: data.businessCategory || '',
              shopAddress: data.shopAddress || data.address || '',
              businessRegistrationNumber: data.businessRegistrationNumber || '',
              productsCount: data.productsCount !== undefined ? Number(data.productsCount) : undefined,
              ordersCount: data.ordersCount !== undefined ? Number(data.ordersCount) : undefined
            });
          }
        });

        setAdminUsers((currentAdminUsers) => {
          if (JSON.stringify(currentAdminUsers) !== JSON.stringify(firestoreUsers)) {
            return firestoreUsers;
          }
          return currentAdminUsers;
        });
        try {
          localStorage.setItem('dreamhouse_admin_users', JSON.stringify(firestoreUsers));
        } catch (e) {}
      } else {
        // Ensure system admin account is present
        const uid = 'demo-admin-theteamcode07';
        setDoc(doc(db, 'accounts', uid), {
          id: uid,
          fullName: 'kishor joshi',
          email: 'theteamcode07@gmail.com',
          phone: '9876543213',
          password: 'admin1234',
          role: 'admin',
          accountType: 'Admin',
          registrationDate: new Date().toLocaleString('en-US'),
          status: 'Active',
          statusLastUpdated: new Date().toLocaleString('en-US'),
          lastLogin: 'Never Logged In',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
          emailVerified: 'Verified',
          createdAt: new Date().toISOString()
        }, { merge: true }).catch((e: any) => {
          console.warn("Seeding error:", e.message);
        });
      }
    }, (err) => {
      console.warn("Firestore onSnapshot error for accounts:", err.message);
    });

    return () => unsubscribe();
  }, []);

  // Real-time Firestore synchronization for Products and Items
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'products'), (snapshot) => {
      const firestoreProducts: Product[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data) {
          firestoreProducts.push({
            id: docSnap.id || data.id,
            name: data.name || data.itemName || 'Untitled Product',
            category: data.category || 'Materials',
            price: Number(data.price) || 0,
            originalPrice: data.originalPrice ? Number(data.originalPrice) : undefined,
            image: data.image || data.imageUrl || 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=500&auto=format&fit=crop&q=80',
            isBestSeller: Boolean(data.isBestSeller),
            freeDelivery: Boolean(data.freeDelivery),
            isDraft: Boolean(data.isDraft),
            brand: data.brand,
            description: data.description,
            availableQuantity: data.availableQuantity !== undefined ? Number(data.availableQuantity) : undefined,
            unit: data.unit,
            deliveryAvailability: data.deliveryAvailability !== undefined ? Boolean(data.deliveryAvailability) : undefined,
            location: data.location,
            contactNumber: data.contactNumber,
            warranty: data.warranty,
            specifications: data.specifications,
            tags: Array.isArray(data.tags) ? data.tags : undefined,
            stockStatus: data.stockStatus,
            seller: data.seller
          });
        }
      });
      setProducts((currentProducts) => {
        if (JSON.stringify(currentProducts) !== JSON.stringify(firestoreProducts)) {
          return firestoreProducts;
        }
        return currentProducts;
      });
      try {
        localStorage.setItem('dreamhouse_products', JSON.stringify(firestoreProducts));
      } catch (e) {}

      if (snapshot.empty) {
        // If Firestore is empty, sync any local products to Firestore
        const saved = localStorage.getItem('dreamhouse_products');
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              parsed.forEach((prod: Product) => {
                const itemData = {
                  ...prod,
                  ownerId: prod.seller?.email || 'shopkeeper@gmail.com',
                  itemName: prod.name,
                  imageUrl: prod.image,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp()
                };
                setDoc(doc(db, 'products', prod.id), cleanUndefined(itemData)).catch(() => {});
                setDoc(doc(db, 'items', prod.id), cleanUndefined(itemData)).catch(() => {});
              });
            }
          } catch (e) {}
        }
      }
    }, (err) => {
      console.warn("Firestore onSnapshot error for products:", err.message);
    });

    return () => unsubscribe();
  }, []);

  // Validate Firestore Connection on boot
  useEffect(() => {
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'orders', 'test-connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();
  }, []);

  // Real-time Firestore synchronization for Orders across all connected devices
  useEffect(() => {
    if (!currentUid && !auth.currentUser) {
      setOrders([]);
      return;
    }
    const pathForOrders = 'orders';
    const unsubscribe = onSnapshot(collection(db, pathForOrders), (snapshot) => {
      const firestoreOrders: Order[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data) {
          firestoreOrders.push({
            id: docSnap.id || data.id,
            customer: data.customer || data.clientName || 'Customer',
            clientId: data.clientId || data.clientEmail || '',
            clientName: data.clientName || data.customer || 'Customer',
            clientEmail: data.clientEmail || '',
            productId: data.productId || '',
            productName: data.productName || '',
            productImage: data.productImage || '',
            quantity: data.quantity !== undefined ? Number(data.quantity) : 1,
            unitPrice: data.unitPrice !== undefined ? Number(data.unitPrice) : 0,
            totalPrice: data.totalPrice !== undefined ? Number(data.totalPrice) : (data.amount !== undefined ? Number(data.amount) : 0),
            amount: data.amount !== undefined ? Number(data.amount) : (data.totalPrice !== undefined ? Number(data.totalPrice) : 0),
            shopkeeperId: data.shopkeeperId || '',
            shopkeeperName: data.shopkeeperName || '',
            date: data.date || (data.createdAt ? new Date(data.createdAt).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }) : new Date().toLocaleDateString('en-US')),
            status: data.status || 'Processing',
            paymentStatus: data.paymentStatus || 'Paid',
            shippingAddress: data.shippingAddress || 'Jobsite Address',
            createdAt: data.createdAt || new Date().toISOString(),
            updatedAt: data.updatedAt || new Date().toISOString(),
            items: Array.isArray(data.items) ? data.items : []
          });
        }
      });

      // Sort newest first
      firestoreOrders.sort((a, b) => {
        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : (a.date ? new Date(a.date).getTime() : 0);
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : (b.date ? new Date(b.date).getTime() : 0);
        return timeB - timeA;
      });

      setOrders((currentOrders) => {
        if (JSON.stringify(currentOrders) !== JSON.stringify(firestoreOrders)) {
          return firestoreOrders;
        }
        return currentOrders;
      });
      try {
        localStorage.setItem('dreamhouse_orders', JSON.stringify(firestoreOrders));
      } catch (e) {}

      // Seed local storage fallback if empty and local orders exist
      if (snapshot.empty) {
        const saved = localStorage.getItem('dreamhouse_orders');
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              parsed.forEach((ord: Order) => {
                const orderData = {
                  ...ord,
                  clientId: ord.clientId || ord.clientEmail || userEmail,
                  clientName: ord.clientName || ord.customer || username,
                  clientEmail: ord.clientEmail || userEmail,
                  createdAt: ord.createdAt || new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                };
                setDoc(doc(db, 'orders', ord.id), cleanUndefined(orderData)).catch(() => {});
              });
            }
          } catch (e) {}
        }
      }
    }, (err) => {
      console.warn("Firestore onSnapshot error for orders:", err.message);
      try {
        handleFirestoreError(err, OperationType.LIST, pathForOrders);
      } catch (e) {}
    });

    return () => unsubscribe();
  }, [userEmail, username, currentUid]);

  // Synchronize registered users list across views in real-time
  useEffect(() => {
    const handleSyncEvent = () => {
      const saved = localStorage.getItem('dreamhouse_admin_users');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            setAdminUsers(parsed);
          }
        } catch (e) {
          // ignore
        }
      }
    };
    window.addEventListener('dreamhouse_sync_users', handleSyncEvent);
    return () => {
      window.removeEventListener('dreamhouse_sync_users', handleSyncEvent);
    };
  }, []);

  const handleUpdateUserProfile = async (updatedData: { fullName?: string; phone?: string; avatar?: string }) => {
    if (updatedData.fullName) setUsername(updatedData.fullName);
    if (updatedData.avatar) setUserAvatar(updatedData.avatar);

    const emailToUse = userEmail || '';
    const currentUid = auth.currentUser?.uid;

    // Update Firestore accounts collection
    try {
      const payload: any = { statusLastUpdated: new Date().toLocaleString('en-US') };
      if (updatedData.fullName !== undefined) payload.fullName = updatedData.fullName;
      if (updatedData.phone !== undefined) payload.phone = updatedData.phone;
      if (updatedData.avatar !== undefined) payload.avatar = updatedData.avatar;

      if (currentUid) {
        await setDoc(doc(db, 'accounts', currentUid), payload, { merge: true });
      } else if (emailToUse) {
        const qAcc = query(collection(db, 'accounts'), where('email', '==', emailToUse.toLowerCase()));
        const snap = await getDocs(qAcc);
        if (!snap.empty) {
          const docId = snap.docs[0].id;
          await setDoc(doc(db, 'accounts', docId), payload, { merge: true });
        }
      }
    } catch (e) {
      console.warn("Failed to update profile in Firestore accounts:", e);
    }

    // 1. Update React State for Admin Users (which saves to localStorage in useEffect)
    setAdminUsers(prev => prev.map(u => {
      const matches = (emailToUse && u.email && u.email.toLowerCase() === emailToUse.toLowerCase()) || 
                      (u.fullName && u.fullName.toLowerCase() === username.toLowerCase());
      if (matches) {
        return {
          ...u,
          fullName: updatedData.fullName || u.fullName,
          phone: updatedData.phone || u.phone,
          avatar: updatedData.avatar || u.avatar
        };
      }
      return u;
    }));

    // 2. Update compatibility Accounts List in localStorage
    const savedAccounts = localStorage.getItem('dreamhouse_accounts');
    if (savedAccounts) {
      try {
        const parsed = JSON.parse(savedAccounts);
        if (Array.isArray(parsed)) {
          const updatedAccounts = parsed.map((acc: any) => {
            const matches = (emailToUse && acc.email && acc.email.toLowerCase() === emailToUse.toLowerCase()) ||
                            (acc.username && acc.username.toLowerCase() === username.toLowerCase()) ||
                            (acc.fullName && acc.fullName.toLowerCase() === username.toLowerCase());
            if (matches) {
              return {
                ...acc,
                fullName: updatedData.fullName || acc.fullName,
                phone: updatedData.phone || acc.phone,
                avatar: updatedData.avatar || acc.avatar,
                username: updatedData.fullName || acc.username || acc.fullName
              };
            }
            return acc;
          });
          localStorage.setItem('dreamhouse_accounts', JSON.stringify(updatedAccounts));
        }
      } catch (e) {
        console.error("Error updating dreamhouse_accounts localStorage:", e);
      }
    }

    // 3. Update Experts list if the user is a professional / expert
    const savedExperts = localStorage.getItem('dreamhouse_experts');
    if (savedExperts) {
      try {
        const parsed = JSON.parse(savedExperts);
        if (Array.isArray(parsed)) {
          const updatedExperts = parsed.map((exp: any) => {
            const matches = (emailToUse && exp.contact && exp.contact.toLowerCase() === emailToUse.toLowerCase()) ||
                            (exp.name && exp.name.toLowerCase() === username.toLowerCase());
            if (matches) {
              return {
                ...exp,
                name: updatedData.fullName || exp.name,
                photo: updatedData.avatar || exp.photo
              };
            }
            return exp;
          });
          localStorage.setItem('dreamhouse_experts', JSON.stringify(updatedExperts));
        }
      } catch (e) {
        console.error("Error updating dreamhouse_experts localStorage:", e);
      }
    }



    // Dispatch the custom synchronization event for instant real-time updates across all pages
    setTimeout(() => {
      window.dispatchEvent(new Event('dreamhouse_sync_users'));
    }, 50);
  };

  const cleanUndefined = (obj: any): any => {
    if (obj === null || typeof obj !== 'object') {
      return obj;
    }
    if (Array.isArray(obj)) {
      return obj.map(cleanUndefined);
    }
    const cleaned: any = {};
    for (const key of Object.keys(obj)) {
      const value = obj[key];
      if (value !== undefined) {
        cleaned[key] = cleanUndefined(value);
      }
    }
    return cleaned;
  };

  const handleAddProduct = async (newProduct: Product) => {
    const itemData = {
      ...newProduct,
      ownerId: newProduct.seller?.email || 'shopkeeper@gmail.com',
      itemName: newProduct.name,
      imageUrl: newProduct.image,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    setProducts(prev => {
      const updated = [newProduct, ...prev];
      try {
        localStorage.setItem('dreamhouse_products', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      await setDoc(doc(db, 'products', newProduct.id), cleanUndefined(itemData));
      await setDoc(doc(db, 'items', newProduct.id), cleanUndefined(itemData));
    } catch (e) {
      console.error("Error saving product to Firestore:", e);
    }
  };

  const handleEditProduct = async (updatedProduct: Product) => {
    const itemData = {
      ...updatedProduct,
      ownerId: updatedProduct.seller?.email || 'shopkeeper@gmail.com',
      itemName: updatedProduct.name,
      imageUrl: updatedProduct.image,
      updatedAt: serverTimestamp()
    };

    setProducts(prev => {
      const updated = prev.map(p => p.id === updatedProduct.id ? updatedProduct : p);
      try {
        localStorage.setItem('dreamhouse_products', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      await setDoc(doc(db, 'products', updatedProduct.id), cleanUndefined(itemData), { merge: true });
      await setDoc(doc(db, 'items', updatedProduct.id), cleanUndefined(itemData), { merge: true });
    } catch (e) {
      console.error("Error updating product in Firestore:", e);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    setProducts(prev => {
      const updated = prev.filter(p => p.id !== productId);
      try {
        localStorage.setItem('dreamhouse_products', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      await deleteDoc(doc(db, 'products', productId));
      await deleteDoc(doc(db, 'items', productId));
    } catch (e) {
      console.error("Error deleting product from Firestore:", e);
    }
  };

  // Toast notifications state
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [shopkeeperNotifications, setShopkeeperNotifications] = useState<ToastNotification[]>([]);
  const [highlightedOrderId, setHighlightedOrderId] = useState<string | null>(null);

  // CMS Website Configuration State
  const [websiteConfig, setWebsiteConfig] = useState<WebsiteConfig>(() => {
    const saved = localStorage.getItem('dreamhouse_website_config');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
      } catch (e) {
        // use default
      }
    }
    return DEFAULT_WEBSITE_CONFIG;
  });

  // Real-time Firestore sync for website configuration
  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'website_config', 'main'), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        const mappedConfig: WebsiteConfig = {
          siteName: data.websiteName || data.siteName || 'Dream House',
          logoUrl: data.websiteLogo || data.logoUrl || '',
          loginPageLogo: data.loginPageLogo || data.websiteLogo || data.logoUrl || '',
          footerLogo: data.footerLogo || data.websiteLogo || data.logoUrl || '',
          splashScreenLogo: data.splashScreenLogo || data.websiteLogo || data.logoUrl || '',
          websiteFavicon: data.websiteFavicon || '',
          heroBannerUrl: data.heroBackground || data.heroBannerUrl || '',
          heroBannerImage: data.heroBannerImage || data.heroBackground || data.heroBannerUrl || '',
          heroTitle: data.heroHeading || data.heroTitle || '',
          heroSubtitle: data.heroDescription || data.heroSubtitle || '',
          roleSelectorTitle: data.roleSelectorTitle || 'Select Your Role',
          roleSelectorSubtitle: data.roleSelectorSubtitle || '',
          joinButtonText: data.heroButtonText || data.joinButtonText || 'Join Dream House',
          footerTagline: data.footerContent || data.footerTagline || '',
          copyrightText: data.copyrightText || data.footerContent || '',
          contactEmail: data.contactEmail || '',
          contactPhone: data.contactPhone || '',
          officeAddress: data.contactAddress || data.officeAddress || '',
          socialLinks: {
            facebook: data.socialFacebook || '',
            instagram: data.socialInstagram || '',
            linkedin: data.socialLinkedin || '',
            twitter: data.socialTwitter || '',
            youtube: data.socialYoutube || '',
          }
        };

        // Update Favicon dynamically
        if (mappedConfig.websiteFavicon) {
            let link = document.querySelector<HTMLLinkElement>("link[rel~='icon']");
            if (!link) {
                link = document.createElement('link') as HTMLLinkElement;
                link.rel = 'icon';
                document.head.appendChild(link);
            }
            link.href = mappedConfig.websiteFavicon;
        }
        // Update Title dynamically
        if (mappedConfig.siteName) {
            document.title = mappedConfig.siteName;
        }
                setWebsiteConfig(mappedConfig);
        localStorage.setItem('dreamhouse_website_config', JSON.stringify(mappedConfig));
      }
    });
    return () => unsub();
  }, []);

  // Trigger toasts for the shopkeeper when they switch/log in to their role
  useEffect(() => {
    if (currentRole === 'shopkeeper' && activeView === 'dashboard') {
      const unread = shopkeeperNotifications.filter(n => !n.read);
      if (unread.length > 0) {
        // Add them to active toasts with marked read status
        setToasts(prev => {
          const existingIds = new Set(prev.map(t => t.id));
          const newToasts = unread
            .filter(n => !existingIds.has(n.id))
            .map(n => ({ ...n, read: true }));
          return [...prev, ...newToasts];
        });

        // Mark them as read in our store
        setShopkeeperNotifications(prev =>
          prev.map(n => ({ ...n, read: true }))
        );
      }
    }
  }, [currentRole, activeView, shopkeeperNotifications]);

  const handleToastAction = (toast: ToastNotification) => {
    if (toast.orderId) {
      setHighlightedOrderId(toast.orderId);
      // Ensure the role is shopkeeper and view is dashboard
      if (currentRole !== 'shopkeeper') {
        setCurrentRole('shopkeeper');
      }
      if (activeView !== 'dashboard') {
        triggerTransition('Opening Dashboard', 'dashboard');
      }
      // Remove clicked toast
      setToasts(prev => prev.filter(t => t.id !== toast.id));
    }
  };

  // Cinematic loading animation triggers
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [transitionLabel, setTransitionLabel] = useState<string>('Initializing Blueprint');

  // Trigger temporary transition screens
  const triggerTransition = (label: string, nextView: typeof activeView, callback?: () => void) => {
    setTransitionLabel(label);
    setIsTransitioning(true);

    setTimeout(() => {
      setActiveView(nextView);
      if (callback) callback();
      setIsTransitioning(false);
    }, 1500);
  };

  // Auth Submit Handlers
  const handleLoginSuccess = (role: UserRole, user: string, email?: string, avatar?: string) => {
    setCurrentRole(role);
    localStorage.setItem('dreamhouse_active_role', role);
    setUsername(user);

    // Resolve email address
    let resolvedEmail = email || '';
    if (!resolvedEmail) {
      if (user.includes('@')) {
        resolvedEmail = user;
      } else {
        // Try searching in adminUsers or localStorage
        const matchedUser = adminUsers.find(u => u.fullName && u.fullName.toLowerCase() === user.toLowerCase());
        if (matchedUser && matchedUser.email) {
          resolvedEmail = matchedUser.email;
        } else {
          // Check static demo users
          if (user.toLowerCase() === 'alex') {
            resolvedEmail = 'alex.homeowner@gmail.com';
          } else if (user.toLowerCase() === 'kishor') {
            resolvedEmail = 'kishor@dreamhouse.com';
          } else if (user.toLowerCase() === 'architect jenkins') {
            resolvedEmail = 'jenkins@architects.com';
          } else if (user.toLowerCase() === 'arthur pendleton') {
            resolvedEmail = 'supplier@probuild.com';
          }
        }
      }
    }

    if (resolvedEmail) {
      setUserEmail(resolvedEmail);
      localStorage.setItem('dreamhouse_current_user_email', resolvedEmail);
    }

    // Look up avatar from direct arg, registered accounts, or default accounts list
    let foundAvatar = avatar || '';
    
    if (!foundAvatar && resolvedEmail) {
      const matchedAdminUser = adminUsers.find(u => u.email && u.email.toLowerCase() === resolvedEmail.toLowerCase());
      if (matchedAdminUser && matchedAdminUser.avatar) {
        foundAvatar = matchedAdminUser.avatar;
      }
    }
    
    if (!foundAvatar) {
      const saved = localStorage.getItem('dreamhouse_accounts');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const match = parsed.find((acc: any) => acc && (
              (acc.username && acc.username.toLowerCase() === user.toLowerCase()) ||
              (acc.email && acc.email.toLowerCase() === resolvedEmail.toLowerCase())
            ));
            if (match && match.avatar) {
              foundAvatar = match.avatar;
            }
          }
        } catch (e) {
          // ignore
        }
      }
    }

    // Set matching or default avatar
    setUserAvatar(foundAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80');

    const label = `Authenticating ${user} as ${role.toUpperCase()}`;
    
    // Auto-route based on logged-in role - directly to dashboard as per user requirement
    triggerTransition(label, 'dashboard');
  };

  const handleSelectRole = (role: UserRole) => {
    setCurrentRole(role);
    const label = `Mounting ${role.toUpperCase()} Workspace Environment`;
    triggerTransition(label, 'dashboard');
  };

  const handleLogout = async () => {
    triggerTransition('Securing Credentials & Exiting', 'auth', async () => {
      try {
        await auth.signOut();
      } catch (e) {
        console.warn("Notice signing out of Firebase Auth:", e);
      }
      setUserEmail('');
      setUsername('');
      setUserAvatar('https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80');
      setCartItems([]);
      setSavedItems([]);
      setRecentCompletedOrder(null);
      sessionStorage.clear();
      localStorage.removeItem('dreamhouse_current_user_email');
      localStorage.removeItem('dreamhouse_cart');
      localStorage.removeItem('dreamhouse_saved_items');
      localStorage.removeItem('dreamhouse_orders');
      localStorage.removeItem('dreamhouse_messages');
      localStorage.removeItem('dreamhouse_2d_projects');
      localStorage.removeItem('dreamhouse_2d_current_plan');
      localStorage.removeItem('dreamhouse_checkout_shop');
      localStorage.removeItem('dreamhouse_announcement_cache');
      localStorage.removeItem('dreamhouse_unread_announcements_count');
      localStorage.removeItem('dreamhouse_user_session_cache');
    });
  };

  // Toast Helper
  const handleToast = (message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const toast: ToastNotification = {
      id: `toast-${Math.random().toString(36).substr(2, 9)}`,
      title: type === 'success' ? 'Success' : type === 'warning' ? 'Alert' : 'Notice',
      message,
      type,
      timestamp: Date.now(),
      roleScope: 'homeowner'
    };
    setToasts(prev => [...prev, toast]);
  };

  // Cart Interactions with Real-Time Firebase Sync
  const handleAddToCart = (product: Product) => {
    const existing = cartItems.find((item) => item.id === product.id);
    let nextItems: CartItem[];
    if (existing) {
      nextItems = cartItems.map((item) =>
        item.id === product.id ? { ...item, qty: item.qty + 1 } : item
      );
    } else {
      nextItems = [
        ...cartItems,
        {
          id: product.id,
          name: product.name,
          category: product.category,
          price: product.price,
          originalPrice: product.originalPrice,
          qty: 1,
          image: product.image,
          freeDelivery: product.freeDelivery,
          seller: product.seller || {
            name: 'Demo Shopkeeper',
            shopName: 'ProBuild Materials Inc.',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            email: 'shopkeeper@gmail.com',
            isVerified: true
          },
          unit: product.unit || 'Piece',
          allowedUnits: product.allowedUnits || [],
          unitPrices: product.unitPrices || {},
          unitStocks: product.unitStocks || {}
        }
      ];
    }
    setCartItems(nextItems);
    if (cartKey) {
      syncCartToFirebase(nextItems, savedItems);
    }
  };

  const handleRemoveFromCart = (id: string) => {
    const nextItems = cartItems.filter((item) => item.id !== id);
    setCartItems(nextItems);
    if (cartKey) {
      syncCartToFirebase(nextItems, savedItems);
    }
  };

  const handleUpdateQty = (id: string, qty: number, unit?: string) => {
    if (qty <= 0) {
      handleRemoveFromCart(id);
      return;
    }
    const nextItems = cartItems.map((item) => {
      if (item.id === id) {
        const updatedItem = { ...item, qty };
        if (unit !== undefined) {
          updatedItem.unit = unit;
          const matchedProduct = products.find(p => p.id === id);
          if (matchedProduct) {
            const customPrice = matchedProduct.unitPrices?.[unit] !== undefined
              ? matchedProduct.unitPrices[unit]
              : matchedProduct.price;
            updatedItem.price = customPrice;
          } else {
            const customPrice = item.unitPrices?.[unit] !== undefined
              ? item.unitPrices[unit]
              : item.price;
            updatedItem.price = customPrice;
          }
        }
        return updatedItem;
      }
      return item;
    });
    setCartItems(nextItems);
    if (cartKey) {
      syncCartToFirebase(nextItems, savedItems);
    }
  };

  const handleClearCart = () => {
    setCartItems([]);
    if (cartKey) {
      syncCartToFirebase([], savedItems);
    }
  };

  const handleSaveForLater = (item: CartItem) => {
    const nextItems = cartItems.filter((i) => i.id !== item.id);
    const alreadySaved = savedItems.find((s) => s.id === item.id);
    const nextSaved = alreadySaved ? savedItems : [...savedItems, item];
    
    setCartItems(nextItems);
    setSavedItems(nextSaved);
    if (cartKey) {
      syncCartToFirebase(nextItems, nextSaved);
    }
    handleToast(`Saved ${item.name} for later`, 'info');
  };

  const handleMoveToCart = (item: CartItem) => {
    const nextSaved = savedItems.filter((i) => i.id !== item.id);
    const existing = cartItems.find((i) => i.id === item.id);
    let nextItems: CartItem[];
    if (existing) {
      nextItems = cartItems.map((i) => i.id === item.id ? { ...i, qty: i.qty + 1 } : i);
    } else {
      nextItems = [...cartItems, item];
    }

    setCartItems(nextItems);
    setSavedItems(nextSaved);
    if (cartKey) {
      syncCartToFirebase(nextItems, nextSaved);
    }
    handleToast(`Moved ${item.name} to cart`, 'success');
  };

  const handleRemoveSavedItem = (id: string) => {
    const nextSaved = savedItems.filter((i) => i.id !== id);
    setSavedItems(nextSaved);
    if (cartKey) {
      syncCartToFirebase(cartItems, nextSaved);
    }
  };

  // Modern Checkout Flow Integration
  const handlePlaceOrder = async (orderPayload: Omit<Order, 'id'> & { id?: string }, paymentDetails: any) => {
    const orderId = orderPayload.id || `#ORD-${Math.floor(Math.random() * 8900) + 1000}`;
    const fullOrder: Order = {
      ...orderPayload,
      id: orderId
    };

    // 1. Permanently store complete order details to Firebase
    try {
      await setDoc(doc(db, 'orders', orderId), cleanUndefined(fullOrder));

      // Deduct stock for items in Firestore
      for (const item of fullOrder.items || []) {
        const prod = products.find(p => p.id === item.productId);
        if (prod && prod.availableQuantity !== undefined) {
          const newQty = Math.max(0, prod.availableQuantity - item.quantity);
          await updateDoc(doc(db, 'products', item.productId), {
            availableQuantity: newQty,
            updatedAt: serverTimestamp()
          }).catch(() => {});
        }
      }
    } catch (error: any) {
      console.error("Error saving order to Firebase:", error);
      try {
        handleFirestoreError(error, OperationType.WRITE, `orders/${orderId}`);
      } catch (e) {}
      throw error;
    }

    // 2. Clear only checked-out items from the cart & update local fallback
    const checkedOutProductIds = new Set(fullOrder.items?.map(i => i.productId) || []);
    const remainingCartItems = cartItems.filter(item => !checkedOutProductIds.has(item.id));
    setCartItems(remainingCartItems);
    if (cartKey) {
      await syncCartToFirebase(remainingCartItems, savedItems);
    }
    setOrders(prev => [fullOrder, ...prev.filter(o => o.id !== orderId)]);

    // 3. Instantly trigger a success toast for the Homeowner
    const homeownerToast: ToastNotification = {
      id: `ho-${Math.random().toString(36).substr(2, 9)}`,
      title: 'Order Placed Successfully!',
      message: `Your material order ${orderId} total of Rs. ${fullOrder.totalPrice?.toFixed(2)} has been saved to Firebase.`,
      type: 'success',
      timestamp: Date.now(),
      roleScope: 'homeowner'
    };
    setToasts(prev => [...prev, homeownerToast]);

    // 4. Queue a notification for the Shopkeeper
    const shopkeeperNotification: ToastNotification = {
      id: `sk-${Math.random().toString(36).substr(2, 9)}`,
      title: 'New Material Order!',
      message: `Client ${username} checked out order ${orderId} (Rs. ${fullOrder.totalPrice?.toFixed(2)}).`,
      type: 'info',
      timestamp: Date.now(),
      read: false,
      orderId: orderId,
      roleScope: 'shopkeeper'
    };
    setShopkeeperNotifications(prev => [...prev, shopkeeperNotification]);

    if (currentRole === 'shopkeeper') {
      setToasts(prev => [...prev, { ...shopkeeperNotification, read: true }]);
    }

    // Set the recent order so the Success page can display it
    setRecentCompletedOrder(fullOrder);
    triggerTransition('Processing Secure Gateway Confirmation', 'order-success');

    return orderId;
  };

  const handleCancelOrder = async (
    orderId: string, 
    reason: string = 'Requested by client', 
    cancelledBy: 'Client' | 'Seller' | 'Admin' | 'Customer' = 'Customer'
  ) => {
    try {
      const orderRef = doc(db, 'orders', orderId);
      const orderSnap = await getDoc(orderRef);
      if (orderSnap.exists()) {
        const orderData = orderSnap.data();
        const isOnlinePayment = orderData.paymentMethod !== 'Cash on Delivery' && orderData.paymentMethod !== 'COD';
        const refundStatusVal = isOnlinePayment ? 'Refund Initiated' : undefined;
        const refundEstVal = isOnlinePayment ? '3-5 Business Days' : undefined;

        // 1. Update order document immediately in Firebase
        await updateDoc(orderRef, {
          status: 'Cancelled',
          cancelledAt: new Date().toISOString(),
          cancelledBy: cancelledBy,
          cancellationReason: reason,
          refundStatus: refundStatusVal,
          refundEstimatedTime: refundEstVal,
          updatedAt: new Date().toISOString()
        });

        // 2. Restore stock immediately back to seller's inventory
        if (orderData.items && Array.isArray(orderData.items)) {
          for (const item of orderData.items) {
            const prod = products.find(p => p.id === item.productId);
            if (prod && prod.availableQuantity !== undefined) {
              const newQty = prod.availableQuantity + item.quantity;
              await updateDoc(doc(db, 'products', item.productId), {
                availableQuantity: newQty,
                updatedAt: serverTimestamp()
              }).catch((e) => console.error("Stock restore error:", e));
            }
          }
        }

        // 3. Create persistent real-time notifications in Firebase
        const notifTime = new Date().toLocaleString();
        
        // Customer Notification
        await setDoc(doc(db, 'notifications', `notif_cust_${Date.now()}_${Math.floor(Math.random() * 1000)}`), {
          id: `notif_cust_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          title: 'Order Cancelled Successfully',
          body: `✅ Your order (${orderId}) has been cancelled successfully.`,
          type: 'Success',
          targetRole: 'homeowner',
          timestamp: notifTime
        });

        // Seller Notification
        await setDoc(doc(db, 'notifications', `notif_sell_${Date.now()}_${Math.floor(Math.random() * 1000)}`), {
          id: `notif_sell_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          title: 'Order Cancelled by Customer',
          body: `⚠ Order ${orderId} has been cancelled by the customer.`,
          type: 'Warning',
          targetRole: 'shopkeeper',
          timestamp: notifTime
        });

        // Admin Notification
        await setDoc(doc(db, 'notifications', `notif_admin_${Date.now()}_${Math.floor(Math.random() * 1000)}`), {
          id: `notif_admin_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          title: 'Customer Cancelled Order',
          body: `⚠ Customer cancelled Order ${orderId}.`,
          type: 'Warning',
          targetRole: 'admin',
          timestamp: notifTime
        });

        // 4. Dispatch instant success toast notifications to UI
        const homeownerToast: ToastNotification = {
          id: `ho-cancel-${Math.random().toString(36).substr(2, 9)}`,
          title: '✅ Order cancelled successfully.',
          message: 'Your order has been moved to the Cancelled Orders section.',
          type: 'success',
          timestamp: Date.now(),
          roleScope: 'homeowner'
        };
        setToasts(prev => [...prev, homeownerToast]);

        const sellerToast: ToastNotification = {
          id: `sk-cancel-${Math.random().toString(36).substr(2, 9)}`,
          title: 'Order Cancelled',
          message: `⚠ Order ${orderId} has been cancelled by the customer.`,
          type: 'warning',
          timestamp: Date.now(),
          read: false,
          orderId: orderId,
          roleScope: 'shopkeeper'
        };
        setShopkeeperNotifications(prev => [...prev, sellerToast]);

        if (currentRole === 'shopkeeper') {
          setToasts(prev => [...prev, { ...sellerToast, read: true }]);
        }

        // 5. Handle online payment refund flow notifications
        if (isOnlinePayment) {
          const refundInitNotif: ToastNotification = {
            id: `ho-refund-init-${Math.random().toString(36).substr(2, 9)}`,
            title: 'Refund Initiated',
            message: `A refund of Rs. ${(orderData.totalPrice ?? orderData.amount ?? 0).toFixed(2)} has been initiated for cancelled order ${orderId}.`,
            type: 'info',
            timestamp: Date.now(),
            roleScope: 'homeowner'
          };
          setToasts(prev => [...prev, refundInitNotif]);

          // Notify completed refund after a small delay
          setTimeout(async () => {
            const refundCompNotif: ToastNotification = {
              id: `ho-refund-comp-${Math.random().toString(36).substr(2, 9)}`,
              title: 'Refund Completed',
              message: `Refund of Rs. ${(orderData.totalPrice ?? orderData.amount ?? 0).toFixed(2)} for order ${orderId} is now Completed and credited back to your payment method.`,
              type: 'success',
              timestamp: Date.now(),
              roleScope: 'homeowner'
            };
            setToasts(prev => [...prev, refundCompNotif]);
            
            try {
              await updateDoc(orderRef, {
                refundStatus: 'Refunded',
                updatedAt: new Date().toISOString()
              });
            } catch (e) {
              console.error("Refund update error:", e);
            }
          }, 5000);
        }
      } else {
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'Cancelled' as const } : o));
      }
    } catch (err: any) {
      console.error("Complete Firebase order cancellation error:", err);
      try {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      } catch (e) {}
      throw err; // Re-throw so caller modal remains open and displays the error message
    }
  };

  const handleCheckout = async () => {
    // Legacy checkout fallback redirects to full screen cart
    setActiveView('cart');
  };

  const handleShipOrder = async (id: string) => {
    try {
      await updateDoc(doc(db, 'orders', id), {
        status: 'Shipped',
        updatedAt: new Date().toISOString()
      });
    } catch (err: any) {
      console.warn("Could not update order status in Firebase:", err);
      try {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${id}`);
      } catch (e) {}
      setOrders(prev => prev.map(o => (o.id === id ? { ...o, status: 'Shipped' as const } : o)));
    }
  };

  // Render view router
  const renderActiveView = () => {
    switch (activeView) {
      case 'auth':
        return (
          <AuthScreen
            websiteConfig={websiteConfig}
            onLoginSuccess={handleLoginSuccess}
            onRegisterAdminUser={(newAdminUser) => {
              setAdminUsers(prev => [...prev, newAdminUser]);
            }}
          />
        );

      case 'roles':
        return (
          <RoleSelector
            websiteConfig={websiteConfig}
            onSelectRole={handleSelectRole}
            onBackToAuth={() => triggerTransition('Logging Out Workspace', 'auth')}
          />
        );

      case 'dashboard':
        if (currentRole === 'admin') {
          return (
            <AdminDashboard
              users={adminUsers}
              setUsers={setAdminUsers}
              websiteConfig={websiteConfig}
              onUpdateWebsiteConfig={async (newConfig) => {
                setWebsiteConfig(newConfig);
                localStorage.setItem('dreamhouse_website_config', JSON.stringify(newConfig));
                try {
                  await setDoc(doc(db, 'website_config', 'main'), {
                    websiteName: newConfig.siteName,
                    websiteLogo: newConfig.logoUrl,
                    heroHeading: newConfig.heroTitle,
                    heroDescription: newConfig.heroSubtitle,
                    heroButtonText: newConfig.joinButtonText,
                    siteName: newConfig.siteName,
                    logoUrl: newConfig.logoUrl,
                    heroBannerUrl: newConfig.heroBannerUrl,
                    heroTitle: newConfig.heroTitle,
                    heroSubtitle: newConfig.heroSubtitle,
                    joinButtonText: newConfig.joinButtonText
                  }, { merge: true });
                } catch (e) {
                  console.error("Error updating website config in Firestore:", e);
                }
              }}
              onLogout={handleLogout}
            />
          );
        }
        const activeUserEmail = (userEmail || auth.currentUser?.email || '').toLowerCase().trim();
        const currentUserDetails = adminUsers.find(u => u.email && u.email.toLowerCase() === activeUserEmail) || 
                             adminUsers.find(u => u.fullName && u.fullName.toLowerCase() === username.toLowerCase());

        if (currentRole === 'professional') {
          return (
            <ProfessionalDashboard
              username={username}
              userAvatar={userAvatar}
              userEmail={userEmail || currentUserDetails?.email || auth.currentUser?.email || ''}
              userPhone={currentUserDetails?.phone}
              registrationDate={currentUserDetails?.registrationDateTime || currentUserDetails?.registrationDate}
              onLogout={handleLogout}
              onUpdateAvatar={(newAvatar) => handleUpdateUserProfile({ avatar: newAvatar })}
              onUpdateProfile={handleUpdateUserProfile}
            />
          );
        }
        if (currentRole === 'shopkeeper') {
          return (
            <ShopkeeperDashboard
              username={username}
              userAvatar={userAvatar}
              userEmail={userEmail || currentUserDetails?.email || auth.currentUser?.email || ''}
              userPhone={currentUserDetails?.phone}
              registrationDate={currentUserDetails?.registrationDateTime || currentUserDetails?.registrationDate}
              products={products}
              onAddProduct={handleAddProduct}
              onEditProduct={handleEditProduct}
              onDeleteProduct={handleDeleteProduct}
              orders={orders}
              onShipOrder={handleShipOrder}
              onLogout={handleLogout}
              highlightedOrderId={highlightedOrderId}
              onClearHighlight={() => setHighlightedOrderId(null)}
              onUpdateAvatar={(newAvatar) => handleUpdateUserProfile({ avatar: newAvatar })}
              onUpdateProfile={handleUpdateUserProfile}
            />
          );
        }
        // Fallback to Homeowner/Client Dashboard
        return (
          <UserDashboard
            users={adminUsers}
            username={username}
            userAvatar={userAvatar}
            orders={orders}
            websiteConfig={websiteConfig}
            cartCount={cartItems.length}
            products={products}
            onAddToCart={handleAddToCart}
            userEmail={currentUserDetails?.email || userEmail || auth.currentUser?.email || ''}
            userPhone={currentUserDetails?.phone}
            registrationDate={currentUserDetails?.registrationDateTime || currentUserDetails?.registrationDate}
            accountStatus={currentUserDetails?.status}
            emailVerified={currentUserDetails?.emailVerified}
            onUpdateProfile={handleUpdateUserProfile}
            onCancelOrder={handleCancelOrder}
            onNavigateToTab={(tab) => {
              if (tab === 'floor_plans') {
                triggerTransition('Loading 2D/3D Floor Plan CAD', 'floor_plans');
              } else if (tab === 'shop') {
                triggerTransition('Accessing Heavy Building Materials Shop', 'shop');
              } else if (tab === 'cart') {
                triggerTransition('Accessing Project Cart', 'cart');
              } else if (tab === 'shopkeepers') {
                triggerTransition('Accessing Shopkeeper Directory', 'shopkeepers');
              } else if (tab === 'experts') {
                triggerTransition('Accessing Expert Directory', 'experts');
              } else if (tab === 'roles') {
                triggerTransition('Accessing Roles Selector', 'roles');
              } else if (tab === 'auth') {
                handleLogout();
              }
            }}
            onLogout={handleLogout}
          />
        );

      case 'floor_plans':
        return (
          <FloorPlanBuilder
            onBackToDashboard={() => triggerTransition('Closing Drafting Workbench', 'dashboard')}
          />
        );

      case 'shop':
        return (
          <MaterialShop
            products={products}
            cartItems={cartItems}
            onAddToCart={handleAddToCart}
            onRemoveFromCart={handleRemoveFromCart}
            onUpdateQty={handleUpdateQty}
            onClearCart={handleClearCart}
            onCheckout={handleCheckout}
            onNavigateToCart={() => triggerTransition('Accessing Project Cart', 'cart')}
            onBackToDashboard={() => triggerTransition('Returning to Homeowner workspace', 'dashboard')}
          />
        );

      case 'cart':
        return (
          <ShoppingCartPage
            cartItems={cartItems}
            savedItems={savedItems}
            products={products}
            onUpdateQty={handleUpdateQty}
            onRemoveFromCart={handleRemoveFromCart}
            onClearCart={handleClearCart}
            onSaveForLater={handleSaveForLater}
            onMoveToCart={handleMoveToCart}
            onRemoveSavedItem={handleRemoveSavedItem}
            onProceedToCheckout={() => triggerTransition('Proceeding to Secure Checkout', 'checkout')}
            onBackToShop={() => triggerTransition('Returning to Marketplace', 'shop')}
            userAddress={userAddress}
            onChangeAddress={setUserAddress}
          />
        );

      case 'checkout':
        return (
          <CheckoutPage
            cartItems={cartItems}
            products={products}
            username={username || 'Alex'}
            userEmail={userEmail || 'alex@example.com'}
            userAddress={userAddress}
            onUpdateQty={handleUpdateQty}
            onRemoveFromCart={handleRemoveFromCart}
            onPlaceOrder={handlePlaceOrder}
            onBackToCart={() => triggerTransition('Returning to Project Cart', 'cart')}
          />
        );

      case 'order-success':
        return (
          <OrderSuccessPage
            orderId={recentCompletedOrder?.id || '#ORD-9912'}
            transactionId={recentCompletedOrder?.id ? `TXN-${recentCompletedOrder.id.replace('#ORD-', '')}` : 'TXN-8742910'}
            paymentMethod="Secure Escrow Payment Gateway"
            amount={recentCompletedOrder?.totalPrice || 0}
            shippingAddress={recentCompletedOrder?.shippingAddress || userAddress}
            onNavigateToTab={(tab) => triggerTransition('Accessing Project Portal', tab)}
            onContinueShopping={() => triggerTransition('Returning to Marketplace', 'shop')}
          />
        );

      case 'shopkeepers':
        return (
          <ShopkeepersView 
            shopkeepers={adminUsers.filter(u => u.accountType === 'Shopkeeper')}
            presenceMap={presenceMap}
          />
        );

      default:
        return <div>Unknown active view state.</div>;
    }
  };

  return (
    <>
      {isTransitioning && (
        <LoadingScreen label={transitionLabel} websiteConfig={websiteConfig} />
      )}
      <div className="w-full h-full">
        {renderActiveView()}
      </div>
      {activeView === 'auth' && (
        <button
          onClick={toggleTheme}
          className="fixed top-6 right-6 z-50 p-3.5 bg-white dark:bg-slate-800 text-slate-800 dark:text-amber-400 rounded-full shadow-lg border border-slate-200 dark:border-slate-700 hover:scale-110 active:scale-95 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#fd8b00]/50 cursor-pointer"
          aria-label="Toggle theme"
          title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
        >
          {theme === 'light' ? (
            <Moon className="w-6 h-6 text-slate-700" />
          ) : (
            <Sun className="w-6 h-6 text-amber-400" />
          )}
        </button>
      )}

      <ToastContainer
        toasts={toasts}
        onCloseToast={(id) => setToasts(prev => prev.filter(t => t.id !== id))}
        onActionClick={handleToastAction}
      />
    </>
  );
}
