const res = await fetch('http://localhost:3000/api/admin/reset-user-password', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'kishor425147@gmail.com', newPassword: 'password123', name: 'kishor', uid: 'acc-1' })
});
console.log(res.status, await res.text());
