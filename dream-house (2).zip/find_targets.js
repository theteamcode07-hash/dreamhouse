import fs from 'fs';
import path from 'path';

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      results.push(file);
    }
  });
  return results;
}

const files = walk('./src');

files.forEach(f => {
  const content = fs.readFileSync(f, 'utf8');
  const lines = content.split('\n');
  const fileDollarMatches = [];
  const fileGrowthMatches = [];

  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) return;

    // Check for growth percentages like +14%, -5%, +12.5%, % growth, vs yesterday, TrendingUp, TrendingDown
    if (
      /(\+|\-)\d+(\.\d+)?%/.test(line) || 
      /%\s*(vs|growth|increase|decrease|up|down)/i.test(line) ||
      /\bvs\s+(yesterday|last|prev)/i.test(line) ||
      /TrendingUp|TrendingDown|ArrowUpRight|ArrowDownRight/.test(line)
    ) {
      fileGrowthMatches.push(`Line ${idx + 1}: ${trimmed}`);
    }

    // Check for dollar sign in UI strings or templates
    if (line.includes('$')) {
      if (
        /\$\d/.test(line) || 
        /\$\s*\d/.test(line) || 
        /\$\$\{/.test(line) || 
        /`\$|"|\'\$/.test(line) ||
        /Price|Total|Fee|Amount|Revenue|Earnings|Cost|Budget/i.test(line)
      ) {
        fileDollarMatches.push(`Line ${idx + 1}: ${trimmed}`);
      }
    }
  });

  if (fileDollarMatches.length > 0 || fileGrowthMatches.length > 0) {
    console.log(`\n================ ${f} ================`);
    if (fileDollarMatches.length > 0) {
      console.log(`--- DOLLAR MATCHES (${fileDollarMatches.length}) ---`);
      fileDollarMatches.forEach(m => console.log(m));
    }
    if (fileGrowthMatches.length > 0) {
      console.log(`--- GROWTH MATCHES (${fileGrowthMatches.length}) ---`);
      fileGrowthMatches.forEach(m => console.log(m));
    }
  }
});
