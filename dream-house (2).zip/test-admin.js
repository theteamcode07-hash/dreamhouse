import { initializeApp, getApps } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import fs from "fs";

process.env.GOOGLE_CLOUD_QUOTA_PROJECT = "dreamhouse-b649d";

const config = JSON.parse(fs.readFileSync("./firebase-applet-config.json"));

if (!getApps().length) {
  initializeApp({
    projectId: config.projectId
  });
}

async function test() {
  try {
    const users = await getAuth().listUsers(1);
    console.log("Success:", users.users.length);
  } catch (e) {
    console.error("Error:", e.message);
  }
}
test();
