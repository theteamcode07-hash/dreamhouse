import fs from 'fs';
let code = fs.readFileSync('src/components/AdminDashboard.tsx', 'utf8');

// Add error state
code = code.replace(
  "const [confirmNewPassword, setConfirmNewPassword] = useState('');",
  "const [confirmNewPassword, setConfirmNewPassword] = useState('');\n  const [resetError, setResetError] = useState<string | null>(null);\n  const [isResettingPass, setIsResettingPass] = useState(false);"
);

// Clear error on open
code = code.replace(
  "setShowResetModalPass(false);\n  };",
  "setShowResetModalPass(false);\n    setResetError(null);\n  };"
);

// Update submit handler
const oldSubmit = `  const handleConfirmPasswordReset = async () => {
    if (!passwordResetModal) return;
    
    if (!newPassword || newPassword.trim().length < 8) {
      alert("Password must be at least 8 characters long.");
      return;
    }
    
    if (newPassword !== confirmNewPassword) {
      alert("Passwords do not match.");
      return;
    }`;

const newSubmit = `  const handleConfirmPasswordReset = async () => {
    if (!passwordResetModal) return;
    setResetError(null);
    
    if (!newPassword || newPassword.trim().length < 8) {
      setResetError("Password must be at least 8 characters long.");
      return;
    }
    
    if (newPassword !== confirmNewPassword) {
      setResetError("Passwords do not match.");
      return;
    }
    
    setIsResettingPass(true);`;

code = code.replace(oldSubmit, newSubmit);

// Update success/catch
const oldCatch = `      alert("Password updated successfully.");
      setPasswordResetModal(null);
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (error: any) {
      console.error("Firebase Password Reset Error:", error);
      alert(\`Failed to reset password: \${error.message}\`);
    }
  };`;

const newCatch = `      alert("Password updated successfully.");
      setPasswordResetModal(null);
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (error: any) {
      console.error("Firebase Password Reset Error:", error);
      setResetError(\`Failed to reset password: \${error.message}\`);
    } finally {
      setIsResettingPass(false);
    }
  };`;

code = code.replace(oldCatch, newCatch);

// Update UI
const oldUI = `            <div className="relative mb-4">
              <input
                type={showResetModalPass ? "text" : "password"}
                className="w-full p-2.5 border border-gray-300 rounded pr-10 text-sm text-[#041627] outline-none focus:border-[#fd8b00]"
                placeholder="Confirm New Password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
              />
            </div>
            <div className="flex gap-3">`;

const newUI = `            <div className="relative mb-4">
              <input
                type={showResetModalPass ? "text" : "password"}
                className="w-full p-2.5 border border-gray-300 rounded pr-10 text-sm text-[#041627] outline-none focus:border-[#fd8b00]"
                placeholder="Confirm New Password"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
              />
            </div>
            {resetError && (
              <div className="mb-4 p-3 bg-red-50 text-red-600 border border-red-100 rounded text-xs text-left max-h-32 overflow-y-auto">
                {resetError}
              </div>
            )}
            <div className="flex gap-3">`;
            
code = code.replace(oldUI, newUI);

code = code.replace(
  `                className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded text-xs font-semibold transition-all shadow-md hover:shadow-lg cursor-pointer"\n              >\n                Reset Password`,
  `                disabled={isResettingPass}
                className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded text-xs font-semibold transition-all shadow-md hover:shadow-lg cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"\n              >\n                {isResettingPass ? '... ' : ''}Reset Password`
);

fs.writeFileSync('src/components/AdminDashboard.tsx', code);
